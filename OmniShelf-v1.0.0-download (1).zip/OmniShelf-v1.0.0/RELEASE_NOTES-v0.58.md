# OmniShelf v0.58 — Release Notes

## Headline
IGDB becomes a deep, first-class game provider in the OmniShelf canonical provider architecture.

## What changed

### Provider integration
- Added `lib/igdb.js` with server-side IGDB v4 access.
- Added Twitch client-credentials token acquisition and explicit application-token mode.
- Added safe in-memory token handling with refresh after a first 401 in client-credential mode.
- Added bounded caching, serialized request pacing and bounded 429 handling.

### Games
- Game search with pagination and bounded limits.
- Game discovery with platform, genre, theme and release-year filters.
- Rich game details covering releases, platforms, companies, genres/themes, modes, perspectives, collections, franchises, localizations, external IDs, age ratings, engines, websites, videos and visual assets.
- Canonical mapping to OmniShelf `Game`.

### Entities
- Persistent IGDB company registry.
- Persistent platform registry.
- Persistent collection registry.
- Persistent franchise registry.
- Entity enrichment journal and Review Queue diagnostics.

### Identity / quality
- Exact IGDB ID matching.
- Alternate/localized title evidence.
- Release-year/type/title similarity evidence.
- Exact provider identity takes precedence over secondary evidence.
- Provider-specific quality scoring and completeness diagnostics.

### Canonical enrichment
- Preview-first IGDB enrichment.
- Existing manual canonical fields are retained.
- Provider metadata and raw game snapshots are preserved.
- Explicit IGDB IDs are required when enriching canonical records whose primary provider is another provider, preventing numeric-ID collisions.
- Review Queue approval also persists IGDB entity relationships.

### UI
- Added first-class IGDB Provider Hub workspace.
- Search, discovery, detail inspection, quality analysis, queue-to-review, entity registry, enrichment and acceptance controls are available from the served application.
- Demo workspace remains usable without credentials.

### Continuity
- Updated `CURRENT_STATE.md` to v0.58.
- Added this release to the cumulative `PROJECT_HISTORY.md`.
- Updated archive/continuity index and current-state documentation.
- Preserved all historical AniList, Open Library, TMDB, Catalog, Community, Collections, Smart Collections, Bulk Ops, Data Hub, Sync and previous continuity material.

## Validation

`npm run igdb:selftest` is the deterministic offline suite.

`npm run igdb:acceptance -- --plan` prints the live read-acceptance plan.

Live acceptance is not marked passed in the offline build environment when the required external credentials/network are unavailable.

## Not claimed

- IGDB write mutations are not implemented.
- Cross-provider identity/reconciliation remains v0.59.
- Possession of credentials is not treated as authorization for public/commercial use.
- Remote provider artwork is not bulk-copied into the local datastore.
