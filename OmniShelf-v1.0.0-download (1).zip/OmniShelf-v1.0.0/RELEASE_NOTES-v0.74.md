# OmniShelf v0.74 — Recommendations 2.0

## Summary
v0.74 adds a read-only recommendation engine over the personal library, durable history, smart collections, statistics, and canonical catalog.

## Recommendation model
- Strong personal signals: favorites, personal scores, completion, active/re-experiencing status, medium preferences, themes/tags, creators, provider affinity, and release-period affinity.
- Catalog signals: canonical metadata, explicit relations, available provider ratings, and popularity signals.
- Library items are excluded from recommendation candidates; dropped works are not surfaced as positive recommendations.
- Every recommendation carries up to three human-readable reasons.
- Results support auto/personalized/discovery/balanced modes, medium filtering, provider-quality thresholding, and result limits.
- Ranking is local and deterministic from the current dataset; no external recommendation API is required.

## API
- `GET /api/recommendations`
- `POST /api/recommendations/selftest`

## UI
A new top-level Recommendations page provides profile strength, candidate/result KPIs, filtering, explainable recommendation cards, inspect/add actions, and an explanation of ranking inputs.

## Validation
The recommendation self-test and HTTP E2E must pass alongside the inherited OmniShelf regression matrix.
