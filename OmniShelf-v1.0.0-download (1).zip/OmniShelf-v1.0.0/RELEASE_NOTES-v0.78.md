# OmniShelf v0.78 — Full Medium-by-Medium Personal Experiences

v0.78 turns the shared personal library into a genuinely medium-aware experience without fragmenting the underlying data model.

## What changed
- Added a single registry for all 18 canonical personal-media types.
- Tailored activity verbs, progress nouns, primary/alternate units, start/resume/finish language and status labels per medium.
- Added unit-aware known totals for media where provider metadata supplies a matching total.
- Added personal medium directory/cards and detailed medium lenses inside My Library.
- Added tailored personal experience data to Work Pages.
- Updated the unified workflow to use medium-appropriate actions and language.
- Added deterministic and disposable HTTP validation.

## Data model
No new personal catalog, library, history or statistics database was introduced. Existing `data.library.items` records remain the source of truth.

## Provider boundary
v0.78 does not make live provider requests for personal experiences. AniList live authorization/acceptance remains independent.

## Validation
24/24 deterministic suites and 8/8 HTTP E2E suites passed; see `BUILD_VALIDATION-v0.78.md` for the full matrix.
