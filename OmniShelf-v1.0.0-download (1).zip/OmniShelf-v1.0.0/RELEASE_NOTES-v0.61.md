# OmniShelf v0.61 — Provider Reliability & Operations

## Release goal

Turn the four deep provider adapters into an observable, failure-isolated provider platform without weakening the canonical catalog, cross-provider identity graph, unified enrichment engine, or existing provider functionality.

## What changed

- Added `lib/reliability.js` with provider-neutral operational telemetry for AniList, Open Library, TMDB and IGDB.
- Added per-provider operation, success/failure, cache, latency and last-error metrics.
- Added persistent operational events and incident history with bounded retention.
- Added configurable per-provider circuit breakers for repeated transient failures, including half-open recovery probes.
- Added shared exponential-backoff policy and `Retry-After` handling used by provider adapters where transient retries occur.
- Deepened Open Library retry handling to cover transient 429/5xx/timeout/network failures with bounded backoff.
- Expanded TMDB retry behavior to transient 429/5xx/504 failures while retaining provider pacing.
- Expanded IGDB retry behavior to transient 429/5xx/504/network failures while preserving credential refresh behavior.
- Expanded AniList retry behavior to transient 429/5xx/504/network failures without changing the live-access compliance gate.
- Added cache-hit/miss observability to successful live provider operations.
- Added stale-provider-data detection based on provider retrieval/enrichment timestamps and a configurable freshness window.
- Added provider readiness and acceptance matrix APIs.
- Added provider reliability API endpoints for dashboard, events, incidents, staleness, self-test and reset operations.
- Added Reliability as a first-class top-level UI workspace.
- Added operational health information to `/api/health` and `/api/providers/status`.
- Added reliability persistence to `data/store.json` and full backup/export/restore preservation.
- Added `npm run reliability:selftest` with deterministic circuit, backoff, cache, staleness and acceptance-matrix checks.
- Preserved all AniList, Open Library, TMDB, IGDB, Identity, Unified Enrichment, Catalog, Community, Collections, Saved Views, Bulk Operations, Data Hub, Review Queue and synchronization features.
- Carried the complete cumulative project history through v0.61 with release rationale, implementation details, validation status and roadmap dependencies.

## Safety boundaries

- Reliability circuit state is provider-specific; failure in one upstream does not block unrelated providers.
- Configuration/authentication failures do not trip transient-outage circuits.
- Live provider acceptance remains separate from offline self-tests and is not falsely claimed from an offline build environment.
- Operational reset requires explicit confirmation.
- Reliability logs are bounded to avoid unbounded workspace growth.

## Next dependency

With reliability/operations in place, v0.62 can focus on Unified Provider Search: OmniShelf search can query appropriate providers, normalize the results, apply identity matching, and return one coherent discovery surface.

## Final validation record

- Reliability deterministic suite: 8/8.
- Regression suites: Identity 10/10, Unified Enrichment 10/10, TMDB 17/17, IGDB 25/25, Open Library 5/5.
- Isolated HTTP E2E: health/status, provider-local failure telemetry, demo isolation, staleness/events, acceptance matrix, backup/export, restore preview/apply, reset and clean-state persistence all passed.
- Validation found and fixed an omitted `providerStatus` export, cache-hit bookkeeping, and null `Retry-After` handling; all are covered by the final test state.
- Live provider acceptance is intentionally unclaimed without credentials/network/authorization.

## Continuity requirement

This release carries the complete cumulative project history through v0.61 and records enough architecture, implementation detail, rationale, validation evidence, known limitations and roadmap dependencies for subsequent work to continue from the archive alone.
