# OmniShelf v0.56 — Open Library Quality & Entity Layer

## Release goal
Deepen Open Library from a discovery/lookup adapter into a quality-aware provider whose Work, Edition, Author, and Subject information can be reconciled with the canonical OmniShelf catalog without creating a second competing catalog model.

## What changed
- Added `lib/openlibrary-quality.js` with completeness scoring, entity-aware quality reports, ISBN normalization, Work/Edition/Author identity extraction, subject normalization, Open Library-aware duplicate matching, Work → Edition relationship planning, entity-registry payload construction, and canonical enrichment previews.
- Added persistent Open Library registries in `data/store.json`: authors, normalized subjects, Work → Edition lineage, enrichment journal, and Review Queue diagnostics.
- Open Library search and normalization now surface catalog-match diagnostics, normalized subjects, provider lineage, and Work/Edition identity metadata.
- Added Work → Edition lookup through `GET /api/openlibrary/works/:id/editions` with relationship diagnostics.
- Added quality analysis, identity matching, entity registry inspection/rebuild, and canonical enrichment preview/apply endpoints.
- Added ISBN-aware cover fallback while continuing the remote-reference-only artwork policy.
- Added deterministic offline quality/entity self-test: `npm run openlibrary:quality-test`.
- Extended live read acceptance to validate Work → Edition relationships when a Work is returned.
- Preserved all earlier AniList, catalog, collections, saved views, bulk operations, Data Hub, provider, sync, and continuity systems.
- Updated all carried continuity documentation to identify v0.56 as the current release while preserving the accumulated historical ledger.

## Data-safety rules
- Preview-before-apply is retained for canonical enrichment.
- Existing non-empty manual canonical fields remain authoritative during enrichment; provider fields are added under provider metadata/provenance.
- Exact provider IDs, shared ISBNs, shared Work IDs, title similarity, creator overlap, publication year, and canonical type contribute to matching; automated matching remains advisory and reviewable.
- No Open Library cover image bytes are silently persisted by the adapter.
- Live upstream Open Library acceptance remains operator-run on a network-enabled machine; this release does not claim live acceptance from the build environment.

## Validation
- JavaScript syntax checks for changed server, Open Library, quality-layer, and acceptance files.
- Deterministic Open Library quality/entity self-test passes.
- Demo search, quality analysis, entity extraction, enrichment preview/apply, registry persistence, backup export, and Work → Edition route exercised locally.
- Browser UI served successfully from an isolated local port; `preview.html` remains the synchronized v0.56 browser preview.
- Release `data/store.json` reset to the v0.55 clean baseline before packaging; demo test records are not shipped.
