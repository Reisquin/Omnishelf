# OmniShelf v0.77 — Universal Import / Export & Migration

**Date:** 2026-10-07  
**Base:** v0.76 — Social / Community 2.0

## Summary

v0.77 makes OmniShelf data portable. The release separates user-facing migration from internal workspace recovery so users can move their personal media state without copying provider operational telemetry or internal governance machinery.

## Added

- Added `lib/portable.js` with a versioned `omnishelf-portable` JSON format.
- Added personal and workspace portable exports.
- Added personal library CSV export.
- Added preview-first portable migration import.
- Added work matching by exact provider identity, shared external identifiers and the existing v0.59 identity evidence layer.
- Added safe creation of missing canonical work records when no strong destination match exists.
- Added explicit existing-personal-state policies: keep existing, use newer, or overwrite with imported state.
- Added migration of Personal Library, History, Smart Library Collections and local Community state with destination ID remapping.
- Added repeat-import markers to prevent duplicate history/reviews/activity.
- Added `portable:selftest` and disposable `portable:http-e2e` validation.
- Added `PORTABLE_IMPORT_EXPORT.md`.

## Boundaries

Portable export intentionally excludes provider raw payloads, operational reliability telemetry, audit logs and governance operational history. Full workspace backup remains the recovery format.

No provider API is called during portable export/import. AniList remains an independent authorization/live-acceptance track.

## Validation

- Portable deterministic self-test: **8/8**.
- Portable HTTP E2E: **7/7**.
- Full deterministic regression: **23/23 suites passed**.
- Full HTTP E2E regression: **7/7 suites passed** once the inherited v0.76 version assertions were updated to the v0.77 release contract.
- All project JavaScript files pass Node syntax validation.
- `preview.html` is byte-identical to `public/index.html`.
- Shipped datastore remains clean.

## Next

v0.78 — Full Medium-by-Medium Personal Experiences.
