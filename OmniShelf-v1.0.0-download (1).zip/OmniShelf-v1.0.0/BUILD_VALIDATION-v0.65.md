# Build Validation — v0.65

## Deterministic medium self-test
Command: `npm run asian-drama:selftest`

Result: **15/15 passed**.

Coverage includes:
- read-only scope
- demo record detection
- airing/completed state classification
- K/C/J profile classification
- original-title preservation
- season/episode metadata
- network context
- language/industry facets
- state filtering
- alias query matching
- country filtering
- ambiguous-English non-classification
- explicit K-Drama tag classification

## Regression suites
All v0.64-era product/provider foundations were re-run successfully:
- Catalog Experience: **8/8**
- Unified Provider Search: **13/13**
- Provider Reliability: **8/8**
- Cross-Provider Identity: **10/10**
- Unified Enrichment: **10/10**
- Final Data Governance: **14/14**
- TMDB offline: **17/17**
- IGDB offline: **25/25**
- Open Library quality/entity: **5/5**

## Isolated HTTP acceptance
A fresh copy of the v0.65 project was served on an isolated port and verified with **9/9** checks:
1. `/api/health` reports v0.65.
2. `/api/medium/asian-dramas` returns the clean catalog lens as read-only.
3. `/api/medium/asian-dramas/profiles` returns all 14 supported profiles.
4. `?demo=1` returns all four deterministic medium fixtures.
5. Demo industry filtering returns the expected K-Drama fixture.
6. URL-encoded original-title search returns the expected fixture.
7. Demo detail exposes original title and episode count.
8. The medium self-test endpoint returns 15/15 passing.
9. `/?view=asian-dramas` serves the v0.65 product surface with the Asian Dramas UI.

The clean demo/read HTTP checks left `data/store.json` unchanged. Clean datastore SHA-256: `8138ddf41ec7c690a003c9873419766e84062ebd6ed27ea5273b5e0e1bd0dfe4`.

## UI/static validation
- `node --check server.js`: passed.
- Extracted client JavaScript from `public/index.html`: syntax check passed.
- `preview.html` is byte-identical to `public/index.html`.
- Automated headless-browser screenshot capture is **not claimed**; the environment has timed out on Chromium capture.

## Data cleanliness
The shipped `data/store.json` contains no catalog records or synthetic demo fixtures. Demo data is generated only in-memory by `lib/asian-dramas.js`.

## Live-provider boundary
v0.65 does not claim live TMDB acceptance. Live upstream behavior remains subject to the existing provider credentials/network/acceptance boundary.

## Release continuity
The release carries the detailed cumulative project history through v0.65, including implementation rationale, architecture decisions, validation evidence, known limitations, and next dependencies.

## Source/package integrity
The regenerated source manifest contains **140 entries** with zero mismatches. Final ZIP integrity must be checked after packaging.
