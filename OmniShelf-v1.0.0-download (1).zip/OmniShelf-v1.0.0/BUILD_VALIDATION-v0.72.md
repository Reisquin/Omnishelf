# OmniShelf v0.72 — Build Validation

Release: v0.72 — Smart Library Collections
Base: v0.71

## Deterministic regression matrix

- Personal Library: 7/7
- Library Experience: 14/14
- Library History: 8/8
- Library Collections: 7/7
- Standalone Work Pages: 8/8
- Work Page: 8/8
- Catalog UX: 5/5
- Catalog Experience: 8/8
- Medium Framework: 7/7
- Asian Drama: 18/18
- Unified Provider Search: 13/13
- Provider Reliability: 8/8
- Cross-Provider Identity: 10/10
- Unified Enrichment: 10/10
- Final Data Governance: 14/14
- TMDB: 17/17
- IGDB: 25/25
- Open Library: 5/5

All inherited deterministic suites were re-run against the v0.72 codebase.

## Syntax validation

Passed for `server.js`, `lib/store.js`, `lib/library.js`, `lib/library-history.js`, `lib/library-experience.js`, `lib/library-collections.js`, `lib/governance.js`, `lib/work-pages.js`, the new collection self-test scripts, the updated library HTTP E2E scripts, and the client JavaScript extracted from `public/index.html`.

## Isolated HTTP E2E

### Smart Library Collections — 17/17

The disposable-copy collection E2E verifies built-in presets, custom creation, collection statistics, direct filtering, favorite filtering, dynamic membership after personal-state mutation, collection updates, save-from-filters, multiple custom collections, backup preservation, deletion, restore preview/application, UI delivery, and work-page projection.

### Personal Library — 19/19

The inherited personal-library HTTP E2E verifies overview, personal state, quick shelves, progress summary, medium views, filtering, completion, work-page projection, re-experience history, timeline, recent additions/completions, history summary/filtering, UI delivery, backup preservation, and history after removal.

No HTTP E2E mutates the shipped clean datastore.

## Release integrity

- `preview.html` is byte-identical to `public/index.html`.
- The shipped datastore contains 0 catalog records, 0 review-queue records, 0 audit entries, 0 personal-library records, 0 smart library collections, and 0 personal-history events.
- Smart Library Collections are stored inside the personal `library` backup payload and restore with it.
- Source manifest verification is performed after all release files are finalized and reports 0 mismatches.
- The final ZIP is independently extracted and revalidated against the deterministic suites and disposable HTTP checks.

## AniList boundary

AniList remains separate from the Smart Library Collections workstream. No personal library collection route requires live AniList authorization or live AniList availability.

## Known boundaries

Smart Library Collections are personal, local, and dynamic. Built-in collections are immutable presets. Custom collections are capped at 100 per workspace and use sanitized rule sets. Membership is recalculated at read time rather than stored as a second membership database. Catalog-level Saved Views remain a separate feature.
