#!/usr/bin/env node
const {runReadOnlyAcceptance}=require('../lib/anilist');
const requireAuth=process.argv.includes('--require-auth');
(async()=>{
  const result=await runReadOnlyAcceptance({requireAuth});
  console.log(JSON.stringify(result,null,2));
  if(result.summary?.blocked) process.exit(3);
  if(result.summary?.failed) process.exit(2);
})().catch(err=>{ console.error(err.stack||err); process.exit(1); });
