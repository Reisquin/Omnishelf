const fs=require('fs');
const path=require('path');
const html=fs.readFileSync(path.join(__dirname,'..','public','index.html'),'utf8');
const checks=[
 ['standalone-route-section',html.includes('id="standaloneWorkRoute"')],
 ['standalone-route-client',html.includes('async function openStandaloneWorkPage(id,push=true)')],
 ['deep-link-handler',html.includes("location.pathname.match(/^\\/work/") || html.includes("location.pathname.startsWith('/work/')")],
 ['history-navigation',html.includes('history.pushState')&&html.includes('popstate')],
 ['full-page-link',html.includes('Open page')],
 ['medium-experience-render',html.includes('mediumExperienceMarkup(p)')],
 ['work-api-route',html.includes("/api/catalog/'+encodeURIComponent(id)+'/work-page")],
 ['version',html.includes('OmniShelf v1.0')]
];
let all=true;
for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`);all=all&&ok;}
if(!all)process.exit(1);
console.log(`Standalone Work Pages ${checks.length}/${checks.length}`);
