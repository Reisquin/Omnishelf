const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const {spawn} = require('child_process');

const source = process.cwd();
const root = fs.mkdtempSync(path.join(os.tmpdir(),'omnish-v081-final-audit-'));
fs.cpSync(source, root, {recursive:true});
const port = 43000 + Math.floor(Math.random()*500);
const child = spawn(process.execPath,['server.js'],{cwd:root,env:{...process.env,PORT:String(port),ANILIST_MODE:'demo',ANILIST_AUTHORIZED_USE:'false',NODE_ENV:'production'},stdio:['ignore','pipe','pipe']});
const checks=[];
const mark=(name,v,detail='')=>checks.push({name,ok:!!v,detail});
const request=(method,pathName,body,headers={})=>new Promise((resolve,reject)=>{const data=body==null?null:JSON.stringify(body);const req=http.request({hostname:'127.0.0.1',port,path:pathName,method,headers:{...(data?{'Content-Type':'application/json','Content-Length':Buffer.byteLength(data)}:{}),...headers}},res=>{let text='';res.setEncoding('utf8');res.on('data',c=>text+=c);res.on('end',()=>{let json=null;try{json=JSON.parse(text)}catch(_){} resolve({status:res.statusCode,headers:res.headers,text,json});});});req.setTimeout(5000,()=>req.destroy(new Error('timeout')));req.on('error',reject);if(data)req.write(data);req.end();});
const wait=()=>new Promise((resolve,reject)=>{const start=Date.now();const tick=()=>request('GET','/api/health').then(r=>r.status===200?resolve():Date.now()-start>8000?reject(new Error('server timeout')):setTimeout(tick,80)).catch(()=>Date.now()-start>8000?reject(new Error('server timeout')):setTimeout(tick,80));tick();});
(async()=>{
  try {
    await wait();
    let r=await request('GET','/');
    mark('root-200',r.status===200);
    mark('root-title',r.text.includes('OmniShelf v1.0'));
    mark('preview-shell',r.text.includes('id="primaryNavigation"')&&r.text.includes('id="mainContent"')&&r.text.includes('Skip to main content'));
    const views=['explore','library','statistics','recommendations','community','mediums','asian-dramas','catalog','search','identity','enrichment','reliability','governance','production','tmdb','igdb','anilist','collections','smart','data','review'];
    for(const view of views){r=await request('GET',`/?view=${encodeURIComponent(view)}`);mark(`view-${view}`,r.status===200&&r.text.includes('OmniShelf v1.0'));}
    r=await request('GET','/api/health');
    mark('health',r.status===200&&r.json?.version==='1.0'&&r.json?.ok===true);
    mark('hardening-status',r.json?.hardening?.dataValid===true&&r.json?.hardening?.schemaVersion===1);
    for(const route of ['/api/catalog','/api/catalog/explore','/api/search?q=demo','/api/library/overview','/api/library/stats','/api/mediums/personal','/api/community/overview','/api/recommendations','/api/providers/status','/api/providers/reliability','/api/providers/staleness','/api/governance/status','/api/production/status','/api/production/validate','/api/openlibrary/status','/api/tmdb/status','/api/igdb/status','/api/anilist/status']){
      r=await request('GET',route);mark(`api-${route.split('?')[0]}`,r.status===200||r.status===204,`status ${r.status}`);
    }
    r=await request('GET','/api/tmdb/search?demo=1&q=demo');mark('tmdb-demo',r.status===200&&r.json?.mode==='demo');
    r=await request('GET','/api/igdb/search?demo=1&q=demo');mark('igdb-demo',r.status===200&&r.json?.mode==='demo');
    r=await request('GET','/api/openlibrary/search?demo=1&q=demo');mark('openlibrary-demo',r.status===200&&r.json?.mode==='demo');
    r=await request('GET','/api/anilist/media/search?demo=1&q=demo');mark('anilist-demo-search',r.status===200&&r.json?.mode==='demo');
    r=await request('GET','/api/nonexistent-final-audit');mark('unknown-route-404',r.status===404&&!!r.headers['x-request-id']);
    r=await request('POST','/api/production/restore',{name:'missing'});mark('restore-guarded',r.status===400||r.status===404);
    const root1=await request('GET','/');mark('etag-present',!!root1.headers.etag);
    const root2=await request('GET','/',null,{'If-None-Match':root1.headers.etag});mark('etag-304',root2.status===304);
    const result={suite:'final-release-audit-v1.0-http-e2e',passed:checks.every(c=>c.ok),passedCount:checks.filter(c=>c.ok).length,total:checks.length,checks};
    console.log(JSON.stringify(result,null,2));process.exitCode=result.passed?0:1;
  }catch(e){console.error(e);process.exitCode=1}
  finally{child.kill('SIGTERM');setTimeout(()=>{try{child.kill('SIGKILL')}catch(_){};try{fs.rmSync(root,{recursive:true,force:true})}catch(_){}},400);}
})().catch(e=>{console.error(e);process.exitCode=1});
