const statistics = require('../lib/library-statistics');
function main(){
  const result=statistics.selfTest();
  console.log(JSON.stringify({suite:'personal-library-statistics',...result}));
  process.exit(result.passed?0:1);
}
main();
