const store = require('../lib/store');
const collections = require('../lib/library-collections');
const library = require('../lib/library');

function main(){
  const data={catalog:[
    {id:'a',title:'Anime A',type:'Anime',provider:'AniList',year:2026,tags:['Action'],providerMetadata:{anilist:{episodes:12}}},
    {id:'b',title:'Novel B',type:'Novel',provider:'Open Library',year:2025,tags:['Drama'],providerMetadata:{openLibrary:{pages:300}}},
    {id:'c',title:'Movie C',type:'Movie',provider:'TMDB',year:2024,tags:['Drama']}
  ],library:{version:1,profile:{name:'You'},items:{},history:{version:1,events:[]},smartCollections:[]}};
  library.upsert(data,'a',{status:'active',progress:6,progressTotal:12,progressUnit:'episodes',score:95,favorite:true,notes:'watch'});
  library.upsert(data,'b',{status:'completed',progress:300,progressTotal:300,progressUnit:'pages',score:88});
  library.upsert(data,'c',{status:'planning'});
  const created=collections.create(data,{name:'Top Anime',description:'My high rated anime',rules:{mode:'all',type:'Anime',scoreMin:90}});
  const first=collections.viewFor(created,data,{limit:24});
  const fav=collections.presetView('favorites',data,{limit:24});
  const cont=collections.presetView('continue',data,{limit:24});
  collections.update(data,created.id,{rules:{mode:'all',type:'Anime',progressMin:40}});
  const updated=collections.viewFor(created,data,{limit:24});
  const built=collections.buildFromLibraryFilters({status:'completed',type:'Novel',favorite:''});
  const checks=[
    ['custom-create',data.library.smartCollections.length===1],
    ['custom-match',first.itemCount===1&&first.items[0].id==='a'],
    ['favorite-preset',fav.itemCount===1&&fav.items[0].id==='a'],
    ['continue-preset',cont.itemCount===1&&cont.items[0].id==='a'],
    ['dynamic-update',updated.itemCount===1&&updated.items[0].id==='a'],
    ['filter-build',built.status==='completed'&&built.type==='Novel'&&built.favorite===undefined],
    ['rule-sanitize',collections.sanitizeRules({scoreMin:120,favorite:true,mode:'all'}).scoreMin==='100']
  ];
  const result={suite:'personal-library-collections',passed:checks.every(x=>x[1]),checks:checks.map(([name,ok])=>({name,ok})),count:checks.length};
  console.log(JSON.stringify(result));
  process.exit(result.passed?0:1);
}
main();
