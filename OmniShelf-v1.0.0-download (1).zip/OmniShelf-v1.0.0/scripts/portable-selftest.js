const portable=require('../lib/portable');
const result=portable.selfTest();
console.log(JSON.stringify({suite:'v1.0-portable-selftest',...result},null,2));
if(!result.passed)process.exit(1);
