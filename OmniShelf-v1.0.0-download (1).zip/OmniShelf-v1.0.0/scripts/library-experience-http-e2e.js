const fs=require('fs');
const path=require('path');
const os=require('os');
const cp=require('child_process');
const {promisify}=require('util');
const {setTimeout:delay}=require('timers/promises');
const copy=fs.cpSync;

async function waitFor(url,timeout=8000){
  const start=Date.now();
  while(Date.now()-start<timeout){
    try{const r=await fetch(url);if(r.ok)return; }catch{}
    await delay(100);
  }
  throw new Error('Server did not become ready');
}
async function req(base,route,options){
  const r=await fetch(base+route,{headers:{'Content-Type':'application/json'},...options});
  const t=await r.text();
  let d={};try{d=t?JSON.parse(t):{};}catch{d={raw:t};}
  if(!r.ok)throw new Error(`${route}: ${d.error||r.status}`);
  return d;
}

(async()=>{
  const source=path.resolve(__dirname,'..');
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'omni-v071-library-'));
  const dest=path.join(tmp,'OmniShelf-v1.0');
  copy(source,dest,{recursive:true});
  const dataPath=path.join(dest,'data','store.json');
  // Preserve a pristine fixture: the source release itself is never mutated.
  const data=JSON.parse(fs.readFileSync(dataPath,'utf8'));
  data.catalog=[]; data.reviewQueue=[]; data.auditLog=[]; data.collections=[]; data.smartCollections=[]; data.library={version:1,profile:{name:'You'},items:{},history:{version:1,events:[]}};
  fs.writeFileSync(dataPath,JSON.stringify(data,null,2)+'\n');
  const port=Number(process.env.OMNI_E2E_PORT||31870)+Math.floor(Math.random()*1000);
  const child=cp.spawn(process.execPath,['server.js'],{cwd:dest,env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
  let stderr=''; child.stderr.on('data',b=>stderr+=b.toString());
  const base=`http://127.0.0.1:${port}`;
  try{
    await waitFor(base+'/api/health');
    const checks=[];
    const mark=(name,ok,detail='')=>{checks.push({name,ok,detail});if(!ok)throw new Error(name+(detail?`: ${detail}`:''));};
    const empty=await req(base,'/api/library/overview');
    mark('overview-empty',empty.stats.count===0&&empty.sectionCounts.continue===0);
    const a=await req(base,'/api/catalog',{method:'POST',body:JSON.stringify({title:'Demo Anime',type:'Anime',year:2026,provider:'TMDB',providerId:'7001',providerMetadata:{anilist:{episodes:12}}})});
    const b=await req(base,'/api/catalog',{method:'POST',body:JSON.stringify({title:'Demo Novel',type:'Novel',year:2025,provider:'Open Library',providerId:'OLDEMO1W',providerMetadata:{openLibrary:{pages:240}}})});
    const c=await req(base,'/api/catalog',{method:'POST',body:JSON.stringify({title:'Demo Film',type:'Movie',year:2024,provider:'TMDB',providerId:'7002'})});
    mark('catalog-seed',!!a.id&&!!b.id&&!!c.id);
    const ae=await req(base,'/api/library/'+encodeURIComponent(a.id),{method:'PUT',body:JSON.stringify({status:'active',progress:3,favorite:true,score:92})});
    await req(base,'/api/library/'+encodeURIComponent(b.id),{method:'PUT',body:JSON.stringify({status:'planning'})});
    await req(base,'/api/library/'+encodeURIComponent(c.id),{method:'PUT',body:JSON.stringify({status:'completed',progress:1,progressTotal:1,progressUnit:'viewings',score:80})});
    mark('personal-state',ae.library.present&&ae.library.record.progressUnit==='episodes'&&ae.library.total===12);
    const overview=await req(base,'/api/library/overview');
    mark('quick-shelves',overview.sectionCounts.continue===1&&overview.sectionCounts.planned===1&&overview.sectionCounts.completed===1&&overview.sectionCounts.favorites===1);
    mark('progress-summary',overview.progress.measurable===3&&overview.progress.remaining===2&&overview.progress.averageProgress===41.7);
    mark('medium-summary',overview.mediums.find(x=>x.type==='Anime')?.active===1&&overview.mediums.find(x=>x.type==='Novel')?.planning===1);
    const medium=await req(base,'/api/library/medium/Anime');
    mark('medium-view',medium.type==='Anime'&&medium.stats.count===1&&medium.stats.active===1&&medium.active.length===1);
    const filtered=await req(base,'/api/library?status=completed');
    mark('filtered-library',filtered.total===1&&filtered.items[0].catalog.title==='Demo Film');
    const advanced=await req(base,'/api/library/'+encodeURIComponent(a.id)+'/advance',{method:'POST',body:JSON.stringify({delta:9})});
    mark('advance-and-complete',advanced.library.record.progress===12&&advanced.library.record.status==='completed'&&advanced.library.percent===100);
    const work=await req(base,'/api/catalog/'+encodeURIComponent(a.id)+'/work-page');
    mark('work-page-projection',work.version==='1.0'&&work.library.present&&work.library.record.progress===12&&work.libraryHistory.total>=2);
    const switched=await req(base,'/api/library/'+encodeURIComponent(a.id),{method:'PUT',body:JSON.stringify({status:'rewatching',progress:1,completedAt:null})});
    mark('reexperience-history',switched.library.record.status==='rewatching');
    const timeline=await req(base,'/api/library/history?limit=50');
    mark('history-timeline',timeline.total===6&&timeline.items[0].action==='session.started'&&timeline.items.some(x=>x.action==='completed'));
    const completedHistory=await req(base,'/api/library/recent/completed?limit=10');
    mark('recent-completions',completedHistory.items.length===2);
    const addedHistory=await req(base,'/api/library/recent/added?limit=10');
    mark('recent-additions',addedHistory.items.length===3);
    const historySummary=await req(base,'/api/library/history/summary');
    mark('history-summary',historySummary.summary.totalEvents===6&&historySummary.summary.completionEvents===2&&historySummary.summary.sessionStarts===1);
    const filteredHistory=await req(base,'/api/library/history?action=completed');
    mark('history-filter',filteredHistory.total===2);
    mark('ui-route', (await fetch(base+'/?view=library')).ok);
    const backup=await req(base,'/api/data/export?scope=full');
    mark('backup-preserves-library',backup.library&&Object.keys(backup.library.items||{}).length===3&&Array.isArray(backup.library.history?.events)&&backup.library.history.events.length===6);
    await req(base,'/api/library/'+encodeURIComponent(c.id),{method:'DELETE'});
    const afterRemove=await req(base,'/api/library/history?catalogId='+encodeURIComponent(c.id));
    mark('history-after-remove',afterRemove.total>=3&&afterRemove.items.some(x=>x.action==='removed'));
    console.log(JSON.stringify({suite:'personal-library-http-e2e-v1.0',passed:true,checks:checks.length,details:checks}));
  }catch(e){
    console.error(JSON.stringify({suite:'personal-library-http-e2e-v1.0',passed:false,error:e.message,stderr}));
    process.exitCode=1;
  }finally{
    child.kill('SIGTERM');
    await delay(100);
    fs.rmSync(tmp,{recursive:true,force:true});
  }
})().catch(e=>{console.error(e);process.exitCode=1});
