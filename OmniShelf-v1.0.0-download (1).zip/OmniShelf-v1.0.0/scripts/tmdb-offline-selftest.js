const assert = require('assert');
const tmdb = require('../lib/tmdb');

function expect(condition, message) { assert.ok(condition, message); }

const movieRaw = tmdb.demoMovie(9001);
const tvRaw = tmdb.demoTV(9002);
const movie = tmdb.normalize('movie', movieRaw);
const tv = tmdb.normalize('tv', tvRaw);

expect(movie.provider === 'TMDB', 'Movie provider should be TMDB');
expect(movie.type === 'Movie', 'Movie should map to canonical Movie');
expect(movie.providerId === '9001', 'Movie provider ID should be preserved');
expect(movie.providerMetadata.tmdb.externalIds.imdbId === 'tt9000001', 'Movie IMDb ID should normalize');
expect(movie.providerMetadata.tmdb.releaseDates.length === 2, 'Movie release-date regions should normalize');
expect(movie.providerMetadata.tmdb.images.backdrops.length === 1, 'Movie backdrop should normalize');
expect(movie.providerMetadata.tmdb.collection.providerId === 9100, 'Movie collection should normalize');

expect(tv.provider === 'TMDB', 'TV provider should be TMDB');
expect(tv.type === 'TV', 'TV should map to canonical TV');
expect(tv.providerMetadata.tmdb.seasons.length === 2, 'TV seasons should normalize');
expect(tv.providerMetadata.tmdb.numberOfEpisodes === 16, 'TV episode count should normalize');

const season = tmdb.demoSeason(9002, 1).normalized;
expect(season.episodes.length === 4, 'Demo season should contain four deterministic episodes');
const episode = tmdb.demoEpisode(9002, 1, 1).normalized;
expect(episode.episodeNumber === 1, 'Demo episode number should normalize');

const matches = tmdb.findMatches(movie, [{...movie, id:'canonical-1', providerId:'9001'}]);
expect(matches[0]?.score === 1, 'Exact TMDB identity should produce a score of 1');

const quality = tmdb.qualityReport(movie);
expect(quality.score >= 80, 'Demo movie should pass a strong quality threshold');

const preview = tmdb.enrichmentPreview({...movie, description:''}, movie);
expect(preview.changedFields.includes('description'), 'Enrichment preview should detect missing description');
expect(preview.changedFields.includes('providerMetadata/tmdb'), 'Enrichment preview should include provider metadata');

const entities = tmdb.entityBundle(movie);
expect(Object.keys(entities.people).length >= 2, 'Movie entity bundle should include cast and crew people');
expect(Object.keys(entities.companies).length === 1, 'Movie entity bundle should include production company');
expect(Object.keys(entities.collections).length === 1, 'Movie entity bundle should include collection');

console.log(JSON.stringify({
  passed: true,
  checks: 17,
  movie: { type: movie.type, providerId: movie.providerId, releaseDateRegions: movie.providerMetadata.tmdb.releaseDates.length },
  tv: { type: tv.type, seasons: tv.providerMetadata.tmdb.seasons.length, episodes: tv.providerMetadata.tmdb.numberOfEpisodes },
  quality: quality.score,
  entities: { people:Object.keys(entities.people).length, companies:Object.keys(entities.companies).length, networks:Object.keys(entities.networks).length, collections:Object.keys(entities.collections).length }
}, null, 2));
