const assert = require('assert');
const crypto = require('crypto');
const igdb = require('../lib/igdb');
const { normalizeForDemo } = require('../lib/providers');

function expect(condition, message) { assert.ok(condition, message); }

const raw = igdb.demoGame(99001);
const game = igdb.normalize(raw);
expect(game.provider === 'IGDB', 'Provider should normalize as IGDB');
expect(game.type === 'Game', 'IGDB records should map to canonical Game');
expect(game.providerId === '99001', 'Provider ID should be preserved as a positive integer string');
expect(game.year === 2025, 'First release year should derive from the Unix timestamp');
expect(game.providerMetadata.igdb.platforms.length === 2, 'Platforms should normalize');
expect(game.providerMetadata.igdb.releases.length === 2, 'Region-aware release dates should normalize');
expect(game.providerMetadata.igdb.developers.length === 1, 'Developer company should normalize');
expect(game.providerMetadata.igdb.publishers.length === 1, 'Publisher company should normalize');
expect(game.providerMetadata.igdb.localizations.length === 1, 'Localizations should normalize');
expect(game.providerMetadata.igdb.externalGames.length === 1, 'External game IDs should normalize');
expect(game.providerMetadata.igdb.ageRatings.length === 1, 'Age ratings should normalize');
expect(game.mediaAssets.artworks.length === 1 && game.mediaAssets.screenshots.length === 1, 'Game artwork/screenshot assets should normalize');
expect(game.aliases.includes('京の灯籠'), 'Native/localized title should be preserved as an alias');
expect(game.externalLinks.some(x => x.includes('igdb.com/games/99001')), 'Canonical IGDB link should be retained');

const search = igdb.demoSearch('Zelda');
expect(search.results.length === 2, 'Demo search should return deterministic results');
expect(search.results.every(x => x.provider === 'IGDB'), 'Demo search results should be fully normalized');

const providerDemo = normalizeForDemo('IGDB', 'Zelda');
expect(providerDemo.length === 2 && providerDemo[0].provider === 'IGDB', 'Provider Hub demo search should use the IGDB demo model');

const discovery = igdb.demoDiscover();
expect(discovery.results.length === 2, 'Demo discovery should return deterministic results');

const sameIdMatches = igdb.findMatches(game, [{ id: 'canonical-1', provider: 'IGDB', providerId: '99001', title: 'Completely Different Label', type: 'Game', aliases: [] }]);
expect(sameIdMatches[0]?.score === 1 && sameIdMatches[0].reasons.includes('exact IGDB ID'), 'Exact IGDB ID should be the strongest provider-aware identity signal');

const quality = igdb.qualityReport(game);
expect(quality.score >= 90, 'Complete demo game should score highly');

const manual = { id: 'canonical-manual', provider: 'Manual', providerId: null, title: 'Manual Canonical Title', type: 'Game', year: null, description: 'Manual description', creators: ['Manual Creator'], tags: ['Manual Tag'], aliases: ['Manual Alias'], externalLinks: [], coverUrl: null, mediaAssets: null, providerMetadata: null, raw: {} };
const preview = igdb.enrichmentPreview(manual, game);
expect(preview.changedFields.includes('providerMetadata'), 'Enrichment preview should detect provider metadata changes');
const merged = igdb.applyEnrichment(manual, game, true);
expect(merged.title === manual.title, 'Enrichment must preserve manual title');
expect(merged.description === manual.description, 'Enrichment must preserve manual description');
expect(merged.creators.includes('Manual Creator') && merged.creators.some(x => x.includes('Demo Kyoto Studio')), 'Enrichment should merge, not replace, creators');
expect(merged.providerMetadata.igdb.id === 99001, 'Enrichment should attach IGDB provider metadata');
expect(merged.raw.igdbGameSnapshot.id === 99001, 'Enrichment should preserve the raw IGDB snapshot');

const entities = igdb.entityBundle(game);
expect(Object.keys(entities.companies).length === 2, 'Entity bundle should contain developer and publisher companies');
expect(Object.keys(entities.platforms).length === 2, 'Entity bundle should contain platforms');
expect(Object.keys(entities.collections).length === 1, 'Entity bundle should contain collections');
expect(Object.keys(entities.franchises).length === 1, 'Entity bundle should contain franchises');

expect(igdb.imageUrl('demo-image','cover_big').includes('/t_cover_big/demo-image.jpg'), 'IGDB image URL helper should create the documented image shape');
expect(igdb.config().configured === false, 'Offline environment should remain unconfigured by default');

console.log(JSON.stringify({
  passed: true,
  checks: 25,
  release: { provider: game.provider, type: game.type, providerId: game.providerId, year: game.year },
  quality: quality.score,
  entities: Object.fromEntries(Object.entries(entities).map(([key, value]) => [key, Object.keys(value).length])),
  fixtureHash: crypto.createHash('sha256').update(JSON.stringify(raw)).digest('hex')
}, null, 2));
