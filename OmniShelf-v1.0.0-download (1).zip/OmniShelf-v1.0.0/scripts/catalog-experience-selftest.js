const explore=require('../lib/explore'); const r=explore.selfTest(); console.log(JSON.stringify(r,null,2)); if(!r.passed) process.exit(1);
