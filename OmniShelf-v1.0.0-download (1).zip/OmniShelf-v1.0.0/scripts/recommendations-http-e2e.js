const fs=require('fs'),path=require('path'),http=require('http'),child=require('child_process');
const root=path.resolve(__dirname,'..'); const temp=fs.mkdtempSync('/tmp/omni-rec-');
fs.cpSync(path.join(root,'data'),path.join(temp,'data'),{recursive:true}); const childRoot=temp;
// Use a disposable copy of the whole project so the test can create library/catalog state without touching the release tree.
fs.cpSync(path.join(root,'lib'),path.join(temp,'lib'),{recursive:true}); fs.cpSync(path.join(root,'public'),path.join(temp,'public'),{recursive:true}); fs.cpSync(path.join(root,'server.js'),path.join(temp,'server.js'));
let server; function req(port,p,opts={}){return new Promise((resolve,reject)=>{const body=opts.body?JSON.stringify(opts.body):null;const q=http.request({hostname:'127.0.0.1',port,path:p,method:opts.method||'GET',headers:{'Content-Type':'application/json',...(body?{'Content-Length':Buffer.byteLength(body)}:{})}},res=>{let s='';res.on('data',c=>s+=c);res.on('end',()=>{let out;try{out=JSON.parse(s)}catch{out=s}resolve({status:res.statusCode,body:out})})});q.on('error',reject);if(body)q.write(body);q.end();});}
(async()=>{try{
  server=child.spawn(process.execPath,['server.js'],{cwd:childRoot,env:{...process.env,PORT:'33124',NO_COLOR:'1'},stdio:'ignore'});
  let health=null;for(let i=0;i<30;i++){try{health=await req(33124,'/api/health');if(health.status===200)break}catch{}await new Promise(r=>setTimeout(r,50));}
  const checks=[]; const ok=(name,v)=>checks.push([name,!!v]);
  ok('health',health?.body?.version==='1.0');
  const none=await req(33124,'/api/recommendations?limit=5'); ok('empty-discovery',none.status===200&&none.body.mode==='discovery'&&none.body.items.length===0&&none.body.summary.candidateCount===0);
  const seeds=[
    {title:'Loved Mystery',type:'Anime',year:2024,tags:['Mystery','Psychological'],creators:['Aiko'],provider:'AniList',providerId:'7401',coverUrl:'/a.svg',providerMetadata:{anilist:{averageScore:91}}},
    {title:'Another Mystery',type:'Anime',year:2025,tags:['Mystery','Psychological'],creators:['Aiko'],provider:'AniList',providerId:'7402',coverUrl:'/b.svg',providerMetadata:{anilist:{averageScore:88}}},
    {title:'Unrelated Game',type:'Game',year:2023,tags:['Sports'],creators:['Other'],provider:'IGDB',providerId:'7403',coverUrl:'/c.svg',providerMetadata:{igdb:{rating:60}}},
    {title:'Mystery Novel',type:'Novel',year:2022,tags:['Mystery'],creators:['Aiko'],provider:'Open Library',providerId:'7404',coverUrl:'/d.svg',providerMetadata:{openLibrary:{ratingsAverage:4.4}}}
  ];
  const made=[]; for(const item of seeds){const r=await req(33124,'/api/catalog',{method:'POST',body:item});made.push(r.body);}
  // Relate the novel to the loved work.
  const rel=await req(33124,`/api/catalog/${encodeURIComponent(made[3].id)}/relations`,{method:'POST',body:{catalogId:made[0].id,type:'SOURCE'}}); ok('relation-create',rel.status===201);
  const add=await req(33124,`/api/library/${encodeURIComponent(made[0].id)}`,{method:'PUT',body:{status:'completed',progress:12,progressTotal:12,progressUnit:'episodes',score:96,favorite:true}}); ok('library-seed',add.status===200);
  const p=await req(33124,'/api/recommendations?limit=3'); ok('personalized',p.status===200&&p.body.mode==='personalized'&&p.body.profile.trackedItems===1);
  ok('excludes-owned',p.body.items.every(x=>x.id!==made[0].id));
  ok('signal',p.body.items.some(x=>x.id===made[1].id));
  ok('explainable',p.body.items.every(x=>Array.isArray(x.reasons)&&x.reasons.length>0));
  ok('relation-signal',p.body.items.some(x=>x.id===made[3].id&&x.reasons.some(r=>r.kind==='related')));
  const t=await req(33124,'/api/recommendations?type=Anime&limit=10'); ok('medium-filter',t.status===200&&t.body.items.every(x=>x.type==='Anime'));
  const d=await req(33124,'/api/recommendations?mode=discovery&limit=10'); ok('discovery-mode',d.status===200&&d.body.mode==='discovery');
  const sc=await req(33124,'/api/recommendations?minScore=85&limit=10'); ok('quality-filter',sc.status===200&&sc.body.items.every(x=>(x.quality??0)>=85));
  ok('no-persistence',fs.readFileSync(path.join(childRoot,'data','store.json'),'utf8').includes('library'));
  ok('ui-route',(await req(33124,'/?view=recommendations')).status===200);
  console.log(JSON.stringify({suite:'recommendations-http-v1.0',passed:checks.every(x=>x[1]),passedCount:checks.filter(x=>x[1]).length,total:checks.length,checks:checks.map(x=>({name:x[0],ok:x[1]}))},null,2));
  if(!checks.every(x=>x[1]))process.exitCode=1;
}catch(e){console.error(e);process.exitCode=1;}finally{if(server)server.kill('SIGTERM');fs.rmSync(temp,{recursive:true,force:true});}})();
