const {selfTest}=require('../lib/medium-experiences'); const r=selfTest(); console.log(JSON.stringify(r,null,2)); process.exit(r.passed?0:1);
