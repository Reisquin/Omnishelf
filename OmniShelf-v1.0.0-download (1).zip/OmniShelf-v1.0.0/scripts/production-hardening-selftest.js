const production=require('../lib/production');
const result=production.selfTest();
console.log(JSON.stringify({suite:'production-hardening-v1.0',mode:'deterministic',...result},null,2));
process.exitCode=result.passed?0:1;
