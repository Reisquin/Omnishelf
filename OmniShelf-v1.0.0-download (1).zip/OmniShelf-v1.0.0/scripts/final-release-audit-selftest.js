const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '..');
const checks = [];
const ok = (name, value, detail='') => checks.push({name, ok:!!value, detail});
const read = (file) => fs.readFileSync(path.join(ROOT,file),'utf8');

const expectedVersion = '1.0';
const packageJson = JSON.parse(read('package.json'));
const versionTxt = read('VERSION.txt').trim();
const server = read('server.js');
const html = read('public/index.html');
const preview = read('preview.html');
const history = read('PROJECT_HISTORY.md');
const state = read('CURRENT_STATE.md');
const readme = read('README.md');
const archiveIndex = read('SUPPLIED_ARCHIVE_INDEX.md');

ok('package-version', packageJson.version === '1.0.0');
ok('version-file', versionTxt === '1.0.0');
ok('server-version', server.includes(`const VERSION = '${expectedVersion}'`));
ok('public-version', html.includes(`OmniShelf v${expectedVersion}`));
ok('preview-version', preview.includes(`OmniShelf v${expectedVersion}`));
ok('preview-identical', html === preview);
ok('current-state', state.startsWith(`# OmniShelf Current State — v${expectedVersion}`) && state.includes('production release'));
ok('readme-current', readme.startsWith('# OmniShelf 1.0.0') && readme.includes('## 1.0.0 — Production Release'));
ok('history-current', history.includes('## 1.0.0 — Production Release'));
ok('archive-index-current', archiveIndex.startsWith('# OmniShelf 1.0.0') && archiveIndex.includes('OmniShelf-v1.0.0.zip'));

const requiredDocs = [
  'BUILD_VALIDATION-v1.0.0.md',
  'FINAL_RELEASE_CHECK-v1.0.0.txt',
  'README.md','CURRENT_STATE.md','PROJECT_HISTORY.md','SUPPLIED_ARCHIVE_INDEX.md',
  'ANILIST_ACCEPTANCE_CHECKLIST.md','OPENLIBRARY_LIVE_ACCEPTANCE.md','TMDB_LIVE_ACCEPTANCE.md','IGDB_LIVE_ACCEPTANCE.md'
];
ok('required-docs', requiredDocs.every(f => fs.existsSync(path.join(ROOT,f))));

const scripts = packageJson.scripts || {};
const missingTargets = [];
for (const [name, cmd] of Object.entries(scripts)) {
  const m = String(cmd).match(/node\s+(.+)$/);
  if (m) {
    const target = m[1].trim().split(/\s+/)[0];
    if (target.startsWith('scripts/') && !fs.existsSync(path.join(ROOT,target))) missingTargets.push(`${name}:${target}`);
  }
}
ok('package-script-targets', missingTargets.length === 0, missingTargets.join(', '));

const medium = require('../lib/medium-personal-experiences');
ok('canonical-medium-count', medium.CANONICAL_MEDIUM_TYPES.length === 18);
ok('canonical-medium-definitions', medium.CANONICAL_MEDIUM_TYPES.every(t => medium.definition(t)));
ok('medium-directory', medium.directory({catalog:[],library:{items:{}}}).length === 18);

const store = JSON.parse(read('data/store.json'));
const prod = require('../lib/production');
const validation = prod.validate(store);
const community = store.community || {};
const clean = store.catalog.length===0 && store.reviewQueue.length===0 && store.collections.length===0 && store.smartCollections.length===0 &&
  store.anilistSyncTombstones.length===0 && store.anilistSyncRuns.length===0 && Object.keys(store.anilistSyncCursors||{}).length===0 &&
  (store.identity?.groups||[]).length===0 && (store.identity?.decisions||[]).length===0 && (store.identity?.runs||[]).length===0 && (store.identity?.candidates||[]).length===0 &&
  (store.enrichment?.runs||[]).length===0 && (store.reliability?.events||[]).length===0 && (store.reliability?.incidents||[]).length===0 &&
  (store.governance?.fieldHistory||[]).length===0 && (store.governance?.deletionTombstones||[]).length===0 && (store.governance?.validationRuns||[]).length===0 &&
  Object.keys(store.library?.items||{}).length===0 && (store.library?.history?.events||[]).length===0 &&
  Object.keys(community.members||{}).length<=1 && (community.follows||[]).length===0 && (community.reviews||[]).length===0 && (community.activities||[]).length===0;
ok('workspace-schema', store.workspaceSchemaVersion === 1);
ok('workspace-valid', validation.valid === true);
ok('clean-shipped-datastore', clean);

const runtimeArtifacts = ['logs','.runtime-logs','data/.backups'];
const manifestText = fs.readFileSync(path.join(ROOT,'SOURCE_SHA256.txt'),'utf8'); ok('no-shipped-runtime-artifacts', runtimeArtifacts.every(rel => !manifestText.includes(` ${rel}`) && !manifestText.includes(`./${rel}`)));

const env = read('.env.example');
ok('safe-provider-defaults', /ANILIST_MODE=demo/.test(env) && /ANILIST_AUTHORIZED_USE=false/.test(env) && /TMDB_WATCH_PROVIDERS_ENABLED=false/.test(env) && /TMDB_JUSTWATCH_ATTRIBUTION_ACK=false/.test(env));
ok('openlibrary-ua-current', /OPENLIBRARY_USER_AGENT=OmniShelf\/1\.0/.test(env));

const forbidden = [];
for (const rel of ['server.js','package.json','VERSION.txt','public/index.html','preview.html','.env.example',...fs.readdirSync(path.join(ROOT,'lib')).filter(x=>x.endsWith('.js')).map(x=>`lib/${x}`)]) {
  const text = read(rel);
  if (/\b(TODO|FIXME|TBD)\b|not implemented|coming soon/i.test(text)) forbidden.push(rel);
}
ok('no-open-implementation-markers', forbidden.length===0, forbidden.join(', '));

const finalAuditMarkers = [
  '1.0.0 — Production Release',
  'Live upstream provider acceptance',
  'AniList authorization',
];
ok('audit-documentation', finalAuditMarkers.every(m => `${read('BUILD_VALIDATION-v1.0.0.md')}\n${read('FINAL_RELEASE_CHECK-v1.0.0.txt')}`.toLowerCase().includes(m.toLowerCase())));

// Verify manifest entries actually hash to their listed bytes when the manifest already exists.
const manifest = read('SOURCE_SHA256.txt').trim().split('\n').filter(Boolean);
let badManifest = 0;
for (const line of manifest) {
  const m = line.match(/^([0-9a-f]{64})\s+(.+)$/);
  if (!m) { badManifest++; continue; }
  const rel = m[2].startsWith('./') ? m[2].slice(2) : m[2];
  try {
    const digest = crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT,rel))).digest('hex');
    if (digest !== m[1]) badManifest++;
  } catch (_) { badManifest++; }
}
ok('source-manifest-valid', badManifest===0, `${manifest.length} entries`);

const passed = checks.every(c => c.ok);
console.log(JSON.stringify({suite:'final-release-audit-v1.0',mode:'deterministic',passed,passedCount:checks.filter(c=>c.ok).length,total:checks.length,checks},null,2));
process.exitCode = passed ? 0 : 1;
