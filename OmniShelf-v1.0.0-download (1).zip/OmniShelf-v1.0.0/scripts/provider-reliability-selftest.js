const reliability = require('../lib/reliability');

function assert(condition, message) { if (!condition) throw new Error(message); }

function main() {
  const before = reliability.snapshot({ includeEvents: true });
  const checks = [];
  try {
    const ctx = reliability.begin('TMDB', 'selftest.accounting');
    reliability.succeed(ctx, { status: 200, cached: false, detail: 'offline deterministic probe' });
    checks.push('success accounting');

    const hitCtx = reliability.begin('IGDB', 'selftest.cache');
    reliability.succeed(hitCtx, { status: 200, cached: true });
    const ig = reliability.providerSnapshot('IGDB');
    assert(ig.cacheHits >= before.providers.IGDB.cacheHits + 1, 'cache hit accounting failed');
    checks.push('cache observability');

    const err = Object.assign(new Error('synthetic upstream failure'), { status: 502, upstreamStatus: 502 });
    for (let i = 0; i < 3; i++) {
      const c = reliability.begin('Open Library', 'selftest.circuit');
      reliability.fail(c, err);
    }
    const open = reliability.providerSnapshot('Open Library');
    assert(open.circuit === 'open', 'circuit did not open after transient threshold');
    checks.push('circuit opening');

    let blocked = false;
    try { reliability.begin('Open Library', 'selftest.blocked'); }
    catch (e) { blocked = e.code === 'PROVIDER_CIRCUIT_OPEN'; }
    assert(blocked, 'open circuit did not block the next operation');
    checks.push('outage isolation');

    assert(reliability.retryDelayMs(0) === 500 && reliability.retryDelayMs(1) === 1000 && reliability.retryDelayMs(2) === 2000, 'exponential retry policy failed');
    assert(reliability.retryDelayMs(1, 5000) === 5000, 'Retry-After override failed');
    checks.push('backoff policy');

    const stale = reliability.scanStaleness([{
      id: 'stale-demo', provider: 'TMDB', title: 'Stale Demo',
      providerMetadata: { tmdb: { provenance: { retrievedAt: new Date(Date.now() - 180 * 86400000).toISOString() } } }
    }], { staleDays: 90 });
    assert(stale.providers.TMDB.stale === 1, 'stale provider detection failed');
    checks.push('stale-data detection');

    const matrix = reliability.acceptanceMatrix([
      { provider: 'AniList', configured: false, demoAvailable: true },
      { provider: 'Open Library', configured: false, demoAvailable: true },
      { provider: 'TMDB', configured: false, demoAvailable: true },
      { provider: 'IGDB', configured: false, demoAvailable: true }
    ]);
    assert(matrix.length === 4 && matrix.every(x => x.offlineTest && x.liveAcceptance), 'acceptance matrix incomplete');
    checks.push('acceptance matrix');

    const composed = reliability.providerStatus('TMDB', { provider: 'TMDB', configured: false });
    assert(composed.provider === 'TMDB' && composed.reliability.provider === 'TMDB' && composed.policy.provider === 'TMDB', 'provider status composition failed');
    checks.push('provider status composition');
  } finally {
    reliability.restore(before);
  }
  console.log(JSON.stringify({ version: '0.61', mode: 'offline', passed: checks.length, total: 8, checks }, null, 2));
}

try { main(); } catch (e) { console.error(e.stack || e.message); process.exitCode = 1; }
