const asianDramas = require('../lib/asian-dramas');
const result = asianDramas.selfTest();
for (const check of result.checks) console.log(`${check.ok ? 'PASS' : 'FAIL'} ${check.name}`);
process.exit(result.passed ? 0 : 1);
