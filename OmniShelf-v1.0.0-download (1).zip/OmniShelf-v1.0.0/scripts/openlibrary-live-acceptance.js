#!/usr/bin/env node
const openLibrary = require('../lib/openlibrary');

async function main() {
  if (process.argv.includes('--plan')) {
    console.log(JSON.stringify({mode:'plan',provider:'Open Library',readOnly:true,steps:[
      'Search one human-requested query via search.json',
      'Resolve one work when returned',
      'Resolve one edition when available',
      'Resolve one author when available',
      'Resolve one ISBN when available',
      'Resolve one Work → Edition relationship set when a Work is returned',
      'Verify cover URL policy uses covers.openlibrary.org and does not persist image bytes'
    ],rateLimited:true,cached:true}, null, 2));
    return;
  }
  try {
    const r = await openLibrary.liveAcceptance({query:process.env.OPENLIBRARY_ACCEPTANCE_QUERY || 'The Lord of the Rings'});
    console.log(JSON.stringify(r,null,2));
    process.exitCode = 0;
  } catch (e) {
    console.error(JSON.stringify({status:'blocked_or_failed',provider:'Open Library',error:e.message},null,2));
    process.exitCode = e.status === 503 ? 3 : 2;
  }
}
main();
