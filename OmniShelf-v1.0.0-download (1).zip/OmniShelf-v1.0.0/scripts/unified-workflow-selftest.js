const workflow = require('../lib/unified-workflow');
const result = workflow.selfTest();
console.log(JSON.stringify({version:'1.0',mode:'deterministic',...result},null,2));
process.exit(result.passed?0:1);
