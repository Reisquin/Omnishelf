const workPages=require('../lib/work-pages');
const r=workPages.selfTest();
console.log(JSON.stringify(r,null,2));
if(!r.passed) process.exit(1);
