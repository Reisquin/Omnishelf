const fs=require('fs');
const path=require('path');
const os=require('os');
const cp=require('child_process');
const {setTimeout:delay}=require('timers/promises');

async function waitFor(url,timeout=8000){const start=Date.now();while(Date.now()-start<timeout){try{const r=await fetch(url);if(r.ok)return;}catch{}await delay(100);}throw new Error('Server did not become ready');}
async function req(base,route,options){const r=await fetch(base+route,{headers:{'Content-Type':'application/json'},...options});const t=await r.text();let d={};try{d=t?JSON.parse(t):{};}catch{d={raw:t};}if(!r.ok)throw new Error(`${route}: ${d.error||r.status}`);return d;}

(async()=>{
  const source=path.resolve(__dirname,'..');
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'omni-v072-library-collections-'));
  const dest=path.join(tmp,'OmniShelf-v1.0');
  fs.cpSync(source,dest,{recursive:true});
  const dataPath=path.join(dest,'data','store.json');
  const data=JSON.parse(fs.readFileSync(dataPath,'utf8'));
  data.catalog=[];data.reviewQueue=[];data.auditLog=[];data.collections=[];data.smartCollections=[];data.library={version:1,profile:{name:'You'},items:{},history:{version:1,events:[]},smartCollections:[]};
  fs.writeFileSync(dataPath,JSON.stringify(data,null,2)+'\n');
  const port=Number(process.env.OMNI_E2E_PORT||31970)+Math.floor(Math.random()*1000);
  const child=cp.spawn(process.execPath,['server.js'],{cwd:dest,env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',b=>stderr+=b.toString());
  const base=`http://127.0.0.1:${port}`;
  try{
    await waitFor(base+'/api/health');
    const checks=[];const mark=(name,ok,detail='')=>{checks.push({name,ok,detail});if(!ok)throw new Error(name+(detail?`: ${detail}`:''));};
    const initial=await req(base,'/api/library/collections');
    mark('built-in-presets',initial.presets.length===6&&initial.items.length===0);
    const a=await req(base,'/api/catalog',{method:'POST',body:JSON.stringify({title:'Demo Anime',type:'Anime',year:2026,provider:'TMDB',providerId:'7201',tags:['Action'],providerMetadata:{anilist:{episodes:12}}})});
    const b=await req(base,'/api/catalog',{method:'POST',body:JSON.stringify({title:'Demo Novel',type:'Novel',year:2025,provider:'Open Library',providerId:'OL7202',providerMetadata:{openLibrary:{pages:240}}})});
    mark('catalog-seed',!!a.id&&!!b.id);
    await req(base,'/api/library/'+encodeURIComponent(a.id),{method:'PUT',body:JSON.stringify({status:'active',progress:6,favorite:true,score:95,notes:'keep'} )});
    await req(base,'/api/library/'+encodeURIComponent(b.id),{method:'PUT',body:JSON.stringify({status:'completed',progress:240,progressTotal:240,progressUnit:'pages',score:88})});
    const custom=await req(base,'/api/library/collections',{method:'POST',body:JSON.stringify({name:'Top Anime',description:'High rated anime',rules:{mode:'all',type:'Anime',scoreMin:90}})});
    const cid=custom.collection.id;
    mark('custom-create',!!cid&&custom.collection.itemCount===1&&custom.collection.items.length===1);
    const list=await req(base,'/api/library/collections');
    mark('collection-list',list.items.length===1&&list.items[0].itemCount===1&&list.items[0].stats.averageScore===95);
    const filtered=await req(base,'/api/library?collection='+encodeURIComponent(cid));
    mark('collection-filter',filtered.total===1&&filtered.items[0].catalog.title==='Demo Anime'&&filtered.collection===cid);
    const fav=await req(base,'/api/library?collection=preset%3Afavorites');
    mark('favorite-preset-filter',fav.total===1&&fav.items[0].record.favorite===true);
    const changed=await req(base,'/api/library/'+encodeURIComponent(a.id),{method:'PUT',body:JSON.stringify({score:80,favorite:false,status:'completed',progress:12,progressTotal:12,progressUnit:'episodes'})});
    mark('dynamic-membership',changed.library.record.score===80);
    const after=await req(base,'/api/library/collections/'+encodeURIComponent(cid));
    mark('dynamic-reevaluation',after.collection.itemCount===0&&after.collection.items.length===0);
    await req(base,'/api/library/collections/'+encodeURIComponent(cid),{method:'PATCH',body:JSON.stringify({rules:{mode:'all',type:'Anime',status:'completed'}})});
    const reopened=await req(base,'/api/library/collections/'+encodeURIComponent(cid));
    mark('collection-update',reopened.collection.itemCount===1&&reopened.collection.items[0].id===a.id);
    const fromFilters=await req(base,'/api/library/collections/from-filters',{method:'POST',body:JSON.stringify({name:'Completed Now',filters:{status:'completed'}})});
    mark('save-from-filters',fromFilters.collection.rules.status==='completed'&&fromFilters.collection.itemCount===2);
    const all=await req(base,'/api/library/collections');
    mark('two-custom-collections',all.items.length===2);
    const backup=await req(base,'/api/data/export?scope=full');
    mark('backup-preservation',backup.library?.smartCollections?.length===2&&Object.keys(backup.library.items||{}).length===2);
    await req(base,'/api/library/collections/'+encodeURIComponent(cid),{method:'DELETE'});
    const afterDelete=await req(base,'/api/library/collections');
    mark('delete-custom',afterDelete.items.length===1);
    const restorePreview=await req(base,'/api/data/restore/preview',{method:'POST',body:JSON.stringify({content:JSON.stringify(backup)})});
    mark('restore-preview',restorePreview.catalog===2&&restorePreview.library?.items===2);
    await req(base,'/api/data/restore/apply',{method:'POST',body:JSON.stringify({content:JSON.stringify(backup),confirm:'RESTORE OMNISHELF'})});
    const restoredCollections=await req(base,'/api/library/collections');
    mark('restore-custom-collections',restoredCollections.items.length===2&&restoredCollections.items.every(x=>x.itemCount>=0));
    const ui=await fetch(base+'/?view=library');
    const html=await ui.text();
    mark('library-ui',ui.ok&&html.includes('Smart Library Collections')&&html.includes('libraryCollectionFilter'));
    const work=await req(base,'/api/catalog/'+encodeURIComponent(a.id)+'/work-page');
    mark('work-page-version',work.version==='1.0'&&work.library.present===true);
    console.log(JSON.stringify({suite:'personal-library-collections-http-e2e-v1.0',passed:true,checks:checks.length,details:checks}));
  }catch(e){console.error(JSON.stringify({suite:'personal-library-collections-http-e2e-v1.0',passed:false,error:e.message,stderr}));process.exitCode=1;}
  finally{child.kill('SIGTERM');await delay(100);fs.rmSync(tmp,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1});
