const recommendations=require('../lib/recommendations'); const r=recommendations.selfTest(); console.log(JSON.stringify({suite:'recommendations',...r})); if(!r.passed)process.exit(1);
