const fs=require('fs');
const s=fs.readFileSync(require('path').join(__dirname,'../public/index.html'),'utf8');
const checks=[
  ['catalog-view-controls',s.includes('catalogViewMode')||s.includes('catalog-view')],
  ['work-page-route-client',s.includes('openWorkPage')],
  ['rich-work-modal',s.includes('workPageModal')],
  ['catalog-card-render',s.includes('catalog-card')&&s.includes("catalogViewMode==='cards'")],
  ['medium-quick-filter',s.includes('catalogQuickMedium')]
];
const passed=checks.every(([,ok])=>ok);
console.log(JSON.stringify({passed,count:checks.length,checks:checks.map(([name,ok])=>({name,ok}))},null,2));
if(!passed) process.exit(1);
