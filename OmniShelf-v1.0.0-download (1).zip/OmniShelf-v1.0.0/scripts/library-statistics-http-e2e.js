const fs=require('fs');
const path=require('path');
const os=require('os');
const cp=require('child_process');
const {setTimeout:delay}=require('timers/promises');
async function waitFor(url,timeout=8000){const start=Date.now();while(Date.now()-start<timeout){try{const r=await fetch(url);if(r.ok)return;}catch{}await delay(100);}throw new Error('Server did not become ready');}
async function req(base,route,options){const r=await fetch(base+route,{headers:{'Content-Type':'application/json'},...options});const t=await r.text();let d={};try{d=t?JSON.parse(t):{};}catch{d={raw:t};}if(!r.ok)throw new Error(`${route}: ${d.error||r.status}`);return d;}
(async()=>{
  const source=path.resolve(__dirname,'..');
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'omni-v075-library-statistics-'));
  const dest=path.join(tmp,'OmniShelf-v1.0');
  fs.cpSync(source,dest,{recursive:true});
  const dataPath=path.join(dest,'data','store.json');
  const data=JSON.parse(fs.readFileSync(dataPath,'utf8'));
  data.catalog=[];data.reviewQueue=[];data.auditLog=[];data.collections=[];data.smartCollections=[];data.library={version:1,profile:{name:'You'},items:{},history:{version:1,events:[]},smartCollections:[]};
  fs.writeFileSync(dataPath,JSON.stringify(data,null,2)+'\n');
  const port=Number(process.env.OMNI_E2E_PORT||32170)+Math.floor(Math.random()*1000);
  const child=cp.spawn(process.execPath,['server.js'],{cwd:dest,env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',b=>stderr+=b.toString());
  const base=`http://127.0.0.1:${port}`;
  try{
    await waitFor(base+'/api/health');
    const checks=[];const mark=(name,ok,detail='')=>{checks.push({name,ok,detail});if(!ok)throw new Error(name+(detail?`: ${detail}`:''));};
    const empty=await req(base,'/api/library/statistics?months=6&calendarDays=30');
    mark('empty-statistics',empty.version==='1.0'&&empty.totals.tracked===0&&empty.monthly.length===6&&empty.activityCalendar.days.length===30);
    const a=await req(base,'/api/catalog',{method:'POST',body:JSON.stringify({title:'Stats Anime',type:'Anime',year:2026,provider:'AniList',providerId:'7301',tags:['Action'],providerMetadata:{anilist:{episodes:12}}})});
    const b=await req(base,'/api/catalog',{method:'POST',body:JSON.stringify({title:'Stats Novel',type:'Novel',year:2026,provider:'Open Library',providerId:'7302',tags:['Drama'],providerMetadata:{openLibrary:{pages:300}}})});
    const c=await req(base,'/api/catalog',{method:'POST',body:JSON.stringify({title:'Stats Movie',type:'Movie',year:2025,provider:'TMDB',providerId:'7303'})});
    mark('catalog-seed',!!a.id&&!!b.id&&!!c.id);
    await req(base,'/api/library/'+a.id,{method:'PUT',body:JSON.stringify({status:'active',progress:3,score:90,favorite:true})});
    await req(base,'/api/library/'+b.id,{method:'PUT',body:JSON.stringify({status:'planning',progress:0,progressTotal:300,progressUnit:'pages',score:80})});
    await req(base,'/api/library/'+c.id,{method:'PUT',body:JSON.stringify({status:'completed',progress:1,progressTotal:1,progressUnit:'viewings',score:100})});
    await req(base,'/api/library/'+a.id+'/advance',{method:'POST',body:JSON.stringify({delta:1})});
    await req(base,'/api/library/'+a.id,{method:'PUT',body:JSON.stringify({status:'completed',progress:12,progressTotal:12,progressUnit:'episodes',score:95,favorite:true})});
    const stats=await req(base,'/api/library/statistics?months=6&calendarDays=30');
    mark('totals',stats.totals.tracked===3&&stats.totals.completed===2&&stats.totals.favorites===1&&stats.totals.averageScore===91.7);
    mark('median-score',stats.totals.medianScore===95);
    mark('progress-units',stats.progressByUnit.some(x=>x.unit==='episodes'&&x.progress===12)&&stats.progressByUnit.some(x=>x.unit==='pages'&&x.progress===0));
    const oct=stats.monthly[stats.monthly.length-1];
    mark('monthly-activity',oct.added===3&&oct.completed===2&&oct.progressUnitsRecorded===1&&oct.activeDays===1);
    mark('medium-breakdown',stats.medium.length===3&&stats.medium.find(x=>x.type==='Anime')?.averageScore===95);
    mark('score-distribution',stats.scoreDistribution.find(x=>x.label==='91–100')?.count===2&&stats.scoreDistribution.find(x=>x.label==='71–80')?.count===1);
    mark('lifecycle',stats.lifecycle.uniqueAdded===3&&stats.lifecycle.uniqueCompleted===2&&stats.lifecycle.currentTracked===3);
    mark('calendar',stats.activityCalendar.activeDays===1&&stats.activityCalendar.max>=1);
    const self=await req(base,'/api/library/statistics/selftest',{method:'POST',body:JSON.stringify({})});
    mark('server-selftest',self.passed===true&&self.count===14);
    const overview=await req(base,'/api/library/overview?limit=6');
    mark('overview-intact',overview.version==='1.0'&&overview.stats.count===3);
    const work=await req(base,'/api/catalog/'+encodeURIComponent(a.id)+'/work-page');
    mark('work-page-version',work.version==='1.0'&&work.library.present===true&&Array.isArray(work.libraryHistory.items));
    const ui=await fetch(base+'/?view=statistics');const html=await ui.text();
    mark('statistics-ui',ui.ok&&html.includes('Your personal analytics')&&html.includes('statisticsTab')&&html.includes('libraryStatsTrend'));
    const backup=await req(base,'/api/data/export?scope=full');
    mark('backup-preservation',backup.library?.items&&Object.keys(backup.library.items).length===3&&backup.library.history?.events?.length>=6);
    console.log(JSON.stringify({suite:'personal-library-statistics-http-e2e-v1.0',passed:true,checks:checks.length,details:checks}));
  }catch(e){console.error(JSON.stringify({suite:'personal-library-statistics-http-e2e-v1.0',passed:false,error:e.message,stderr}));process.exitCode=1;}
  finally{child.kill('SIGTERM');await delay(100);fs.rmSync(tmp,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1});
