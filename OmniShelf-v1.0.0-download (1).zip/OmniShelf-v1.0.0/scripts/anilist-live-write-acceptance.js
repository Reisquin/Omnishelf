#!/usr/bin/env node
const crypto = require('crypto');
const anilist = require('../lib/anilist');

const args = new Set(process.argv.slice(2));
const planOnly = args.has('--plan') || !args.has('--confirm-write');
const includeFavourite = args.has('--include-favourite');
const mediaArg = process.argv.find(x => x.startsWith('--media-id='));
const mediaId = Number(mediaArg ? mediaArg.split('=')[1] : process.env.ANILIST_WRITE_TEST_MEDIA_ID || 0);
const requiredFlag = String(process.env.ANILIST_WRITE_ACCEPTANCE || '').toLowerCase() === 'true';

function out(v) { console.log(JSON.stringify(v, null, 2)); }
function fail(message, status=2) { out({status:'failed', message}); process.exitCode=status; }
function same(a,b) { return JSON.stringify(a) === JSON.stringify(b); }
function fuzzyDate(x) { return x ? {year:x.year??null, month:x.month??null, day:x.day??null} : null; }
function stateFromEntry(e) {
  return {
    id:e?.id ?? null,
    mediaId:e?.mediaId ?? null,
    status:e?.status ?? null,
    score:e?.score ?? null,
    progress:e?.progress ?? null,
    progressVolumes:e?.progressVolumes ?? null,
    repeat:e?.repeat ?? null,
    priority:e?.priority ?? null,
    private:e?.private ?? null,
    notes:e?.notes ?? null,
    hiddenFromStatusLists:e?.hiddenFromStatusLists ?? null,
    customLists:e?.customLists ?? null,
    advancedScores:e?.advancedScores ?? null,
    startedAt:fuzzyDate(e?.startedAt),
    completedAt:fuzzyDate(e?.completedAt),
  };
}

async function readEntry(viewerId, mid) {
  const query = `query($userId:Int!,$mediaId:Int!){ MediaList(userId:$userId,mediaId:$mediaId){ id userId mediaId status score format progress progressVolumes repeat priority private notes hiddenFromStatusLists customLists advancedScores startedAt{year month day} completedAt{year month day} updatedAt createdAt media{id type title{userPreferred romaji english native} isAdult} } }`;
  const r = await anilist.graph(query, {userId:Number(viewerId), mediaId:Number(mid)}, {cache:false,allowRetry:false,timeoutMs:12000});
  return {entry:r.data?.MediaList||null, rateLimit:r.rateLimit};
}

async function readMedia(mid) {
  const query = `query($id:Int!){ Media(id:$id){ id type format isAdult title{userPreferred} } }`;
  const r = await anilist.graph(query, {id:Number(mid)}, {cache:false,allowRetry:false,timeoutMs:12000});
  return {media:r.data?.Media||null, rateLimit:r.rateLimit};
}

async function readFavourite(mid) {
  const query = `query($id:Int!){ Media(id:$id){ id isFavourite isFavouriteBlocked } }`;
  const r = await anilist.graph(query, {id:Number(mid)}, {cache:false,allowRetry:false,timeoutMs:12000});
  return {media:r.data?.Media||null, rateLimit:r.rateLimit};
}

async function saveList(vars) {
  return anilist.graph(anilist.SAVE_LIST_MUTATION, vars, {cache:false,allowRetry:false,timeoutMs:12000});
}

async function updateLists(vars) {
  return anilist.graph(anilist.UPDATE_LISTS_MUTATION, vars, {cache:false,allowRetry:false,timeoutMs:12000});
}

async function deleteList(id) {
  return anilist.graph(anilist.DELETE_LIST_MUTATION, {id:Number(id)}, {cache:false,allowRetry:false,timeoutMs:12000});
}

async function toggleFavourite(mid, type) {
  const vars = type === 'MANGA' ? {mangaId:Number(mid)} : {animeId:Number(mid)};
  return anilist.graph(anilist.TOGGLE_FAVOURITE_MUTATION, vars, {cache:false,allowRetry:false,timeoutMs:12000});
}

(async()=>{
  if(!mediaId) return fail('A test media ID is required. Set ANILIST_WRITE_TEST_MEDIA_ID or pass --media-id=<AniList media ID>.', 2);
  const plan = {
    mediaId,
    includeFavourite,
    steps:[
      'Authenticate and resolve Viewer',
      'Read exact Media and existing MediaList entry before changes',
      'If no entry exists: create a temporary PLANNING entry with a unique acceptance note',
      'Exercise UpdateMediaListEntries on that entry',
      'Delete the temporary entry and verify it is gone',
      'If an entry already exists: change only priority, then restore the exact captured priority/state',
      includeFavourite ? 'ToggleFavourite twice and verify the original favourite state is restored' : 'Skip favourite write probe unless --include-favourite is supplied',
      'Emit a machine-readable report without exposing the access token',
    ]
  };

  if(planOnly){
    return out({status:'planned',writeEnabled:false,required:{ANILIST_WRITE_ACCEPTANCE:true,confirmFlag:'--confirm-write'},plan});
  }
  if(!requiredFlag) return fail('Refusing to write: set ANILIST_WRITE_ACCEPTANCE=true.', 3);
  if(!args.has('--confirm-write')) return fail('Refusing to write: pass --confirm-write explicitly.', 3);
  const policy=anilist.liveAccessPolicy();
  if(!policy.liveEnabled) return fail('Refusing to write: AniList live access is disabled by the compliance gate.', 3);

  const auth = await anilist.authStatus();
  if(!auth.authenticated) return fail('Authenticated AniList session required for write acceptance.', 3);
  const viewerId = auth.viewer.id;
  const runId = crypto.randomUUID();
  const startedAt = new Date().toISOString();
  const report={status:'passed',runId,startedAt,viewer:{id:viewerId,name:auth.viewer.name},mediaId,steps:[],rateLimits:[]};
  let createdEntryId=null;
  let existing=null;
  let originalState=null;
  try {
    const media=await readMedia(mediaId); report.steps.push({name:'media-read',status:'passed',media:media.media}); report.rateLimits.push(media.rateLimit);
    if(!media.media) throw new Error('AniList Media record not found');
    const before=await readEntry(viewerId,mediaId); existing=before.entry; originalState=stateFromEntry(existing); report.steps.push({name:'list-entry-before',status:'passed',exists:Boolean(existing),state:originalState}); report.rateLimits.push(before.rateLimit);

    if(existing){
      const probePriority = existing.priority === 255 ? 254 : (existing.priority || 0) + 1;
      const s=await saveList({id:Number(existing.id),mediaId:Number(mediaId),priority:probePriority});
      report.rateLimits.push(s.rateLimit);
      const afterSave=await readEntry(viewerId,mediaId); report.rateLimits.push(afterSave.rateLimit);
      if(Number(afterSave.entry?.priority)!==Number(probePriority)) throw new Error(`Priority probe did not apply (expected ${probePriority}, got ${afterSave.entry?.priority})`);
      report.steps.push({name:'save-existing-probe',status:'passed',probePriority});
      const u=await updateLists({ids:[Number(existing.id)],priority:Number(existing.priority||0)});
      report.rateLimits.push(u.rateLimit);
      const restored=await readEntry(viewerId,mediaId); report.rateLimits.push(restored.rateLimit);
      if(!same(stateFromEntry(restored.entry),originalState)) throw new Error('Existing list entry did not restore to its exact original mutable state');
      report.steps.push({name:'bulk-update-restore',status:'passed'});
    } else {
      const note=`OmniShelf live write acceptance ${runId}`;
      const s=await saveList({mediaId:Number(mediaId),status:'PLANNING',progress:0,progressVolumes:0,repeat:0,priority:0,private:false,notes:note,hiddenFromStatusLists:false});
      report.rateLimits.push(s.rateLimit);
      createdEntryId=s.data?.SaveMediaListEntry?.id;
      if(!createdEntryId) throw new Error('SaveMediaListEntry did not return a list entry ID');
      const afterCreate=await readEntry(viewerId,mediaId); report.rateLimits.push(afterCreate.rateLimit);
      if(Number(afterCreate.entry?.id)!==Number(createdEntryId)) throw new Error('Created list entry could not be read back');
      report.steps.push({name:'create-temporary-entry',status:'passed',entryId:createdEntryId});
      const u=await updateLists({ids:[Number(createdEntryId)],status:'CURRENT'});
      report.rateLimits.push(u.rateLimit);
      const afterBulk=await readEntry(viewerId,mediaId); report.rateLimits.push(afterBulk.rateLimit);
      if(afterBulk.entry?.status!=='CURRENT') throw new Error(`UpdateMediaListEntries did not apply (got ${afterBulk.entry?.status})`);
      report.steps.push({name:'bulk-update-temporary-entry',status:'passed',statusAfter:'CURRENT'});
      const del=await deleteList(createdEntryId); report.rateLimits.push(del.rateLimit);
      const afterDelete=await readEntry(viewerId,mediaId); report.rateLimits.push(afterDelete.rateLimit);
      if(afterDelete.entry) throw new Error('DeleteMediaListEntry did not remove the temporary entry');
      createdEntryId=null;
      report.steps.push({name:'delete-temporary-entry',status:'passed'});
    }

    if(includeFavourite){
      const fav=await readFavourite(mediaId); report.rateLimits.push(fav.rateLimit);
      if(fav.media?.isFavouriteBlocked){ report.steps.push({name:'favourite-roundtrip',status:'skipped',reason:'AniList marks this media as favourite-blocked'}); }
      else {
        const original=Boolean(fav.media?.isFavourite);
        await toggleFavourite(mediaId,media.media.type); const mid1=await readFavourite(mediaId); report.rateLimits.push(mid1.rateLimit);
        await toggleFavourite(mediaId,media.media.type); const mid2=await readFavourite(mediaId); report.rateLimits.push(mid2.rateLimit);
        if(Boolean(mid2.media?.isFavourite)!==original) throw new Error('Favourite state was not restored to its original value');
        report.steps.push({name:'favourite-roundtrip',status:'passed',original});
      }
    }
    report.finishedAt=new Date().toISOString();
    report.rateLimits=report.rateLimits.filter(Boolean);
    return out(report);
  } catch(e){
    report.status='failed'; report.error=e.message;
    try {
      if(createdEntryId) { await deleteList(createdEntryId); report.cleanup='attempted'; }
      if(existing && originalState) {
        await saveList({id:Number(originalState.id),mediaId:Number(mediaId),priority:originalState.priority===null?undefined:originalState.priority});
        const restored=await readEntry(viewerId,mediaId); if(same(stateFromEntry(restored.entry),originalState)) report.recovery='original-state-restored-after-error'; else report.recovery='manual-check-required';
      }
    } catch(cleanErr) { report.cleanupError=cleanErr.message; }
    return out(report);
  }
})().catch(err=>{console.error(err.stack||err);process.exitCode=1;});
