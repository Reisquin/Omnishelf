const unified = require('../lib/unified-search');
const identity = require('../lib/identity');
const store = require('../lib/store');

function ok(name, condition, detail='') { if (!condition) throw new Error(`${name} failed${detail ? `: ${detail}` : ''}`); return {name, status:'passed', detail}; }

async function main() {
  const tests=[];
  const data=store.read();

  const broad = unified.route({query:'Dune',type:'all'});
  tests.push(ok('Broad routing', broad.providers.length===4, broad.providers.join(', ')));
  const game = unified.route({query:'Dune',type:'Game'});
  tests.push(ok('Game routing', game.providers.length===1 && game.providers[0]==='IGDB', game.reason));
  const drama = unified.route({query:'My Drama',type:'Drama'});
  tests.push(ok('Drama routing', drama.providers.length===1 && drama.providers[0]==='TMDB', drama.reason));
  const isbn = unified.route({query:'9780000000001',type:'all'});
  tests.push(ok('ISBN routing', isbn.providers.length===1 && isbn.providers[0]==='Open Library', isbn.reason));
  const explicit = unified.route({query:'Dune',type:'all',providers:'TMDB,IGDB'});
  tests.push(ok('Explicit routing', explicit.providers.join('|')==='TMDB|IGDB', explicit.reason));

  const demo = await unified.searchUnified({query:'Dune',type:'all',limit:8,demo:true,catalog:data.catalog,data,includeCatalog:true});
  tests.push(ok('Four-provider demo fanout', demo.totals.providersQueried===4 && demo.totals.providersFulfilled===4, JSON.stringify(demo.providerSummary)));
  tests.push(ok('Demo has provider results', demo.totals.providerResults>=8, String(demo.totals.providerResults)));
  tests.push(ok('Demo is non-persistent', store.read().catalog.length===data.catalog.length && (store.read().identity?.groups||[]).length===(data.identity?.groups||[]).length));
  tests.push(ok('Provider failures are represented', demo.providerSummary.every(x=>['fulfilled','rejected'].includes(x.status))));
  tests.push(ok('Search results have stable IDs', demo.results.every(x=>String(x.resultId).includes(':'))));
  tests.push(ok('Catalog can be excluded', (await unified.searchUnified({query:'Dune',type:'all',limit:4,demo:true,catalog:data.catalog,data,includeCatalog:false})).totals.catalogResults===0));

  const sameA={provider:'TMDB',providerId:'1',title:'The Same Work',type:'Movie',year:2020,aliases:[],creators:[],externalLinks:[],providerMetadata:{tmdb:{id:1,mediaType:'movie'}}};
  const sameB={provider:'Open Library',providerId:'OL1W',title:'The Same Work',type:'Novel',year:2020,aliases:[],creators:[],externalLinks:[],providerMetadata:{openLibrary:{workId:'OL1W'}}};
  const conflict=identity.compare(sameA,sameB);
  tests.push(ok('Type mismatch remains conservative', conflict.confidence!=='high' && conflict.confidence!=='exact-external', `${conflict.score} ${conflict.confidence}`));

  const clusterDemo=await unified.searchUnified({query:'Dune',type:'all',limit:12,demo:true,catalog:[sameA,sameB],data:{catalog:[sameA,sameB],identity:{groups:[],decisions:[],runs:[],candidates:[]}},includeCatalog:true});
  tests.push(ok('Cross-provider grouping is non-persistent', clusterDemo.totals.clusters>=1 && (store.read().identity?.groups||[]).length===(data.identity?.groups||[]).length));

  console.log(JSON.stringify({version:'0.62',suite:'unified-search',passed:tests.length,tests},null,2));
}
main().catch(e=>{console.error(e.stack||e.message);process.exit(1);});
