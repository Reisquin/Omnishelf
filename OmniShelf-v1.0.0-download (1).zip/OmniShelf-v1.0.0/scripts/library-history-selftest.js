const history=require('../lib/library-history');
const r=history.selfTest();
console.log(JSON.stringify({suite:'personal-library-history',...r}));
if(!r.passed)process.exitCode=1;
