const enrichment = require('../lib/enrichment');

function assert(cond, msg){ if(!cond) throw new Error(msg); }
function run(){
  const demo=enrichment.demoPlan();
  const plan=demo.plan;
  assert(plan.groupId==='demo-group','group id');
  assert(plan.targetCatalogId==='demo-manual','target selection');
  const title=plan.fields.find(x=>x.field==='title');
  assert(title.proposed==='The Glass Ocean','preferred title');
  assert(title.selectedSource.provider==='Manual','title preference');
  const year=plan.fields.find(x=>x.field==='year');
  assert(year.proposed===2023,'preferred year');
  assert(plan.fields.find(x=>x.field==='tags').proposed.includes('Drama'),'array union');
  assert(plan.fields.find(x=>x.field==='tags').proposed.includes('Sea'),'array union from OL');
  const type=plan.fields.find(x=>x.field==='type');
  assert(type.conflicts.length===2,'type conflict buckets expected');
  assert(plan.unresolvedConflicts.includes('type'),'unresolved conflict surfaced');
  assert(plan.providerCoverage.length===4,'provider coverage');
  assert(/^([a-f0-9]{64})$/.test(plan.planHash),'plan hash');
  const data=JSON.parse(JSON.stringify({catalog:demo.plan.fields ? [
    {id:'demo-manual',provider:'Manual',title:'The Glass Ocean',type:'Novel',year:2023,description:'A hand-curated description.',creators:['Mira Sen'],tags:['Mystery','Ocean'],aliases:['Glass Ocean'],coverUrl:'/demo/manual.svg',updatedAt:'2026-10-06T10:00:00.000Z'}
  ]:[],identity:{version:1,groups:[{id:'demo-group',members:['demo-manual','demo-al','demo-ol','demo-tmdb'],fieldPreferences:{title:'demo-manual',description:'demo-manual',year:'demo-manual',coverUrl:'demo-al'}}]},enrichment:{version:1,runs:[]}}));
  const items=demo.plan.fields?[
    {id:'demo-manual',provider:'Manual',title:'The Glass Ocean',type:'Novel',year:2023,description:'A hand-curated description.',creators:['Mira Sen'],tags:['Mystery','Ocean'],aliases:['Glass Ocean'],coverUrl:'/demo/manual.svg',updatedAt:'2026-10-06T10:00:00.000Z'},
    {id:'demo-al',provider:'AniList',providerId:'7001',title:'The Glass Ocean',type:'Novel',year:2023,description:'A mysterious story at sea.',creators:['Mira Sen'],tags:['Mystery','Drama'],aliases:['Glass Ocean'],coverUrl:'/demo/anilist/cover.svg'},
    {id:'demo-ol',provider:'Open Library',providerId:'OL7001W',title:'The Glass Ocean',type:'Novel',year:2023,description:'A novel of secrets and tides.',creators:['Mira Sen'],tags:['Mystery','Sea'],aliases:['The Glass Ocean'],coverUrl:'https://covers.openlibrary.org/b/isbn/9787001000001-L.jpg',externalLinks:['https://openlibrary.org/works/OL7001W']},
    {id:'demo-tmdb',provider:'TMDB',providerId:'7001',title:'The Glass Ocean',type:'Movie',year:2024,description:'A film adaptation of the novel.',creators:['Mira Sen'],tags:['Drama','Mystery'],aliases:['Glass Ocean'],coverUrl:'https://image.tmdb.org/t/p/w500/demo.jpg'}
  ]:[];
  data.catalog.push(...items.slice(1));
  const applied=enrichment.applyPlan(data,plan,{expectedUpdatedAt:'2026-10-06T10:00:00.000Z',planHash:plan.planHash});
  assert(applied.item.tags.includes('Drama') && applied.item.tags.includes('Sea'),'applied array merge');
  assert(applied.item.enrichment.identityGroupId==='demo-group','enrichment lineage');
  assert(applied.item.enrichment.fieldProvenance.description.sources.length===4,'field provenance');
  assert(data.enrichment.runs.length===1,'run persisted');
  console.log(JSON.stringify({passed:10,checks:[
    'identity-group plan', 'field preference resolution', 'array union', 'conflict surfacing', 'provider coverage', 'deterministic plan hash', 'apply safety check', 'field-level provenance', 'run journal', 'demo neutrality'
  ]},null,2));
}
try{run();}catch(e){console.error(e.stack);process.exit(1);}
