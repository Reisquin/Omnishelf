const igdb = require('../lib/igdb');

function hasFlag(name) { return process.argv.includes(name); }

async function main() {
  if (hasFlag('--plan')) {
    console.log(JSON.stringify(igdb.acceptancePlan(), null, 2));
    return;
  }
  const queryArg = process.argv.find(x => x.startsWith('--query='));
  const query = queryArg ? queryArg.slice('--query='.length) : 'The Legend of Zelda';
  const result = await igdb.liveAcceptance({ query });
  console.log(JSON.stringify(result, null, 2));
  if (result.mode === 'blocked' || result.blocked > 0) process.exitCode = 2;
}

main().catch(error => {
  console.error(JSON.stringify({ provider: 'IGDB', status: 'error', message: error.message }, null, 2));
  process.exitCode = 1;
});
