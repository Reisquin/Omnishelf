const mediumPersonal = require('../lib/medium-personal-experiences');
const result = mediumPersonal.selfTest();
console.log(JSON.stringify({version:'1.0',suite:'medium-personal',mode:'deterministic',...result},null,2));
process.exit(result.passed?0:1);
