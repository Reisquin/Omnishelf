#!/usr/bin/env node
const {runFullReadAcceptance}=require('../lib/anilist');
(async()=>{try{const r=await runFullReadAcceptance({timeoutMs:8000});console.log(JSON.stringify(r,null,2));if(r.summary?.blocked)process.exit(3);if(r.summary?.failed)process.exit(2);}catch(e){console.error(e.stack||e);process.exit(1);}})();
