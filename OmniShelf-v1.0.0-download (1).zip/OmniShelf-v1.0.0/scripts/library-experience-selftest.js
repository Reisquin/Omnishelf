const experience=require('../lib/library-experience');
const r=experience.selfTest();
console.log(JSON.stringify({suite:'personal-library-experience',...r}));
if(!r.passed)process.exitCode=1;
