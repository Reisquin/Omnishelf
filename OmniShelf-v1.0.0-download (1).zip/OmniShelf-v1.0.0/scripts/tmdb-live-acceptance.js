const tmdb = require('../lib/tmdb');

function hasFlag(name) { return process.argv.includes(name); }

async function main() {
  if (hasFlag('--plan')) {
    console.log(JSON.stringify(tmdb.acceptancePlan(), null, 2));
    return;
  }
  const queryArg = process.argv.find(x => x.startsWith('--query='));
  const query = queryArg ? queryArg.slice('--query='.length) : 'Inception';
  const result = await tmdb.liveAcceptance({ query });
  console.log(JSON.stringify(result, null, 2));
  if (result.mode === 'blocked' || result.blocked > 0) process.exitCode = 2;
}

main().catch(error => {
  console.error(JSON.stringify({provider:'TMDB',status:'error',message:error.message}, null, 2));
  process.exitCode = 1;
});
