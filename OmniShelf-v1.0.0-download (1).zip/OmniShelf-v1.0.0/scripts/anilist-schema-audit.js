#!/usr/bin/env node
const {schemaAudit}=require('../lib/anilist');
(async()=>{try{const r=await schemaAudit();console.log(JSON.stringify(r,null,2));process.exit(r.comparison?.status==='drift'?2:0);}catch(e){console.error(JSON.stringify({error:e.message,code:e.code||null,status:e.status||null},null,2));process.exit(e.status===451?3:2);}})();
