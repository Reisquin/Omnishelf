const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');
const http = require('http');

function request(port, method, route, body) {
  return new Promise((resolve, reject) => {
    const payload = body == null ? null : Buffer.from(JSON.stringify(body));
    const req = http.request({host:'127.0.0.1', port, path:route, method, headers: payload ? {'content-type':'application/json','content-length':payload.length} : {}}, res => {
      const chunks=[];
      res.on('data', c=>chunks.push(c));
      res.on('end',()=>{
        const text=Buffer.concat(chunks).toString('utf8');
        let json=null; try { json=JSON.parse(text); } catch {}
        resolve({status:res.statusCode, json, text});
      });
    });
    req.on('error', reject);
    if(payload) req.write(payload);
    req.end();
  });
}

function waitForServer(port, limit=60) {
  return new Promise((resolve,reject)=>{
    let tries=0;
    const tick=async()=>{
      tries++;
      try { const r=await request(port,'GET','/api/health'); if(r.status===200){resolve(); return;} } catch {}
      if(tries>=limit){reject(new Error('server did not become ready')); return;}
      setTimeout(tick,100);
    };
    tick();
  });
}

(async()=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'omnish-v075-workflow-'));
  fs.cpSync(process.cwd(), root, {recursive:true});
  const storePath=path.join(root,'data','store.json');
  const seed=JSON.parse(fs.readFileSync(storePath,'utf8'));
  seed.catalog=[];
  seed.reviewQueue=[];
  seed.auditLog=[];
  seed.collections=[];
  seed.smartCollections=[];
  seed.anilistSyncTombstones=[];
  seed.anilistSyncRuns=[];
  seed.anilistSyncCursors={};
  seed.identity={version:1,groups:[],decisions:[],runs:[],candidates:[]};
  seed.enrichment={version:1,runs:[]};
  seed.library={version:1,profile:{name:'You'},items:{},smartCollections:[],history:{version:1,events:[]}};
  const item={id:'workflow-e2e-work',title:'Workflow E2E Work',type:'Novel',status:'finished',year:2026,description:'Synthetic release test record.',genres:['Drama'],providerMetadata:{}};
  seed.catalog.push(item);
  fs.writeFileSync(storePath, JSON.stringify(seed,null,2));
  const port=39275+Math.floor(Math.random()*1000);
  const child=spawn(process.execPath,['server.js'],{cwd:root,env:{...process.env,PORT:String(port),ANILIST_MODE:'demo'},stdio:['ignore','pipe','pipe']});
  let stderr=''; child.stderr.on('data',d=>stderr+=d.toString());
  try {
    await waitForServer(port);
    const a=await request(port,'GET','/api/catalog/workflow-e2e-work/work-page');
    if(a.status!==200 || !a.json?.workflow || a.json.workflow.version!==1) throw new Error('work-page workflow payload missing');
    const b=await request(port,'GET','/api/catalog/workflow-e2e-work/workflow');
    if(b.status!==200 || b.json?.workflow?.primaryAction?.id!=='add') throw new Error('initial workflow action incorrect');
    const steps=[
      ['add', 'planning'],
      ['start', 'active'],
      ['advance', 'active'],
      ['complete', 'completed'],
    ];
    for(const [action,status] of steps){
      const body=action==='advance'?{action,delta:1}:{action};
      const r=await request(port,'POST','/api/catalog/workflow-e2e-work/workflow/action',body);
      if(r.status!==200) throw new Error(`${action} failed with ${r.status}: ${r.text}`);
      if(r.json?.record?.status!==status) throw new Error(`${action} expected ${status} got ${r.json?.record?.status}`);
    }
    const c=await request(port,'GET','/api/catalog/workflow-e2e-work/workflow');
    if(c.status!==200 || c.json?.workflow?.stages?.find(s=>s.id==='completion')?.state!=='complete') throw new Error('finish stage not complete');
    const audit=await request(port,'GET','/api/audit');
    const workflowAudits=Array.isArray(audit.json)?audit.json.filter(e=>e.action==='workflow.action'&&e.catalogId==='workflow-e2e-work'):[];
    if(workflowAudits.length<4) throw new Error('workflow audit trail missing');
    console.log(JSON.stringify({suite:'v1.0-unified-workflow-http-e2e',passed:8,checks:['work page exposes workflow','workflow endpoint exposes primary action','add','start','advance','complete','finish stage','workflow audit trail']}));
  } finally {
    child.kill('SIGTERM');
    setTimeout(()=>{ if(!child.killed) child.kill('SIGKILL'); },500);
    fs.rmSync(root,{recursive:true,force:true});
  }
})().catch(err=>{ console.error(err.message); process.exitCode=1; });
