const fs=require('fs');
const path=require('path');
const os=require('os');
const cp=require('child_process');
const {setTimeout:delay}=require('timers/promises');

async function waitFor(url,timeout=10000){
  const start=Date.now();
  while(Date.now()-start<timeout){
    try{const r=await fetch(url);if(r.ok)return;}catch{}
    await delay(100);
  }
  throw new Error('Server did not become ready');
}
async function request(base,route,options={}){
  const r=await fetch(base+route,{headers:{'Content-Type':'application/json'},...options});
  const t=await r.text();let body={};try{body=t?JSON.parse(t):{};}catch{body={raw:t};}
  return {status:r.status,body};
}
(async()=>{
  const source=path.resolve(__dirname,'..');
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'omni-v081-medium-'));
  const dest=path.join(tmp,'OmniShelf-v1.0');
  fs.cpSync(source,dest,{recursive:true});
  const dataPath=path.join(dest,'data','store.json');
  const data=JSON.parse(fs.readFileSync(dataPath,'utf8'));
  data.catalog=[
    {id:'anime1',title:'Demo Anime',type:'Anime',year:2026,provider:'Manual',providerId:null,providerMetadata:{anilist:{episodes:12,volumes:3}},tags:['Demo'],creators:['Creator']},
    {id:'manga1',title:'Demo Manga',type:'Manga',year:2025,provider:'Manual',providerId:null,providerMetadata:{anilist:{chapters:120,volumes:10}},tags:['Demo'],creators:['Creator']},
    {id:'movie1',title:'Demo Film',type:'Movie',year:2024,provider:'Manual',providerId:null,tags:['Demo'],creators:['Creator']},
    {id:'game1',title:'Demo Game',type:'Game',year:2023,provider:'Manual',providerId:null,tags:['Demo'],creators:['Creator']},
    {id:'comic1',title:'Demo Comics',type:'Comics',year:2022,provider:'Manual',providerId:null,tags:['Demo'],creators:['Creator']}
  ];
  data.library={version:1,profile:{name:'You'},items:{},history:{version:1,events:[]},smartCollections:[]};
  data.community={version:2,currentUserId:'you',members:{you:{id:'you',name:'You',handle:'you',bio:'',avatarUrl:null}},follows:[],reviews:[],activities:[],reviewLikes:[]};
  fs.writeFileSync(dataPath,JSON.stringify(data,null,2)+'\n');
  const port=Number(process.env.OMNI_E2E_PORT||33178)+Math.floor(Math.random()*400);
  const child=cp.spawn(process.execPath,['server.js'],{cwd:dest,env:{...process.env,PORT:String(port),ANILIST_MODE:'demo',ANILIST_AUTHORIZED_USE:'false'},stdio:['ignore','pipe','pipe']});
  let stderr=''; child.stderr.on('data',b=>stderr+=b.toString());
  const base=`http://127.0.0.1:${port}`; const checks=[];
  const mark=(name,ok,detail='')=>{checks.push({name,ok,detail});if(!ok)throw new Error(name+(detail?`: ${detail}`:''));};
  try{
    await waitFor(base+'/api/health');
    let r=await request(base,'/api/mediums/personal');
    mark('directory-200',r.status===200);
    mark('directory-18',r.body.items?.length===18);
    mark('directory-anime',r.body.items?.find(x=>x.type==='Anime')?.unit==='episodes');
    mark('directory-game',r.body.items?.find(x=>x.type==='Game')?.unit==='hours');
    mark('directory-comics',r.body.items?.find(x=>x.type==='Comics')?.unit==='issues');
    r=await request(base,'/api/mediums/personal/selftest',{method:'POST',body:'{}'});
    mark('selftest',r.status===200&&r.body.passed===true&&r.body.count>=15);
    r=await request(base,'/api/library/medium/Comics');
    mark('empty-comics-view',r.status===200&&r.body.stats?.count===0&&r.body.experience?.unit==='issues');
    r=await request(base,'/api/library/anime1',{method:'PUT',body:JSON.stringify({status:'active',progress:3})});
    mark('anime-upsert',r.status===200&&r.body.library?.record?.progressUnit==='episodes'&&r.body.library?.total===12);
    r=await request(base,'/api/library/manga1',{method:'PUT',body:JSON.stringify({status:'active',progress:2,progressUnit:'volumes'})});
    mark('manga-alternate-unit',r.status===200&&r.body.library?.record?.progressUnit==='volumes'&&r.body.library?.total===10);
    r=await request(base,'/api/library/movie1',{method:'PUT',body:JSON.stringify({status:'planning'})});
    mark('movie-planning',r.status===200&&r.body.library?.record?.status==='planning'&&r.body.library?.experience?.statusLabels?.planning==='Plan to watch');
    r=await request(base,'/api/catalog/anime1/work-page');
    mark('anime-work-page',r.status===200&&r.body.version==='1.0'&&r.body.personalExperience?.unit==='episodes'&&r.body.workflow?.primaryAction?.label==='+1 episode');
    r=await request(base,'/api/catalog/movie1/work-page');
    mark('movie-work-page',r.status===200&&r.body.personalExperience?.unit==='viewings'&&r.body.workflow?.primaryAction?.label==='Watch movie');
    r=await request(base,'/api/library/medium/Manga');
    mark('manga-medium-view',r.status===200&&r.body.experience?.unit==='chapters'&&r.body.active?.[0]?.experience?.currentUnit==='volumes'&&r.body.active?.[0]?.total===10);
    r=await request(base,'/api/library/medium/Anime');
    mark('anime-medium-view',r.status===200&&r.body.experience?.statusLabels?.active==='Watching'&&r.body.active?.[0]?.experience?.unit==='episodes');
    r=await request(base,'/');
    mark('ui-root',r.status===200);
    console.log(JSON.stringify({version:'1.0',suite:'medium-personal-http-e2e',passed:true,checks:checks.length,details:checks},null,2));
  }catch(e){
    console.error(JSON.stringify({version:'1.0',suite:'medium-personal-http-e2e',passed:false,error:e.message,checks,stderr},null,2));
    process.exitCode=1;
  }finally{
    child.kill('SIGTERM');
    await delay(150);
    fs.rmSync(tmp,{recursive:true,force:true});
  }
})().catch(e=>{console.error(e);process.exitCode=1});
