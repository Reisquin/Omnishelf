const assert = require('assert');
const identity = require('../lib/identity');

function item(id, provider, providerId, title, type='Movie', year=2024, extra={}) {
  return { id, provider, providerId, title, type, year, creators:['Aiko Ren'], aliases:['Silent Lantern'], tags:['Mystery'], externalLinks:[], ...extra };
}

const tests = {};
const same = identity.compare(item('a','TMDB','1','The Silent Lantern','Movie',2024), item('b','Manual',null,'The Silent Lantern','Movie',2024));
tests.highConfidenceSameType = same.score >= 0.9 && ['high','probable'].includes(same.confidence);
const mismatch = identity.compare(item('a','TMDB','1','The Silent Lantern','Movie',2024), item('b','IGDB','1','The Silent Lantern','Game',2024));
tests.typeMismatchCapped = mismatch.score <= 0.54 && mismatch.reasons.some(x=>x.includes('Type mismatch'));
const isbnA=item('a','Open Library','OL1W','The Work','Novel',2020,{providerMetadata:{workId:'OL1W',isbns:['978-0-1234-5678-9']}});
const isbnB=item('b','Open Library','OL1M','The Work Edition','Novel',2020,{providerMetadata:{editionId:'OL1M',isbns:['9780123456789']}});
tests.isbnNormalization = identity.compare(isbnA,isbnB).score >= 0.99 && identity.compare(isbnA,isbnB).signals.exactExternal.includes('isbn');
const data={catalog:[item('a','TMDB','1','The Silent Lantern','Movie',2024),item('b','Open Library','OL1W','The Silent Lantern','Novel',2024,{providerMetadata:{workId:'OL1W'}}),item('c','IGDB','1','Silent Lantern','Game',2024),item('d','AniList','2','Silent Lantern','Movie',2024)],identity:{version:1,groups:[],decisions:[],runs:[],candidates:[]}};
const rebuild=identity.rebuild(data,0.5);
tests.rebuildProducesCandidates = rebuild.run.catalogSize===4 && Array.isArray(rebuild.candidates) && rebuild.candidates.length>=1;
const group=identity.addToGroup(data,'a','b','selftest');
tests.confirmCreatesGroup = group.members.length===2 && identity.groupForCatalogId(data,'a').id===group.id;
const second=identity.addToGroup(data,'b','c','selftest');
tests.groupMerge = second.members.length===3 && data.identity.groups.length===1;
const pref=identity.setPreference(data,second.id,'title','c');
tests.fieldPreference = pref.fieldPreferences.title==='c';
data.identity.decisions.push({id:'d1',decisionKey:identity.decisionKey('a','c'),action:'reject'});
tests.rejectionSuppresses = identity.rejected(data,'a','c')===true;
const confirmedPair=identity.addToGroup(data,'a','d','selftest');
tests.confirmedPairIsNeverRejected = identity.rejected(data,'a','d')===false && confirmedPair.members.length===4 && data.identity.groups.length===1;
const demo=identity.demoCandidates();
tests.demoDatastoreNeutral = demo.items.length===4 && demo.pairs.length===6;
const passed=Object.values(tests).filter(Boolean).length;
console.log(JSON.stringify({version:'0.60',regressionOf:'v0.59-identity',mode:'offline',passed,total:Object.keys(tests).length,checks:tests,demoPairs:demo.pairs.length},null,2));
if(passed!==Object.keys(tests).length) process.exit(1);
