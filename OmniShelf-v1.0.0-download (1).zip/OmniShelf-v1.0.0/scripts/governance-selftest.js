const assert = require('assert');
const crypto = require('crypto');
const governance = require('../lib/governance');

function clone(v){ return JSON.parse(JSON.stringify(v)); }
function baseData(){
  const manual={id:'m1',provider:'Manual',title:'Manual Title',type:'Novel',year:2020,description:'Human copy',creators:['Author'],tags:['Literature'],aliases:['Native Title'],coverUrl:null,externalLinks:[],updatedAt:'2026-10-06T00:00:00.000Z'};
  const tmdb={id:'t1',provider:'TMDB',providerId:'100',title:'Manual Title',type:'Movie',year:2020,description:'Remote copy',creators:['Director'],tags:['Drama'],aliases:['Manual Title'],coverUrl:'https://image.test/t.jpg',externalLinks:[],providerMetadata:{provenance:{retrievedAt:'2026-01-01T00:00:00.000Z'}},updatedAt:'2026-10-06T00:00:00.000Z'};
  return {catalog:[manual,tmdb],collections:[{id:'c1',name:'Shelf',items:['m1']}],smartCollections:[],reviewQueue:[],identity:{version:1,groups:[{id:'g1',members:['m1','t1'],conflicts:[{field:'type'}]}],decisions:[],runs:[],candidates:[]},enrichment:{version:1,runs:[]},reliability:{version:1,providers:{},events:[],incidents:[]},governance:{}};
}
function run(){
  const d=baseData(); governance.ensure(d);
  const checks={};
  checks.policyExists=Boolean(d.governance.policyHash);
  checks.manualAttribution=governance.attributionForItem(d.catalog[0]).description.sourceType==='manual';
  checks.manualProtected=governance.policyDecision(d,d.catalog[0],'description',{provider:'TMDB'},'Remote replacement') .allowed===false;
  checks.emptyFieldCanFill=governance.policyDecision(d,d.catalog[0],'coverUrl',{provider:'TMDB'},'https://image.test/new.jpg').allowed===true;
  checks.explicitOverrideAllows=governance.policyDecision(d,d.catalog[0],'description',{provider:'TMDB'},'Remote replacement',true).allowed===true;
  const stale=governance.freshnessForItem(d.catalog[1],d.governance,Date.parse('2026-10-06T00:00:00.000Z'));
  checks.staleDetected=stale.status==='stale';
  const unknown=governance.freshnessForItem({...d.catalog[1],providerMetadata:{}},d.governance,Date.now());
  checks.unknownVisible=unknown.status==='unknown';
  const impact=governance.deletionImpact(d,'m1'); checks.deletionImpact=impact.riskLevel==='high'&&impact.identityGroups.length===1&&impact.collections.length===1;
  const tomb=governance.recordDeletion(d,d.catalog[0],impact); checks.deletionTombstone=tomb.riskLevel===undefined && d.governance.deletionTombstones.length===1;
  const before=clone(d.catalog[1]); const after={...before,description:'new'}; governance.recordFieldChanges(d,before,after,{action:'test'}); checks.fieldAuditRecorded=d.governance.fieldHistory.length===1;
  const validation=governance.validateData(d); checks.validationProducesReport=typeof validation.fieldAttributionCoverage==='number'&&Array.isArray(validation.warnings);
  const payload=governance.attachBackupIntegrity({format:'omnishelf-backup',version:'0.63',exportedAt:'2026-10-06T00:00:00.000Z',catalog:d.catalog,collections:d.collections,smartCollections:d.smartCollections,reviewQueue:d.reviewQueue,auditLog:[],governance:d.governance});
  const verified=governance.verifyBackup(payload); checks.backupHashValid=verified.valid;
  const tampered=clone(payload); tampered.catalog[0].title='Tampered'; checks.tamperDetected=governance.verifyBackup(tampered).valid===false;
  checks.policyHashStable=governance.hashPayload(d.governance.policy)===d.governance.policyHash;
  const passed=Object.values(checks).every(Boolean);
  return {passed,checks,policyHash:d.governance.policyHash,validation};
}
const out=run(); console.log(JSON.stringify(out,null,2)); process.exitCode=out.passed?0:1;
