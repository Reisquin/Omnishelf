#!/usr/bin/env node
const http=require('http');
const {spawn}=require('child_process');
const port=Number(process.env.PORT||33751);
const child=spawn(process.execPath,['server.js'],{env:{...process.env,PORT:String(port),ANILIST_MODE:'demo',ANILIST_AUTHORIZED_USE:'false'},stdio:'ignore'});
function get(path){return new Promise((resolve,reject)=>{const req=http.get({hostname:'127.0.0.1',port,path,headers:{Accept:'application/json'}},res=>{let b='';res.on('data',c=>b+=c);res.on('end',()=>{try{resolve({status:res.statusCode,data:JSON.parse(b)})}catch(e){reject(e)}})});req.on('error',reject);req.setTimeout(5000,()=>req.destroy(new Error('timeout')));});}
(async()=>{try{for(let i=0;i<30;i++){try{await get('/api/health');break}catch{await new Promise(r=>setTimeout(r,100));}} const r=await get('/api/anilist/integrity/audit?demo=1'); console.log(JSON.stringify(r.data,null,2)); if(r.status!==200||!r.data.passed)process.exitCode=2;}catch(e){console.error(e.stack||e);process.exitCode=1;}finally{child.kill('SIGTERM');}})();
