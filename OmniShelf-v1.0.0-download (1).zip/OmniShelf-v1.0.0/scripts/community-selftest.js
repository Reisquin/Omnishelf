const community=require('../lib/community');
const result=community.selfTest();
console.log(JSON.stringify({version:'1.0',mode:'deterministic',...result},null,2));
if(!result.passed)process.exit(1);
