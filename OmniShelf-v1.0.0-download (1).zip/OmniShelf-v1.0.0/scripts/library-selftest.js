const library=require('../lib/library');
const r=library.selfTest();
console.log(JSON.stringify({suite:'personal-library',...r}));
