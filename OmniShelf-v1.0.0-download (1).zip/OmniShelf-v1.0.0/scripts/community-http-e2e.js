const http=require('http');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const FILE=path.join(__dirname,'..','data','store.json');
const original=fs.readFileSync(FILE,'utf8');
function req(port,pathName,opts={}){return new Promise((resolve,reject)=>{const body=opts.body==null?null:JSON.stringify(opts.body);const r=http.request({hostname:'127.0.0.1',port,path:pathName,method:opts.method||'GET',headers:body?{'Content-Type':'application/json','Content-Length':Buffer.byteLength(body)}:{}},res=>{let s='';res.on('data',c=>s+=c);res.on('end',()=>{let json=null;try{json=JSON.parse(s)}catch{}resolve({status:res.statusCode,body:json,text:s})})});r.on('error',reject);if(body)r.write(body);r.end();});}
(async()=>{
 let child=null;const port=34076;try{
  // Use a disposable fixture so the shipped datastore remains untouched.
  const data=JSON.parse(original);data.catalog=[
   {id:'w1',title:'Community One',type:'Anime',year:2024,coverUrl:'/demo/a.svg',provider:'Manual',providerId:null,relations:[],tags:['Mystery'],creators:['Creator A'],status:'active',createdAt:'2026-10-01T00:00:00.000Z',updatedAt:'2026-10-01T00:00:00.000Z'},
   {id:'w2',title:'Community Two',type:'Movie',year:2023,coverUrl:'/demo/b.svg',provider:'Manual',providerId:null,relations:[],tags:['Drama'],creators:['Creator B'],status:'active',createdAt:'2026-10-01T00:00:00.000Z',updatedAt:'2026-10-01T00:00:00.000Z'},
   {id:'w3',title:'Community Three',type:'Novel',year:2022,coverUrl:'/demo/c.svg',provider:'Manual',providerId:null,relations:[],tags:['Mystery'],creators:['Creator C'],status:'active',createdAt:'2026-10-01T00:00:00.000Z',updatedAt:'2026-10-01T00:00:00.000Z'}
  ];data.library={version:1,profile:{name:'You'},items:{},smartCollections:[],history:{version:1,events:[]}};data.community={version:2,currentUserId:'you',members:{you:{id:'you',name:'You',handle:'you',bio:'',avatarUrl:null,createdAt:'2026-10-01T00:00:00.000Z',updatedAt:'2026-10-01T00:00:00.000Z'},m1:{id:'m1',name:'Mina',handle:'mina',bio:'Stories.',favoriteWorkIds:['w1','w2'],createdAt:'2026-10-01T00:00:00.000Z',updatedAt:'2026-10-01T00:00:00.000Z'}},follows:[],reviews:[],activities:[],reviewLikes:[]};
  fs.writeFileSync(FILE,JSON.stringify(data,null,2)+'\n');
  child=require('child_process').spawn('node',['server.js'],{cwd:path.join(__dirname,'..'),env:{...process.env,PORT:String(port)}});
  await new Promise((resolve,reject)=>{const t=setTimeout(()=>resolve(),250);child.on('error',reject);});
  const checks=[];
  let r=await req(port,'/api/community/overview');checks.push(['overview',r.status===200&&r.body?.profile?.id==='you']);
  r=await req(port,'/api/community/follow',{method:'POST',body:{userId:'m1',follow:true}});checks.push(['follow',r.status===200&&r.body?.following===true]);
  r=await req(port,'/api/community/favorite',{method:'POST',body:{catalogId:'w1',value:true}});checks.push(['favorite-syncs-library',r.status===200&&r.body?.library?.record?.favorite===true]);
  r=await req(port,'/api/community/reviews',{method:'POST',body:{catalogId:'w1',score:95,body:'Excellent community test review.',spoiler:false}});const reviewId=r.body?.review?.id;checks.push(['review-create',r.status===201&&!!reviewId]);
  r=await req(port,'/api/community/reviews?sort=liked');checks.push(['review-list',r.status===200&&r.body?.reviews?.some(x=>x.id===reviewId)]);
  r=await req(port,'/api/community/reviews/'+reviewId+'/like',{method:'POST',body:{value:true}});checks.push(['review-like',r.status===200&&r.body?.liked===true&&r.body?.likes===1]);
  r=await req(port,'/api/community/discovery');checks.push(['community-discovery',r.status===200&&Array.isArray(r.body?.items)]);
  r=await req(port,'/api/data/export?format=json&scope=backup');checks.push(['backup-community',r.status===200&&!!r.body?.community&&Array.isArray(r.body.community.reviews)]);
  const passed=checks.every(x=>x[1]);console.log(JSON.stringify({version:'1.0',mode:'http-e2e',passed,checks:checks.map(x=>({name:x[0],ok:x[1]}))},null,2));
  if(!passed)process.exitCode=1;
 }catch(e){console.error(e);process.exitCode=1}
 finally{if(child)child.kill('SIGTERM');setTimeout(()=>{fs.writeFileSync(FILE,original);},50);setTimeout(()=>process.exit(process.exitCode||0),120);}
})();
