# OmniShelf v0.56 — Build Validation

Validation performed against the v0.56 working tree.

## Static checks
- `node --check server.js` — pass.
- `node --check lib/openlibrary.js` — pass.
- `node --check lib/openlibrary-quality.js` — pass.
- `node --check` across every file in `scripts/` — pass.
- Browser JavaScript extracted from `public/index.html` — pass.
- `public/index.html` and `preview.html` are byte-identical.

## Deterministic Open Library quality tests
`npm run openlibrary:quality-test` — pass.

Checks cover Work identity, Author references, subject normalization, Work → Edition relationship extraction, exact provider matching, and Edition identity preservation.

## Local HTTP smoke tests
The v0.56 server was started on an isolated local port and verified with:
- `GET /`
- `GET /api/openlibrary/quality/status`
- `GET /api/openlibrary/search?demo=1`
- `GET /api/openlibrary/works/OLDEMO1W/editions?demo=1`
- `POST /api/openlibrary/quality/analyze` in demo mode
- `POST /api/openlibrary/enrich/preview` in demo mode
- `POST /api/openlibrary/enrich/apply` in demo mode
- `GET /api/openlibrary/entities`
- full backup export
- full backup restore preview/apply, including the Open Library registry

All tested routes behaved as expected.

## Datastore safety
The demo enrichment/apply flow was exercised and then the release datastore was restored to the exact clean v0.55 baseline. The final `data/store.json` SHA-256 matches the supplied v0.55 archive's datastore.

The release therefore ships without synthetic test catalog records.

## Live upstream status
No live Open Library or AniList acceptance pass is claimed from this environment. Live acceptance remains an operator-run step on a network-enabled deployment with the required configuration/authorization.

## Visual preview
`preview.html` is the synchronized v0.56 browser preview and `public/index.html` is the served UI. A new PNG screenshot was not included because the available headless Chromium process did not terminate reliably in this environment; no screenshot result is represented as a completed browser capture.
