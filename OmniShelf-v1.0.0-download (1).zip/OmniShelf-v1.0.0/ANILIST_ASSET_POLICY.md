# AniList Asset Policy

## v0.49

OmniShelf treats AniList artwork/media as provider-supplied remote assets. The normalized asset model preserves URLs and metadata for:

- coverImage: extraLarge, large, medium, color, primary/fallback selection
- bannerImage
- trailer: id, site, thumbnail
- streamingEpisodes: title, thumbnail, url, site
- externalLinks: URL, site, type, language, icon, notes, disabled state

The UI renders remote assets lazily with `referrerpolicy="no-referrer"` and removes broken images without breaking the media page.

The default integration does **not** download or persist AniList image bytes. This avoids silently turning the provider API into an independent asset store. Any deployment that introduces local asset caching must first verify that the intended AniList use and retention model are authorized.

The asset quality endpoint reports availability without downloading asset bytes.
