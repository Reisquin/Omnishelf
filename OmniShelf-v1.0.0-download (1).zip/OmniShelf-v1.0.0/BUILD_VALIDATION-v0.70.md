# OmniShelf v0.70 — Build Validation

Release: v0.70 — Everyday Personal Library Experience
Base: v0.69

## Deterministic regression matrix

- Personal Library: 7/7
- Library Experience: 11/11
- Standalone Work Pages: 8/8
- Work Page: 8/8
- Catalog UX: 5/5
- Catalog Experience: 8/8
- Medium Framework: 7/7
- Asian Drama: 18/18
- Unified Provider Search: 13/13
- Provider Reliability: 8/8
- Cross-Provider Identity: 10/10
- Unified Enrichment: 10/10
- Final Data Governance: 14/14
- TMDB: 17/17
- IGDB: 25/25
- Open Library: 5/5

All inherited deterministic suites passed after updating the standalone work-page version expectation to v0.70.

## Syntax validation

Passed for `server.js`, `lib/store.js`, `lib/library.js`, `lib/library-experience.js`, `lib/governance.js`, `lib/work-pages.js`, and the client JavaScript extracted from `public/index.html`.

## Isolated HTTP E2E

`node scripts/library-experience-http-e2e.js` passed **12/12** in a disposable workspace copy. Coverage includes overview, catalog seeding, personal-state creation, quick shelves, measurable progress, medium summary/view, filtered library, progress advancement/completion, work-page projection, UI route delivery, and backup preservation.

No HTTP E2E mutations were applied to the shipped datastore.

## Release integrity

- `preview.html` is byte-identical to `public/index.html`.
- Clean shipped datastore contains 0 catalog records, 0 review-queue records, 0 audit entries, and 0 personal-library records.
- Clean datastore SHA-256: `37e7cf6f5f99edd4372034f2786732fb20c553a0ce005909222cab5236c82549`.
- Source manifest was regenerated with 170 tracked file hashes.
- The final ZIP is independently extracted and revalidated before delivery.

## AniList boundary

AniList live authorization and live acceptance remain outside this release. v0.70 does not depend on AniList availability or authorization for My Library functionality.

## Known boundaries

The personal layer remains a local single workspace (`You`). Mixed-medium progress is not combined into a fake universal unit. External personal-state synchronization remains out of scope for this release.
