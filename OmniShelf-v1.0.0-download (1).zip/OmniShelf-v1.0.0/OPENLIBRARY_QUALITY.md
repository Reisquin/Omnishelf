# Open Library Quality & Entity Layer — v0.56

## Purpose
v0.56 keeps Open Library as a provider of evidence and enrichment while OmniShelf remains the canonical catalog. Provider records are normalized, matched, reviewed, and then applied; the provider never becomes a parallel catalog database.

## Work and Edition lineage
Open Library distinguishes a logical Work from publication-specific Editions. OmniShelf records the Work identity separately from Edition identities and persists the Work → Edition relationship after enrichment. The relationship registry stores edition IDs plus the useful publication-level fields returned during the bounded enrichment pass.

The server exposes:
- `GET /api/openlibrary/works/:id/editions`

The route is bounded by the same low-volume enrichment limits used by the provider adapter.

## Author entities
For author references attached to a Work, v0.56 can resolve a bounded number of Author records and persist:
- Open Library Author ID
- name and alternate names
- birth/death dates when supplied
- work count and top work when supplied
- top subjects
- canonical links back to Open Library
- linked Work IDs inside the local registry

Author quality reports use author-specific completeness checks rather than work/edition checks.

## Subject normalization
Open Library subjects are retained as source-derived values and additionally normalized into a small OmniShelf category vocabulary when a clear match exists. Unrecognized subjects remain preserved as `topic:<slug>` entities rather than being discarded.

Normalization is intentionally conservative. A subject match is a classification hint, not an editorial assertion.

## Identity and duplicate diagnostics
Open Library-aware matching uses a hierarchy of evidence:
1. exact Open Library provider identifier
2. shared normalized ISBN
3. shared Open Library Work ID
4. normalized exact title
5. token-based title similarity
6. creator overlap
7. publication year
8. canonical type

The service returns reasons with each candidate match. High-confidence identifiers are deliberately weighted more strongly than fuzzy text similarity.

The matching endpoint is:
- `POST /api/openlibrary/matches`

The Review Queue also records the quality report and match diagnostics for Open Library candidates so the decision is auditable.

## Quality scoring
`POST /api/openlibrary/quality/analyze` reports completeness for a Work, Edition, or Author.

Work reports evaluate title, authors, publication date/year, description, subjects, identifiers, publishers, languages, cover, and Work identity.

Edition reports evaluate title, Work relationship, ISBNs, publisher, language, publication date, pages/format, cover, and Edition identity.

Author reports evaluate name, alternate names, life dates, work count, top work, top subjects, photo availability, and Author identity.

The score is a diagnostic, not a publishing gate. Review/apply remains explicit.

## Enrichment
Canonical enrichment is preview-first:
- `POST /api/openlibrary/enrich/preview`
- `POST /api/openlibrary/enrich/apply`

Enrichment can add or strengthen aliases, creators, tags, description, year, provider metadata, normalized subjects, Work → Edition lineage, remote cover references, and raw provider snapshots.

Existing non-empty manual title/description/creator/tag information is preserved. Provider-derived evidence is attached with `providerMetadata.provenance` and raw snapshots for traceability.

## Entity registry
The persistent `openLibrary` store namespace contains:
- `authors`
- `subjects`
- `workEdition`
- `enrichmentJournal`
- `reviewDiagnostics`

The registry can be inspected through:
- `GET /api/openlibrary/entities?type=authors|subjects|works`

It can be rebuilt from current canonical catalog metadata through an explicitly confirmed operation:
- `POST /api/openlibrary/entities/rebuild`

## Covers
v0.56 keeps artwork as remote references. If a normal Open Library cover identifier is unavailable but a valid ISBN is present, the adapter can construct an ISBN-based Covers API reference as a fallback. No cover bytes are persisted by this layer.

## Offline acceptance
`npm run openlibrary:quality-test` validates deterministic fixtures for Work/Edition identity, ISBN normalization, subject normalization, quality scoring, relationship extraction, and enrichment/entity payload construction.

The existing read-only live acceptance suite remains available through:
- `POST /api/openlibrary/live-acceptance`
- `npm run openlibrary:acceptance`

v0.56 adds a live Work → Edition relationship check when a Work is successfully returned. Live acceptance is still operator-run and cannot be claimed solely from this build environment.
