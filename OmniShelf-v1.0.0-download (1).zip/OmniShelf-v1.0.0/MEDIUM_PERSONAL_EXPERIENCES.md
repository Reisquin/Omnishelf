# OmniShelf v0.78 — Full Medium-by-Medium Personal Experiences

## Purpose
OmniShelf v0.78 adds a provider-neutral presentation and interaction registry for the 18 canonical personal-media types. The goal is not 18 separate libraries; it is one durable personal state model with medium-appropriate language, units, statuses and workflow guidance.

## Supported canonical types
Anime; Manga; Manhwa; Manhua; Novel; Light Novel; Web Novel; Visual Novel; Game; Movie; TV; Comics; Narrative Poetry; Poetry; Play; Short Story; Short Story Collection; Novella.

## Per-medium behavior
Each profile defines an activity verb, primary progress unit, supported alternate units, start/resume/finish labels, status labels, notes/favorite prompts, milestones, history wording and resume guidance. Examples: Anime/TV use episodes; manga families use chapters; novels and short stories use pages; games use hours/sessions; movies use viewings; visual novels expose units/hours/routes; comics expose issues/chapters/pages; poetry exposes poems/pages; plays expose acts/scenes/pages; collections expose stories/pages.

## Architecture
- `lib/medium-personal-experiences.js` is the single registry.
- `lib/library.js` consumes the registry for medium-aware progress inference, including unit-specific known totals when a user chooses an alternate unit.
- `lib/library-experience.js` exposes the profile on medium views, including empty supported media.
- `lib/unified-workflow.js` uses medium-specific start/resume/advance/finish labels.
- `lib/work-pages.js` and the Work Page UI expose the personal experience alongside canonical medium metadata.
- `/api/mediums/personal` returns the read-only registry directory.
- `/api/mediums/personal/selftest` runs the deterministic registry suite.

No second catalog, personal-state database, provider model or analytics store is introduced. Existing v0.69+ personal records remain the source of truth.

## Boundaries
Medium-specific UI does not invent provider totals. Known totals are used only for the matching progress unit. Unknown totals remain user-editable. Provider integrations remain read/write-governed independently from personal tracking.
