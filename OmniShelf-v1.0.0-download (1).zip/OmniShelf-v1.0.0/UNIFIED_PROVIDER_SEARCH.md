# Unified Provider Search

## Purpose

Unified Provider Search is the v0.62 read-only discovery layer. Its job is to hide provider selection from the user while preserving provider identity and the existing OmniShelf canonical model.

The intended flow is:

`Search OmniShelf → route providers → query independently → normalize → rank → compare with catalog → group strong cross-provider evidence → present results`

## Provider routing

Smart routing is used when no explicit provider list is supplied.

- ISBN-like queries → Open Library
- `Game` → IGDB
- `Movie` → TMDB
- `TV` / `Drama` → TMDB
- `Anime` / `Manga` / `Manhwa` / `Manhua` → AniList + Open Library
- `Visual Novel` → AniList + IGDB
- `Light Novel` / `Web Novel` → AniList + Open Library
- `Novel` / `Non-fiction` / `Poetry` / `Novella` / `Short Story Collection` / `Anthology` → Open Library
- otherwise → AniList + Open Library + TMDB + IGDB

Explicit `providers=...` scope overrides smart routing.

## Provider fan-out

Each selected provider is queried independently. The orchestrator records `fulfilled` or `rejected` status, latency, result count, cache state, and a provider error without cancelling the entire search. Existing v0.61 reliability wrappers instrument these operations automatically.

## Normalization

Provider-native results are converted into the same canonical-style record shape already used by OmniShelf. Provider-specific metadata, raw snapshots, media assets and external identifiers remain attached to each provider result. Search does not discard provider provenance.

TMDB movie and TV searches are both queried for broad screen searches. Open Library returns Work/Edition-aware normalized records from its existing adapter. AniList is normalized through the existing `lib/providers.js` canonical mapping. IGDB uses its existing deep Game normalization.

## Ranking

Each result receives a deterministic `queryScore` based on normalized title/alias agreement, prefix/contains matches, token overlap and creator hits. The score is a discovery relevance signal; it is not an identity confidence score and never creates catalog state.

## Catalog matching

Each provider result is compared against the current canonical catalog through the v0.59 identity engine. The top possible catalog matches are exposed on the result, with score, confidence, reasons and existing identity-group membership where applicable. Strong matches are labeled as catalog matches in the Search UI.

## Cross-provider grouping

Search also compares returned provider results against each other. Strong evidence—exact shared identifiers, high-confidence identity evidence, or similarly strong comparison signals—can put multiple provider results into a temporary discovery cluster. The cluster exists only in that search response. No persistent identity group, decision, enrichment run or audit mutation is created.

Lower-confidence relationships are returned as `related` evidence instead of being collapsed. This deliberately keeps discovery conservative and avoids turning ambiguous same-title records into persistent merges.

## Catalog separation

Catalog results are returned separately from provider results. This preserves the distinction between “already in my OmniShelf catalog” and “discovered from a provider”. The user can inspect the existing catalog match while still deciding whether to import a provider result through Review Queue.

## API

`GET /api/search?q=<query>&type=<type>&providers=<comma-list>&limit=<n>&page=<n>&demo=1`

Returns:

- `routing` — selected providers and routing reason
- `providerSummary` — per-provider status/latency/count/cache/error
- `results` — normalized external provider results
- `catalogResults` — matching local catalog records
- `clusters` — strong discovery-only cross-provider groupings
- `related` — lower-confidence cross-provider relationships
- `totals` — overall counts
- `partial` — whether some but not all selected providers failed

`GET /api/search/route` returns the routing decision without querying any provider.

`GET /api/search/demo-plan` returns routing guarantees and example routing behavior without touching the datastore.

## Review Queue boundary

The Search UI can send a normalized provider result to `/api/review/queue`. Review Queue recalculates provider-specific match diagnostics before an operator approves or rejects the import. Search itself never bypasses that control.

## UI

The Search tab is top-level navigation. It provides:

- single search box
- media-type filter
- provider-scope selector
- result-limit selector
- demo/live search actions
- routing explanation
- provider health cards
- separate catalog results
- unified provider results with source, type, relevance and catalog-match information
- cross-provider relationship evidence
- Review Queue import action

## Validation

`npm run unified-search:selftest` covers smart routing, explicit routing, four-provider demo fan-out, stable result IDs, non-persistence, catalog include/exclude behavior, conservative type mismatch handling, and discovery-only grouping. Existing provider, identity, enrichment and reliability suites remain required regressions.
