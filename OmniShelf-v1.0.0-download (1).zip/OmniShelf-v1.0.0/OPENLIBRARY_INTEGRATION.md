# Open Library Integration — v0.56

## Scope

v0.56 promotes Open Library from a deep discovery/lookup adapter into a quality-aware provider with identity, entity, lineage, enrichment, and audit support.

The adapter covers:

- Search API discovery with title, author, ISBN, subject, language, pagination, and sort inputs.
- Work lookup via `/works/{workId}.json`.
- Work → Edition lookup via `/works/{workId}/editions.json`.
- Edition lookup via `/books/{editionId}.json`.
- ISBN lookup via `/isbn/{isbn}.json`.
- Author lookup via `/authors/{authorId}.json`.
- Separate normalization for Work/Edition/Author records.
- Canonical OmniShelf mapping with Work-vs-Edition identity preserved.
- ISBN normalization and provider-aware duplicate matching.
- Work → Edition relationship extraction.
- Author entity extraction and bounded author enrichment.
- Conservative subject normalization with source values retained.
- Record quality scoring for Works, Editions, and Authors.
- Canonical enrichment preview/apply with provider provenance and raw snapshots.
- Persistent Open Library author/subject/work-edition registries and enrichment diagnostics.
- Remote cover references plus ISBN cover fallback; image bytes are not silently persisted.
- Five-minute bounded cache and request serialization at approximately three requests per second for identified clients.
- Read-only live acceptance and a deterministic offline quality/entity self-test.

## Canonical workflow

`Open Library Search → Normalize → Identity Match → Review → Apply → Enrich / Registry`

The canonical catalog remains the source of truth. Open Library provider records do not bypass the Review Queue for new imports.

## Canonical type mapping

The adapter intentionally uses conservative subject-based heuristics:

- Biography, autobiography, memoir, nonfiction, essays → `Non-fiction`
- Poetry/poems → `Poetry`
- Novella → `Novella`
- Short stories → `Short Story Collection`
- Theatre/drama/play-related subjects → `Play`
- Otherwise → `Novel`

These are normalization hints, not authoritative editorial classification. Review/apply remains the canonical OmniShelf gate.

## Identity matching

Open Library candidates are checked against the canonical catalog using:

- exact Open Library identifier
- shared normalized ISBN
- shared Work ID
- normalized exact title
- title token similarity
- creator overlap
- publication year
- canonical type

The result includes a score and human-readable reasons. Identifier-based evidence outranks fuzzy similarity.

## Quality and entities

See `OPENLIBRARY_QUALITY.md` for the full v0.56 quality/entity model.

Key APIs:

- `GET /api/openlibrary/quality/status`
- `POST /api/openlibrary/quality/analyze`
- `POST /api/openlibrary/matches`
- `GET /api/openlibrary/entities`
- `POST /api/openlibrary/entities/rebuild`
- `POST /api/openlibrary/enrich/preview`
- `POST /api/openlibrary/enrich/apply`

## Application registration / identification

Open Library's current API guidance asks regular API users to identify the application with a User-Agent containing an application name and contact information. Use:

```env
OPENLIBRARY_USER_AGENT=OmniShelf/0.56
OPENLIBRARY_CONTACT=your-real-contact@example.com
```

Do not put secrets into the frontend. Provider configuration remains server-side.

## Operational guardrails

The adapter is deliberately not a bulk importer. Open Library's current documentation describes the Web APIs as low-volume, human-facing discovery/lookup services and directs bulk consumers toward data dumps or direct contact.

Enrichment therefore uses bounded lookups rather than harvesting an entire provider corpus.

## Cover policy

Cover references use `https://covers.openlibrary.org`. When a cover identifier is not available but an ISBN is known, v0.56 may construct an ISBN-based remote cover URL as a fallback. No cover image bytes are silently persisted by the adapter.

## Routes

- `GET /api/openlibrary/status`
- `GET /api/openlibrary/search`
- `GET /api/openlibrary/works/:id`
- `GET /api/openlibrary/works/:id/editions`
- `GET /api/openlibrary/editions/:id`
- `GET /api/openlibrary/authors/:id`
- `GET /api/openlibrary/isbn/:isbn`
- `GET /api/openlibrary/quality/status`
- `POST /api/openlibrary/quality/analyze`
- `POST /api/openlibrary/matches`
- `GET /api/openlibrary/entities`
- `POST /api/openlibrary/entities/rebuild`
- `POST /api/openlibrary/enrich/preview`
- `POST /api/openlibrary/enrich/apply`
- `POST /api/openlibrary/live-acceptance`
- `GET /api/openlibrary/cache`
- `POST /api/openlibrary/cache/clear`

## Validation

Offline quality/entity self-test:

```bash
npm run openlibrary:quality-test
```

Acceptance plan:

```bash
npm run openlibrary:acceptance -- --plan
```

Live read-only acceptance:

```bash
npm run openlibrary:acceptance
```

A network-blocked environment is reported as blocked/failed rather than a false pass.
