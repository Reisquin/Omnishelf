# OmniShelf v0.76 — Social / Community 2.0

## Summary
v0.76 makes the social layer a first-class provider-neutral OmniShelf product surface. It adds local community profiles, following, public reviews, review likes, explicit social activity and discovery through other members while preserving the existing canonical catalog, personal library and provider architecture.

## Added
- `lib/community.js` and durable `data.community` state.
- Community Overview, Members, Activity, Reviews and From People product views.
- Public profile editing for the current local user.
- Follow / unfollow.
- Public community review create/edit/delete with optional score and spoiler flag.
- Review likes.
- Community-driven discovery from public favorites of followed members.
- Work Page community review projection and review handoff.
- Backup/restore coverage and reference sanitization.
- Deterministic self-test and disposable HTTP E2E.

## Preserved
- Canonical catalog ownership.
- Personal Library, History, Smart Collections, Statistics 2.0 and Recommendations 2.0.
- Unified Discovery → Library workflow.
- Provider identity, enrichment, reliability and governance layers.
- AniList's external Community workspace as a separate provider feature.

## Explicit boundaries
This release intentionally does not add production authentication or multi-user security isolation. The local `you` identity is the product/data-model foundation; production security, account infrastructure and final hardening remain later roadmap work.

## Next
v0.77 — Universal Import / Export & Migration.
