# OmniShelf v0.79 — UI/UX & Accessibility Finalization

v0.79 is the product-wide UI/UX and accessibility finalization pass.

## Added
- Semantic primary navigation and main content landmark.
- Skip-to-content keyboard navigation.
- Consistent focus-visible treatment and accessible control naming.
- Keyboard-safe detail dialogs with focus return, Escape handling and Tab trapping.
- Responsive navigation, toolbars, grids and work/detail surfaces.
- Reduced-motion behavior.
- Shared live announcements for view changes and request failures.
- Consistent minimum interactive target sizing and empty/loading/error-state support.

## Preserved
All catalog, provider, identity, enrichment, governance, Personal Library, History, Smart Collections, Statistics 2.0, Recommendations 2.0, Unified Workflow, Community 2.0, portable migration and 18 medium-specific personal experiences. AniList live authorization/acceptance remains independent and gated.

## Validation
See `BUILD_VALIDATION-v0.79.md` and `FINAL_RELEASE_CHECK-v0.79.txt`.
