# OmniShelf Medium Experiences — v0.66

## Purpose
v0.66 turns the dedicated-medium idea introduced in v0.65 into a reusable product framework. A medium experience is a read-oriented product surface over the canonical catalog; it can add discovery, classification, facets and presentation without creating a second source of truth.

## Reusable registry
`lib/medium-experiences.js` registers shared product surfaces for Anime, Manga, Novels, Film & TV, Asian Dramas, Games, Visual Novels, Plays & Theatre, and Short Fiction. Each record declares the canonical types it consumes, whether it is core/dedicated/planned, and its product route.

The registry is intentionally small. It does not replace the canonical type system. It tells the UI how to present a medium experience and which canonical types feed it.

API:
- `GET /api/mediums` — current medium-experience directory and live catalog counts.
- `POST /api/mediums/selftest` — deterministic registry validation.

## Asian Drama deepening
v0.66 extends the v0.65 Asian Drama read model with a provider-discovery layer.

### Live provider discovery
- `GET /api/medium/asian-dramas/discover`
- Profile-aware TMDB TV discovery using the profile's `with_origin_country` value when no text query is supplied.
- Text search uses TMDB TV search first, followed by OmniShelf's regional classification filter.
- Results are normalized through the existing TMDB adapter, then classified through the v0.65 Asian Drama module.
- Quality, catalog-match and identity-candidate evidence are attached to each result.
- Discovery is read-only. No catalog mutation occurs during provider search.

TMDB's current TV Discover endpoint explicitly supports `with_origin_country` and `with_original_language`, while TV search covers original, translated and also-known-as names. citeturn876975search1turn876975search6

### Controlled ingestion
`POST /api/medium/asian-dramas/ingest-preview` resolves a selected TMDB TV record, validates that it meets the Asian Drama classification policy, calculates quality and catalog/identity matches, and returns a Review Queue payload. The UI then calls the existing Review Queue endpoint explicitly. There is no automatic apply path.

### Platform availability
v0.66 adds a gated read-only Watch Providers surface:
- `GET /api/medium/asian-dramas/watch-providers/status`
- `GET /api/medium/asian-dramas/watch-providers`
- Equivalent TMDB provider status at `GET /api/tmdb/watch-providers/status`.

Live provider availability requires both `TMDB_WATCH_PROVIDERS_ENABLED=true` and `TMDB_JUSTWATCH_ATTRIBUTION_ACK=true`. The second gate is deliberate because TMDB's current Watch Providers documentation states that the data is powered by JustWatch and requires JustWatch attribution. citeturn876975search0

When enabled and used live, the UI must preserve the JustWatch attribution notice. The feature is disabled by default. Demo mode is local and deterministic.

## Data policy
- Medium views never replace canonical records.
- Regional classification remains conservative and data-driven.
- Romanization is never guessed.
- Provider search never creates catalog records automatically.
- Review Queue remains the explicit bridge between external discovery and canonical mutation.
- Watch-provider availability remains separate from core catalog metadata until the attribution/data-boundary requirements are satisfied.

## Asian Drama product intent
The medium should continue to support Korean, Chinese/Mainland Chinese, Japanese, Taiwanese, Hong Kong, Thai, Filipino, Vietnamese, Indonesian, Malaysian, Singaporean, Indian, Bangladeshi and Pakistani drama profiles. Future work can add region-specific terminology and data only when the canonical/provider data actually supports it.

## v0.66 validation boundaries
The medium-experience self-test now covers the reusable registry plus discovery filtering/quality signals. Provider discovery remains read-only until an explicit Review Queue action. The isolated HTTP acceptance covers medium routing, multiple regional profiles, provider detail, availability gating/demo behavior, discovery blocking without credentials, and Review Queue handoff. Watch Providers remains separately gated; v0.66 does not write streaming availability into canonical catalog records.
