# OmniShelf v0.59 — Cross-Provider Identity & Reconciliation

## Purpose

v0.59 establishes the identity layer that turns AniList, Open Library, TMDB and IGDB from four deep provider integrations into evidence sources for one unified OmniShelf catalog. The canonical catalog remains the system of record. Identity groups create a non-destructive relationship between catalog records that represent the same underlying work.

## Scope

The release covers:

- AniList, Open Library, TMDB and IGDB provider identities.
- Manual/non-provider catalog records.
- Exact provider-ID matches.
- Exact shared external identifiers.
- ISBN normalization so punctuation differences do not prevent a match.
- Title and alias similarity.
- Creator overlap.
- Year proximity.
- Canonical type compatibility.
- Human-readable reasons/signals and confidence labels.
- Persistent catalog-wide candidate indexing.
- Explicit confirm/reject decisions.
- Durable identity groups.
- Group merging when two previously confirmed groups are linked.
- Field-level conflict reporting.
- Explicit preferred source selection for supported fields.
- Backup/export/restore continuity.
- Audit-log recording for identity operations.

## Identity evidence order

The comparison engine deliberately ranks identity evidence rather than treating all signals as equal.

1. An exact same-provider provider ID is a hard identity signal.
2. An exact shared normalized external identifier is a near-hard signal. ISBNs are normalized before comparison.
3. Fuzzy evidence combines title similarity, alias similarity, creator overlap, year proximity and canonical type compatibility.
4. Incompatible canonical types receive a safety cap. A shared title is not enough to equate a novel, film, TV series, game, manga, or other distinct medium.
5. Scores become confidence labels (`high`, `probable`, `review`, `weak`, `none`; plus exact-match labels) and expose the contributing reasons.

The thresholds are intentionally conservative. `MATCH_THRESHOLD` controls what is surfaced as a candidate; `AUTO_CONFIRM_THRESHOLD` is informational for future workflow design and does not silently confirm anything in v0.59.

## Persistent data model

`data/store.json` now includes:

```text
identity
  version
  groups[]
  decisions[]
  runs[]
  candidates[]
```

### Groups

A group contains catalog member IDs and derived provider identities. It also retains field conflicts and `fieldPreferences`, where each supported field points to the catalog member that should be preferred for that field.

Group membership is non-destructive. No source row is deleted, and provider-native IDs remain attached to their original catalog records.

### Decisions

A decision is keyed by the two catalog IDs in sorted order, making it stable regardless of which side was selected in the UI. Confirm/reject actions include score, confidence, reasons/signals, timestamp and decision source. Rejected pairs suppress repeat false positives during candidate generation.

A pair already inside a confirmed group cannot be rejected through the normal decision route. Undoing an established relationship requires a future explicit split/unlink operation rather than contradictory reject state.

### Candidate index and rebuild runs

A catalog-wide rebuild compares each unordered pair once, applies rejection suppression, stores the strongest candidate evidence and persists up to 5,000 candidates. Each run records catalog size, total candidate count, indexed count and confidence-band counts. This makes the review surface durable instead of recomputing only in memory.

## Matching provider records not yet in the catalog

Provider search and detail results expose `identityMatches` against the current canonical catalog. A provider result becomes durably linkable after it exists as a catalog record (normally through the existing Search → Normalize → Match → Review → Apply flow). This keeps v0.59 canonical-first and avoids creating a second hidden identity database outside the catalog.

## Review and confirmation workflow

1. Discover or inspect a provider result.
2. Compare it against existing canonical records.
3. Review score, confidence and evidence.
4. Confirm the same-work relationship explicitly.
5. OmniShelf creates a new identity group or merges two groups.
6. Inspect field conflicts.
7. Select preferred sources field-by-field where needed.
8. Continue to v0.60 enrichment using the confirmed identity graph.

No automatic destructive merge occurs during this workflow.

## API surface

### Read

- `GET /api/identity/status`
- `GET /api/identity/groups?q=...`
- `GET /api/identity/groups/:id`
- `GET /api/identity/candidates?catalogId=...`

### Analysis / mutation

- `POST /api/identity/analyze`
  - `catalogId` for an existing catalog record.
  - `candidate` for an unsaved normalized provider candidate.
  - `demo:true` for a datastore-neutral fixture.
- `POST /api/identity/rebuild`
  - Requires `confirm: REBUILD_IDENTITY_INDEX`.
- `POST /api/identity/decision`
  - `action: confirm|reject`.
  - Requires two catalog IDs.
  - Rejecting an already confirmed pair returns a conflict response rather than creating contradictory state.
- `POST /api/identity/preference`
  - Selects the preferred group member for a supported field.

Provider search/detail routes expose `identityMatches`, and catalog-detail responses expose the current group plus candidates.

## UI

Identity Studio is a first-class top-level tab. It exposes:

- Catalog-wide graph KPIs.
- Candidate index rebuild.
- Per-record analysis.
- A deterministic demo.
- Confirmed-group browser.
- Group inspection.
- Conflict visibility.
- Per-field preferred-source controls.

The Identity tab can be opened with `?view=identity`.

## Data safety

- Identity operations are local unless the upstream provider workflow itself is explicitly invoked.
- No provider access token is stored by the identity engine.
- Backup/export includes the identity state.
- Restore filters group members against the restored catalog and removes empty/orphaned groups.
- Catalog bulk deletion prunes identity group membership.
- Rejection history remains auditable, but current confirmed groups cannot be put into contradictory rejected state.
- Demo fixtures never mutate the shipped datastore.

## Validation

`npm run identity:selftest` validates 10 deterministic invariants:

1. Same-type high-confidence matching.
2. Type-mismatch score capping.
3. ISBN normalization.
4. Catalog-wide rebuild candidate generation.
5. Initial group creation.
6. Existing-group merging.
7. Field preference persistence.
8. Rejection suppression.
9. Confirmed identities cannot be treated as rejected state.
10. Demo datastore neutrality.

Regression suites for the preceding provider milestones are retained and rerun in v0.59:

- TMDB: 17 checks.
- IGDB: 25 checks.
- Open Library: 5 checks.

## Known limitations and future work

- v0.59 does not collapse multiple physical catalog rows into one canonical row. Identity groups provide the relationship layer first.
- There is no explicit split/unlink workflow yet; the API protects confirmed pairs from contradictory rejection instead.
- Provider search candidates must enter the canonical catalog before a durable group can be created.
- Field preferences identify the source to prefer; v0.60 will use those preferences as part of field-level multi-provider enrichment.

## Architectural rationale

The identity layer is intentionally separated from enrichment. First determine which records are the same work; only then decide which provider should supply which canonical field. This avoids contaminating identity decisions with mutable provider metadata and gives v0.60 a stable foundation for unified enrichment, provenance and source precedence.

Asian-drama and regional-story support remains part of the canonical identity problem, not a provider silo. Native titles, Romanized titles, alternate international titles, country/language context and related adaptations can all participate in the identity evidence used by future provider integrations.
