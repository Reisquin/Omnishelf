# OmniShelf v0.66 — Medium Experience Framework & Asian Drama Deepening

## Summary
v0.66 turns the v0.65 dedicated-medium concept into a reusable product framework and deepens Asian Drama from a canonical read lens into a provider-aware discovery and controlled-ingestion experience.

## Added
- Reusable `lib/medium-experiences.js` registry and Mediums UI directory.
- `GET /api/mediums` and deterministic medium registry self-test.
- Live/demo Asian Drama provider discovery via TMDB.
- Country-profile routing using TMDB TV `with_origin_country` plus original-language filters.
- Search-first discovery for typed queries, followed by OmniShelf regional classification.
- Per-result metadata-quality scoring and catalog/identity matching evidence.
- Provider-detail inspection before ingestion.
- Explicit Review Queue handoff via an ingestion preview; no automatic catalog mutation.
- Gated streaming-availability lookup powered by TMDB Watch Providers, with explicit JustWatch attribution gate and deterministic demo mode.
- TMDB Watch Providers status endpoint and discovery origin-country support.
- Complete cumulative history through v0.66.

## Compatibility
The v0.59 identity graph, v0.60 unified enrichment engine, v0.61 reliability layer, v0.62 unified search and v0.63 governance boundary remain the underlying data architecture. v0.64 Explore and v0.65 Asian Drama presentation remain intact.

## External-source boundary
TMDB TV Discover currently supports `with_origin_country` and `with_original_language`; TMDB TV Search covers original, translated and also-known-as names. citeturn876975search1turn876975search6

TMDB's TV Watch Providers endpoint states that the data is powered by JustWatch and requires JustWatch attribution, so live availability is behind two explicit configuration gates and is not enabled by default. citeturn876975search0

## Validation fixes
- Multi-language regional profiles are not narrowed to the first language unless the user explicitly selects a provider language.
- Asian Drama provider-detail and ingestion demo flows now resolve the selected discovery fixture, keeping discovery, inspection and Review Queue payloads consistent.
- Ingestion preview explicitly reports that it is read-only.
- Demo Watch Provider links now point at the inspected fixture ID.

## Known limits
- Live TMDB discovery/availability still requires real credentials and network access.
- Romanized titles are never invented.
- Streaming availability remains a read-only provider surface and is not written into the canonical record by v0.66.
- Live visual-browser screenshot capture remains environment-dependent.

## Validation note
The deterministic Asian Drama suite was expanded to include profile-filtered provider-discovery fixtures, metadata-quality signals, and multi-market coverage in addition to the original canonical lens checks.
