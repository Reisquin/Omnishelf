# OmniShelf v0.64 — Build Validation

## Validation matrix
- Catalog Experience deterministic self-test: **8/8**
- Existing Unified Search deterministic regression: **13/13**
- Provider Reliability deterministic regression: **8/8**
- Identity deterministic regression: **10/10**
- Unified Enrichment deterministic regression: **10/10**
- TMDB offline regression: **17/17**
- IGDB offline regression: **25/25**
- Open Library quality regression: **5/5**

## HTTP E2E
Isolated server run on a fresh copy of the v0.63 datastore. Assertions: **7/7**
1. `/api/health` reports v0.64.
2. `/api/catalog/explore` reports a clean zero-item catalog.
3. `/api/catalog/explore/selftest` returns passed=true and 8 checks.
4. Manual catalog creation is visible through Explore.
5. Type facet updates correctly after creation.
6. Tag facet updates correctly after creation.
7. Catalog remains mutable only through the existing governed catalog write path.

## Static validation
- `node --check server.js`: passed.
- `node --check lib/explore.js`: passed.
- Embedded JavaScript syntax check for `public/index.html`: passed.
- `preview.html` is maintained as a byte-identical mirror of `public/index.html`.
- ZIP integrity check: passed.
- Source SHA-256 manifest: regenerated after final edits; zero mismatches.

## Manual/visual boundary
Chromium is available in the build environment, but visual screenshot automation is not used as a release gate because prior releases established this environment's headless-browser instability. The served HTML was verified over HTTP and the source/preview mirrors are kept identical.

## Clean-data verification
The release datastore contains no synthetic catalog records, demo records, test audit entries or temporary validation mutations. All E2E writes were performed on an isolated copy and were not copied back into the shipped datastore.
