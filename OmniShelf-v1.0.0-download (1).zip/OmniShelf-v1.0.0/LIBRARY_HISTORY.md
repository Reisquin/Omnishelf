# Personal Library History — v0.71

## Purpose
The personal library now keeps two distinct layers:

- **Current state** — the latest status, progress, score, favorite state, notes and dates.
- **History** — a chronological event stream describing meaningful changes to that state.

This makes it possible to answer both “What am I doing now?” and “What happened to this work over time?” without changing the canonical catalog.

## Event model
Each history event stores:
- event ID and timestamp
- canonical catalog ID
- title/type snapshot
- action (`added`, `progress`, `completed`, `status.changed`, `session.started`, `favorite.changed`, `score.changed`, `note.changed`, `dates.changed`, `updated`, `removed`)
- progress information when available
- delta for progress events
- previous and next personal-state snapshots when applicable
- source metadata

The title/type snapshot is deliberate: a removal event remains readable even when the current personal record is gone.

## Session semantics
Moving from `completed` into `rewatching`, `rereading`, or `replaying` creates a `session.started` event. The earlier completion event remains intact. This is the first temporal foundation for future session statistics and multi-session views.

## APIs
- `GET /api/library/history` — chronological history with optional catalog/action/date filters.
- `GET /api/library/history/summary` — aggregate event counts and activity dates.
- `GET /api/library/recent/completed` — latest completion events.
- `GET /api/library/recent/added` — latest library additions.
- Work pages expose the latest personal history for the current canonical work.

## Retention
The local history stream retains up to 2,000 events. This bound is intentional for a local product so the datastore cannot grow without limit from small personal updates.

## Backup
Full OmniShelf backups carry `library.history` alongside current personal library state. Restore preserves the event stream, while current personal-library records are still filtered against the restored canonical catalog IDs.
