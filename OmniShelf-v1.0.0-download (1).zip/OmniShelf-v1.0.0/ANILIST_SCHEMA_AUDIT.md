# AniList Schema Audit — v0.48

OmniShelf v0.48 adds two complementary checks:

1. `GET /api/anilist/static-read-matrix` validates that every dedicated read family has a local minimal GraphQL probe.
2. `POST /api/anilist/schema-audit` runs a live introspection request (only in authorized mode) and compares AniList query/mutation root names against the checked-in baseline at `data/anilist-schema-baseline.json`.
3. `POST /api/anilist/full-read-acceptance` runs the full dedicated read probe matrix. It is read-only and requires the HTTP confirmation string `RUN-ANILIST-READ-ACCEPTANCE`.

The audit reports missing and newly observed root names separately. New roots are informational; missing baseline roots are reported as `drift`.

The current AniList reference pages are manually generated and may lag the live schema, so the universal server-side GraphQL gateway remains the authoritative escape hatch.

Auth-only probes: Viewer, Notification, Markdown, and AniChartUser. They are skipped when the readiness report does not contain a valid non-expired access token.
