# OmniShelf v0.63 — Build Validation

## Scope

v0.63 adds the final data governance boundary above the existing identity, enrichment, reliability and unified provider search layers.

## Deterministic validation

The release includes:

- `npm run governance:selftest`
- `npm run unified-search:selftest`
- `npm run reliability:selftest`
- `npm run identity:selftest`
- `npm run enrichment:selftest`
- `npm run tmdb:selftest`
- `npm run igdb:selftest`
- `npm run openlibrary:quality-test`

Final deterministic results:
- Governance: 14/14
- Unified Search: 13/13
- Reliability: 8/8
- Identity: 10/10
- Unified Enrichment: 10/10
- TMDB: 17/17
- IGDB: 25/25
- Open Library: 5/5

## HTTP / workflow validation

The final disposable server validation should cover:

1. `/api/health` reports v0.63.
2. `/api/governance/status` reports application version v0.63 and a deterministic governance policy hash.
3. `/api/governance/policy` returns the active policy and hash.
4. Manual field protection blocks an ordinary provider overwrite.
5. An empty field may be filled by a provider.
6. Explicit governance override can be inspected without mutating production data.
7. `/api/governance/validate` records a validation run and exposes stale/unknown/conflict findings.
8. `/api/governance/deletion-impact/:catalogId` exposes identity/collection/review impact.
9. JSON backup export contains governance state and `backupIntegrity`.
10. `/api/governance/backup/verify` accepts an intact backup.
11. A tampered backup is rejected by both verification and restore validation.
12. Restore preview reports governance state and integrity status.
13. Catalog creation and manual PATCHes carry governance field attribution.
14. Review Queue application carries governance attribution.
15. Existing provider/enrichment/search routes remain functional.
16. Governance UI route serves successfully and the preview mirrors the served UI.

## Known environmental limitation

A headless browser screenshot may remain environment-limited even when the UI serves correctly. A visual capture is not marked passed unless the runtime completes it successfully.

Live provider acceptance is not claimed without provider credentials/network/authorization.

## Final package evidence

Final package evidence:

- Source SHA-256 manifest: 124 entries; 0 mismatches
- ZIP integrity: PASS
- Clean shipped datastore: PASS; no synthetic catalog/provider/reliability/governance test records shipped; governance zero-state is explicitly persisted
- Preview mirror equality: PASS; `public/index.html` and `preview.html` are byte-identical
- HTTP E2E: PASS; 18/18 isolated assertions
- JavaScript syntax: PASS for server, governance module, self-test, and embedded preview scripts
- Headless browser screenshot: not claimed due to container runtime limitation; UI served and HTTP route checks passed
