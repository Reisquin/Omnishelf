# AniList official references used for OmniShelf v0.34

- GraphQL guide: https://docs.anilist.co/guide/graphql/
- Root query reference: https://docs.anilist.co/reference/query
- Root mutation reference: https://docs.anilist.co/reference/mutation
- User: https://docs.anilist.co/reference/object/user
- Favourites: https://docs.anilist.co/reference/object/favourites
- Activity union: https://docs.anilist.co/reference/union/activityunion
- Text/List activity: https://docs.anilist.co/reference/object/textactivity and https://docs.anilist.co/reference/object/listactivity
- Thread: https://docs.anilist.co/reference/object/thread
- Review: https://docs.anilist.co/reference/object/review
- Recommendation: https://docs.anilist.co/reference/object/recommendation
- Airing schedule: https://docs.anilist.co/reference/object/airingschedule
- Rate limiting: https://docs.anilist.co/guide/rate-limiting
- Terms: https://docs.anilist.co/guide/terms-of-use

The official reference is manually generated and the GraphQL schema explorer is the authoritative way to inspect fields available at runtime.

- Mutation Reference (current): https://docs.anilist.co/reference/mutation
- Query Reference (current): https://docs.anilist.co/reference/query
- Pagination (current): https://docs.anilist.co/guide/graphql/pagination

- Current Query Reference reviewed for the expanded Media filter surface: https://docs.anilist.co/reference/query
- GraphQL getting-started and request behavior: https://docs.anilist.co/guide/graphql/
- Pagination guidance: https://docs.anilist.co/guide/graphql/pagination


## v0.36 reference audit
Checked against the current published AniList documentation on 2026-10-05. The documentation states that GraphQL requests are POSTs to `https://graphql.anilist.co` with `query` and `variables`, and the API reference pages are manually generated and may not always be up to date.

Query-reference domains audited for dedicated wrappers include Page, Media, MediaTrend, AiringSchedule, Character, Staff, MediaList, MediaListCollection, GenreCollection, MediaTagCollection, User, Viewer, Notification, Studio, Review, Activity, ActivityReply, Following, Follower, Thread, ThreadComment, Recommendation, Like, Markdown, AniChartUser, SiteStatistics, and ExternalLinkSourceCollection.

Mutation-reference domains audited include UpdateUser, SaveMediaListEntry, UpdateMediaListEntries, DeleteMediaListEntry, DeleteCustomList, SaveTextActivity, SaveMessageActivity, SaveListActivity, DeleteActivity, ToggleActivityPin, ToggleActivitySubscription, SaveActivityReply, DeleteActivityReply, ToggleLike, ToggleLikeV2, ToggleFollow, ToggleFavourite, UpdateFavouriteOrder, SaveReview, DeleteReview, RateReview, SaveRecommendation, SaveThread, DeleteThread, ToggleThreadSubscription, SaveThreadComment, DeleteThreadComment, UpdateAniChartSettings, and UpdateAniChartHighlights.


## v0.38 references rechecked
- Media object reference: https://docs.anilist.co/reference/object/media
- User object reference: https://docs.anilist.co/reference/object/user
- MediaList object reference: https://docs.anilist.co/reference/object/medialist
- Character object reference: https://docs.anilist.co/reference/object/character
- Staff object reference: https://docs.anilist.co/reference/object/staff
- Studio object reference: https://docs.anilist.co/reference/object/studio
- Favourites object reference: https://docs.anilist.co/reference/object/favourites
- Query reference: https://docs.anilist.co/reference/query


v0.38 official references checked: current AniList User reference exposes `statistics: UserStatisticTypes`; UserStats/statistics-related fields reviewed for the statistics workspace.


## v0.38 — User.statistics
- AniList User reference: `statistics: UserStatisticTypes`, the user’s anime & manga list statistics.
- UserStatistics exposes count, mean score, standard deviation, time/progress totals, and ranked dimensions including countries, formats, genres, lengths, release years, scores, staff, start years, statuses, studios, tags, and voice actors.
- The dimension connections accept `UserStatisticsSort`; OmniShelf v0.38 exposes the documented sort variants.
- Reference: https://docs.anilist.co/reference/object/user


## v0.39 references checked
- Query Reference: https://docs.anilist.co/reference/query
- MediaExternalLink: https://docs.anilist.co/reference/object/mediaexternallink
- Mutations guide: https://docs.anilist.co/guide/graphql/mutations
- API Reference overview: https://docs.anilist.co/reference/


## v0.40 verification notes
- Current Query Reference: Page.mediaList is the documented paginated list browser; direct MediaList is for a single list entry.
- Current MediaList object reference exposes `format` and `score`; `scoreRaw` is a mutation input, not a MediaList response field.
- Current mutation reference documents SaveMediaListEntry / UpdateMediaListEntries for authenticated list state changes.


## v0.41 references
- AniList MediaList object: https://docs.anilist.co/reference/object/medialist
- AniList MediaListOptionsInput: https://docs.anilist.co/reference/input/medialistoptionsinput
- AniList MediaListTypeOptions: https://docs.anilist.co/reference/object/medialisttypeoptions
- AniList Mutation Reference: https://docs.anilist.co/reference/mutation
- AniList authentication: https://docs.anilist.co/guide/auth/
- AniList rate limiting: https://docs.anilist.co/guide/rate-limiting


## v0.42 references
- AniList mutation reference documents `DeleteMediaListEntry` for deleting a remote MediaList entry and the `SaveMediaListEntry` input fields used by two-way sync.
- AniList `MediaList` exposes `updatedAt`, `createdAt`, `customLists`, `advancedScores`, and `format`; v0.42 retains these in sync snapshots.


### v0.43 audit notes
- AniList `Page.mediaList` is queried sorted by `UPDATED_TIME_DESC`; incremental scanning uses the returned `updatedAt` field as a local watermark.
- AniList does not expose a dedicated MediaList `updatedAt > cursor` argument in the current Page.mediaList reference, so incremental refresh is implemented by ordered page scanning with an overlap watermark.
- Remote deletion still requires periodic full reconciliation because deleted entries do not appear in MediaList results.
- Official references consulted: Query/Mutation Reference, Page Reference, MediaList Reference, MediaListSort, and mutation authentication guidance.


## v0.44 Asset references
- Media exposes coverImage, bannerImage, trailer, externalLinks, streamingEpisodes and siteUrl.
- MediaCoverImage provides extraLarge, large, medium and average color.
- MediaExternalLink provides url, site, siteId, type, language, color, icon, notes and isDisabled.
- MediaStreamingEpisode provides title, thumbnail, url and site.
- Current API docs: https://docs.anilist.co/reference/object/media ; https://docs.anilist.co/reference/object/mediacoverimage ; https://docs.anilist.co/reference/object/mediaexternallink ; https://docs.anilist.co/reference/object/mediastreamingepisode
