# OmniShelf v0.73 — Build Validation

Release: v0.73 — Personal Statistics 2.0
Base: v0.72

## Deterministic regression matrix

- Personal Library: 7/7
- Library Experience: 14/14
- Library History: 8/8
- Library Collections: 7/7
- Personal Statistics: 14/14
- Standalone Work Pages: 8/8
- Work Page: 8/8
- Catalog UX: 5/5
- Catalog Experience: 8/8
- Medium Framework: 7/7
- Asian Drama: 18/18
- Unified Provider Search: 13/13
- Provider Reliability: 8/8
- Cross-Provider Identity: 10/10
- Unified Enrichment: 10/10
- Final Data Governance: 14/14
- TMDB: 17/17
- IGDB: 25/25
- Open Library: 5/5

All deterministic suites were re-run against the v0.73 codebase and passed.

## Syntax validation

Passed for `server.js`, `lib/library-statistics.js`, the updated work-page module, the library/statistics E2E and self-test scripts, the inherited personal-library/collection E2E harnesses, and the client JavaScript extracted from `public/index.html`.

## Isolated HTTP E2E

### Personal Statistics — 15/15
The disposable-copy E2E verifies an empty statistics payload, catalog seeding, current totals, score median, unit-aware progress, monthly additions/completions/recorded deltas, medium breakdown, score distribution, lifecycle counts, activity calendar, server-side self-test, intact library overview, v0.73 work-page projection, Statistics UI delivery, and backup preservation.

### Personal Library — 19/19
The inherited personal-library E2E continues to verify overview, personal state, quick shelves, progress summary, medium views, filtering, completion, work-page projection, re-experience history, timeline, recent milestones, filtering, UI delivery, backup preservation and post-removal history.

### Smart Library Collections — 17/17
The inherited collection E2E continues to verify built-in presets, custom creation, direct filtering, dynamic reevaluation, save-from-filters, backup/restore and work-page projection.

No HTTP E2E mutates the shipped clean datastore.

## Release integrity

- `preview.html` is byte-identical to `public/index.html`.
- The shipped datastore remains clean: 0 catalog, review, audit, legacy collection, smart-collection, library and history records.
- Clean datastore SHA-256: `6c4d62d5f24bbef59179cf7f120ade7b76dee6d0ad8e5a2fe30b8f28fcb760fa`.
- No separate statistics datastore is introduced.
- Final source manifest contains **191 entries** and verifies with **0 mismatches** against the finalized project tree, including hidden filenames such as `.env.example`.
- The final ZIP contains **201 entries / 192 files** under exactly one `OmniShelf-v0.73` root directory and is independently extracted and revalidated.

## AniList boundary

AniList remains independent from v0.73. No personal-statistics route requires live AniList authorization or live API availability. The previously agreed October 8, 2026 authorization cutoff remains an external decision point and is not assumed either way in this build.

## Known boundaries

Personal statistics are local and read-only. Current-state metrics describe records that still exist in the personal library. Historical trend metrics depend on the durable history events available to OmniShelf. Consumption units are only summed when history records an explicit numeric delta; missing historical deltas are not reconstructed.
