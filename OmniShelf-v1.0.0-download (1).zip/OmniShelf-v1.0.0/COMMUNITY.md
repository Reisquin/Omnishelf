# OmniShelf v0.76 — Social / Community 2.0

## Purpose

v0.76 restores and deepens OmniShelf's community layer as a provider-neutral local product surface. AniList's external Community API remains inside the AniList provider workspace and is not used as the source of OmniShelf community state.

## Community state

`data.community` contains the local community workspace: profiles, follows, public reviews, activity events and review likes. The current local identity is `you`.

Personal favorites for `you` are projected from `data.library.items` through `lib/library.js`; Community does not create a second favorite store for the current user. Other community profiles can expose public favorite work IDs.

## Product surfaces

- **Overview** — profile KPIs, people to know, community activity, latest reviews, and discovery from people you follow.
- **Members** — search public profiles and follow/unfollow members.
- **Activity** — All / Following / Mine feed views over explicit community events. Personal library history is not automatically published.
- **Reviews** — public community reviews with score, spoiler flag, likes, editing and deletion for the current user.
- **From People** — works surfaced from public favorites of followed members or a selected member.
- **Profile** — public identity, network counts, favorites and reviews, plus self-edit controls for the current profile.

## Work Page integration

The Work Page receives a read-only `communityReviews` projection. A direct **Write community review** control opens the Community review editor for the current work. This completes the v0.75 journey's review checkpoint without introducing another catalog or personal-library state system.

## API

- `GET /api/community/overview`
- `GET /api/community/members`
- `GET /api/community/profile/:id`
- `PATCH /api/community/profile`
- `POST /api/community/follow`
- `GET /api/community/following`
- `POST /api/community/favorite`
- `GET /api/community/reviews`
- `POST /api/community/reviews`
- `PATCH /api/community/reviews/:id`
- `DELETE /api/community/reviews/:id`
- `POST /api/community/reviews/:id/like`
- `GET /api/community/activity`
- `GET /api/community/discovery`
- `POST /api/community/selftest`

Passing `demo=1` to the read-only community discovery endpoints returns deterministic sample profiles/reviews/activity built only from the current catalog; demo state is not persisted.

## Architectural boundaries

Community state is provider-neutral. It does not mutate AniList, Open Library, TMDB or IGDB records. Community review publishing is local and auditable. Provider ratings or reviews remain provider metadata and are not silently converted into OmniShelf community reviews.

The current release intentionally does not claim production authentication or multi-user security isolation. The local `you` identity and explicit community records are a product/data model foundation; security, authentication, authorization, migration and failure-hardening remain later production-hardening work.

## Backup / restore

`data.community` is included in full workspace backup exports. Restore sanitizes member favorite references, follow edges, reviews, likes and activity against the restored catalog/member graph so community state cannot retain orphaned references.
