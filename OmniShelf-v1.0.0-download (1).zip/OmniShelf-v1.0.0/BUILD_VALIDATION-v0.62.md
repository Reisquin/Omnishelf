# OmniShelf v0.62 — Build Validation

## Scope

v0.62 adds the read-only Unified Provider Search layer over the canonical OmniShelf catalog and the deep AniList, Open Library, TMDB and IGDB adapters. It adds smart routing, provider fan-out, normalized discovery results, catalog matching, discovery-only cross-provider grouping, partial-failure handling, and a first-class Search workspace. The v0.59 identity graph, v0.60 unified enrichment engine and v0.61 provider reliability/operations layer remain intact.

## Deterministic validation

| Suite | Result |
|---|---:|
| `npm run unified-search:selftest` | **13/13** |
| `npm run reliability:selftest` | **8/8** |
| `npm run identity:selftest` | **10/10** |
| `npm run enrichment:selftest` | **10/10** |
| `npm run tmdb:selftest` | **17/17** |
| `npm run igdb:selftest` | **25/25** |
| `npm run openlibrary:quality-test` | **5/5** |

The Unified Search suite covers smart routing, explicit provider scope, four-provider demo fan-out, non-persistence, stable result IDs, catalog inclusion/exclusion, conservative identity behavior, provider-failure representation, and discovery-only grouping. The retained regression suites protect the existing provider, identity, enrichment and reliability layers.

## Final observed results

- Unified Search deterministic self-test: **13/13**
- Provider Reliability regression: **8/8**
- Cross-Provider Identity regression: **10/10**
- Unified Enrichment regression: **10/10**
- TMDB regression: **17/17**
- IGDB regression: **25/25**
- Open Library quality regression: **5/5**
- Isolated HTTP end-to-end workflow: **15/15 assertions passed**

## HTTP end-to-end validation

An isolated server was started on a non-default test port against the clean v0.61 datastore. The following checks passed in a disposable server workspace:

1. `/api/health` reports v0.62.
2. `/api/search/route` returns deterministic smart routing for broad, Game and Drama intent.
3. `/api/search/route` returns the explicit provider scope unchanged when supplied.
4. `/api/search?demo=1` fans out across AniList, Open Library, TMDB and IGDB without external network access.
5. Demo search returns provider summaries with per-provider status, counts and latency.
6. Demo search returns stable provider result IDs and normalized canonical-style fields.
7. Catalog results remain separate from provider results.
8. Search demo does not persist catalog or identity-group mutations.
9. `/api/search?providers=TMDB&demo=1` constrains the result set to TMDB.
10. `/api/search?type=Game&demo=1` routes to IGDB only.
11. `/api/search?type=Drama&demo=1` routes to TMDB only.
12. `/api/search/route` performs routing without invoking a provider.
13. Queueing a returned normalized provider record uses the existing Review Queue mutation path; Search itself does not bypass review.
14. The disposable Review Queue was restored to its exact pre-test datastore state after the handoff test.
15. The served Search UI is accessible through `/?view=search` and contains the new search workspace controls.

## Source / syntax validation

JavaScript syntax checks passed for:

- `server.js`
- `lib/unified-search.js`
- `lib/anilist.js`
- `lib/openlibrary.js`
- `lib/tmdb.js`
- `lib/igdb.js`
- `lib/identity.js`
- `lib/enrichment.js`
- `lib/reliability.js`
- `scripts/unified-search-selftest.js`

The final release has `public/index.html == preview.html` byte-for-byte after packaging preparation.

## Defects found during v0.62 validation and fixed

- The first TMDB fixture probe used the adapter's already-normalized result as if it were raw data; the validation probe was corrected to use the actual `demoSearch` contract. No shipped TMDB adapter defect was present.
- The first local catalog switch was wired but `includeCatalog=false` was not honored by the orchestrator; the flag is now respected and covered by the self-test.
- Search grouping is explicitly limited to strong evidence so that same-title records with incompatible types are not collapsed into an identity cluster.

## Persistence / safety

Unified Search does not add durable search state to `data/store.json`. It reads the current catalog and identity graph, produces an in-memory response, and leaves identity groups, enrichment runs, reliability history and catalog records unchanged. External provider results can only enter canonical data through the existing Review Queue workflow.

## Live acceptance boundary

No live provider search acceptance is claimed in this environment. Real AniList, Open Library, TMDB and IGDB execution still depends on the provider-specific external conditions documented by each adapter and on network/credential availability.

## Packaging requirements

Final package evidence:

- Source manifest: 119 entries; verification produced zero mismatches.
- Clean shipped datastore: catalog=0, reviewQueue=0, identity.groups=0, enrichment.runs=0, reliability.events=0, reliability.incidents=0.

Before packaging:

- `VERSION.txt` = `0.62.0`
- `package.json` = `0.62.0`
- `npm run unified-search:selftest` is present
- `public/index.html` and `preview.html` match exactly
- source SHA-256 manifest is regenerated after all final source/document edits
- shipped datastore is clean and contains no demo search state
- cumulative project history reaches v0.62 and carries enough implementation detail, rationale, validation evidence and roadmap dependency information to continue from the archive alone
- release ZIP integrity is checked after creation

## Next dependency

v0.63 — Final Data Governance Layer.
