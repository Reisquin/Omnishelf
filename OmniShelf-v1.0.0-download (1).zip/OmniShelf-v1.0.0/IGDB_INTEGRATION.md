# IGDB Integration — OmniShelf v0.58

## Purpose

v0.58 promotes IGDB from the Provider Hub's placeholder into OmniShelf's fourth provider adapter and makes games a first-class canonical work type. IGDB data remains provider-scoped until the planned v0.59 cross-provider identity/reconciliation layer.

The adapter follows the established pipeline:

`IGDB → Search / Discover → Normalize → Match → Review → Apply / Enrich → Entity Registry`

The canonical catalog remains the system of record. Provider payloads are retained under `providerMetadata.igdb` and `raw`, with explicit provenance.

## Current scope

### Discovery
- Game search with bounded pagination and result limits.
- Game discovery with optional platform, genre, theme, release-year and sort filters.
- Search and discovery results include provider-aware catalog match candidates.

### Rich game details
A normalized game can retain:
- IGDB ID, slug and canonical IGDB URL.
- Summary and storyline.
- First release date and release year.
- Full release-date records with platform, region and status when supplied.
- Platforms and platform-type information.
- Developer, publisher, porting and supporting companies.
- Genres, themes, keywords, game modes and player perspectives.
- Collection and franchise relationships, plus version/parent-game metadata.
- Alternative names and localized titles.
- External game identifiers and links.
- Age ratings and content-description labels when supplied.
- Game engines.
- Websites and video records.
- Cover, artwork and screenshot references.

### Entity layer
Approved or explicitly enriched records feed the persistent `data.igdb` registry:
- `companies`
- `platforms`
- `collections`
- `franchises`
- `enrichmentJournal`
- `reviewDiagnostics`

Each persisted entity records the IGDB provider identity and linked canonical/provider work IDs where applicable. v0.58 does not claim that an IGDB company/platform identity is globally canonical; that belongs to later reconciliation work.

## Canonical mapping

IGDB records normalize to OmniShelf:

`IGDB Game → Game`

No attempt is made in v0.58 to split or merge games across AniList, Open Library, TMDB, or manual records. Provider-aware matching can identify likely existing records; it does not automatically merge them.

The normalized record is deliberately additive. Existing non-empty manual catalog fields are retained during enrichment. Provider-specific data is stored under `providerMetadata.igdb` and raw snapshots are preserved under `raw.igdbGameSnapshot`.

## Identity diagnostics

The v0.58 matcher uses these signals, in descending importance:
1. Exact IGDB ID when the existing record is already an IGDB record.
2. Shared alternate/localized title.
3. Release year.
4. Canonical type compatibility.
5. Title similarity.

An exact IGDB provider identity remains a hard `1.00` match; secondary evidence never downgrades it.

Cross-provider identity, confidence calibration across providers, merge/reject decisions, and field-level conflict resolution remain scheduled for v0.59.

## Enrichment

Enrichment is preview-first.

1. A canonical catalog record is selected.
2. An explicit IGDB provider ID is selected, or an existing IGDB identity is used.
3. OmniShelf retrieves/normalizes the game.
4. A preview reports changed canonical field groups, quality score, release/platform counts and entity counts.
5. Apply is explicit and writes an audit event.
6. Entity registry state is updated together with the canonical record.

A safety check prevents a canonical record belonging to another provider from accidentally using that provider's numeric ID as an IGDB ID. Cross-provider enrichment must supply an IGDB identity explicitly or have one already attached in `providerMetadata.igdb`.

## Review Queue

IGDB search results can be sent to the existing Review Queue. Review diagnostics record provider-aware match candidates and the IGDB quality report. When an approved IGDB item is applied through the common provider-apply route, the entity registry is updated in the same operation.

This preserves the same human-controlled ingestion rule used by Open Library and TMDB instead of silently inserting provider search results into the canonical catalog.

## Server/API surface

- `GET /api/igdb/status`
- `GET /api/igdb/cache`
- `POST /api/igdb/cache/clear`
- `GET /api/igdb/search?q=...`
- `GET /api/igdb/discover?...`
- `GET /api/igdb/games/:id`
- `GET /api/igdb/companies/search?q=...`
- `GET /api/igdb/platforms/search?q=...`
- `GET /api/igdb/collections/search?q=...`
- `GET /api/igdb/franchises/search?q=...`
- `GET /api/igdb/companies/:id`
- `GET /api/igdb/platforms/:id`
- `GET /api/igdb/collections/:id`
- `GET /api/igdb/franchises/:id`
- `POST /api/igdb/quality/analyze`
- `POST /api/igdb/matches`
- `GET /api/igdb/entities`
- `POST /api/igdb/enrich/preview`
- `POST /api/igdb/enrich/apply`
- `GET /api/igdb/live-acceptance` (returns an explicit method error)
- `POST /api/igdb/live-acceptance`
- `POST /api/review/queue` (common review path; IGDB diagnostics are provider-aware)
- `POST /api/providers/apply` (common review approval/apply path; IGDB entities persist on apply)

## Authentication / network boundary

IGDB requests are server-side only. The browser never receives or directly uses the client secret.

Supported configuration:
- `IGDB_CLIENT_ID` + `IGDB_CLIENT_SECRET` for Twitch client-credentials token acquisition.
- Or `IGDB_CLIENT_ID` + `IGDB_ACCESS_TOKEN` for an operator-supplied application token.

The access-token state is kept in memory and not written to the datastore. Client-credential tokens are refreshed after a first 401 response. Explicit `IGDB_ACCESS_TOKEN` mode does not attempt to manufacture or persist a replacement token.

The adapter serializes outbound calls with a conservative interval and retries a single rate-limit condition inside a bounded wait. This is intentionally more defensive than simply firing requests concurrently.

## Caching and image policy

- Five-minute in-memory cache.
- 200-entry cache bound.
- No provider payload cache is persisted in `data/store.json`.
- Cover/artwork/screenshot references remain remote URLs; v0.58 does not bulk-copy IGDB image bytes into the local datastore.
- The image helper derives a URL from an IGDB `image_id` and a documented image size when a direct image URL is not already supplied.

## Demo mode

The demo workspace is deterministic and network-free. It includes:
- A Japanese-themed narrative game fixture with native title/localization data.
- Region-aware Japanese/Asia release records.
- Multiple platforms.
- Developer/publisher companies.
- Collection/franchise relationships.
- External store identifier.
- Age rating.
- Artwork, screenshot and trailer fixtures.

Demo results use the same normalization and matching code as live data. They do not call IGDB or Twitch.

## Validation model

`npm run igdb:selftest` validates the offline contract, including:
- canonical Game mapping;
- release/platform/company/localization normalization;
- external IDs and age ratings;
- image URL generation;
- Review/identity assumptions;
- exact-provider-ID match precedence;
- manual-field-preserving enrichment;
- raw provider snapshot retention;
- entity bundle population;
- demo Provider Hub compatibility;
- unconfigured safe-default state.

`npm run igdb:acceptance -- --plan` prints the operator plan. `npm run igdb:acceptance -- --query=...` is the read-only live run and requires network access plus valid credentials.

## Deliberate non-goals

v0.58 does not implement:
- IGDB write mutations.
- Automatic cross-provider merges.
- A global canonical platform/company identity model.
- Bulk harvesting of IGDB as an offline dump pipeline.
- Watch/streaming availability as a canonical provider field.

These are intentionally separated from this release so the provider adapter remains testable and auditable.
