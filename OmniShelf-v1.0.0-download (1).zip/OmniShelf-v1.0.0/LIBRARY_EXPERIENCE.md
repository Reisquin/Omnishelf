# OmniShelf v0.70 — Everyday Personal Library Experience

## Purpose
v0.70 turns the v0.69 personal-library layer from a tracking form into an everyday workspace. The canonical catalog remains the source of truth for works; personal state remains separate and user-owned.

## Everyday library overview
`GET /api/library/overview` exposes a read-only dashboard built from the existing personal library records. It provides:
- current library statistics and status counts
- a measurable-progress summary only where a finite total exists
- quick-shelf counts for Continue, Plan to, Completed and Favorites
- compact sections for Continue, Plan to, Completed, Favorites and Recently Updated
- per-medium personal statistics

The overview does not create duplicate catalog records or persist presentation-specific state.

## Medium-specific personal views
`GET /api/library/medium/:type` exposes one medium lens using the same canonical IDs and personal records. A medium view includes:
- tracked item count
- active / planning / paused / completed / dropped counts
- favorite count
- average personal score
- finite progress coverage
- active items
- planned items
- recently updated items

This allows Anime, Manga, Novels, Games, Movies, TV, Drama and other supported media to feel different at the personal-workflow level without creating separate libraries.

## UI changes
The My Library surface now includes:
- an at-a-glance progress dashboard
- quick shelves for the most common actions
- a medium directory with per-medium counts and score/progress signals
- selectable medium personal views
- compact Continue / Plan Next / Recently Updated shelves
- the existing searchable, filterable, sortable, paginated full library grid

One-click progress advancement remains medium-aware through the v0.69 `library.inferProgressMeta()` contract.

## Safety and boundaries
- Personal state never overwrites canonical/provider metadata.
- Read-only dashboard endpoints do not mutate the datastore.
- Personal writes continue through the existing governed library routes and audit trail.
- Backup/restore behavior from v0.69 remains unchanged and continues to carry personal state.
- AniList synchronization remains a separate provider workflow; v0.70 does not couple the personal dashboard to upstream provider availability.

## Validation
`npm run library:selftest` preserves the v0.69 personal-library unit contract.
`npm run library:experience:selftest` validates the v0.70 dashboard model, quick shelves, measurable progress summary, and medium-specific view model.
An isolated HTTP E2E suite validates the overview and medium endpoints using a disposable datastore copy.
