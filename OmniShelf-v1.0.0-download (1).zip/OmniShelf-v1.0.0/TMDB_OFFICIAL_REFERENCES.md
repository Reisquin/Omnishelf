# TMDB Official References

These references were consulted while implementing v0.57 and should be re-checked before production deployment because TMDB can update its documentation and terms.

- API v3 reference: https://developer.themoviedb.org/reference/intro/getting-started
- Authentication / API access: https://developer.themoviedb.org/docs/authentication-application
- Append to response: https://developer.themoviedb.org/docs/append-to-response
- Image basics: https://developer.themoviedb.org/docs/image-basics
- Movie images: https://developer.themoviedb.org/reference/movie-images
- TV season details: https://developer.themoviedb.org/reference/tv-season-details
- API FAQ / attribution guidance: https://developer.themoviedb.org/docs/faq
- API Terms of Use: https://www.themoviedb.org/api-terms-of-use
- TMDB branding: https://developer.themoviedb.org/docs/getting-started

Implementation notes derived from these sources:
- The Read Access Token / Bearer mechanism is preferred for v3 application auth.
- `append_to_response` is used for bounded rich-detail reads.
- TMDB image URLs are derived from the returned file paths and remain remote references.
- The live adapter treats HTTP 429 as a rate-limit condition and retries once within a bounded window.
- Attribution/licensing requirements must be re-checked for the final deployment context.
