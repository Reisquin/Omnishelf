# OmniShelf v0.74 — Build Validation

Release: v0.74 — Recommendations 2.0

## Recommendation validation
- Recommendations self-test: **10/10**
- Recommendations HTTP E2E: **14/14**
- Empty-library discovery mode verified.
- Personalized mode verified after meaningful personal signal.
- Existing library items excluded from candidates.
- Explicit relation bonus verified.
- Creator/theme/medium signals verified.
- Provider rating normalization verified across AniList, TMDB, IGDB and Open Library scales.
- Medium filtering, discovery mode, quality threshold, and result limit verified.
- Recommendations are read-only and do not persist recommendation records.
- Smart Collection rule affinity is incorporated into ranking.
- Recent history events contribute a bounded recency preference signal.
- Personal Statistics are used to strengthen profile classification.

## Regression matrix
The inherited deterministic suites were re-run after the v0.74 recommendation changes:

| Suite | Result |
|---|---:|
| Personal Library | 7/7 |
| Library Experience | 14/14 |
| Library History | 8/8 |
| Smart Library Collections | 7/7 |
| Personal Statistics 2.0 | 14/14 |
| Recommendations 2.0 | 10/10 |
| Standalone Work Pages | 8/8 |
| Work Page | 8/8 |
| Catalog UX | 5/5 |
| Catalog Experience | 8/8 |
| Medium Experiences | 7/7 |
| Asian Drama | 18/18 |
| Unified Provider Search | 13/13 |
| Provider Reliability | 8/8 |
| Cross-Provider Identity | 10/10 |
| Unified Enrichment | 10/10 |
| Final Data Governance | 14/14 |
| Open Library Quality | 5/5 |
| TMDB | 17/17 |
| IGDB | 25/25 |

## HTTP E2E
- Recommendations: 14/14
- Personal Library Experience: 19/19
- Smart Library Collections: 17/17
- Personal Statistics 2.0: 15/15

All HTTP mutation tests use disposable project copies and do not mutate the release datastore.

## Static checks
- `server.js`, `lib/recommendations.js`, `lib/work-pages.js`, and current E2E scripts pass Node syntax validation.
- All embedded `public/index.html` JavaScript blocks pass syntax compilation.
- `preview.html` and `public/index.html` are byte-identical.

## Release integrity
Final source-manifest count is 198 files excluding the manifest itself. The final archive contains one top-level root directory, 199 file entries, and 9 nested directory entries (208 total ZIP entries); the immutable ZIP SHA-256 is reported with the release handoff.

AniList remains independent from v0.74. Recommendations never perform live AniList/API calls.
