# OmniShelf v0.44 — AniList Acceptance Checklist

## Current status

AniList is the sole active provider workstream.

**Local implementation status:** release-candidate complete for the implemented AniList surface.

**Live acceptance status:** pending a network-enabled environment and a real AniList application/account because this build environment cannot reach AniList upstream.

## Covered domains

- Media search / browse / detail
- Media type/format normalization
- Covers and cover color
- Banner images
- Trailers (identity/site/thumbnail)
- Legal streaming episode references and thumbnails
- External-link metadata and icons
- Relations
- Characters / voice actors
- Staff / roles
- Studios
- Recommendations
- Reviews
- Media statistics / trends / airing
- Users / followers / following
- Activities / replies / likes / subscriptions
- Forums / threads / comments
- Notifications
- Favourites and favourite ordering
- User lists / MediaList / MediaListCollection / Page.mediaList
- List options / custom lists / advanced scoring
- User statistics
- Site statistics
- Genres / media tags
- Markdown parsing
- AniChart user/settings/highlights
- OAuth authentication
- Generic GraphQL gateway for schema evolution
- Reference audit / field audit
- Caching, timeout, rate-limit handling
- Two-way list sync
- Conflict resolution
- Deletion tombstones
- Incremental sync / watermark / run journal / idempotency / recovery
- Review-queue integration and canonical catalog application

## Asset guarantees

When AniList supplies these fields, OmniShelf preserves them in the normalized `mediaAssets` structure and provider metadata:

- `coverImage.extraLarge`
- `coverImage.large`
- `coverImage.medium`
- `coverImage.color`
- `bannerImage`
- `trailer.id`
- `trailer.site`
- `trailer.thumbnail`
- `streamingEpisodes[].title`
- `streamingEpisodes[].thumbnail`
- `streamingEpisodes[].url`
- `streamingEpisodes[].site`
- `externalLinks[]` metadata including `url`, `site`, `siteId`, `type`, `language`, `color`, `icon`, `notes`, `isDisabled`
- `siteUrl`

## Final live acceptance procedure

1. Configure AniList OAuth client ID, client secret, and exact redirect URI.
2. Connect an AniList account.
3. Load Viewer + list options + statistics.
4. Browse/search Media and open a rich Media detail.
5. Verify cover, banner, trailer thumbnail, streaming references, and external links.
6. Queue an AniList Media item and apply it through the Review Queue.
7. Verify `mediaAssets` and provider metadata in the canonical catalog.
8. Run a two-way sync preview.
9. Resolve a controlled local/remote conflict.
10. Test a remote list deletion and tombstone resolution.
11. Run incremental sync, verify watermark commit and idempotency replay.
12. Run a full reconciliation to detect deletions that incremental scans cannot see.

## Network limitation

Live AniList upstream calls are not claimed as tested in the current build environment because outbound DNS/network access is unavailable.


## v0.45 — Compliance / Authorization Gate

- Live AniList access defaults to disabled (`ANILIST_MODE=demo`).
- Live GraphQL, OAuth and upstream health calls require both `ANILIST_MODE=authorized` and `ANILIST_AUTHORIZED_USE=true`.
- `/api/anilist/compliance` exposes the current gate state and links to AniList's current Terms of Use.
- Demo routes remain available without credentials or upstream access.
- The gate is an operational safeguard; it does not grant permission to use the AniList API. Any required AniList permission/license must be obtained separately.


## v0.45 Acceptance Checklist

- [x] Default live access is disabled (`ANILIST_MODE=demo`).
- [x] Live GraphQL, OAuth, and upstream health require explicit authorized mode.
- [x] Compliance endpoint and UI panel are present.
- [x] Demo routes remain functional without upstream access.
- [x] Live-block behavior returns HTTP 451 from representative live endpoints.
- [ ] Live AniList acceptance in a network-enabled environment after required authorization/permission is confirmed.

### v0.53 enrichment checks
- Create an AniList canonical catalog item.
- Preview full Media-detail enrichment.
- Confirm deep connection counts are surfaced.
- Apply using the preview `updatedAt`.
- Verify providerMetadata.anilistDetail and raw Media detail are retained.
- Verify existing manual description/tags/aliases/creators are preserved.
- Reuse the old preview and expect HTTP 409 stale-preview rejection.


## v0.54 write acceptance

- [x] Separate CLI from read-only acceptance
- [x] Default plan-only behavior
- [x] Explicit `ANILIST_WRITE_ACCEPTANCE=true` gate
- [x] Explicit `--confirm-write` gate
- [x] Explicit operator-selected media ID
- [x] Existing-entry Save/Update/restore path
- [x] New-entry Save/Update/Delete cleanup path
- [x] Optional favourite round-trip
- [x] No access token output
- [x] Demo mode remains non-writing
- [ ] Live upstream execution from a network-enabled, authorized deployment
