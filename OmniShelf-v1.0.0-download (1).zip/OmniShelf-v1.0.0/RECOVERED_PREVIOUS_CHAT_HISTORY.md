# Recovered Previous-Chat History — OmniShelf

This document records historical OmniShelf progress recovered from the user-supplied previous-chat transcript (`Omnishelf Chat (1).docx`) and the actual version archives v0.2 through v0.20.

This is a historical source record, not a claim that every old feature remains active unchanged in the current application. The current source/version takes precedence for implementation behavior.

## Recovered version history

### v0.2 — Foundation / Core Domain
Verified from the supplied v0.2 README and source archive.
- Working local Express + SQLite application.
- SQLite-backed catalog.
- Unified title model with media-specific progress units.
- People, characters, companies, platforms, external IDs, relations, users, library entries, collections, reviews, and activity tables.
- REST API for search, title details, types, library, stats, activity, creating titles, and updating library entries.
- Responsive API-connected UI.
- Domain principle: a title has a `type_slug`; the type defines its natural progress unit.

### v0.3 — Authentication / Admin / Provider Foundation
Verified from the supplied v0.3 README and source archive.
- Session authentication using secure HTTP-only cookies.
- First-class admin role.
- Metadata-provider adapters for AniList, Open Library, TMDB, and IGDB.
- Duplicate detection using canonical title keys and same-type matching.
- Admin import flow with force-import fallback.
- Relationship creation between catalog entries.
- SQLite local default plus PostgreSQL schema/deployment path.

### v0.4 — Ratings / Favorites / Rankings / Genres
Verified from the supplied v0.4 README and source archive.
- AniList-inspired 1–100 rating system.
- Weighted community score.
- Persistent Favorites page.
- Cumulative progress-language updates.
- Highest Rated, Release Dates, and Genres pages.
- Queryable genre tables.
- Automatic migration from legacy 10-point scores to 100-point scores.
- Existing Catalog Studio and provider ingestion retained.

### v0.5 — Rich Title Pages / Profiles / Reviews
Verified from the supplied v0.5 README and source archive.
- Dedicated linkable title pages.
- Synopsis, metadata, genres, people, characters, companies, platforms, relationships, rating distribution, reviews.
- Persistent Favorites with media and sorting filters.
- Cumulative progress display.
- Public profile page with library/completion/favorites stats, favorites, and recent activity.
- Reviews support optional 1–100 score and spoiler-free flag.

### v0.6 — Social / Library Layer
Verified from the supplied v0.6-fixed README and source archive.
- Favorites remain first-class.
- Cumulative progress updates.
- 1–100 community scoring.
- User profiles and follower counts.
- Follow/unfollow.
- Custom public/private collections with title management.
- Detailed statistics by medium/status.
- Personalized recommendations based on favorite genres.
- Existing catalog ingestion/admin relationship tools retained.

### v0.7 — Activity-First Home / UI Direction
Verified from the supplied v0.7 archive README/source.
- Home became activity-first.
- Two-column activity stream and right-side shelf rail.
- Compact status composer.
- Quick discovery links.
- Light blue/lilac OmniShelf visual direction.

### v0.8 — Continuation of Activity-First UI
Verified from the supplied v0.8 archive. Its bundled README still identifies the v0.6 base, while the shipped source is a later UI continuation; the archive is retained as evidence for that stage.

### v0.9 — Profile Favorites / Navigation Refinement
Verified from the supplied v0.9 README and source archive.
- Home remains activity-first.
- Continue / Curated for You / Jump Around rail removed.
- Discover remains a top-level Browse destination.
- Prominent Favourites hub on profiles.
- Work favourites cover supported media types.
- Profile favourites cover Characters, Arcs/Routes/Parts, Dynamics, and People.
- Work favourites can be filtered by medium.

### v0.10 — Interactive Favorites
Verified from the supplied v0.10 README/source archive.
- Interactive Favorites in profile preview.
- Work favorites cover 12 media types in that version's approved taxonomy.
- Favorite Characters, Arcs/Routes/Parts, Dynamics, and People can be toggled.
- Favorite state persists in browser localStorage in the standalone preview.
- Medium filter on profile work favorites.
- No “Your Shelf”, “Curated for You”, or “Jump Around” sections added to Home.
- Discover remains top-level.

### v0.11 — Entity & Discovery
Verified from the supplied v0.11 README/source archive.
- Dedicated clickable pages for works, characters, people, arcs/routes/parts, and dynamics.
- Universal global search grouped by entity type.
- Clickable relationships between works and related entities.
- Favorites toggled directly from entity pages.
- Highest Rated supports media + genre filtering.
- Release Dates has dedicated chronological browsing.
- Discover remains top-level.
- Home remains activity-first.

### v0.12 — Expanded Storytelling Taxonomy
Verified from the supplied v0.12 README/source archive.
- Expanded storytelling media taxonomy including Anime, Manga, Manhwa, Manhua, Novel, Light Novel, Web Novel, Visual Novel, Game, Movie, TV, Comic, Graphic Novel, Webcomic, Narrative Poetry, Poetry, Play, Screenplay, Short Story, Short Story Collection, Novella, Anthology, Audiobook, Audio Drama, Radio Drama, Fiction Podcast, Opera, Musical Theatre, Libretto, Interactive Fiction, Gamebook, Epic / Oral Tradition, Memoir / Autobiography, Documentary, Tabletop RPG, Dance Theatre, Puppet Theatre, Photo Narrative.
- Media page grouped the storytelling forms.
- Discover, Highest Rated, Release Dates, and Profile Favorites used the expanded taxonomy.

### v0.13 — Taxonomy Refinement
Verified from the supplied v0.13 README/source archive.
- Continued the expanded storytelling-medium system.
- The bundled README reflects a refined list with some forms removed relative to v0.12.
- Media, Discover, Highest Rated, Release Dates, and Profile Favorites remained aligned to the same taxonomy system.

### v0.14 — Universal Catalog / Browse Foundation
Verified from the supplied v0.14 README/source archive.
- Advanced Discover filters: search, medium, genre, sort.
- Dedicated Trending and Popular pages.
- Highest Rated supports medium, genre, minimum rating-count, and sort order.
- Release Dates remains dedicated.
- Existing Favorites profile system retained.
- Existing interconnected Work / Character / Person / Part / Dynamic pages retained.
- Latest approved storytelling-medium taxonomy carried forward.

### v0.15 — Community & Progress Interaction Layer
Verified from the supplied v0.15 README/source archive.
- 1–100 personal ratings.
- Cumulative progress updates.
- Progress history on title pages.
- Write/update/delete reviews.
- Community review display.
- Activity-feed status posting.
- Activity detail modal with likes and replies.
- Add-to-library flow with status, progress, and personal score.
- Existing favorites, profile, entity pages, discovery, rankings, genres, release dates, and expanded taxonomy retained.

### v0.16 — Community Layer
Verified directly from the supplied previous-chat transcript.
- Discover members / search users.
- Follow / unfollow.
- Follower, following, completed-title, and interest stats.
- Public profiles with bio, network statistics, recent activity, public favorites, and favorite works with medium + score.
- Home activity tabs: All activity / Following / Mine.
- Following feed changes when following another member.
- Dedicated Reviews page with media filtering, minimum score, newest, highest score, and most-liked sorting.
- Preview HTTP 200 and JavaScript syntax validation were reported.

### v0.17 — Recommendations / Custom Lists / Statistics
Verified directly from the supplied previous-chat transcript.
- Top-level Recommendations page.
- Personalized recommendations from favorites, ratings, genres, and media preferences.
- Medium/genre filters and refreshable ranking.
- Explanation for why recommendations appeared.
- Public/private custom lists.
- Create/edit/delete lists.
- Add titles to multiple lists.
- Add-to-list from title pages.
- Reordering and removal.
- Library totals, completed/current counts, average personal score, medium/genre distributions, 1–100 rating distribution, review/progress statistics, and all Favorite categories counted.
- Home remains the activity/update feed rather than becoming recommendations-first.

### v0.18 — Advanced Search / Catalog Studio / Relationship Manager
Verified directly from the supplied previous-chat transcript.
- Advanced combined search, e.g. Action + Manga + 1990–2020 + 80+ + Highest Rated.
- Filters: keyword, entity type, medium, genre, year range, minimum score, status, sort order.
- Searches works, characters, people, story parts, and dynamics.
- Catalog Studio for duplicate detection/review, metadata gaps, relationship issues, pending imports, metadata editing, and issue resolution.
- Relationship Manager supports Adaptation, Source Material, Sequel, Prequel, Remake, Spin-off, Side Story, and Alternative Version.
- Relationships stored locally in preview at that stage.

### v0.19 — Rich Catalog Data
Verified directly from the supplied previous-chat transcript and the v0.19 archive README.
- Alternate/native-language titles.
- Complete release information and medium-specific metadata.
- Credits.
- Studios, publishers, developers, directors, playwrights.
- Themes and tags.
- Editions and release history.
- External references.
- Story structure.
- Arcs / routes / parts.
- Connected adaptations and related works.
- Medium-specific metadata behavior: e.g. Visual Novel routes/platforms; Game platforms/playtime/developer; Play acts/playwright/premiere; Novel pages/publisher/author.
- Character pages with alternate names, affiliations, traits, primary work, connections.
- People pages with roles and known works.
- Arc/Route/Part pages with parent-work relationship.
- Dynamic pages connecting members directly to character pages.

### v0.20 — Catalog Operations / Data Hub
Verified directly from the supplied previous-chat transcript and the v0.20 archive README.
- Data Hub in main navigation.
- JSON/CSV import, drag/drop, and paste.
- Preview before changes.
- Required-field validation.
- Duplicate detection against catalog and within import.
- Merge existing titles vs only-add-new mode.
- Approved-apply workflow.
- Import history.
- Catalog health checks.
- Missing descriptions/genres and incomplete-record detection.
- JSON/CSV export.
- Import template download.
- Dependency-free Node server.
- API: `GET /api/health`, `GET /api/catalog`, `POST /api/import`, `GET /api/export`.

## Current continuation point

The post-v0.20 project was then continued in the current conversation through the Provider Hub and deep AniList workstream, with v0.43 as the latest packaged state at the time this recovery record was created.

## Source files supplied by the user

The recovery set includes the actual archives:
- OmniShelf-v0.2.zip
- OmniShelf-v0.3 (1).zip
- OmniShelf-v0.4.zip
- OmniShelf-v0.5-web (1).zip
- OmniShelf-v0.6-fixed.zip
- OmniShelf-v0.7.zip
- OmniShelf-v0.8.zip
- OmniShelf-v0.9.zip
- OmniShelf-v0.10.zip
- OmniShelf-v0.11.zip
- OmniShelf-v0.12.zip
- OmniShelf-v0.13.zip
- OmniShelf-v0.14.zip
- OmniShelf-v0.15.zip
- OmniShelf-v0.16.zip
- OmniShelf-v0.17 (1).zip
- OmniShelf-v0.18.zip
- OmniShelf-v0.19.zip
- OmniShelf-v0.20.zip
- Omnishelf Chat (1).docx

The exact previous-chat transcript recovered in the DOCX contains the detailed v0.16–v0.20 milestone summaries, including the stated validation results and the declared next-step handoffs.

## Current continuation — v0.61 Provider Reliability & Operations
The project continued from the generated v0.60 archive. v0.61 implemented provider-neutral operational state for AniList, Open Library, TMDB and IGDB; success/failure/cache/latency/rate-limit metrics; bounded event and incident history; provider-local circuit isolation after repeated transient failures; shared backoff/Retry-After coordination; stale-data detection; readiness and acceptance APIs; a Reliability UI workspace; and reliability persistence in backup/restore. Validation found and fixed an omitted `providerStatus` export that initially broke `/api/health` and provider status routes, and expanded the deterministic reliability self-test to 8 checks. HTTP E2E verified provider-local configuration failures, demo isolation, staleness/events, acceptance reporting, backup/restore telemetry and explicit reset to clean state. The shipped v0.61 datastore is clean. Next dependency: v0.62 Unified Provider Search.
