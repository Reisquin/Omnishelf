# OmniShelf v0.80 — Production Hardening

v0.80 hardens the established OmniShelf application for safer local operation, recovery, observability and failure isolation without changing the canonical catalog, provider, personal library, community or medium-personal ownership boundaries.

## Workspace safety

- `workspaceSchemaVersion` is explicit and startup migration is deterministic.
- `store.json` writes use a temporary file, `fsync` and atomic rename so an interrupted write cannot leave a partially written JSON file.
- Workspace validation checks catalog structure, duplicate provider identities, personal-library references, history references, collections, smart collections and Community references.
- Restore validates the backup payload and resulting workspace before replacement.

## HTTP hardening

- Every response carries a unique `X-Request-Id`.
- Adds `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`, `Cross-Origin-Resource-Policy` and a restrictive Content Security Policy.
- Request URI length and JSON body size are bounded.
- JSON parsing rejects dangerous object keys (`__proto__`, `prototype`, `constructor`) and excessive nesting.
- Read and write requests are rate-limited per client address.
- Node request/header/keep-alive timeouts are bounded and malformed client connections are rejected cleanly.

## Observability and failure isolation

- Requests are logged as structured JSONL with method, path, status, duration and request ID.
- Errors and fatal process events are logged separately without request bodies or provider secrets.
- Runtime logs rotate after 5 MiB and keep one previous segment.
- `SIGINT` / `SIGTERM` trigger graceful HTTP server shutdown with a bounded fallback.
- The existing provider reliability layer remains provider-local; v0.80 does not replace it with a global provider dependency.

## Recovery

- `/api/production/backups` lists the five newest local recovery snapshots.
- `/api/production/backup` creates an integrity-hashed backup of the current workspace.
- `/api/production/restore` requires the explicit `RESTORE_PRODUCTION_BACKUP` confirmation token.
- Every restore first creates a `pre-restore` recovery snapshot so a failed or unwanted restore can be rolled back.
- Backup files are created with restricted `0600` permissions.

## System surface

The new **System** tab exposes runtime status, workspace validation and recovery controls without introducing a second datastore. Operational backups and logs are runtime artifacts and are not populated in the shipped clean datastore.

## API

- `GET /api/production/status`
- `GET /api/production/validate`
- `GET /api/production/backups`
- `POST /api/production/backup`
- `POST /api/production/restore`

## Boundaries

v0.80 does not claim live provider acceptance. AniList authorization/live acceptance remains an independent externally gated concern, and Open Library/TMDB/IGDB remain subject to their existing provider-specific acceptance and reliability boundaries.

## Validation commands

`npm run production:selftest` runs deterministic hardening checks.

`npm run production:http-e2e` runs disposable-workspace HTTP checks for security headers, workspace health, validation, backup creation/listing, restore confirmation and backup retention.
