# AniList Final Integration Audit — v0.51

## Purpose

v0.51 verifies the local canonical data lifecycle for rich AniList provider records. The audit is deliberately datastore-neutral and does not call AniList or perform mutations.

## What is checked

- Provider identity is preserved.
- AniList `providerMetadata` is preserved.
- The full provider `raw` payload is preserved when present.
- `mediaAssets` are preserved.
- Catalog relationships are preserved.
- Media-list score format/state can survive the canonical record lifecycle.
- Sync tombstones/runs/cursors remain represented in workspace backup payloads.
- Rich AniList fields survive the same normalization path used by full workspace restore.

## Runtime checks

Demo audit endpoint:

`GET /api/anilist/integrity/audit?demo=1`

CLI:

`npm run anilist:integrity-audit`

The CLI exits non-zero if any integrity assertion fails.

## Important limitation

This is not a live AniList service test. Live AniList reads and authenticated writes require a network-enabled deployment and remain behind the explicit AniList authorization/compliance gate. AniList's current API is GraphQL and its current documentation/reference should be treated as the upstream contract.


## v0.53 enrichment integrity
The canonical enrichment path is tested separately because provider search results may contain only a partial Media shape. Enrichment rehydrates the full Media detail record before applying it to the canonical catalog.

## v0.53 — Canonical enrichment acceptance
- An approved AniList catalog item can be previewed and enriched from the full Media detail response.
- Enrichment preserves existing OmniShelf identity and non-empty manual metadata while unioning provider-derived tags, aliases, creators and external links.
- The rich provider snapshot retains the selected Media detail response, including assets and deep connection blocks when supplied.
- Apply is protected by a catalog `updatedAt` precondition to prevent stale previews from overwriting newer changes.
