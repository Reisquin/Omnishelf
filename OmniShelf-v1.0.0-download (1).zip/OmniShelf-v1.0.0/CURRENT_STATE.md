# OmniShelf Current State — v1.0

OmniShelf 1.0.0 is the production release of the audited v1.0 release candidate. It preserves the full project-owned application scope and records the final production-release boundary.

## 1.0.0 current state
- All project-owned product layers through v0.80 are preserved: canonical catalog, four-provider hub, identity, enrichment, reliability, governance, Explore/Catalog, medium experiences, Work Pages, Personal Library, History, Smart Collections, Statistics 2.0, Recommendations 2.0, Unified Workflow, Community 2.0, portable migration, UI/UX/accessibility and Production Hardening.
- Version/runtime metadata and current-facing release documentation are synchronized to v1.0.
- The 18 canonical medium-personal experience definitions remain complete.
- The shipped datastore remains a clean schema-version-1 local baseline.
- The source manifest and extracted archive are verified after final packaging.
- Release status: **1.0.0 production release**; v0.81 completion audit: **PASS — release-candidate ready**.
- Final automated acceptance: **37/37 executable suites, 498/498 checks**.

## Completion boundary
The application is internally complete within the declared local single-workspace product scope. Live upstream provider acceptance is not falsely claimed; it remains operator-run/external. AniList authorization remains independently gated.

## Next status
No undisclosed internal subsystem is required by the planned roadmap before a 1.0 decision. Future work should be explicitly scoped as post-RC polish, live-provider acceptance, or new product development.

# OmniShelf Historical State — v0.80

OmniShelf v0.80 was the previous release. It completes Production Hardening over the established canonical catalog, provider, personal library, community, medium-experience and UI/UX architecture.

## v0.80 current state
- Local workspace schema version is explicit (`1`) and startup migration is deterministic.
- Store persistence uses atomic temp-file + fsync + rename writes, preventing partial datastore files.
- Workspace validation checks structural invariants, provider identity uniqueness, catalog references, personal library/history references, collection references, and community references.
- HTTP responses include security headers and a unique request ID; request/error telemetry is emitted as structured JSONL at runtime.
- JSON request bodies have size/nesting/dangerous-key guards and requests have bounded URI/body limits.
- Read/write request rates are bounded per local client address.
- Runtime/server timeouts, malformed-client handling, uncaught exception/unhandled rejection logging, and graceful shutdown are hardened.
- Production recovery backups are integrity-hashed, permission-restricted, retained to five snapshots, and validated before restore.
- Restore requires an explicit confirmation token and automatically creates a pre-restore recovery backup.
- A first-class `System` surface exposes runtime status, validation and recovery controls.

## Data ownership boundary
No new domain datastore is introduced. Production hardening operates on the existing `data/store.json`; operational logs/backups are runtime artifacts kept outside the shipped clean datastore.

## Provider boundary
No provider integration is required for v0.80. AniList remains an independent external authorization/live-acceptance track.

## Validation
Final v0.80 evidence is recorded in `BUILD_VALIDATION-v0.80.md` and `FINAL_RELEASE_CHECK-v0.80.txt`. The acceptance matrix is 35/35 executable suites passed (422 checks).

## Next direction
v1.0 — Final Release Candidate / Completion Audit.

# OmniShelf Historical State — v0.79

OmniShelf v0.79 was the previous release. It completes UI/UX & Accessibility Finalization over the established OmniShelf product architecture.

## v0.79 current state
- Semantic primary navigation, main landmark and skip-to-content navigation are in the shared shell.
- Active views expose `aria-current`/`aria-controls`; hidden panels carry `aria-hidden`.
- Previously unlabeled controls receive accessible names and buttons normalize to `type=button`.
- Keyboard focus-visible styling and primary-dialog focus management are implemented.
- A global live region reports view changes and request failures.
- Responsive behavior is tightened across navigation, toolbars, grids, work pages and dialogs.
- Reduced-motion behavior is respected and interactive targets are standardized.

## Data ownership boundary
No new domain datastore is introduced. v0.79 is a presentation/interaction finalization release.

## Provider boundary
No new live provider dependency is introduced. AniList authorization/live acceptance remains independently gated.

## Validation
Final v0.79 evidence is recorded in `BUILD_VALIDATION-v0.79.md` and `FINAL_RELEASE_CHECK-v0.79.txt`.

## Next
v0.80 — Production Hardening.

# OmniShelf Current State — v0.78 (historical)

OmniShelf v0.78 was the previous release. It adds Full Medium-by-Medium Personal Experiences over the existing canonical catalog, personal library, history, Smart Library Collections, statistics, recommendations, unified workflow and Community layers. The medium layer is provider-neutral and does not create duplicate catalog or personal-state stores.

## v0.78 current state
- `lib/medium-personal-experiences.js` is the single registry for the 18 canonical personal-media types.
- Each supported type has tailored activity language, primary/alternate progress units, start/resume/finish labels, status labels, notes/favorite copy, milestones and resume guidance.
- `lib/library.js` consumes the registry for medium-aware progress inference and unit-specific known totals, while preserving arbitrary legacy/custom progress units.
- Personal Library medium views remain read-only projections over the same `data.library.items` records and now expose tailored medium experiences even for supported types with zero tracked items.
- Work Pages expose the tailored personal experience alongside the canonical medium experience and existing community/workflow/library state.
- Unified Workflow uses the medium-specific start/resume/advance/finish language while preserving the existing seven-stage provider-neutral journey.
- `/api/mediums/personal` exposes the registry directory and `/api/mediums/personal/selftest` exposes deterministic validation.

## Data ownership boundary
Medium-specific presentation is derived from canonical catalog records plus personal library state. No second catalog, personal-state database, provider model, history store, statistics database or analytics datastore is introduced.

## Provider boundary
This release makes no live provider calls for medium-personal behavior. AniList, Open Library, TMDB and IGDB remain behind their existing Provider Hub boundaries; AniList live authorization/acceptance remains independent.

## Validation
Final v0.78 validation evidence is recorded in `BUILD_VALIDATION-v0.78.md` and `FINAL_RELEASE_CHECK-v0.78.txt`.

## Next
v0.79 — UI/UX & Accessibility Finalization (completed).
# OmniShelf Current State — v0.76

OmniShelf v0.76 added Social / Community 2.0 as a provider-neutral local social layer over the canonical catalog and existing personal library. The community layer owns public profiles, follows, community reviews, review likes, explicit social activity and community-driven discovery without creating a duplicate catalog or personal-library favorite store.

## v0.76 historical state
- Community was a first-class top-level product tab, distinct from the external AniList Community workspace.
- Local profiles supported display name, handle, bio and optional avatar URL.
- Follow/unfollow relationships, public reviews, review likes and explicit All / Following / Mine activity scopes were durable.
- Current-user community favorites projected from `data.library.items` through the existing personal library layer.
- Community-driven discovery used followed/public member favorites.
- Work Pages exposed `communityReviews` and a direct community-review handoff.
- Full workspace backup/restore included community state and sanitized orphan social references.
- Production authentication/multi-user security isolation was intentionally deferred to hardening.

## Validation
Final v0.76 validation evidence remains recorded in `BUILD_VALIDATION-v0.76.md` and `FINAL_RELEASE_CHECK-v0.76.txt`.

## Next
v0.76 — Social / Community 2.0.

# OmniShelf Current State — v0.75

OmniShelf v0.75 is the current release. It adds a provider-neutral Unified Discovery → Library journey over the existing canonical catalog, durable Work Pages, Personal Library, History, Smart Library Collections, Statistics 2.0 and Recommendations 2.0. It does not create a second catalog or personal-state store and it does not perform provider writes.

## v0.75 current state
- The shared journey is: Discover → Work Page → Add to Library → Track → Finish → Review checkpoint → Recommend.
- Work-page responses now include a workflow read model with state-aware stage status, primary action, secondary navigation and progress.
- `GET /api/catalog/:id/workflow` exposes the journey directly; `POST /api/catalog/:id/workflow/action` routes supported personal actions through the existing library write layer; `POST /api/workflow/selftest` exposes deterministic validation.
- Explore and Unified Search hand off to durable standalone Work Pages; Recommendations use the same workflow action endpoint for adding a work to the personal library.
- Personal writes continue to flow through `lib/library.js`, so existing history, statistics and smart-collection behavior remains intact.
- The Review stage is explicitly a checkpoint using the existing personal score/notes state. Publishable/community review workflows remain deferred to the later Social / Community phase rather than introducing an unapproved parallel review datastore.

## AniList
AniList remains an independent external authorization/live-acceptance track. v0.75 does not require live AniList access and does not enable live provider writes.

## Validation
Final v0.75 validation evidence is recorded in `BUILD_VALIDATION-v0.75.md` and `FINAL_RELEASE_CHECK-v0.75.txt`.

## Next
v0.77 — Universal Import / Export & Migration is the current completed release.

v0.78 — Full Medium-by-Medium Personal Experiences is the next major product phase in the established roadmap.

# OmniShelf Current State — v0.74

OmniShelf v0.74 is the current release. It adds Recommendations 2.0 as a read-only, local, explainable recommendation layer using personal library state, durable history, Smart Collection rule affinity, Statistics-derived profile strength, canonical metadata, provider ratings already present in the catalog, explicit catalog relations, and bounded popularity signals. Works already tracked in the personal library and dropped works are excluded.

## v0.74 current state
- Personal Library, History, Smart Collections, Statistics 2.0, and Recommendations 2.0 are complete.
- Recommendations support auto/personalized/discovery/balanced modes, medium filters, provider-quality thresholds, result limits, diversity caps, relationship boosts, and up to three reasons per result.
- Recommendation generation performs no live provider requests.
- AniList remains preserved as an independent external authorization/live-acceptance track and is not a blocker for recommendation generation or current product development.



- Top-level Statistics tab is available at `/?view=statistics`.
- `GET /api/library/statistics` exposes lifetime, medium, score, progress-unit, monthly, yearly and activity-calendar statistics.
- `POST /api/library/statistics/selftest` runs the deterministic statistics validation.
- Current totals come from `data.library.items`; historical trends come from `data.library.history.events`.
- Mixed units are kept separate; OmniShelf does not sum episodes, pages, hours and viewings into one misleading total.
- Explicit numeric progress deltas are the only history values counted as recorded consumption units. Manual progress edits without a delta are not retroactively reconstructed.
- My Library, History, Smart Library Collections and Work Pages continue to use the same personal-state records.

## AniList

AniList remains preserved and independent of the v0.73 workstream. No live authorization or API acceptance is claimed by this release. The previously agreed October 8, 2026 response cutoff remains the external decision point.

## Next

v0.74 is planned as Recommendations 2.0, using personal library state, history, Smart Library Collections and statistics to improve personalized discovery.

## Previous current state — v0.72

# OmniShelf Current State — v0.72

OmniShelf v0.72 is the current release. It extends the v0.71 personal library/history layer with dynamic Smart Library Collections. Current personal state remains separate from canonical/provider metadata.

## v0.72 current state

- Built-in personal collections: Continue, Plan to, Completed, Favorites, 90+ Rated, Recently Updated.
- Custom personal collections stored under `library.smartCollections`.
- Rule engine supports catalog context plus personal status, favorite, score, progress, notes and recency rules.
- Collection matching is evaluated from current personal state; no rebuild or manual refresh of stored membership is required.
- My Library exposes collection cards, a collection filter, create/edit/delete controls, and save-from-filters.
- Full backup/restore preserves personal collections with the existing library payload.

## AniList

AniList remains preserved and independent of the v0.72 workstream. No live authorization assumption is introduced.

## Next

v0.73 is planned as Personal Statistics 2.0, using actual library state and history rather than catalog-only metadata.

## Previous current state — v0.71

# OmniShelf Current State — v0.71

## Current release
v0.71 adds a durable temporal layer to the v0.70 personal library. Current personal state remains separate from canonical/provider metadata, while meaningful personal changes are recorded in a bounded chronological history stream.

## Personal Library History
- `data.library.history` stores up to 2,000 structured events for the `You` workspace.
- Additions, progress, completions, status changes, favorites, scores, notes, dates, rewatch/reread/replay starts, and removals are represented explicitly.
- Recent completed and recent added projections are available through dedicated APIs.
- My Library now has a Personal Activity timeline, History at a glance, and Recent Milestones.
- Work Pages expose the latest personal history for the current work.
- Full backup/export and restore preserve personal history.

## Validation
- `npm run library:history:selftest` validates the temporal event model.
- The personal-library HTTP E2E validates history persistence, filtering, completion/session events, work-page projection, and backup/restore preservation.

## Provider boundary
AniList remains independent of the personal library and history system.

## Next direction
v0.72 can now build live Smart Library Collections on top of current personal state plus the temporal layer, without introducing another parallel catalog.

# OmniShelf Current State — v0.70

## Current release
v0.70 deepens the v0.69 personal library into an everyday workspace while preserving the canonical catalog and provider architecture. The personal layer remains separate from provider and canonical metadata.

## Everyday Personal Library
- `GET /api/library/overview` provides personal quick-shelf sections, status statistics, measurable progress, and per-medium summaries.
- `GET /api/library/medium/:type` provides a selectable medium-specific personal view over the same canonical IDs.
- `My Library` now opens with Continue, Plan to, Completed, Favorites, Recently Updated, progress overview, and medium lenses before the full searchable grid.
- Compact continuation cards provide direct work-page navigation and one-click medium-aware progress advancement.
- The existing v0.69 add/edit/save/advance/remove flows remain intact.

## Validation
- `npm run library:selftest` preserves the v0.69 personal-library contract.
- `npm run library:experience:selftest` validates the v0.70 dashboard/read-model layer.
- The release validation records isolated HTTP checks for overview, medium views, filtering, progress advancement, work-page projection, backup/restore preservation, and deletion cleanup.

## Provider boundary
AniList remains an independent external provider track. My Library does not depend on AniList live availability, authorization, or synchronization.

## Next direction
v0.71 should move from personal-library usability into the next personalization/discovery layer, building on canonical catalog, medium experiences, work pages, and the now-mature personal state model.

# OmniShelf Current State — v0.69

## Current release
v0.69 adds the first dedicated personal-library layer on top of the canonical catalog while preserving v0.68 standalone work pages and the existing provider/data architecture. Personal state is keyed by canonical catalog ID and does not overwrite provider metadata.

## Personal Library
- `data.library` is a versioned single-workspace (`You`) personal state store.
- Each record tracks status, progress, progress total, progress unit, personal 1–100 score, favorite state, notes, started/completed dates and updatedAt.
- Medium-aware progress inference uses episodes, chapters, pages, hours, viewings, acts, or generic units.
- `My Library` provides filters, sorting, pagination, KPIs, progress bars and inline editing.
- Work pages expose Add / Save / Advance / Remove controls using the same personal state API.

## API and backup behavior
- `GET /api/library`, `/api/library/stats`, `/api/library/:catalogId`
- `PUT /api/library/:catalogId`, `POST /api/library/:catalogId/advance`, `DELETE /api/library/:catalogId`
- Full workspace backups preserve personal library state and restore filters orphaned personal entries.

## Validation
Exact v0.69 evidence is recorded in `BUILD_VALIDATION-v0.69.md` and `PERSONAL_LIBRARY.md`. The final regression matrix must preserve the full v0.56-v0.68 stack plus the new library suite and isolated personal-library HTTP E2E.

## Next direction
v0.70 should deepen the everyday library experience and medium-specific work-page layouts: richer continuation/progress views, better personal dashboards, and more specialized work-page sections before the next major personalization/discovery phase.



## Current release
v0.68 makes the rich work page a first-class, shareable navigation surface. The canonical Catalog now has a stable `/work/:id` route powered by the same provider-neutral work-page API used by the v0.67 modal preview.

## Standalone work pages
- `GET /work/:id` serves the OmniShelf application shell for deep links.
- Client routing detects the work route, renders a full-page work experience, updates the document title, and supports browser history/back navigation.
- Catalog card/list surfaces expose both lightweight Preview and durable Open page actions.
- The standalone page can hand back to Catalog without creating a duplicate work record or alternate data source.

## Medium-aware work pages
- `lib/work-pages.js` now exposes `mediumExperience` highlights derived from canonical/provider metadata.
- Dedicated highlight groups exist for Asian Dramas, Games, Novels, Anime/Manga/Visual Novels, Film, and TV.
- Asian Drama classification remains conservative: explicit Drama type or unambiguous TMDB origin-country evidence; generic language alone is insufficient.

## Validation
Exact v0.68 evidence is recorded in `BUILD_VALIDATION-v0.68.md` and `STANDALONE_WORK_PAGES.md`. The full deterministic regression matrix passes, isolated HTTP E2E is 3/3, and E2E mutations were performed only in disposable copies; the shipped datastore remains clean.

## Next direction
v0.69 should deepen the standalone work-page experience with richer per-medium layouts and begin the personal library layer while preserving the canonical provider/data architecture.

# OmniShelf Current State — v0.67

## Current release
v0.67 makes the canonical Catalog the main product workspace rather than an administrative record table. It adds card/list browsing, persistent view preference, medium quick filters, richer catalog cards, and a read-only rich work-page model that adapts its visible metadata to the work/provider already stored in the canonical catalog.

## v0.67 Catalog UX
- Catalog defaults to a card-oriented browse view while retaining a compact list view.
- Card view surfaces cover, type, provider/year/status, description, creators, tags and direct work actions.
- List view remains available for dense selection/bulk-operation workflows.
- View preference is stored in browser local storage.
- Quick medium shortcuts reuse the existing governed Catalog filters; they do not create a second catalog.
- Catalog cards expose `Open work`, which opens the rich work page without losing the underlying catalog context.

## v0.67 Rich Work Pages
- Added `lib/work-pages.js` as a provider-neutral read model over a canonical catalog item.
- `GET /api/catalog/:id/work-page` combines the canonical record with relations, collections, identity evidence and current enrichment state.
- The work-page model exposes hero assets, title variants, overview/storyline, at-a-glance metadata, creators, cast/crew, releases, relationships, collections, identity, enrichment, governance, external sources, gallery assets and provider-specific detail.
- TMDB works expose TV/movie-specific information already present in normalized provider metadata; IGDB, Open Library and AniList records surface their existing provider-specific fields through the same presentation contract.
- Work pages are deliberately read-only; editing still uses the existing governed catalog PATCH path.
- Medium-specific behavior is data-driven rather than hard-coded per provider. Existing Asian Drama metadata is therefore visible through the shared title/language/country/network/airing structure without creating a separate catalog.

## Validation
Exact v0.67 evidence is recorded in `BUILD_VALIDATION-v0.67.md` and `WORK_PAGE_EXPERIENCE.md`. The shipped datastore remains clean; E2E mutations are performed only in disposable copies.

## Next direction
v0.68 should deepen standalone medium-specific work pages and start the dedicated work-page navigation/URL model, followed by a richer personal library experience.

# OmniShelf Current State — v0.66

## Current release
v0.66 turns the v0.65 dedicated-medium concept into a reusable product framework and deepens Asian Drama into provider-aware discovery and controlled ingestion. The canonical catalog remains the sole source of truth.

## v0.66 medium framework
- `lib/medium-experiences.js` registers reusable medium product surfaces for Anime, Manga, Novels, Film & TV, Asian Dramas, Games, Visual Novels, Plays & Theatre, and Short Fiction.
- `GET /api/mediums` exposes the directory and live canonical counts.
- `POST /api/mediums/selftest` validates registry behavior.
- The `Mediums` product tab gives the product layer a reusable directory instead of hard-coding Asian Dramas as a one-off navigation surface.

## v0.66 Asian Drama provider experience
- `GET /api/medium/asian-dramas/discover` supports demo/live TMDB discovery, profile-aware country/original-language filtering, title search, state/year/language filters, quality signals and catalog/identity evidence.
- `GET /api/medium/asian-dramas/provider-detail` fetches a deep TMDB TV record for inspection before import.
- `POST /api/medium/asian-dramas/ingest-preview` returns a controlled Review Queue payload and never mutates the catalog.
- Watch Providers are separately gated through `TMDB_WATCH_PROVIDERS_ENABLED` and `TMDB_JUSTWATCH_ATTRIBUTION_ACK`.
- Demo discovery/availability is deterministic and datastore-neutral.

## External-source boundaries
TMDB's current TV Discover surface supports `with_origin_country` and `with_original_language`, and TV Search covers original, translated and also-known-as names. Streaming availability is powered by JustWatch and requires JustWatch attribution when used.

## Validation
Exact v0.66 evidence is recorded in `BUILD_VALIDATION-v0.66.md`. The final release must include all historical regression suites from v0.56-v0.65 plus the v0.66 medium/discovery checks.

## Next direction
v0.67 should improve core Catalog UX and medium-specific work pages now that the medium framework can support specialized presentation without creating new catalog silos.

---

# OmniShelf Current State — v0.64

## Current release
v0.64 begins the product-experience phase after the provider-architecture roadmap completed at v0.63. The first focus is a product-facing Explore surface over the canonical catalog, with read-only aggregation, browse shortcuts, curated recency, tag discovery, and a focused work detail modal.

## v0.64 operational model
- Explore is a read model over the canonical catalog; it is not a new source of truth.
- `GET /api/catalog/explore` returns summary KPIs, type/provider/status/tag facets, recently added works and recently updated works.
- `POST /api/catalog/explore/selftest` exposes the deterministic Explore module test.
- Explore shortcuts feed the existing governed Catalog filters; external discovery feeds the existing Unified Provider Search.
- Work details reuse the existing `GET /api/catalog/:id` view so identity, enrichment, collections, relations and governance state stay consistent.

## Product direction
Explore is the beginning of a more polished consumer-facing OmniShelf experience. Asian dramas remain a first-class planned medium experience; v0.64 intentionally exposes Drama navigation without pretending that country/industry/language/airing semantics are already fully modeled.

## Validation status
Exact release evidence is recorded in `BUILD_VALIDATION-v0.64.md`. The release has no synthetic catalog/test records.

## Next direction
v0.65 — first dedicated medium-experience layer, prioritizing Asian dramas and other media with richer metadata/airing structures, while reusing the canonical/provider/governance foundations.

# OmniShelf Current State — v0.63

## Current release
Final Data Governance is complete. The canonical catalog now has a provider-neutral governance boundary covering field provenance, manual-vs-provider precedence, overwrite protection, freshness classification, deletion-impact inspection, field-level audit history, and integrity-verified JSON workspace backups. v0.62 Unified Provider Search, v0.61 Provider Reliability, v0.60 Unified Enrichment, and v0.59 Cross-Provider Identity remain the active foundations beneath it.

## v0.63 operational model
- Governed fields: title, type, year, description, creators, tags, aliases, coverUrl, externalLinks.
- Manual values are protected from ordinary provider overwrite. Empty fields can be filled; same-provider refresh remains allowed; higher-precedence providers may replace lower-precedence provider values when no manual protection applies.
- Freshness defaults are local OmniShelf policy values: AniList 30 days, TMDB 30 days, IGDB 30 days, Open Library 180 days. Unknown timestamps remain unknown.
- Provider-backed deletions create durable governance deletion tombstones; existing AniList sync tombstones remain intact.
- Field history is retained in `data.governance.fieldHistory`; broader workspace actions remain in `auditLog`.
- JSON workspace backups contain a SHA-256 payload hash; restore rejects a tampered payload, while older un-hashed backups remain backward-compatible.

## APIs
- GET /api/governance/status
- GET /api/governance/policy
- GET /api/governance/audit?field=&catalogId=&limit=
- GET /api/governance/items/:catalogId
- GET /api/governance/deletion-impact/:catalogId
- POST /api/governance/validate
- POST /api/governance/backup/verify
- POST /api/governance/policy/check
- POST /api/governance/deletion/preview

## Validation status
Exact release evidence is recorded in `BUILD_VALIDATION-v0.63.md`. Live provider acceptance remains separate and is not claimed without credentials/network/authorization.

## Known boundaries
- Governance does not invent provider retrieval timestamps; missing timestamps remain unknown.
- CSV remains a portable flat export and does not encode the entire governance graph.
- Explicit provider-specific enrich endpoints are governed at the canonical write boundary, while provider-native raw schemas remain owned by their adapters.

## Product direction carried forward — Asian dramas
Asian dramas are a first-class product use case, not a separate database silo. The canonical model should support Korean, Chinese, Japanese, Taiwanese, Thai, Hong Kong, Filipino, Vietnamese and other Asian drama industries through native/original titles, romanized and international aliases, language, country/industry, networks/platforms, episode/airing structure, cast/characters, and adaptation/related-work relationships while remaining part of the same unified catalog.

## Next direction
The explicit provider-architecture roadmap is complete at v0.63. The next phase should use the mature data foundation for product-quality work: catalog UX, discovery, personalization, richer medium-specific experiences, Asian-drama support, and deployment/operational polish.

# Current State — v0.62

Active workstream: **Unified Provider Search**. v0.62 adds a provider-neutral, read-only discovery layer across the canonical catalog plus AniList, Open Library, TMDB and IGDB. Smart routing selects a provider set from media type/query shape unless the user explicitly supplies a provider scope. Each provider is queried independently under v0.61 reliability instrumentation; one provider can fail without suppressing successful providers.

Search results are normalized into the existing catalog shape, assigned deterministic query-relevance signals, matched against the current catalog using the v0.59 identity engine, and optionally grouped when strong cross-provider identity evidence exists. Search grouping is discovery-only and never creates or alters a persistent identity decision. External results remain attributable to their source and can enter the existing Review Queue.

Key APIs: `GET /api/search`, `GET /api/search/route`, `GET /api/search/demo-plan`. Main UI: Search tab and `?view=search`.

Validation: Unified Search 13/13; Reliability 8/8; Identity 10/10; Unified Enrichment 10/10; TMDB 17/17; IGDB 25/25; Open Library 5/5. Isolated HTTP E2E passed 15/15 assertions, including Review Queue handoff/apply and Search UI routing. Live external provider acceptance remains separate from deterministic/offline search validation.

## Next milestone

v0.63 — Final Data Governance Layer: field-level provenance, source attribution, manual-vs-provider precedence, overwrite rules, stale-data policy, deletion safety, backup/restore verification, import/export preservation, and audit history.

# OmniShelf Current State — v0.61

## Current focus
Provider Reliability & Operations is the active milestone. AniList, Open Library, TMDB and IGDB remain deep provider integrations; v0.59 remains the cross-provider identity graph and v0.60 remains the preview-first unified enrichment layer. v0.61 adds the operational controls needed before broader live refresh orchestration and unified provider search.

## Current release summary
v0.61 adds provider-neutral operational telemetry, bounded event/incident history, circuit isolation, transient retry/backoff coordination, cache observability, stale-data detection, readiness/acceptance reporting, reliability APIs and a dedicated Reliability workspace. Provider adapters retain their existing authentication, pacing and schema behavior; reliability observes and controls the boundary rather than replacing those adapters.

## Provider operational model
- Providers: AniList, Open Library, TMDB, IGDB.
- Per-provider metrics: operations, blocked operations, successes, failures, cache hits/misses, aggregate/average latency, last success/failure/error, consecutive transient failures, circuit state, circuit-open count, degradation timestamps, and observed upstream rate-limit fields when available.
- Transient failures can open a per-provider circuit after `OMNI_PROVIDER_FAILURE_THRESHOLD` consecutive failures (default 3). Open circuits fail fast with `PROVIDER_CIRCUIT_OPEN`; after `OMNI_PROVIDER_CIRCUIT_COOLDOWN_MS` (default 30000 ms), one half-open recovery probe is allowed.
- Configuration and authentication failures do not count as transient outage failures, so missing credentials cannot accidentally trip an outage circuit.
- Backoff honors `Retry-After` when supplied and otherwise uses bounded exponential delays. Provider adapters continue to own provider-specific retry semantics.
- Successful cached responses are observable through hit/miss counters without replacing provider-specific cache implementations.
- Staleness defaults to 90 days via `OMNI_STALE_DAYS`; missing retrieval/enrichment timestamps are `unknown`, never silently fresh.

## Persistence / backup
`data/store.json` carries a `reliability` object with provider operational state plus bounded events/incidents. Full workspace backup/export/restore carries this state. Older backups without the field remain compatible and preserve current runtime reliability state unless a saved reliability snapshot is supplied.

## APIs / UI
- `GET /api/providers/reliability` — provider health, readiness, recent events/incidents and staleness summary.
- `GET /api/providers/reliability/events?provider=&limit=` — bounded event log.
- `GET /api/providers/reliability/incidents?provider=&limit=` — circuit incident log.
- `GET /api/providers/staleness?provider=&staleDays=` — freshness report.
- `GET /api/providers/reliability/acceptance` — offline/live acceptance matrix.
- `POST /api/providers/reliability/selftest` — deterministic local reliability test.
- `POST /api/providers/reliability/reset` — explicit operational reset.
- `/api/health`, `/api/providers/status`, and provider-specific status routes expose reliability state.
- New first-class **Reliability** tab exposes health cards, circuits, latency/failure metrics, operational logs, freshness and acceptance state, plus controlled self-test/reset actions.

## Validation status
- `npm run reliability:selftest`: 8/8 deterministic checks.
- Regression suites: Identity 10/10, Unified Enrichment 10/10, TMDB 17/17, IGDB 25/25, Open Library 5/5.
- Isolated HTTP E2E: health/status, provider-local failure telemetry, demo isolation, staleness, event log, acceptance matrix, backup/export, restore preview/apply, reset and clean-state persistence all passed.
- JavaScript syntax validation passed for modified server/reliability/adapter/self-test files.
- Preview is maintained as a static mirror of the served UI. Headless Chromium screenshot capture was environment-limited and is not represented as a passed visual test.
- Final shipped datastore is clean; synthetic failures are reset before release packaging.

## Known boundaries
- Live provider acceptance remains separate from deterministic offline tests and is not claimed without credentials/network/authorization.
- Reliability observes completed top-level provider operations; it does not replace provider-specific queues or upstream policies.
- Historical records without provider retrieval timestamps can only be reported as `unknown` for freshness.

## Next milestone
v0.62 — Unified Provider Search: route one OmniShelf search across relevant providers, normalize results, apply the v0.59 identity layer, and present one coherent discovery surface.

# Historical v0.60 State Snapshot

## Current focus
Confirmed identity groups can now be turned into a deterministic, preview-first enrichment plan for one selected catalog target. The engine combines evidence across Manual, AniList, Open Library, TMDB and IGDB records without deleting provider-native members.

## Enrichment model
- `lib/enrichment.js` defines supported fields, deterministic provider precedence, normalized list merging, scalar conflict detection, plan hashing, application safety checks, provider coverage, and enrichment status.
- Scalar fields (`title`, `type`, `year`, `description`, `coverUrl`) use an explicit v0.59 identity-group field preference first; otherwise the field-specific provider precedence is used. Manual is the default first-choice source for scalar fields.
- List-like fields (`creators`, `tags`, `aliases`, `externalLinks`) are merged from all identity-group members with normalized de-duplication.
- Every planned field records its available source records. Selected scalar fields record the chosen source. Conflicts remain present in the plan and on the enriched record even when a preferred value is chosen.

## Safety and persistence
- Enrichment is preview-first and non-destructive to provider-native records.
- Apply checks both the current target `updatedAt` and a deterministic plan hash derived from group/target state and proposed field values, not generation time.
- Enriched targets carry `enrichment.identityGroupId`, provider coverage, coverage score, unresolved conflict fields, field-level provenance, and the enrichment policy.
- `data.enrichment.runs` stores an auditable run journal.
- Full backup/export/restore preserves `enrichment` state.

## APIs / UI
- Added top-level Unified Enrichment tab with status KPIs, group browser, demo, preview, field-by-field plan, provenance/source display, and explicit Apply action.
- Added `GET /api/enrichment/status`, `/groups`, `/items/:catalogId`, `/coverage`.
- Added `POST /api/enrichment/preview` and `/apply`.
- Catalog detail responses expose current enrichment lineage when present.

## Validation
- `npm run enrichment:selftest` passes 10/10 deterministic checks.
- Existing identity/provider regression suites remain required and are re-run before packaging.
- Final HTTP E2E covers group creation, preview, apply, stale-target rejection, plan-hash rejection, backup/export/restore, and clean datastore restoration.

## Next milestone
- v0.61 — Provider Reliability & Operations: operational hardening across AniList, Open Library, TMDB and IGDB.

# v0.59 historical state — Cross-Provider Identity & Reconciliation

### Identity engine
- `lib/identity.js` provides provider-neutral identity fingerprints and comparisons.
- Evidence includes exact same-provider IDs, exact shared external identifiers, normalized ISBNs, title/alias similarity, creator overlap, year proximity, and canonical-type compatibility.
- Confidence labels are `exact`, `exact-external`, `high`, `probable`, `review`, `weak`, or `none`.
- Incompatible canonical types are capped at review/weak territory so similar titles across different media do not auto-merge.

### Persistent graph
- `data/store.json` now carries `identity.version`, `identity.groups`, `identity.decisions`, `identity.runs`, and the persisted `identity.candidates` index.
- Confirmed identity groups are non-destructive collections of catalog member IDs.
- Each group exposes provider identities, field conflicts, and a preferred catalog source for each supported field.
- Confirm/reject decisions are auditable and rejection keys suppress repeat false positives. A pair already in a confirmed group cannot enter contradictory rejected state through the normal decision endpoint.

### APIs / UI
- Identity Studio is a first-class top-level tab.
- `POST /api/identity/analyze` handles catalog, candidate, and demo analysis.
- `POST /api/identity/rebuild` persists a deterministic catalog-wide candidate index run.
- `POST /api/identity/decision` records explicit confirm/reject actions; confirm creates or merges identity groups.
- `POST /api/identity/preference` selects the preferred member source for a group field.
- Provider search/detail responses now expose cross-provider `identityMatches` alongside their provider-specific match diagnostics.
- Catalog detail responses expose the current identity group plus candidate matches.

### Data safety
- Full JSON backups include identity groups, decisions, and rebuild runs.
- Workspace restore preserves identity state and filters group member references against the restored catalog.
- Catalog bulk deletion prunes orphaned identity groups.
- No demo identity data is written to the shipped datastore.

### Validation
- `npm run identity:selftest` passes 10/10.
- Previous provider deterministic self-tests are retained for regression.
- Live external acceptance remains separate and is not claimed from the offline build environment.

### Next milestone
- v0.61 — Provider Reliability & Operations.
