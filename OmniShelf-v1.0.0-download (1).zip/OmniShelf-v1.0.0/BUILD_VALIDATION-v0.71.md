# OmniShelf v0.71 — Build Validation

Release: v0.71 — Personal Library History & Timeline
Base: v0.70

## Deterministic regression matrix

- Personal Library: 7/7
- Library History: 8/8
- Library Experience: 14/14
- Standalone Work Pages: 8/8
- Work Page: 8/8
- Catalog UX: 5/5
- Catalog Experience: 8/8
- Medium Framework: 7/7
- Asian Drama: 18/18
- Unified Provider Search: 13/13
- Provider Reliability: 8/8
- Cross-Provider Identity: 10/10
- Unified Enrichment: 10/10
- Final Data Governance: 14/14
- TMDB: 17/17
- IGDB: 25/25
- Open Library: 5/5

All inherited deterministic suites are re-run against the v0.71 codebase.

## Syntax validation

Passed for `server.js`, `lib/store.js`, `lib/library.js`, `lib/library-history.js`, `lib/library-experience.js`, `lib/governance.js`, `lib/work-pages.js`, and the client JavaScript extracted from `public/index.html`.

## Isolated HTTP E2E

The v0.71 personal-library HTTP E2E covers history persistence and projection in addition to the v0.70 workflow: additions, progress changes, completion, re-experience session start, work-page history, timeline filtering, summary, recent completed/added projections, backup preservation, restore preservation, and history after personal removal.

No E2E mutation is applied to the shipped datastore.

## Release integrity

- `preview.html` is byte-identical to `public/index.html`.
- Clean shipped datastore contains 0 catalog records, 0 review-queue records, 0 audit entries, 0 personal-library records, and 0 library-history events. SHA-256: `27e25b16e6d3ab230c34dbb4f79e58aafb77cb552fe16416087a69fd27b0cc9e`.
- Source manifest contains 177 entries and verifies with 0 mismatches.
- The final ZIP is independently extracted and revalidated against the same deterministic matrix.

## AniList boundary
AniList authorization and live acceptance remain a separate external track and are not required for the personal-library history system.

## Known boundaries
History is local to the `You` workspace and bounded at 2,000 events. External history synchronization remains outside this release.
