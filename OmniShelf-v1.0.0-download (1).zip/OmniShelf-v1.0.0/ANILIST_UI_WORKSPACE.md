# AniList Unified Workspace — v0.52

The AniList tab is now presented as one coherent workspace. The existing feature sections remain available; navigation and overview elements connect them without removing their underlying controls.

## Navigation
- Overview / Acceptance
- Discover: Media / Search / Entities
- Account: Lists / Sync / Statistics
- Community: Community / Platform
- Developer: Integrity / Schema / GraphQL

## Continuity
`public/index.html` and `preview.html` are generated from the same v0.52 UI source to avoid drift between the served site and preview.
