# OmniShelf v0.59 — Cross-Provider Identity & Reconciliation

## Purpose
v0.59 is the bridge between the four deep provider integrations and a genuinely unified OmniShelf catalog. Provider-specific matching remains intact, but OmniShelf can now reason across AniList, Open Library, TMDB, IGDB and manually created catalog records.

## What changed
- Added `lib/identity.js`, a provider-neutral identity engine.
- Added exact provider-ID matching, shared external-identifier matching, ISBN normalization, title/alias similarity, creator overlap, year proximity, canonical-type compatibility, confidence levels, and human-readable match reasons.
- Added persistent identity state: confirmed groups, confirm/reject decisions, rebuild runs, and the durable candidate index.
- Identity groups retain their member catalog records, provider identities, field conflicts, and preferred source per field.
- Added explicit confirmation/rejection APIs with audit events; no automatic destructive merge occurs. The HTTP decision boundary also refuses a reject action when the pair is already a confirmed identity, avoiding contradictory state.
- Added identity candidate surfacing to Provider Hub search results and canonical catalog detail responses.
- Added `GET /api/identity/status`, `/groups`, `/groups/:id`, `/candidates`; `POST /api/identity/analyze`, `/rebuild`, `/decision`, and `/preference`.
- Added a datastore-neutral identity reconciliation demo.
- Added `npm run identity:selftest` with 10 regressions covering same-type confidence, type-mismatch safety cap, ISBN normalization, rebuild candidates, group creation/merge, preferred-field selection, rejection suppression, confirmed-pair consistency, and demo neutrality.
- Backup/export/restore now carries the identity graph and decision history.
- Identity groups are pruned safely when catalog records are deleted or restored from backup.
- Added Identity Studio to the UI with reconciliation controls, candidate review, confirmed groups, conflict inspection, and field-preference selection.

## Architectural rationale
- The canonical catalog remains the system of record; provider records are evidence and enrichment sources.
- Identity is a non-destructive graph over catalog records, allowing OmniShelf to recognize “same work” without rewriting provider-native records.
- Cross-medium similarities are intentionally capped when canonical types are incompatible; a shared title alone cannot silently turn a film, novel, manga, TV series or game into the same work.
- Exact shared identifiers are treated as stronger evidence than fuzzy title matching.
- Human confirmation is required to form durable identity groups. Rejections are remembered so the same false positive is not repeatedly resurfaced.
- Field conflicts are surfaced rather than overwritten; preferred values are selected explicitly at group level.

## Validation
- Identity offline self-test: 10/10.
- Existing Open Library, TMDB and IGDB deterministic self-tests were rerun for regression: 5/5, 17/17, and 25/25 respectively.
- Isolated HTTP tests covered identity status, demo analysis, catalog creation, candidate analysis, confirm, group merge, group inspection, field preference, rejection suppression, confirmed-pair conflict protection, backup export and restore preview.
- Final shipped datastore is clean; test catalog mutations are not included.
- `BUILD_VALIDATION-v0.59.md` records the exact test boundary and fixes found during the release.

## Known limitations
- This release does not automatically merge the underlying catalog records into a single physical row; identity groups provide the non-destructive canonical relationship layer first.
- A confirmed pair cannot be rejected through the normal decision endpoint; an explicit split/unlink operation is reserved for a future release.
- Provider-native live acceptance remains governed by each provider's existing acceptance rules.
- Cross-provider enrichment using an identity group is the next logical layer once identity confidence and preferred-field provenance are established.
