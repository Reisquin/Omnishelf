# TMDB Attribution & Deployment Notes

OmniShelf v0.57 includes an About & Credits block in the served workspace and synchronized preview. It identifies TMDB as the Movie/TV data provider and includes a TMDB logo reference plus links to TMDB and the developer documentation.

The application states that it uses the TMDB API and is not endorsed or certified by TMDB. Before public or commercial deployment, re-check TMDB's then-current attribution, branding, API Terms, image-use, caching, and commercial licensing requirements. This release does not claim that those requirements have been reviewed or approved for any particular deployment.

The v0.57 implementation intentionally avoids provider-specific watch-provider data because those responses may introduce additional downstream attribution requirements. That feature can be addressed under the later provider governance layer.
