# OmniShelf v0.73 — Personal Statistics 2.0

v0.73 adds a provider-neutral, read-only personal analytics layer over the v0.73 library and v0.71+ history models. It does not create another datastore or change canonical/provider metadata.

## Statistics model

### Current-state metrics
The statistics engine reads the current `You` library records and reports:
- tracked items
- active, completed, planning, paused and dropped counts
- favorites and scored-item counts
- average, median, minimum and maximum personal scores
- items with progress and items with measurable finite totals
- average finite completion percentage
- current per-unit progress grouped by episodes, chapters, pages, hours, viewings, acts and generic units
- current breakdowns by medium and score band

### Historical metrics
The durable `data.library.history.events` stream powers:
- additions by month/year
- completions by month/year
- explicit progress events by month/year
- recorded progress deltas by month
- rewatch/reread/replay session starts
- active days
- recent activity calendar
- historical unique-added and unique-completed counts

### Transparency boundary
Statistics do not invent consumption from a final progress number. A progress delta is counted as recorded consumption only when the history event includes an explicit numeric `delta`. Manual progress edits without a delta remain visible as history events but are not retroactively reconstructed into consumption units.

Aggregates are kept unit-aware. OmniShelf does not present a meaningless single “hours + pages + episodes” total; current progress is shown by unit.

## API

`GET /api/library/statistics?months=12&calendarDays=84` returns the complete statistics read model. `months` is bounded to 1–36 and `calendarDays` to 14–366.

`POST /api/library/statistics/selftest` runs the deterministic statistics suite without mutating the shipped datastore.

## UI

The top-level **Statistics** tab provides:
- lifetime snapshot
- progress-by-unit view
- monthly activity trend
- medium breakdown
- score distribution
- activity calendar
- yearly summary
- calculation notes

The experience is intentionally read-only. Personal library mutations continue to flow through the existing library APIs, after which statistics are recalculated on the next read.

## Safety / continuity

No new persistent statistics store is introduced. Backup/restore automatically preserves the library and history from which the statistics are derived. Catalog, provider, identity, enrichment, reliability and governance boundaries remain unchanged.

AniList remains independent. v0.73 does not require live AniList access. The authorization cutoff previously agreed for October 8, 2026 remains external to this release.
