# OmniShelf v0.69 — Personal Library Experience

## Purpose
The personal library is a user-owned layer over the canonical catalog. It stores what the user is doing with a work without rewriting provider or catalog metadata.

## Data model
`data.library` contains a versioned profile and an object keyed by canonical `catalogId`. Each entry may store status, progress, progress total, progress unit, personal 1–100 score, favorite state, notes, started/completed dates, and updatedAt. Progress units are inferred conservatively from the medium (episodes, chapters, pages, hours, viewings, acts, or generic units) but remain user-editable.

## Supported statuses
- planning — Plan to
- active — In progress
- paused — Paused
- completed — Completed
- dropped — Dropped
- rewatching — Rewatching
- rereading — Rereading
- replaying — Replaying

## Product surfaces
- `My Library` is a top-level product tab with search, status/type/favorite filters, sorting, pagination, summary KPIs, progress bars, and inline editing.
- Every canonical work page exposes a personal-library panel. A work can be added, updated, advanced by one inferred unit, or removed without modifying canonical metadata.
- Library state is returned alongside the work-page read model so modal and standalone work pages remain synchronized.
- The Library route is available through `?view=library`.

## API
- `GET /api/library` — filtered/paginated personal library view.
- `GET /api/library/stats` — personal library KPIs.
- `GET /api/library/:catalogId` — one canonical work plus its personal state.
- `PUT /api/library/:catalogId` — upsert personal state.
- `POST /api/library/:catalogId/advance` — increment progress by one unit and auto-complete when a known total is reached.
- `DELETE /api/library/:catalogId` — remove personal state.
- `POST /api/library/selftest` — deterministic offline validation.

## Backup / restore
Full workspace JSON backups preserve `library.profile` and `library.items`. Restore drops personal entries whose catalog IDs do not exist in the restored canonical catalog, preventing orphaned personal state. The library does not change the canonical catalog schema.

## Design boundary
The application is currently a single local workspace, so the personal layer is scoped to `You`. The data model intentionally keeps the boundary explicit so a future authenticated multi-user implementation can scope library state by account without changing canonical work identities.
