# OmniShelf v0.73 — Personal Statistics 2.0

v0.73 turns the personal library and its durable history into a proper analytics surface. The release is read-only and provider-neutral.

## Highlights

- New top-level **Statistics** experience.
- Lifetime personal snapshot with current-state and history milestones.
- Unit-aware current progress summaries instead of mixing episodes/pages/hours into one misleading number.
- Monthly activity trends for additions, completions, progress events, re-experience sessions and active days.
- Current personal library breakdown by medium.
- Current personal score distribution in 10-point bands, plus average/median/min/max.
- Recent activity calendar across a selectable 84/180/365-day window.
- Year-by-year history summary.
- Explicit documentation of how recorded progress deltas are calculated.
- Deterministic statistics self-test and isolated HTTP E2E coverage.
- Existing My Library, History, Smart Library Collections, Work Pages and provider architecture preserved.

## Architecture

`lib/library-statistics.js` is a read model over `lib/library.js` and `lib/library-history.js`. No second personal datastore is created.

## AniList

AniList remains unchanged and independent from personal statistics. No live AniList authorization or API availability is required by v0.73.

## Validation

See `BUILD_VALIDATION-v0.73.md` for the deterministic regression matrix, isolated HTTP checks, source-manifest verification and archive integrity.

## Next milestone

v0.74 — Recommendations 2.0, using the richer personal state, history, collections and statistics layers to improve personalized discovery.
