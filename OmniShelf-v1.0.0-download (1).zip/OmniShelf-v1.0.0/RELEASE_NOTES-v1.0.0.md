# OmniShelf 1.0.0 — Production Release

OmniShelf 1.0.0 freezes the audited v0.81 release candidate as the production release.

The complete project-owned application scope remains intact: canonical catalog, provider hub, identity, enrichment, reliability, governance, Explore/Catalog, medium experiences, Work Pages, Personal Library, History, Smart Collections, Statistics, Recommendations, Unified Workflow, Community, portable migration, accessibility and Production Hardening.

No live upstream provider acceptance is claimed by this archive. Provider acceptance and AniList authorization remain external/operator-run release gates.
