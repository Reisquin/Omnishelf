# IGDB Attribution / Deployment Boundary — OmniShelf v0.58

IGDB is treated as an external data provider, not as a license grant.

v0.58 preserves provider identity and source links in normalized IGDB records and keeps provider-specific metadata under `providerMetadata.igdb`.

Before any public or commercial deployment, review the then-current IGDB and Twitch terms, application requirements, branding guidance, and any applicable redistribution rules. The presence of an API credential is not treated as proof that a particular use case is authorized.

Demo mode is deterministic and does not claim that demo fixtures are real IGDB records.
