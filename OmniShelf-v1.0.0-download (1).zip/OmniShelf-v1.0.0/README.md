# OmniShelf 1.0.0 — Production Release

OmniShelf 1.0.0 is the production release of the established OmniShelf product architecture for safer operation, recovery, validation, observability, and runtime failure isolation.

See `UI_UX_ACCESSIBILITY.md`, `MEDIUM_PERSONAL_EXPERIENCES.md`, `RELEASE_NOTES-v1.0.0.md`, `BUILD_VALIDATION-v1.0.0.md`, and `FINAL_RELEASE_CHECK-v1.0.0.txt`.

## 1.0.0 — Production Release

- Packages the audited v0.81 release candidate as the 1.0.0 production release.
- Verifies version/documentation consistency, package-script integrity, all 18 canonical medium-personal definitions, clean release state, source-manifest integrity, synchronized preview/public HTML, safe provider defaults and absence of open implementation markers.
- Adds `RELEASE_NOTES-v1.0.0.md`, `BUILD_VALIDATION-v1.0.0.md`, `FINAL_RELEASE_CHECK-v1.0.0.txt` and `DEPLOYMENT_CHECKLIST-v1.0.0.md`.
- Adds deterministic and disposable HTTP completion-audit suites that exercise the major product routes, demo provider boundaries, System safeguards, static caching and guarded error paths.
- The completion verdict is **PASS — release-candidate ready** for the declared local single-workspace product scope. Live upstream provider acceptance remains an external operator-run concern and is not claimed by this archive.

`npm run final-release:selftest` runs the deterministic completion audit.
`npm run final-release:http-e2e` runs the disposable HTTP completion audit.

## v0.80 — Production Hardening

- Adds a provider-neutral local production hardening layer for workspace validation, schema migration, atomic persistence, integrity-checked recovery backups, bounded request bodies/URIs, JSON safety checks, rate limiting, request IDs, structured request/error logging, graceful shutdown, and hardened HTTP response headers.
- Adds a `System` workspace surface for runtime status, validation, recovery-backup creation/listing, and explicit restore.
- Adds local production endpoints: `/api/production/status`, `/api/production/validate`, `/api/production/backups`, `/api/production/backup`, and `/api/production/restore`.
- Production restore validates backup integrity and workspace invariants before replacement and creates a pre-restore recovery backup automatically.
- Persistence is written atomically through a temporary file + fsync + rename path to prevent partial `store.json` writes.
- Workspace schema versioning is explicit and migrations are applied on startup without introducing a second domain datastore.
- Runtime logs are structured JSONL files and are intentionally generated at runtime rather than shipped with the archive.
- External provider credentials, live API authorization, and provider operational state remain governed by their existing independent boundaries.

`npm run production:selftest` runs deterministic production-hardening validation.
`npm run production:http-e2e` runs disposable-workspace production-hardening HTTP validation.

## v0.79 — UI/UX & Accessibility Finalization

- Finalizes the shared application shell for keyboard access, responsive behavior, accessible naming, focus management, semantic landmarks, dialogs, live status and reduced motion.
- Adds a dedicated `UI_UX_ACCESSIBILITY.md` product/validation guide and deterministic UI/accessibility checks.
- Preserves the v0.78 medium-personal experience registry and all inherited product layers.

## v0.78 — Full Medium-by-Medium Personal Experiences

- Adds a reusable `lib/medium-personal-experiences.js` registry for all 18 canonical supported medium types: Anime, Manga, Manhwa, Manhua, Novel, Light Novel, Web Novel, Visual Novel, Game, Movie, TV, Comics, Narrative Poetry, Poetry, Play, Short Story, Short Story Collection, and Novella.
- Gives each medium a tailored activity model, primary progress unit, alternate units, start/resume/finish language, status labels, notes/favorite copy, milestones and resume guidance without changing stored library status semantics.
- Aligns `library.inferProgressMeta()` with the medium-specific registry and exposes the tailored experience through Personal Library and Work Page read models.
- Adds medium-specific personal views even when a medium currently has zero tracked items; these remain read-only projections over the existing personal library.
- Expands progress units to include medium-appropriate concepts such as issues, pieces, poems, scenes and routes while retaining arbitrary stored units for backward compatibility.
- Adds `/api/mediums/personal` plus deterministic self-test coverage.
- Does not create a second catalog, personal-state store, provider model or statistics database.

`npm run medium-personal:selftest` runs deterministic medium-personal validation.
`npm run medium-personal:http-e2e` runs disposable-workspace HTTP validation.

## v0.76 — Social / Community 2.0

- Adds a first-class Community product tab separate from the external AniList Community workspace.
- Adds durable local profiles with display name, handle, bio and optional avatar URL.
- Adds follow / unfollow relationships and All / Following / Mine community activity views.
- Adds public, editable personal community reviews with optional 1–100 score and spoiler flag.
- Review likes are persisted and auditable.
- Community favorites for the current user reuse the existing `lib/library.js` favorite state rather than creating a duplicate personal store.
- Adds community-driven discovery from followed members' public favorite works and direct member taste views.
- Work Pages now expose community reviews and a direct “Write community review” handoff.
- Full community state is preserved in workspace backups/restores and sanitized against missing catalog/member references.
- Demo mode provides deterministic sample community profiles/reviews without persisting demo records.
- Local social identity is intentionally not an authentication/security boundary yet; production authentication and multi-user isolation remain a later hardening concern.

`npm run community:selftest` runs deterministic Social / Community validation.
`npm run community:http-e2e` runs disposable-workspace HTTP validation.

## v0.75 — Unified Discovery → Library

- Shared seven-stage journey model: Discover → Work Page → Add to Library → Track → Finish → Review checkpoint → Recommend.
- State-aware primary work actions for add, start, resume, advance and complete.
- A single provider-neutral workflow API wraps the existing personal-library write layer; no provider records are mutated.
- Explore, Catalog, Search, Library and Recommendations hand users toward durable Work Pages instead of fragmenting the journey across separate previews.
- Medium-aware progress semantics and all existing personal library/history/smart collection/statistics behavior remain unchanged.
- The review checkpoint has now been extended by v0.76 into an actual local community-review store without altering the canonical/provider models.

`npm run unified-workflow:selftest` runs the deterministic workflow validation.

## Continuity

This archive carries the accumulated OmniShelf history through v1.0. Existing provider integrations, cross-provider identity, unified enrichment, reliability, data governance, Catalog/Explore, medium experiences, standalone Work Pages, Personal Library, History, Smart Collections, Statistics 2.0 and Recommendations 2.0 remain intact.

## AniList boundary

AniList remains an independent external authorization/live-acceptance track. The v1.0 completion audit does not claim live AniList acceptance.

## Completion status

The application is release-candidate ready and internally complete within the declared local single-workspace product scope. Optional live upstream provider acceptance remains operator-run and external.

