# OmniShelf Project History

## 1.0.0 — Production Release

- Frozen from the audited v0.81 Final Release Candidate.
- Project-owned application scope and local single-workspace boundary are complete.
- Production deployment checklist added; live upstream provider acceptance remains operator-run/external.

## v1.0 — Final Release Candidate / Completion Audit

- Performed a project-wide completion audit over the v0.80 Production Hardening release rather than introducing another domain subsystem.
- Verified version consistency across package/runtime/preview, current-facing documentation continuity, package-script target integrity, all 18 canonical medium-personal definitions, clean-state invariants, provider-safe defaults and source/preview/package integrity.
- Added the deterministic `final-release:selftest` and disposable `final-release:http-e2e` audit suites.
- Explicitly reviewed the product scope: canonical catalog/provider stack, identity/enrichment/reliability/governance, discovery and medium experiences, Work Pages, Personal Library stack, Recommendations, Unified Workflow, Community, portable migration, UI/accessibility and Production Hardening.
- Distinguished project-owned completeness from optional external provider acceptance. No live upstream acceptance is claimed by the offline build environment.
- The local single-workspace boundary is intentional for the current product scope; multi-user account infrastructure is not silently treated as an unfinished requirement.

#### v1.0 completion verdict
**PASS — release-candidate ready.** OmniShelf is internally complete within its declared product scope and is ready for a 1.0 release decision without requiring another undisclosed subsystem.

#### v1.0 validation evidence
- Inherited v0.80 matrix: 35/35 executable suites passed before the final audit.
- Final-release deterministic completion audit: **24/24 checks**.
- Final-release HTTP completion audit: **52/52 checks**.
- Complete automated acceptance: **37/37 executable suites — 498/498 checks**.
- Source manifest: 245 release files, zero mismatches.
- `preview.html` == `public/index.html`; shipped datastore is clean; extracted archive and ZIP integrity pass.

## v0.80 — Production Hardening

v0.80 hardens OmniShelf for production-like operation without changing the canonical domain model. It introduces explicit workspace schema versioning/migration, atomic `store.json` persistence, structural workspace validation, security response headers, request IDs, bounded request URI/body and JSON safety handling, per-client read/write rate limits, structured runtime request/error logs, Node request/server timeouts, malformed-client handling, graceful shutdown and fatal error capture. It adds `lib/production.js`, local `/api/production/*` operations, integrity-checked runtime recovery backups with five-snapshot retention and automatic pre-restore recovery copies, and a first-class System UI. It does not introduce a second domain datastore and does not require live provider APIs.

Validation: production hardening deterministic self-test and disposable HTTP E2E are included; inherited full regression suites remain part of the final v0.80 acceptance matrix. Final acceptance: **35/35 executable suites passed — 422 checks** (292 deterministic, 130 HTTP).

## v0.79 — UI/UX & Accessibility Finalization
- Finalized the shared application shell for accessibility, responsive behavior and interaction consistency without changing canonical data ownership.
- Added semantic navigation/main landmarks, skip-to-content, active navigation state, deterministic accessible naming for controls, focus-visible styling, dialog keyboard management, live announcements, reduced-motion support and small-screen layout rules.
- Added deterministic UI/accessibility and disposable HTTP E2E validation scripts and retained the full inherited regression matrix.
- Final release validation: 25 deterministic suites / 286 checks and 9 HTTP E2E suites / 114 checks passed.
- Preserved all v0.78 medium-specific personal experiences and all prior catalog/provider/personal/community architecture.
- AniList remains independent and live-gated.

## v0.78 — Full Medium-by-Medium Personal Experiences

**Date:** 2026-10-07  
**Base:** v0.77 — Universal Import / Export & Migration

### Scope
v0.78 completes the planned medium-by-medium personal experience layer over the existing canonical catalog and personal-library model. It makes personal tracking meaningfully different by medium without creating separate libraries, catalogs, identity stores or analytics databases.

### Implementation
- Added `lib/medium-personal-experiences.js` as the provider-neutral registry for all 18 canonical supported personal-media types: Anime, Manga, Manhwa, Manhua, Novel, Light Novel, Web Novel, Visual Novel, Game, Movie, TV, Comics, Narrative Poetry, Poetry, Play, Short Story, Short Story Collection, and Novella.
- Each medium now has tailored activity language, primary progress unit, supported alternate units, start/resume/finish labels, status labels, notes/favorite copy, milestones and resume guidance.
- Added unit-specific known-total inference so alternate progress units do not accidentally inherit a total belonging to another unit.
- Preserved arbitrary legacy/custom progress units for backward compatibility.
- Integrated the registry into `lib/library.js`, `lib/library-experience.js`, `lib/unified-workflow.js`, `lib/work-pages.js` and the served product UI.
- Added medium-specific Personal Library directory/cards and detailed medium views, including supported media with zero tracked items.
- Work Pages now expose the personal experience alongside canonical medium presentation, community context, workflow and library history.
- Unified Workflow now uses medium-appropriate start/resume/advance/finish labels while keeping the provider-neutral seven-stage journey intact.
- Added `/api/mediums/personal` and `/api/mediums/personal/selftest`.
- Added deterministic medium-personal self-test and disposable HTTP E2E coverage.

### Architectural rationale
The personal relationship with a work remains a single `data.library` record. Medium-specific behavior is a presentation/interaction layer that interprets that same record according to the canonical work type. Provider data remains authoritative only for catalog/provider concerns; personal state remains user-owned.

The registry deliberately does not invent missing route counts, story counts, page totals, season totals or playtime. When a matching provider-derived total is unavailable for the selected unit, the total remains unknown and editable by the user.

The v0.78 layer also preserves the distinction between canonical medium experiences (v0.64–v0.68) and personal experiences: canonical metadata answers what the work is, while the personal registry answers how the user experiences/tracks it.

### Validation
- Medium Personal deterministic self-test: **15/15**.
- Medium Personal HTTP E2E: **15/15**.
- Full deterministic regression: **24/24 suites, 265/265 checks**.
- Full HTTP E2E regression: **8/8 suites, 103/103 checks**.
- Node syntax validation passed across all JavaScript source and test files.
- All embedded client JavaScript blocks passed syntax validation.
- Served root returned HTTP 200; `/api/health` reported v0.78.
- `preview.html` is byte-identical to `public/index.html`.
- Shipped datastore remains clean; all stateful HTTP tests use disposable copies.
- Source manifest contains 226 hashed release files and verifies with zero mismatches.
- Final archive contains 227 files / 236 ZIP entries under exactly one `OmniShelf-v0.78` root and passed extraction and ZIP integrity verification.

### Known boundaries
- Medium-specific personal tracking is currently a single local `You` workspace, inheriting the existing v0.69+ authentication/multi-user boundary.
- Medium profiles are provider-neutral and make no live provider requests.
- Richer medium-specific product surfaces remain a later UI/UX refinement phase where necessary; v0.78 establishes the shared semantic foundation without branching the data model.
- AniList authorization/live acceptance remains an independent external dependency and is not required for v0.78 personal experiences.

### Next
v0.79 — UI/UX & Accessibility Finalization.

## v0.77 — Universal Import / Export & Migration

**Date:** 2026-10-07  
**Base:** v0.76 — Social / Community 2.0

### Scope
v0.77 adds a provider-neutral portable data layer so a user can move OmniShelf personal/workspace content between installations without treating internal provider operations as portable user content. It deliberately complements the full workspace backup/recovery format rather than replacing it.

### Implementation
- Added `lib/portable.js` with schema version 1 and `omnishelf-portable` package format.
- Added personal portable JSON, workspace portable JSON and personal library CSV export routes.
- Added preview/apply migration routes and UI in the existing Data Hub.
- Work matching uses exact provider identity, shared external identifiers and v0.59 identity scoring before falling back to creation of a new canonical record.
- Existing canonical records are never silently overwritten; personal-library overwrite behavior is controlled by an explicit policy.
- Imported library records, history, Smart Library Collections and community data are remapped from exported source IDs to destination IDs.
- Community handles are used to match member identities where possible; follows/reviews/likes/activity are rebuilt against the destination graph.
- Portable markers make repeated history/review/activity imports idempotent.
- Added deterministic self-test and disposable HTTP E2E coverage.

### Architectural rationale
The existing `/api/data/export?scope=backup` format remains the authoritative recovery artifact because it preserves provider entities, identity/enrichment state, reliability telemetry, governance history and audit state. Portable export is intentionally a user-facing migration contract and therefore excludes those operational/internal structures.

Canonical work identity remains owned by the existing catalog + v0.59 reconciliation layer; v0.77 does not create a second identity database. Personal state remains owned by `lib/library.js`; v0.77 only translates its catalog-keyed records through a portable work reference. Community remains provider-neutral and local.

### Validation
- Portable deterministic self-test: 8/8.
- Portable HTTP E2E: 7/7.
- Full deterministic regression: 23/23 suites passed.
- Full HTTP E2E regression: 7/7 suites passed after updating inherited v0.76 release-string assertions to v0.77.
- Node syntax validation passed across all JavaScript files.
- `preview.html` byte-identical to `public/index.html`.
- Shipped datastore clean after testing.

### Next
v0.78 — Full Medium-by-Medium Personal Experiences.

## v0.76 — Social / Community 2.0

**Date:** 2026-10-07  
**Base:** v0.75 — Unified Discovery → Library

### Scope
v0.76 deepens OmniShelf's existing social/community direction into a provider-neutral local community layer. The goal is to make profiles, follows, reviews, favorites and taste-based discovery part of OmniShelf itself rather than relying on an external provider community system.

### Implementation
- Added `lib/community.js` with durable community state, profile projection, follows, public reviews, review likes, explicit activity events, member search and taste-based discovery.
- Current user's favorite works are derived from the existing personal library favorite state, avoiding a duplicate personal favorites datastore.
- Added `GET /api/community/overview`, `/members`, `/profile/:id`, `/following`, `/reviews`, `/activity`, `/discovery`; `PATCH /api/community/profile`; and mutation routes for follow, favorite, review create/update/delete and review like/unlike.
- Added deterministic `POST /api/community/selftest` and disposable-workspace `community-http-e2e` coverage.
- Added a first-class Community tab with Overview, Members, Activity, Reviews and From People views.
- Work Pages now expose community-review projections and a direct Write community review handoff.
- Added `COMMUNITY.md`, release notes, build validation and final release check.

### Product boundaries
- AniList Community remains a separate provider workspace; no AniList community API data is silently persisted into OmniShelf's local community state.
- Personal library history is not automatically published to the community; explicit social actions create community activity.
- Demo community records are deterministic and non-persistent.
- The current `you` identity is local and not a production authentication boundary. Multi-user authentication/authorization is reserved for later production hardening.
- Community review state is public within the local workspace model and auditable; provider review metadata remains provider-owned.

### Backup / restore
Community state is included in full workspace backups. Restore sanitizes member favorite IDs, follows, reviews, review likes and activity against the restored catalog/member graph, preventing orphaned social references.

### Validation target
The release requires the new community deterministic and HTTP E2E suites plus the full inherited v0.75 deterministic/HTTP regression matrix, server/module/client syntax checks, clean datastore verification and ZIP integrity.

### Next
v0.77 — Universal Import / Export & Migration.

## v0.75 — Unified Discovery → Library

**Date:** 2026-10-07
**Base:** v0.74 — Recommendations 2.0

### Goal

v0.75 connects OmniShelf's already-complete discovery, Work Page, personal library, tracking/history and recommendation surfaces into one coherent provider-neutral journey. The release deliberately composes existing layers instead of creating a parallel catalog or personal-state model.

### Implementation
- Added `lib/unified-workflow.js` as the shared journey model and action boundary.
- The journey has seven explicit stages: Discover → Work Page → Add to Library → Track → Finish → Review checkpoint → Recommend.
- Added state-aware primary actions for add, start, resume, advance and complete; supported pause, drop, favorite and remove actions are available through the same workflow action layer.
- Added `GET /api/catalog/:id/workflow`, `POST /api/catalog/:id/workflow/action`, and `POST /api/workflow/selftest`.
- Included the workflow projection in the existing Work Page API response so modal and standalone work pages use the same state.
- Added the **Your journey** Work Page panel with stage state, progress meter, primary action and navigation handoffs.
- Explore cards and Unified Search results now make the durable Work Page the primary handoff instead of splitting the journey between separate detail surfaces.
- Recommendations use the workflow action endpoint when adding a recommended work to the personal library, keeping the handoff on the same mutation path.
- Added deterministic workflow self-test and disposable HTTP E2E coverage.

### Architectural rationale

The canonical catalog still answers “what is this work?” and provider data remains behind the Provider Hub, identity, enrichment, reliability and governance boundaries. Personal status/progress/score/favorite/notes remain owned by `lib/library.js`; its existing history recording therefore remains the source for v0.71 History and downstream Statistics/Smart Collections. v0.75 adds orchestration, not a second persistence model.

The Review stage is intentionally a checkpoint, not a new review database. The current release exposes the existing personal score/notes path and explicitly defers publishable/community review functionality to the planned Social / Community phase. Recommendations remain local/read-only with no provider calls.

### Validation

The release requires deterministic self-tests, HTTP E2E coverage in disposable copies, server/module/client syntax validation, clean datastore verification, preview/public HTML byte identity, cumulative regression coverage and ZIP integrity before packaging. Exact results are recorded in `BUILD_VALIDATION-v0.75.md` and `FINAL_RELEASE_CHECK-v0.75.txt`.

### AniList boundary

AniList remains an independent external authorization/live-acceptance track. No part of the v0.75 Unified Discovery → Library journey requires live AniList access or enables provider writes.

### Next

v0.76 — Social / Community 2.0 remains the next major product phase in the established roadmap.

---

## v0.74 — Recommendations 2.0

Built the second-generation recommendation layer. The engine derives a personal preference profile from library engagement, favorites, scores, statuses, history-adjacent state, smart-collection-ready library state, and catalog metadata. It scores eligible catalog works, excludes works already in the personal library and dropped candidates, supports personalized/discovery/balanced modes, medium and quality filters, relationship boosts, diversity caps, and up to three explainable reasons per result. Added `lib/recommendations.js`, self-test/E2E coverage, server API, top-level Recommendations UI, and release documentation. No provider is queried live by the recommendation engine.

# v0.73 — Personal Statistics 2.0

**Date:** 2026-10-07
**Base:** v0.72 — Smart Library Collections

## Goal

v0.73 turns the existing personal library plus durable history into a genuine personal analytics layer. The core architectural rule is that statistics are a read model, not another stored database.

## Implementation

- Added `lib/library-statistics.js`.
- Added `GET /api/library/statistics` with bounded month/calendar parameters.
- Added `POST /api/library/statistics/selftest`.
- Added `scripts/library-statistics-selftest.js` and `scripts/library-statistics-http-e2e.js`.
- Added a top-level Statistics product surface in `public/index.html`.
- Added lifetime snapshot, unit-aware progress, monthly history trends, medium breakdown, score distribution, activity calendar and yearly view.
- Updated the Work Page read-model version to v0.73 and preserved the existing personal library/history projection.
- Kept backup/restore unchanged because statistics are derived from data already included in the personal library payload.

## Statistics semantics

Current-state numbers describe the personal records that currently exist in `data.library.items`. Historical additions, completions, progress events, sessions and active days are derived from `data.library.history.events`.

The statistics engine deliberately keeps progress unit-aware. It does not create a fake aggregate in which episodes, pages, hours and viewings are added together. Recorded consumption is limited to explicit numeric history deltas; manual progress edits that lack a delta remain history-visible but are not invented as consumption.

Score distributions use current personal 1–100 scores and do not modify or reinterpret canonical/provider scores.

## Product rationale

v0.70 answered “what should I do next?” and v0.71 answered “what did I do?” while v0.72 answered “which saved personal views should update automatically?”. v0.73 answers “what does my overall media life look like?” without weakening those earlier layers.

## Validation

- Personal Statistics: 14/14 deterministic checks.
- Personal Statistics HTTP E2E: 15/15.
- Personal Library HTTP E2E: 19/19.
- Smart Library Collections HTTP E2E: 17/17.
- Full inherited deterministic regression matrix passed.
- Source manifest and extracted-archive verification are required before release packaging.

## AniList dependency boundary

AniList remains independent of this milestone. No statistics route requires live AniList access. The previously agreed October 8, 2026 response cutoff remains an external authorization decision and is not assumed in v0.73.

## Next dependency

v0.74 — Recommendations 2.0 can now use library state, history, smart collections and statistics as inputs for personalized discovery.

---

# v0.72 — Smart Library Collections

**Date:** 2026-10-07

## Product goal

v0.72 turns the personal library into a reusable query surface. Instead of maintaining static lists, users can define Smart Library Collections whose membership is derived from current personal state and recalculated on every read.

## Implementation

- Added `lib/library-collections.js` with built-ins, rule sanitization, matching, statistics, CRUD helpers, filter-to-collection conversion and deterministic self-test.
- Extended `library` state with `smartCollections` while retaining the existing versioned personal-state shape.
- Added collection-aware My Library filtering via `GET /api/library?collection=...`.
- Added personal collection APIs under `/api/library/collections`.
- Added built-in collection presets and custom collection UI to My Library.
- Added save-current-filters workflow.
- Preserved catalog-level Saved Views as a separate feature.
- Extended backup governance manifest with `libraryCollections`.
- Preserved collection definitions through full backup/restore.

## Rules

Custom rules can target title/description/creator/tag search, medium, provider, year, tag, status, status sets, favorite state, score ranges, finite progress ranges, progress unit, score/note presence, unfinished state, and recent updated/started/completed windows. Matching supports `all` and `any`.

## Validation

The v0.72 collection self-test covers creation, matching, built-in presets, dynamic reevaluation and rule sanitization. HTTP E2E coverage verifies creating a canonical work, creating personal state, creating/applying/updating/deleting a smart collection, collection filtering, dynamic membership after a personal-state mutation, and backup/restore preservation. The full inherited deterministic matrix remains required before release.

## Boundaries

This milestone does not alter AniList, provider adapters, canonical catalog metadata, or catalog-level Saved Views. It is entirely additive to the personal-state layer introduced in v0.69-v0.71.

# v0.71 — Personal Library History & Timeline

v0.71 builds directly on the v0.70 everyday personal-library experience. The key product distinction is temporal: the current record tells OmniShelf where a work is now; the new history stream records meaningful transitions without polluting the canonical catalog.

## Implementation
- Added `lib/library-history.js` as the provider-neutral history model.
- Added bounded event retention at 2,000 events.
- Added event classification for additions, progress, completion, status changes, rewatch/reread/replay session starts, favorites, scores, notes, dates, generic updates, and removals.
- Added title/type snapshots so removed personal records remain understandable in historical views.
- Integrated history recording into the existing personal `upsert` and `remove` paths.
- Added overview projections for recent activity, recent completions, and recent additions.
- Added APIs for timeline querying, summaries, and milestone projections.
- Added Personal Activity, History at a glance, Recent Milestones, and per-work Personal History UI.
- Preserved history in full backup/export and restore.

## Product rationale
v0.70 made My Library useful in the present tense. v0.71 adds memory. A user should not lose the meaning of their journey merely because they changed a status, completed a work, began a rewatch, or removed an item from the current shelf. The history layer makes that progression inspectable while keeping provider data and canonical metadata untouched.

## AniList boundary
AniList is not a dependency for personal history. No live AniList call is made by any v0.71 history route or UI.

## Validation
The release includes a dedicated deterministic history suite plus expanded personal-library HTTP E2E coverage. All inherited v0.56-v0.70 deterministic suites remain part of the release matrix.

## Next milestone
v0.72 — Smart Library Collections.

---

# OmniShelf — Original Front-End Prototype (pre-v0.2)

- Initial polished responsive browser prototype for a unified media database/tracker.
- Supported Anime, Manga, Manhwa, Manhua, Novels, Light Novels, Web Novels, Visual Novels, Video Games, Movies, TV Shows, and Comics.
- Included Home dashboard, unified search, personal library, Current/Planned/Completed/Dropped status tracking, media-type filtering, Discover/catalog, title detail modal, add-title flow, progress logging, activity feed, and responsive desktop/tablet/mobile layout.
- Established the foundational design principle that one account can track many storytelling media while preserving medium-specific progress semantics.
- Proposed production direction: database-backed unified title model with media-specific extension fields, relations, people/characters/studios/authors/genres/tags, user entries, reviews/ratings, activity, collections, platforms, external IDs, and images.

## v0.2 — Foundation Build
- Replaced the static prototype with a working local Node/Express + SQLite application.
- Added a unified title model with media-specific progress units.
- Added people, characters, companies, platforms, external IDs, relations, users, library entries, collections, reviews, and activity tables.
- Added REST endpoints for search, title detail, types, library, statistics, activity, title creation, and library-entry updates.
- Added responsive API-connected UI and demo seed data.
- Established the future production direction of PostgreSQL, authentication, external metadata ingestion, deduplication/merge tooling, and social features.

## v0.3 — Authentication, Admin & Provider Adapters
- Added session-based authentication using secure HTTP-only cookies.
- Added first-class admin role for catalog curation.
- Added provider adapters for AniList, Open Library, TMDB, and IGDB.
- Added duplicate detection using canonical title keys and same-type matching.
- Added admin import with force-import fallback.
- Added catalog relationships such as adaptation, sequel, prequel, spin-off, remake, and source material.
- SQLite remained the zero-setup database; PostgreSQL schema/docker foundation was retained.

## v0.4 — Ratings, Favorites & Discovery
- Added AniList-inspired 1–100 user ratings and weighted community scoring.
- Added persistent first-class Favorites.
- Added cumulative progress update language.
- Added Highest Rated, Release Dates, and Genres pages plus medium-aware genre filtering/sorting.
- Added normalized genre tables for queryable browsing.
- Added automatic migration of v0.3 score data from 10-point to 100-point semantics.

## v0.5 — Dedicated Title & Profile Pages
- Added dedicated linkable title pages rather than modal-only details.
- Added richer title metadata: synopsis, genres, people, characters, companies, platforms, relationships, rating distribution, and reviews.
- Added ranked lists, public profile statistics/favorites/activity, and optional review scores/spoiler-free flags.
- Retained catalog studio, provider ingestion, duplicate detection, and relationship tooling.

## v0.6 — Social / Library Layer
- Expanded Favorites, cumulative progress, 1–100 scoring, title pages, profiles, follow/unfollow, public/private collections, statistics, and personalized recommendations.
- Added a standalone simulated browser preview alongside the full local app.

## v0.7 — Activity-First UI Direction
- Reoriented Home around an activity-first feed with a two-column activity stream, shelf rail, status composer, quick discovery links, and updated visual direction.
- Backend/data model remained on the v0.6 foundation.

## v0.8 — Profile / Navigation UI Refinement
- Kept Home activity-first and Discover as a dedicated top-level destination.
- Refined Profile into a two-column layout with Favorites permanently visible on the left.
- Made profile Favorites clickable and preserved the main profile area for library stats, lists, and activity.

## v0.9 — Favorites / Home Refinement
- Removed Continue / Curated for You / Jump Around rails from Home.
- Preserved Discover as a top-level Browse destination.
- Expanded profile Favorites across supported work media plus Character, Arc/Route/Part, Dynamic, and People favorites.
- Added medium filtering to profile work Favorites.

## v0.10 — Interactive Favorites
- Made Favorites interactive in the profile preview with browser-local persistence.
- Added toggleable favorites for works, Characters, Arcs/Routes/Parts, Dynamics, and People.
- Preserved activity-first Home and top-level Discover.

## v0.11 — Entity & Discovery Layer
- Added clickable pages for works, characters, people, arcs/routes/parts, and dynamics.
- Added grouped universal global search across entity types.
- Added clickable entity/work relationships.
- Enabled Favorites directly from entity pages with local persistence.
- Added Highest Rated media/genre filtering and dedicated chronological Release Dates browsing.
- Kept Home activity-first and Discover top-level.

## v0.12 — Expanded Storytelling Media Taxonomy
- Expanded the canonical storytelling-medium list to include Graphic Novel, Webcomic, Narrative Poetry, Poetry, Play, Screenplay, Short Story, Short Story Collection, Novella, Anthology, Audiobook, Audio Drama, Radio Drama, Fiction Podcast, Opera, Musical Theatre, Libretto, Interactive Fiction, Gamebook, Epic / Oral Tradition, Memoir / Autobiography, Documentary, Tabletop RPG, Dance Theatre, Puppet Theatre, and Photo Narrative alongside earlier media.
- Updated Media, Discover, Highest Rated, Release Dates, and Profile Favorites to use the expanded taxonomy.

## v0.13 — Expanded Storytelling Media Continuation
- Continued the expanded storytelling-medium taxonomy and demo catalog, preserving the universal Media/Discover/Highest Rated/Release Dates/Profile Favorites model.

## v0.14 — Universal Storytelling Catalog Prototype
- Added advanced Discover filters for search, medium, genre, and sort.
- Added dedicated Trending and Popular browse pages.
- Expanded Highest Rated filters with minimum rating-count and sort order.
- Retained interconnected entity pages and the latest storytelling-medium taxonomy.

## v0.15 — Community & Progress Web Preview
- Added 1–100 personal ratings and cumulative progress history on title pages.
- Added write/update/delete reviews and community review display.
- Added activity-feed status posting plus activity detail with likes/replies.
- Added library flow with status, progress, and personal score.
- Preserved Favorites, profiles, entity pages, discovery, rankings, genres, release dates, and expanded media taxonomy.

## v0.16 — Social Layer
- Added Community member discovery/search, follow/unfollow, and All/Following/Mine activity filtering.
- Added public member profiles with network statistics, public Favorites, and recent activity.
- Added dedicated Reviews page with media/score/sort filters and title links.

## v0.17 — Personalization, Lists & Statistics
- Added dedicated personalized Recommendations using Favorites, ratings, genres, and media preferences.
- Added public/private Custom Lists with ordering, item management, add-to-list flows, and deletion/editing.
- Added Statistics covering library totals, completion/current counts, average score, medium/genre/rating distributions, reviews, progress, and all Favorite categories.

## v0.18 — Advanced Search & Catalog Studio
- Added multi-condition Advanced Search across works and entity types with keyword, type, medium, genre, year, score, status, and sorting.
- Added Catalog Studio for duplicate review, metadata gaps, relationship issues, pending imports, metadata editing, and issue resolution.
- Added a Relationship Manager for adaptation, source material, sequel, prequel, remake, spin-off, side story, and alternative version.

## v0.19 — Rich Catalog / Entity Metadata
- Added alternate/native titles, complete release/status data, medium-specific metadata, credits, studios/publishers/developers/directors/playwrights, themes, tags, editions/release history, external references, story structure, arcs/routes/parts, and connected adaptations/related works.
- Added richer Character, People, Arc/Route/Part, and Dynamic pages.


# OmniShelf v0.31 — AniList Account & List Workspace

- Added a first-class authenticated/public AniList List Workspace with richer list browsing controls.
- Added demo AniList viewer/list data for offline UI preview and testing.
- Added `GET /api/anilist/user` for public AniList user profiles.
- Added `GET /api/anilist/viewer?demo=1` and `GET /api/anilist/lists?demo=1` demo paths.
- Added richer single-entry list editing through `POST /api/anilist/list-entry`.
- Added authenticated bulk list-entry updates through `POST /api/anilist/list-entries/bulk` using AniList `UpdateMediaListEntries`.
- Added a list manager UI with status/score/progress/notes editing, synced-catalog indicators, and safe delete controls.
- Kept the generic GraphQL gateway as the escape hatch for the full current AniList schema.

# OmniShelf v0.31 — AniList Account & List Workspace

- Added authenticated/public AniList List Workspace with list browsing controls.
- Added offline demo viewer/list data for UI preview and validation.
- Added `GET /api/anilist/user?id=...|name=...` public user profile route.
- Added richer single-entry list editing through `POST /api/anilist/list-entry`.
- Added bulk list-entry updates through `POST /api/anilist/list-entries/bulk`, using AniList's shared-IDs `UpdateMediaListEntries` mutation contract.
- Added list entry status, score, progress, progress-volume, repeat, priority, privacy and notes editing controls.
- Added list-entry delete controls.
- Kept public list browsing separate from authenticated mutation operations.

# OmniShelf v0.30 — AniList Complete Operations Layer

- Added a documented AniList query/mutation coverage registry for the current root API surface.
- Added `GET /api/anilist/capabilities` to expose coverage, auth model, and GraphQL endpoint metadata.
- Added `POST /api/anilist/introspect` to retrieve the live AniList GraphQL schema when network access is available.
- Hardened AniList GraphQL transport with request timeouts and bounded retry handling for idempotent queries/rate limiting.
- Expanded AniList UI with a live operation-coverage panel.
- Preserved the server-side generic GraphQL gateway as the universal path for current and newly exposed AniList fields/mutations.

# OmniShelf Project History

This file is the canonical continuity ledger for OmniShelf. Every future OmniShelf release archive should carry this file forward and append its own completed changes. It is intended to make cross-conversation continuation reliable.

## Baseline / recovered previous-chat state

### v0.20 — Catalog Operations
- Browser Data Hub preview for importing JSON/CSV.
- Import validation and duplicate detection before applying changes.
- Catalog health inspection.
- JSON/CSV export in the browser workflow.
- Node server with persistent catalog data.
- API: GET `/api/health`, GET `/api/catalog`, POST `/api/import`, GET `/api/export`.
- Normalized work fields included `id`, `title`, `media`, `year`, `score`, `ratings`, `genres`, `origin`, `format`, `status`, `description`, `people`, `chars`, and `relations`.
- No third-party npm dependencies required.

### v0.21 — Provider Hub
- Provider workflow established as: Provider Search → Normalize → Match Existing Catalog → Review → Apply.
- Provider adapters: AniList, Open Library, TMDB, IGDB.
- Provider results are normalized into OmniShelf's canonical schema before catalog application.
- Likely duplicates are matched before import and require explicit review.
- AniList manga can normalize into Manga, Manhwa, Manhua, Novel, or Light Novel from metadata rather than blindly importing as Manga.
- Demo search works without API credentials.
- Local server: `npm start`, then `http://localhost:3000`.
- API: GET `/api/providers/status`, POST `/api/providers/search`, POST `/api/providers/normalize`, POST `/api/providers/apply`.
- Provider credentials remain server-side.
- `.env.example` documents credential placement.
- Live upstream calls were not executed in the build environment because outbound DNS/network access was unavailable.

### v0.22 — Provider Review Queue
- Persistent review queue added between normalization/matching and application.
- Review states: pending, approved, rejected, applied.
- Likely duplicate matches surfaced during review.
- Explicit approval required before catalog insertion.
- Rejection reasons captured.
- Audit log added for review/application actions.
- API: GET `/api/review/queue`, POST `/api/review/queue`, POST `/api/review/queue/:id/approve`, POST `/api/review/queue/:id/reject`, GET `/api/audit`.

### v0.23 — Catalog Workspace
- Canonical catalog browsing and management workspace.
- Search by title, creator, and description.
- Filtering by type, provider, and year.
- Canonical metadata editing.
- Catalog item deletion.
- API: GET `/api/catalog?q=&type=&provider=&year=`, POST `/api/catalog`, PATCH `/api/catalog/:id`, DELETE `/api/catalog/:id`.
- Applying approved provider items checks `(provider, providerId)` identity to block exact provider duplicates.

### v0.24 — Catalog Detail, Metadata & Relationships
- Catalog item detail endpoint: GET `/api/catalog/:id`.
- Expanded item metadata: status, tags, aliases/alternate titles, external links.
- Metadata editing for these fields.
- Catalog-to-catalog relationships: Related, Sequel, Prequel, Adaptation, Spin-off, Collection.
- Relationship add/remove API.
- Manual canonical catalog creation from the UI.
- Older records receive compatible defaults when loaded.

### v0.25 — Collections & Advanced Catalog Navigation
- First-class collections kept separate from catalog-to-catalog relationships.
- Create, rename, search, inspect, and delete collections.
- Add/remove canonical catalog items from collections.
- Catalog filtering by collection, status, and tag.
- Search includes aliases and tags in addition to title, creator, and description.
- Sorting by title, year, date added, last updated, type, provider, or status.
- Ascending/descending sort order.
- Pagination with page/limit metadata.
- Catalog facets for type/provider/status/tag counts.
- Catalog item detail reports collection membership.
- Deleting an item cleans up collection memberships and relationships.
- Collection API: GET `/api/collections?q=`, POST `/api/collections`, GET `/api/collections/:id`, PATCH `/api/collections/:id`, DELETE `/api/collections/:id`, POST `/api/collections/:id/items`, DELETE `/api/collections/:id/items`.
- Catalog API supports collection filtering and facet queries.

### v0.26 — Smart Collections / Saved Views
- Rule-based saved views recalculate against the live canonical catalog.
- Rules support search, type, provider, year, status, and tag.
- Rules can match all or any conditions.
- Current catalog filters can be saved as reusable views.
- Saved views show live counts/previews.
- Saved views can be opened directly in Catalog.
- Saved views can be renamed/deleted.
- Catalog filtering supports `smartCollectionId=` in addition to manual collection filtering.
- Audit events recorded for smart-view actions.
- API: GET `/api/smart-collections?q=`, POST `/api/smart-collections`, GET `/api/smart-collections/:id`, PATCH `/api/smart-collections/:id`, DELETE `/api/smart-collections/:id`, POST `/api/smart-collections/from-filters`.

### v0.27 — Bulk Catalog Operations (current)
- Multi-select catalog items from the current catalog page.
- Select all currently visible page items.
- Bulk status updates (Active/Archived).
- Bulk add/remove tag.
- Bulk add/remove collection membership.
- Bulk deletion with relationship and collection cleanup.
- Bulk mutation limit: 100 selected catalog items.
- Bulk mutations recorded in the audit log.
- API: POST `/api/catalog/bulk` with actions `status`, `addTag`, `removeTag`, `addToCollection`, `removeFromCollection`, or `delete`.
- Selections are intentionally scoped to the displayed catalog page to avoid accidental whole-library changes.

## Canonical design decisions

### Content taxonomy
The simplified taxonomy is intentional:
- Screenplays: removed as a standalone content type.
- Audiobooks: removed as a standalone type.
- Podcasts: removed as a standalone type.
- Operating: removed as a standalone type.
- Musical Theatre: removed as a standalone type.
- Librettos: removed as a standalone type.
- Interactive Fiction: removed as a standalone type.
- Gamebooks: removed as a standalone type.
- Epic / oral tradition: categorized under Novels.
- Memoir / Autobiography: categorized under Non-fiction.
- Documentary: not a standalone top-level type; use the applicable remaining category.

### Provider architecture
Providers are external sources, not the canonical catalog schema. The canonical pipeline is:

`Search → Normalize → Match → Review → Apply`

No provider result should be automatically dumped into the canonical catalog without normalization and explicit review/application.

### Continuity rule for future releases
Every new OmniShelf archive should include:
- this `PROJECT_HISTORY.md` with the full version history up to that release;
- the README documenting the current release and all prior major capabilities;
- a clean datastore unless test data is intentionally part of the product;
- validation notes describing what was actually tested and what could not be tested.

Do not infer that an older feature was removed just because a newer README focuses on the latest feature; use this ledger as the cumulative project history.


### v0.28 — Data Hub, Import/Export & Workspace Backups
- First-class Data Hub tab added to the workspace.
- Full workspace backup export as a versioned JSON snapshot.
- Catalog-only JSON export.
- Catalog-only CSV export.
- Preview-first catalog import from JSON or CSV.
- Catalog imports validate required title/type fields before apply.
- Import duplicate detection uses provider identity when available and title/type/year as a fallback.
- Duplicate and invalid import rows are skipped rather than silently creating copies.
- Full workspace backup restore supports preview before replacement.
- Full restore requires explicit `RESTORE OMNISHELF` confirmation.
- Restore validates backup structure and prunes dangling collection/relationship references.
- Restore preserves the existing audit history while recording the restore operation.
- Data Hub keeps the existing Provider Hub, Review Queue, Catalog, Collections, Saved Views, and Bulk Operations intact.
- API: GET `/api/data/export?format=json|csv&scope=backup|catalog`, POST `/api/data/import/preview`, POST `/api/data/import/apply`, POST `/api/data/restore/preview`, POST `/api/data/restore/apply`.

### v0.29 — AniList Deep Integration
- AniList promoted from a basic provider adapter to a first-class deep integration layer.
- Added a reusable server-side GraphQL client for `https://graphql.anilist.co`.
- Added public Media search and advanced browse parameter support for type, search, adult filter, status, season, season year, country, source, genres, tags, and sort.
- Added rich Media detail retrieval including titles, dates, season, format/status, episode/chapter/volume metadata, scores, popularity, favourites, genres, tags, cover/banner, external links, streaming episodes, trailer, airing data, rankings, relations, characters/voice actors, staff, studios, recommendations, reviews, statistics, and authenticated list-entry state.
- Expanded AniList normalization into OmniShelf fields with aliases, tags, cover, creators, external links, and a provider-specific `providerMetadata` payload.
- Added AniList character, staff, and studio search endpoints.
- Added authenticated OAuth2 Authorization Code flow with AniList login callback, viewer status, and logout. AniList access tokens remain server-side; no client secret is sent to the browser.
- Added authenticated MediaList / MediaListCollection retrieval, list-entry save/delete mutations, favourite toggle, and review save mutation.
- Added a generic `/api/anilist/graphql` gateway so OmniShelf can access the current AniList GraphQL surface without waiting for a new hard-coded endpoint for every schema field.
- Added AniList Deep Integration UI with search, rich detail view, review-queue import, viewer/list tools, OAuth connection state, and GraphQL console.
- Added Demo mode for Media search/detail so the AniList workflow can be exercised without credentials or upstream network access.
- Preserved the full v0.20-v0.28 project history in this file and in future release archives.
- Live AniList upstream requests cannot be claimed as tested in this build environment because outbound network/DNS access is unavailable.


## Validation for v0.31

- Server JavaScript syntax check
- AniList module syntax check
- Browser JavaScript syntax check
- `/api/anilist/capabilities` (26 query roots / 29 mutation roots)
- AniList demo viewer/list/media search/browse endpoints
- Provider status regression
- Input validation for single and bulk list mutations
- Static UI preview generated from the shipped v0.31 AniList workspace DOM/CSS with offline demo state
- ZIP integrity/package validation

Live AniList upstream requests remain unavailable in the build environment because outbound DNS/network access is unavailable.


### v0.32 — AniList Community, Favourites & Account Settings
- Added dedicated AniList social/user search, following, follower and profile operations.
- Added Activity feed coverage for TextActivity, ListActivity and MessageActivity plus activity replies.
- Added authenticated activity like/pin/subscription and delete/reply operations.
- Added notification feed coverage using the documented NotificationUnion variants.
- Added forum thread browsing, subscription, creation/deletion, comment creation/deletion.
- Added review and recommendation browsing plus recommendation creation and review rating/deletion.
- Added airing schedule and MediaTrend endpoints.
- Added GenreCollection and MediaTagCollection endpoints.
- Added favourites browsing for anime, manga, characters, staff and studios.
- Added authenticated AniList account settings retrieval and UpdateUser mutation.
- Added custom-list deletion endpoint.
- Added demo payloads for every major v0.32 UI domain.
- Added an AniList Community, Favourites & Settings workspace to the UI.

## v0.32 validation
- Node syntax checks for `server.js` and `lib/anilist.js`.
- Browser JavaScript syntax check for the shipped `public/index.html`.
- Provider status regression retained.
- AniList capabilities endpoint retained and versioned to v0.32.
- Demo social users/following/followers/activities/threads/reviews/recommendations/airing/trends/notifications/favourites/settings/genres/tags payloads exercised locally.
- Mutation input validation exercised for settings, follow, activity, thread, review and recommendation endpoints.
- Clean datastore verified before packaging.
- ZIP integrity verified.
- Live AniList upstream requests were not claimed as tested because outbound DNS/network access remains unavailable in the build environment.

Official AniList documentation consulted for this increment includes the GraphQL guide, query and mutation references, User/Favourites/Activity/Thread/Review/Recommendation/AiringSchedule object references, rate-limiting guidance and API terms: https://docs.anilist.co/


### v0.33 — AniList Deep Entity Workspaces
- Added dedicated Character, Staff, and Studio detail queries with current AniList profile fields and connected relationships.
- Added paginated connected-media/character/staff previews using AniList connection `pageInfo`, `edges`, and `nodes`.
- Added unified `/api/anilist/entity/search` for Character/Staff/Studio searches.
- Added unified `/api/anilist/entity/{character|staff|studio}/{id}` detail endpoints.
- Added AniList Entity Workspace UI with live/demo search and detail inspection.
- Preserved universal GraphQL gateway and all previous AniList/social/list functionality.
- Live AniList calls not tested in this environment because outbound DNS/network access is unavailable.


## v0.34 — AniList mutation completeness
- Added dedicated handlers and GraphQL operations for SaveMessageActivity, SaveListActivity, ToggleLikeV2, UpdateFavouriteOrder, UpdateAniChartSettings, UpdateAniChartHighlights, and AniChartUser.
- Preserved universal GraphQL gateway and cumulative history.
- Official AniList references reviewed for the current release.

- Validation: dedicated handlers pass local input validation; live upstream execution remains unavailable in this environment because outbound DNS/network access is blocked.


### v0.35 — AniList production hardening & full Media browse filter surface
- Expanded the dedicated AniList Media browse/search query to cover the current documented Media filter arguments, including ID/MAL ID, dates and date comparisons, format/status variants, episode/duration/chapter/volume ranges, score/popularity thresholds, licensing filters, source/country filters, genre/tag include/exclude filters, list membership, and sort.
- Corrected the dedicated browse default so adult content is excluded unless explicitly requested, matching AniList's documented query default.
- Added bounded in-memory caching for anonymous read-only AniList GraphQL queries (20s TTL, 150-entry cap); authenticated requests and mutations are never cached.
- Added `/api/anilist/cache` and `/api/anilist/cache/clear` for cache inspection/maintenance.
- Added `/api/anilist/health` plus optional live upstream probe with a bounded 5s timeout.
- Added generic GraphQL query/variables size limits to avoid accidental oversized requests.
- Expanded AniList error payloads to preserve GraphQL errors and rate-limit metadata.
- Capabilities endpoint now reports v0.35 hardening and Media browse reference coverage.
- Preserved all prior OmniShelf and AniList functionality and cumulative history.
- Live AniList upstream calls remain unavailable in this build environment because outbound DNS/network access is blocked.


### v0.36 — AniList reference contract completion
- Expanded dedicated query wrappers to cover the current documented argument surfaces for MediaList, MediaListCollection, User, Character, Staff, Studio, Activity, Thread, ThreadComment, Review, Recommendation, AiringSchedule, MediaTrend, and Notification.
- Added dedicated Like, Markdown, SiteStatistics, and ExternalLinkSourceCollection query handlers.
- Expanded SaveMediaListEntry and UpdateMediaListEntries with scoreRaw, startedAt and completedAt; expanded SaveTextActivity, SaveReview, SaveThread and SaveThreadComment with documented optional mutation fields.
- Added `/api/anilist/reference-audit` and corresponding UI panel.
- Maintained the universal GraphQL gateway for the complete evolving schema.
- Official docs rechecked for this increment; live upstream execution remains unavailable because outbound DNS/network access is blocked.


### v0.37 — AniList Deep Field & Connection Completion
- Expanded canonical Media metadata to cover additional documented fields: version, seasonInt, hashtag, updatedAt, isLocked, trending, favourite flags, licensing/source fields, and review/recommendation/moderation flags.
- Added pagination variables and connection metadata for airing schedules, trends, characters, staff, studios, recommendations, and reviews.
- Expanded MediaList fields with score format, asArray, and user identity.
- Expanded User detail and options coverage; favourites are now paginated.
- Expanded Character/Staff/Studio deep detail queries with documented relationship/filter arguments.
- Added `/api/anilist/field-audit` and a matching UI panel for dedicated-field coverage.
- Official AniList object/query references rechecked for this increment. Live upstream execution remains unavailable because outbound DNS/network is blocked in the build environment.


### v0.38 — AniList User Statistics Workspace
- Added a dedicated User.statistics query for anime and manga totals and ranked breakdowns across countries, formats, genres, lengths, release years, scores, staff, start years, statuses, studios, tags and voice actors.
- Added `GET /api/anilist/user/statistics?id=...|&name=...&limit=...&sort=...` with bounded limits and documented `UserStatisticsSort` support (`COUNT`, `MEAN_SCORE`, `PROGRESS`, `ID` variants).
- Added an AniList Statistics Workspace to the UI with side-by-side anime/manga metrics and ranked breakdown sections, including staff/studios/tags/voice actors.
- Added a field-audit entry for `UserStatistics` and carried forward the generic GraphQL gateway.
- Preserved all previous AniList functionality and cumulative history.
- Live AniList upstream requests remain unavailable in this build environment because outbound DNS/network access is blocked.

### v0.39 — AniList Platform Data & Utilities
- Added paginated SiteStatistics retrieval with per-domain page controls and perPage cap aligned to the current AniList query reference.
- Added SiteStatistics demo data for local preview/testing.
- Added ExternalLinkSourceCollection demo mode and interactive filters for id, external-link type, and media type.
- Added authenticated AniList Markdown rendering with a safe demo renderer for offline previews.
- Added Likeable object lookup workspace and AniChartUser status workspace to surface the remaining dedicated utility/root queries.
- Added AniList Platform Data & Utilities UI and carried cumulative history forward.
- Rechecked current official AniList Query Reference and MediaExternalLink documentation for this increment.
- Live AniList upstream execution remains unavailable because outbound DNS/network access is blocked in the build environment.


### v0.40 — AniList Sync Center
- Added authenticated AniList-to-OmniShelf synchronization planning for catalog items linked to AniList media IDs.
- Added paginated MediaList fetching with a bounded sync limit and explicit comparison states: in-sync, remote-changed, local-missing-entry, and remote-only.
- Added `/api/anilist/sync/plan` for previewing list-state differences without mutating the catalog.
- Added `/api/anilist/sync/pull-apply` to apply selected remote list-entry state into linked OmniShelf catalog `providerMetadata.mediaListEntry` records, preserving an audit trail and last-synced timestamp.
- Added `/api/anilist/sync/queue-remote-only` to send remote AniList entries that are not yet in the canonical catalog into the existing Review Queue instead of silently importing them.
- Added an AniList Sync Center UI with demo mode, comparison summary, per-item selection, pull/apply and review-queue actions.
- Retained all previous AniList integration, generic GraphQL gateway, reference/field audit, and cumulative history.
- Live AniList upstream execution remains unavailable in the build environment because outbound DNS/network access is unavailable.


### v0.40 compatibility correction
- Corrected the AniList list browser to use the documented paginated `Page.mediaList` query instead of treating the top-level `MediaList` root as paginated.
- Removed `scoreRaw` from MediaList response selections; AniList documents it as a mutation input, while `MediaList` exposes `score` plus its `format`.
- Sync snapshots now preserve `format` so score interpretation is retained.

- v0.40 Demo Sync Center actions are dry-run only and do not mutate the datastore.


#

## v0.41 — AniList Two-Way Sync & List Configuration
- Added staged local list-entry overrides and explicit two-way conflict classification against a persistent last-synced snapshot.
- Added authenticated local-to-AniList push resolution plus remote-wins resolution.
- Added AniList list configuration GET/POST for custom lists, advanced scoring sections, score format, and related list options.
- Added Sync Center UI for staging local changes, reviewing conflicts, and applying an explicit resolution.
- Added deterministic demo mode for two-way sync and list configuration; demo mutation actions never write to the datastore.
- Preserved cumulative project history and all existing AniList workspaces.
- Live upstream execution remains operator-run because the build environment cannot reach AniList.

## v0.42 — AniList Two-Way Sync & List Configuration
- Added staged local list-entry overrides and explicit two-way conflict classification against a persistent last-synced snapshot.
- Added authenticated local-to-AniList push resolution plus remote-wins resolution.
- Added AniList list configuration GET/POST for custom lists, advanced scoring sections, score format, and related list options.
- Added Sync Center UI for staging local changes, reviewing conflicts, and applying an explicit resolution.
- Added deterministic demo mode for two-way sync and list configuration; demo mutation actions never write to the datastore.
- Preserved cumulative project history and all existing AniList workspaces.
- Live upstream execution remains unavailable because outbound DNS/network access is blocked in the build environment.

## v0.42 — AniList Sync Tombstones
- Added persistent anilistSyncTombstones to retain AniList-linked identity after local catalog deletion.
- Sync plan now surfaces local-deleted rows and remote-deleted/local-present rows with explicit safe resolutions.
- Added /api/anilist/sync/resolve-tombstone and /api/anilist/sync/tombstones.
- Catalog single/bulk deletion records AniList tombstones.
- Full cumulative history remains v0.20 → v0.42.

## v0.42 — AniList Sync Deletion Safety
- Added persistent AniList sync tombstones.
- Local catalog deletion records the last-synced AniList identity/state.
- Added safe resolution paths for remote deletion and local deletion, including restore local, delete remote, keep remote, recreate remote, and delete local.
- Backup/restore carries tombstones.
- Cumulative history remains v0.20 → v0.42.


### v0.43 — AniList Incremental Sync & Run Journal
- Added incremental AniList MediaList scanning using a persistent per-user/per-type `updatedAt` watermark with a one-second overlap to avoid timestamp-tie loss.
- Added persistent sync run journal and idempotency-key replay behavior.
- Added explicit watermark commit endpoint; previews never advance the cursor automatically.
- Added run/cursor inspection endpoints and Incremental Sync & Run Journal UI.
- Backups/restores now carry AniList sync runs and cursors.
- Preserved tombstone-based deletion safety and all previous AniList capabilities.
- Live AniList execution remains unavailable in this environment because outbound DNS/network access is blocked.

## Recovered Previous-Chat Archives

The user supplied the actual OmniShelf v0.2–v0.20 archives plus `Omnishelf Chat (1).docx` so the project history could be reconciled against the real previous-chat work. A detailed recovered record is stored in `RECOVERED_PREVIOUS_CHAT_HISTORY.md`. This record is historical evidence; current source behavior remains authoritative.

### v0.44 — AniList Final Asset & Acceptance Layer
- Promoted AniList media assets to a first-class normalized `mediaAssets` structure on provider-normalized catalog records and preserved them through catalog import/backup normalization.
- Assets include cover image sizes/color, banner image, trailer id/site/thumbnail, legal streaming episode thumbnails/URLs, external-link metadata/icons, and AniList site URL.
- Added `GET /api/anilist/media/:id/assets` and `GET /api/anilist/acceptance`.
- Expanded the AniList Media detail UI to display banner, cover, trailer thumbnail, legal streaming episode thumbnails/links, and external-link metadata.
- Corrected AniList provider mapping: ANIME → Anime, ANIME+MOVIE → Movie; MANGA format/country/genre metadata → Manga/Manhwa/Manhua/Novel/Light Novel/Web Novel.
- Restored the broader canonical catalog type selector from the recovered v0.20 storytelling foundation while retaining the later intentional standalone-type removals.
- Added deterministic local SVG demo assets for offline UI/acceptance testing; demo routes remain datastore-safe.
- Rechecked current official AniList Media, MediaCoverImage, MediaExternalLink, MediaStreamingEpisode, GraphQL, OAuth and rate-limit documentation.
- Live AniList network execution remains unavailable in this build environment because outbound DNS/network access is blocked.


### v0.45 — AniList Compliance / Authorization Gate
- Added a default-deny live AniList access gate: `ANILIST_MODE=demo` and `ANILIST_AUTHORIZED_USE=false`.
- Added `/api/anilist/compliance` to expose operational gate state and the current AniList Terms of Use URL.
- GraphQL, OAuth login/token exchange, and live upstream health checks are blocked unless the deployment explicitly enables authorized mode.
- Demo routes remain available without upstream access.
- Auth status reports the compliance block rather than silently clearing a configured token.
- Acceptance checklist and README document that the gate is an operational safeguard, not legal permission.
- Rechecked current AniList Terms of Use and API documentation before this increment.


## v0.46 — AniList Live Acceptance Harness
- Added portable live-readiness diagnostics for authorized deployments, including OAuth-client configuration and local JWT expiry metadata without exposing access tokens.
- Added explicit, read-only live acceptance runner covering public Media/assets and, with a valid token, Viewer, paginated Page.mediaList, User.statistics, and Viewer media-list options.
- Added `GET /api/anilist/live-readiness`, `POST /api/anilist/live-acceptance`, `npm run anilist:acceptance`, and `ANILIST_LIVE_ACCEPTANCE.md`.
- Read-only acceptance performs no AniList mutations and requires an explicit request confirmation token over HTTP.
- Added rate-limit capture to acceptance results; no access token is returned or persisted by the harness.
- Retained default-deny compliance gate and full v0.2→v0.45 project continuity.
- Live acceptance cannot be executed in the current build environment because outbound AniList network access is unavailable; the harness is intended for the user's network-enabled deployment.


## v0.46 — Acceptance Harness Hardening
- Corrected read-only acceptance result status handling so network/API failures cannot be mistaken for passes.
- HTTP acceptance returns 451 when the compliance gate blocks live access and 502 when an authorized read-only run has actual failed checks.
- CLI exit codes are explicit: 0 pass, 2 failed checks, 3 compliance blocked.


### v0.47 — AniList Schema Drift & Full Read Acceptance Matrix
- Added a checked-in AniList query/mutation root baseline at `data/anilist-schema-baseline.json`.
- Added `GET /api/anilist/static-read-matrix` to verify every dedicated query family has a local minimal GraphQL probe.
- Added `POST /api/anilist/schema-audit` for authorized live introspection and root-name drift comparison.
- Added `POST /api/anilist/full-read-acceptance` plus `npm run anilist:acceptance-full` for a read-only probe against all 26 dedicated query roots, skipping auth-only probes when no valid token is loaded.
- Added CLI `npm run anilist:schema-audit`; exit code 2 indicates detected root drift, 3 indicates the compliance gate.
- No AniList mutation is executed by the new acceptance matrix.
- Preserved full v0.2 → v0.46 continuity and AniList-only focus.


## v0.48 — AniList Final Feature Audit
- Corrected the AniList root-query baseline from an incomplete inventory to the current documented 27 query roots, adding the previously omitted `MediaListCollection` root.
- Expanded the static read matrix to 27 dedicated root probes; missing-root calculation now derives from the checked-in baseline and reports 27/27 local coverage.
- Added a minimal `MediaListCollection` probe using the documented required `userId` + `type` arguments.
- Tightened the acceptance matrix so direct root queries such as `Review`, `Recommendation`, `Activity`, `ActivityReply`, `Thread`, `ThreadComment`, `AiringSchedule`, and `MediaTrend` are probed at their actual root fields rather than only through `Page` connections.
- Updated the UI and release metadata to report 27 dedicated AniList query roots / 27 read probes while retaining 29 documented mutation roots.
- Rechecked the current official AniList Query and Mutation references; the current Query Reference lists `MediaListCollection` alongside the other root queries.
- Live schema introspection and full live reads remain operator-run acceptance steps because outbound AniList network access is unavailable in the build environment.
- Preserved full v0.2 → v0.48 continuity and AniList-only focus.




## v0.49 — AniList Media Quality & Asset Reliability
- Promoted AniList artwork/media from raw fields to an explicit asset-quality model.
- Added cover primary/fallback selection and available-size metadata.
- Added asset availability diagnostics at `/api/anilist/assets/quality`.
- Added lazy/no-referrer remote rendering and broken-asset isolation in the UI.
- Added `ANILIST_ASSET_POLICY.md`; remote image bytes are not silently persisted.
- Preserved cumulative v0.20 → v0.49 history and all existing AniList sync/compliance features.

## v0.50 — AniList Media Quality & Asset Reliability
- Promoted AniList artwork/media from raw fields to an explicit asset-quality model.
- Added cover primary/fallback selection and available-size metadata.
- Added asset availability diagnostics at `/api/anilist/assets/quality`.
- Added lazy/no-referrer remote rendering and broken-asset isolation in the UI.
- Added `ANILIST_ASSET_POLICY.md`; remote image bytes are not silently persisted.
- Preserved cumulative v0.20 → v0.50 history and all existing AniList sync/compliance features.


## v0.50 — AniList Unified Media Workspace & Lineage
- Added a unified media workspace linking AniList source identity to the OmniShelf canonical record.
- Added lineage state for canonical ID/type/title, collections, sync metadata, and tombstones.
- Added asset/connection/list-state summary across covers, banners, trailers, streaming, relations, characters, staff, studios, recommendations, and reviews.
- Added `GET /api/anilist/workspace/media/:id` with Demo and authorized-live paths.
- Preserved the existing default-deny AniList compliance gate and cumulative project history.

### v0.51 — AniList Final Integration Audit & Data Round-Trip Integrity
- Added a local, datastore-neutral AniList integrity audit at `/api/anilist/integrity/audit?demo=1` plus `npm run anilist:integrity-audit`.
- Audits preservation of AniList providerMetadata, raw provider payloads, mediaAssets, canonical identity/relationships, and backup sync collections through the same restoration normalization path used by full workspace restore.
- Fixed full-workspace restore so rich catalog fields are preserved instead of being reduced to the basic import shape.
- Updated catalog JSON/full-backup export version metadata to v0.51.
- Corrected the AniList read-matrix UI to display its actual probe count instead of the stale 26/26 value.
- Added an AniList Data Integrity panel to the UI; audit is demo-safe and datastore-neutral.
- Preserved full v0.2 → v0.51 continuity and AniList-only focus.
- Live AniList calls remain operator-run because outbound AniList access is unavailable in the build environment.



### v0.52 — AniList Unified Workspace UI
- Reconciled `public/index.html` with the more recent `preview.html` so the served app and preview no longer drift.
- Reintroduced the Unified Media Workspace into the served application.
- Added AniList workspace overview/status cards, quick demo actions, sticky internal navigation, stable anchors, and visual section dividers.
- Updated document/package/server version metadata to v0.52.
- Preserved full recovered v0.2→v0.52 continuity and all prior AniList backend behavior.


## v0.53 — AniList Canonical Enrichment
- Added `POST /api/anilist/catalog/enrich/preview` and `POST /api/anilist/catalog/enrich/apply`.
- Full AniList Media detail can now be merged into an approved canonical OmniShelf AniList record.
- Rich detail snapshot preserves assets, relations, character/staff/studio connections, recommendations, reviews, rankings, stats, next-airing data, streaming episodes, external links and `mediaListEntry`.
- Enrichment preserves existing OmniShelf manual tags, aliases, creators, and descriptive fields unless a value is absent locally.
- Apply rejects stale previews when the catalog `updatedAt` has changed.
- Demo enrichment is non-persistent until explicit Apply; live enrichment remains compliance-gated.


## v0.53 — AniList Canonical Enrichment
- Added `POST /api/anilist/catalog/enrich/preview` and `POST /api/anilist/catalog/enrich/apply`.
- Full AniList Media detail can now be merged into an approved canonical AniList catalog item.
- Enrichment preserves rich provider metadata, raw detail payload, assets and deep Media connections.
- Existing OmniShelf manual tags, aliases, creators and non-empty description are preserved.
- Apply rejects stale previews using `updatedAt`.
- Demo mode is datastore-neutral only for preview; explicit Demo Apply writes the same deterministic enrichment structure locally for testing and the release datastore is reset before packaging.


## v0.54 — AniList Live Write Acceptance
- Added a separate, explicitly opt-in authenticated write acceptance CLI.
- Covers `SaveMediaListEntry`, `UpdateMediaListEntries`, and `DeleteMediaListEntry` with either exact restoration of an existing entry or create/update/delete cleanup for a temporary entry.
- Optional `ToggleFavourite` double-toggle with state verification.
- Requires authorized live mode, `ANILIST_WRITE_ACCEPTANCE=true`, `--confirm-write`, and an explicit media ID.
- Never prints access tokens.
- Added a non-writing readiness endpoint and UI instructions.
- Demo mode remains write-free.


## v0.55 — Open Library Deep Integration
- Promoted Open Library from Provider Hub demo placeholder to a real low-volume discovery/lookup adapter.
- Added Search API integration with title/author/ISBN/subject/language/page/sort inputs and a bounded result size.
- Added Work, Edition, Author, and ISBN JSON lookups using Open Library's documented endpoints.
- Added canonical normalization with work/edition distinction, conservative subject-based type mapping, creator/subject/publication/ISBN metadata, provenance, raw snapshots, and remote cover URLs.
- Added request identification (`OPENLIBRARY_USER_AGENT` + `OPENLIBRARY_CONTACT`), five-minute bounded caching, and request serialization at approximately three requests per second for identified clients.
- Added `POST /api/openlibrary/live-acceptance` and CLI `npm run openlibrary:acceptance` for read-only operator-run validation.
- Added Provider Hub UI for Open Library live/demo search, details, queue-to-review, and acceptance plan.
- Added `OPENLIBRARY_INTEGRATION.md`, `OPENLIBRARY_LIVE_ACCEPTANCE.md`, and `OPENLIBRARY_OFFICIAL_REFERENCES.md`.
- Preserved all previous AniList, catalog, collection, smart collection, bulk operations, Data Hub, and continuity/history work.
- Live Open Library API execution was not claimed in this build environment because outbound DNS/network access is unavailable.


## v0.56 — Open Library Quality & Entity Layer
- Added `lib/openlibrary-quality.js` for entity-aware completeness scoring, ISBN normalization, Open Library identity matching, subject normalization, Work → Edition relationship planning, entity registry payloads, and enrichment previews.
- Added persistent `openLibrary.authors`, `openLibrary.subjects`, `openLibrary.workEdition`, `openLibrary.enrichmentJournal`, and `openLibrary.reviewDiagnostics` state.
- Added `GET /api/openlibrary/works/:id/editions` for bounded Work → Edition discovery and relationship diagnostics.
- Open Library search/Provider Hub results now surface identity-aware catalog matches, reasons, normalized subjects, and richer provider lineage.
- Added `GET /api/openlibrary/quality/status`, `POST /api/openlibrary/quality/analyze`, `POST /api/openlibrary/matches`, `GET /api/openlibrary/entities`, `POST /api/openlibrary/entities/rebuild`, `POST /api/openlibrary/enrich/preview`, and `POST /api/openlibrary/enrich/apply`.
- Canonical Open Library enrichment preserves existing non-empty manual canonical fields and attaches provider metadata, provenance, raw Work/Edition/Author snapshots, normalized subjects, author references, and Work → Edition lineage.
- Added ISBN-based remote cover fallback while retaining the remote-reference-only cover policy.
- Added `npm run openlibrary:quality-test` deterministic offline validation and extended `npm run openlibrary:acceptance` with a Work → Edition relationship check.
- Full backup/export now carries the Open Library entity registry and enrichment diagnostics.
- Preserved cumulative v0.2 → v0.55 continuity and all prior AniList, Catalog, Collections, Smart Collections, Bulk Ops, Data Hub, provider, sync, and acceptance work.
- Live Open Library acceptance remains operator-run; no live upstream pass is claimed from the build environment.


### v0.57 — TMDB Deep Integration
- Promoted TMDB from the pre-existing Provider Hub placeholder into the third deep provider integration.
- Added `lib/tmdb.js` with server-side TMDB v3 authentication using the Read Access Token (preferred) or API key, five-minute bounded caching, serialized requests, conservative pacing, deterministic demo fixtures, and a bounded 429 retry using `Retry-After`.
- Added Movie and TV search with page/year/language/region/adult controls and bounded result normalization.
- Added Movie/TV Discover support with provider-aware sort handling and bounded filters for year, genres, original language, companies, keywords and dates.
- Added rich Movie/TV detail reads using `append_to_response` for credits, images, external IDs, videos, translations, keywords, alternate titles, recommendations/similar records, and Movie release-date regions.
- Added collection, person, TV season and TV episode reads and normalization.
- Added canonical mapping into `Movie` and `TV`, with provider metadata preserving dates, runtime/episode runtime, status, companies, networks, creators, cast, crew, seasons, collection, localization, IDs, images, videos and raw provider snapshots.
- Added TMDB-aware identity diagnostics using exact provider IDs, IMDb IDs, normalized title evidence, alternate titles, year and original-title evidence. Cross-provider reconciliation is intentionally deferred to v0.59.
- Added TMDB entity persistence for people, production companies, networks and collections. Both explicit canonical enrichment and Review Queue approval now persist TMDB entities.
- Added quality reporting, preview-first canonical enrichment with stale-write protection, provider provenance, raw detail snapshots, and entity rebuild tooling.
- Added TMDB Provider Hub UI with search/discovery, rich detail inspection, quality analysis, queue-to-review, entity registry/rebuild, canonical enrichment, TV structure, and acceptance controls.
- Added a TMDB About & Credits block with logo reference and attribution language; no claim of public/commercial licensing approval is made.
- Added deterministic `npm run tmdb:selftest` and operator-run `npm run tmdb:acceptance`; live acceptance is read-only and remains unexecuted in the offline build environment.
- Corrected server MIME handling so local SVG demo assets serve correctly and synchronized `preview.html` with the served application.
- Added a backward-compatible `/api/health` response for the inherited server contract and corrected carried AniList/Open Library API version reporting to identify the current v0.57 release without rewriting historical coverage metadata.
- Kept TMDB `append_to_response` endpoint families type-safe: Movie details include Movie-only `release_dates`, while TV details use only TV-compatible appended resources.
- Preserved all prior AniList implementation/acceptance state, Open Library quality/entity state, catalog/collections/saved views/bulk ops/Data Hub, Review Queue, synchronization, provenance, and cumulative project history.

#### v0.57 architectural rationale
- TMDB data remains provider-specific until identity reconciliation is mature; the canonical catalog stays the system of record.
- Provider metadata is additive and provenance-bearing, while existing non-empty manual catalog fields are retained during enrichment.
- Remote TMDB images remain remote references; the local datastore does not bulk-copy artwork.
- Demo fixtures are deterministic and do not require external network access, allowing provider logic and UI flows to be tested before credentials are available.
- Live acceptance is deliberately separated from implementation: having credentials is not treated as proof that an external integration is authorized or production-ready.

### v0.58 — IGDB Deep Integration
- Promoted IGDB from the Provider Hub placeholder to the fourth deep provider integration.
- Added `lib/igdb.js` with server-side IGDB v4 access, Twitch client-credential token acquisition, optional explicit application-token mode, memory-only token state, and credential-refresh handling after a first 401 in client-credential mode.
- Added bounded five-minute caching, 200-entry cache bound, serialized request pacing and bounded 429 retry behavior.
- Added Game search with pagination and bounded result limits plus discovery filters for platform, genre, theme, release-year ranges and sort order.
- Added rich Game detail normalization for release dates/regions, platforms, developer/publisher/porting/supporting companies, genres/themes/keywords, game modes, perspectives, collections, franchises, version lineage, alternative names, localizations, external IDs, age ratings, engines, websites, videos, covers, artwork and screenshots.
- Added canonical mapping `IGDB Game → Game` with provider provenance and raw snapshot retention.
- Added persistent IGDB entities for companies, platforms, collections and franchises, plus enrichment journal and Review Queue diagnostics.
- Added provider-aware identity matching using exact IGDB ID, alternate/localized titles, year, canonical type and title evidence. Corrected the scoring precedence so an exact provider ID remains a hard 1.00 match.
- Added quality scoring and diagnostics across title, release date, genres/themes, platforms, cover, developer/publisher, description, external links and localization/alternate titles.
- Added preview-first canonical enrichment that preserves existing non-empty manual fields and adds `providerMetadata.igdb` plus raw snapshots.
- Hardened cross-provider enrichment so another provider's numeric ID cannot be silently reused as an IGDB ID; an explicit IGDB identity is required when none is already attached.
- Integrated IGDB with the common Review Queue create/apply path, including provider-aware diagnostics and entity-registry persistence on approval/apply.
- Added first-class IGDB Provider Hub UI for search, discovery, details, quality, queue import, entity registry, enrichment and acceptance.
- Added deterministic demo fixtures including Japanese/native-title localization and region-aware release records to exercise rich provider fields without external network access.
- Added `npm run igdb:selftest` (25 deterministic checks) and `npm run igdb:acceptance` for operator-run read-only live validation.
- Added `IGDB_INTEGRATION.md`, `IGDB_LIVE_ACCEPTANCE.md`, `IGDB_OFFICIAL_REFERENCES.md`, `IGDB_ATTRIBUTION.md`, `RELEASE_NOTES-v0.58.md`, and `BUILD_VALIDATION-v0.58.md`.
- Updated backup/export/restore and store normalization to carry `data.igdb` entity state and diagnostics.
- Updated common provider demo normalization and fixed the IGDB demo path to use the authoritative deterministic IGDB fixture model.
- Preserved all prior AniList implementation, compliance/acceptance, synchronization, Open Library, TMDB, Catalog, Community, Collections, Saved Views, Bulk Ops, Data Hub, Review Queue, provenance and continuity work.

#### v0.58 architectural rationale
- IGDB remains an enrichment/discovery provider, not the canonical source of truth.
- Exact provider IDs outrank heuristic similarity; cross-provider merges are intentionally deferred to v0.59.
- Provider-specific data is additive and provenance-bearing; manual canonical values are not silently overwritten.
- Live provider access is server-side only and credential-safe.
- Demo mode uses the same normalization/matching logic as live data, making offline development meaningful rather than a separate mock implementation.
- Remote provider artwork remains referenced rather than bulk-downloaded into the canonical datastore.
- Asian drama support remains a canonical data-model concern, not an IGDB/provider silo; dedicated regional provider coverage will be evaluated in the later provider/reconciliation phases.



### v0.59 — Cross-Provider Identity & Reconciliation
- Added a provider-neutral identity engine (`lib/identity.js`) spanning AniList, Open Library, TMDB, IGDB and Manual catalog records.
- Added exact same-provider identity detection and shared external-ID detection, including normalized ISBN comparison.
- Added title/alias similarity, creator overlap, year proximity, and canonical-type compatibility scoring with explicit confidence levels and human-readable reasons.
- Added a safety cap for canonical-type mismatches so identical/similar titles across incompatible media types cannot silently become the same work.
- Added persistent `identity.groups`, `identity.decisions`, `identity.runs`, and `identity.candidates` state.
- Identity groups are non-destructive: they group existing catalog records rather than deleting or overwriting provider-native rows. When two existing groups are confirmed against each other, the groups are merged.
- Added explicit manual confirm/reject decisions, persistent rejection suppression, audit entries, and per-field preferred-source selection.
- Added Identity Studio UI for analyzing a catalog record, rebuilding the candidate index, reviewing candidates, confirming/rejecting identities, inspecting conflicts, and choosing preferred field sources.
- Added `GET /api/identity/status`, `/groups`, `/groups/:id`, `/candidates` and `POST /api/identity/analyze`, `/rebuild`, `/decision`, `/preference`.
- Provider search/detail and catalog-detail responses now expose cross-provider identity candidates in addition to provider-specific match diagnostics.
- Full workspace backup/export/restore now preserves identity groups, decisions, rebuild runs and the persisted candidate index; restore/deletion paths prune orphaned identity references safely.
- Added deterministic `npm run identity:selftest` (10 checks) covering confidence scoring, type mismatch safety, ISBN normalization, rebuilds, group creation/merge, field preferences, rejection suppression, confirmed-pair consistency and demo neutrality.
- Added a datastore-neutral identity demo with intentionally mixed media types to illustrate why title similarity alone cannot be treated as proof of same-work identity.
- Preserved all AniList v0.54 acceptance state, Open Library v0.55–v0.56 work, TMDB v0.57 work, IGDB v0.58 work, catalog/collections/saved views/bulk ops/Data Hub/Review Queue/sync, and the complete cumulative project history.

#### v0.59 architectural rationale
- OmniShelf remains canonical-first: provider data is evidence, while identity groups create a stable non-destructive bridge across providers.
- Exact identifiers outrank fuzzy evidence.
- Cross-provider matching is intentionally conservative around medium/type mismatches, because a film adaptation, novel, manga, TV series or game can share a title without being the same canonical work.
- Identity confirmation is explicit and auditable; there is no silent merge. The normal reject route also cannot create contradictory state for a pair already inside a confirmed group; future reversal requires an explicit split/unlink operation.
- Field conflicts are surfaced rather than overwritten, preparing the catalog for v0.60's field-level multi-provider enrichment.

#### v0.59 documentation
- Added `IDENTITY_RECONCILIATION.md` and `BUILD_VALIDATION-v0.59.md` so the matching model, persistent state, safety boundary, API workflow, validation evidence and future v0.60 enrichment dependency travel with the build.

#### v0.59 continuity
Every subsequent release must continue to carry this entire cumulative history and enough implementation detail, rationale, validation, acceptance state, known limitations and roadmap context to let future work continue without reconstructing prior conversations.


### v0.60 — Unified Enrichment Engine
- Added a provider-neutral `lib/enrichment.js` layer that consumes only confirmed v0.59 identity groups and produces a deterministic field-by-field enrichment plan.
- Added field-specific scalar precedence and explicit identity-group preference override behavior. Manual is the default first-choice scalar source when present; future provider-specific governance can refine these policies.
- Added list-like field union with normalized de-duplication for creators, tags, aliases and external links.
- Added field-level provenance for every proposed/applied field, including all candidate source records, selected scalar source, source provider IDs, reason, and conflict flag.
- Added explicit scalar conflict buckets instead of silently discarding disagreement. Preferred values can still be applied while unresolved evidence remains visible in the enrichment lineage.
- Added deterministic SHA-256 enrichment plan hashing based on group/target state and plan content, explicitly excluding generation timestamp so a valid preview can be safely rechecked.
- Added target `updatedAt` optimistic-concurrency protection so an enrichment apply is rejected if the target changed after preview.
- Added persistent `data.enrichment.runs` journal and per-record `enrichment` lineage containing identity group, provider coverage, coverage score, unresolved conflicts, field provenance and policy.
- Added `GET /api/enrichment/status`, `/groups`, `/items/:catalogId`, `/coverage`, and `POST /api/enrichment/preview`, `/apply`.
- Added Unified Enrichment UI with group browser, status KPIs, datastore-neutral demo, preview plan, source display, conflict indicators and explicit apply control.
- Added backup/export/restore preservation of `enrichment` state and enriched catalog lineage.
- Added `npm run enrichment:selftest` with 10 deterministic assertions covering identity-group planning, field preferences, array union, conflict surfacing, provider coverage, deterministic plan hashing, concurrency/plan safety, field provenance, run journaling and demo neutrality.
- Preserved all prior AniList, Open Library, TMDB, IGDB, identity/reconciliation, catalog, Community, Collections, Saved Views, Bulk Operations, Data Hub, Review Queue, synchronization, acceptance and continuity work.

#### v0.60 architectural rationale
- Identity groups remain the non-destructive bridge; v0.60 does not physically merge provider rows or delete provider evidence.
- Enrichment targets one selected catalog member by default, preferring a Manual record when present, so the canonical surface can be human-owned while retaining provider evidence.
- Provider precedence is deterministic but explicit identity-group field preferences always outrank the default order.
- Arrays are additive and de-duplicated; scalars choose one value but retain the competing source evidence and conflict state.
- Plan hashes exclude timestamps, preventing false stale-plan failures while still binding the apply to the exact target snapshot and proposed plan.
- v0.60 intentionally does not become a broad live refresh orchestrator; provider reliability, live refresh scheduling, and unified provider search remain later work.

#### v0.60 documentation
- Added `UNIFIED_ENRICHMENT.md`, `RELEASE_NOTES-v0.60.md`, and `BUILD_VALIDATION-v0.60.md`.
- The cumulative history requirement continues: every future build must carry enough implementation detail, rationale, validation evidence, known limitations and roadmap dependencies to continue product development without reconstructing prior conversations.

### v0.61 — Provider Reliability & Operations
- Added provider-neutral `lib/reliability.js` around AniList, Open Library, TMDB and IGDB operations. It persists provider operational state, bounded event history and bounded circuit incidents without replacing provider-specific adapters.
- Added per-provider operations, blocked-operation count, successes, failures, cache hits/misses, total/average latency, last operation/error timestamps, consecutive transient failures, circuit state/open count, degradation timestamps and observed rate-limit fields where available.
- Added transient-failure circuit isolation: three consecutive transient failures open a provider-local circuit by default; open circuits fail fast with `PROVIDER_CIRCUIT_OPEN`; configurable cooldown permits one half-open recovery probe; successful recovery closes the circuit.
- Kept configuration/authentication failures out of the transient-outage circuit path so missing credentials remain diagnostic rather than being treated as an upstream outage.
- Added shared deterministic exponential backoff with bounded `Retry-After` support. Provider modules retain provider-specific request pacing/credential logic while using the common delay policy for transient retry decisions.
- Deepened Open Library retry handling for transient 429/5xx/timeout/network failures; expanded TMDB and IGDB transient retry behavior; expanded AniList transient retry behavior without weakening the existing live-access compliance gate.
- Added cache observability around completed provider operations while retaining each adapter's existing cache implementation and limits.
- Added stale-provider-data detection with a default 90-day window. Missing retrieval/enrichment timestamps are reported as `unknown` instead of silently fresh.
- Added reliability/readiness/acceptance APIs: `/api/providers/reliability`, filtered events/incidents, `/api/providers/staleness`, `/api/providers/reliability/acceptance`, deterministic self-test and explicit reset. `/api/health`, `/api/providers/status`, and provider-specific status routes expose reliability state.
- Added a first-class Reliability UI workspace with health cards, circuit state, latency/failure metrics, operational event log, stale-data view, acceptance matrix, deterministic self-test and confirmed reset action.
- Persisted reliability state in `data/store.json`; full backup/export/restore now carries reliability provider state, event history and incidents. Older backups without the field remain compatible.
- Added `scripts/provider-reliability-selftest.js` and `npm run reliability:selftest`, finalized at 8/8 deterministic assertions.
- During server validation, fixed an omitted `providerStatus` module export that initially broke `/api/health` and provider status routes. Also fixed cache-hit accounting and explicit-null `Retry-After` semantics discovered by deterministic testing.
- Verified provider-local failure behavior: missing TMDB credentials recorded three TMDB failures without opening a transient outage circuit, while TMDB demo search remained available. Verified backup/restore and operational reset against a disposable server workspace; final shipped datastore remained clean.
- Preserved all AniList, Open Library, TMDB, IGDB, identity/reconciliation, unified enrichment, catalog, Community, Collections, Saved Views, Bulk Operations, Data Hub, Review Queue, synchronization and acceptance work.
- Carried the complete cumulative project history and continuity documentation through v0.61. Next dependency: v0.62 Unified Provider Search.

#### v0.61 architectural rationale
- Reliability is provider-local: one upstream failure cannot disable unrelated providers.
- Circuit breaking is limited to transient upstream conditions; configuration/authentication mistakes are intentionally surfaced without creating outage state.
- Operational telemetry is bounded and persisted so diagnostics survive restarts/backups without allowing the reliability journal to grow without limit.
- Reliability observes top-level provider operations and complements rather than replaces each provider's own request queue, cache and credential rules.
- Staleness reporting is conservative because older provider-backed catalog records may lack retrieval timestamps; `unknown` is preferable to an incorrect freshness claim.
- Live acceptance remains an external operator activity and is explicitly separated from deterministic offline testing.

#### v0.61 documentation
- Added `PROVIDER_RELIABILITY.md` for the operational model, circuit/backoff/cache/freshness behavior, APIs, UI and acceptance boundary.
- Added `RELEASE_NOTES-v0.61.md` and `BUILD_VALIDATION-v0.61.md` with release rationale, exact validation evidence, defects found/fixed and known limitations.
- Updated `CURRENT_STATE.md`, `README.md`, `SUPPLIED_ARCHIVE_INDEX.md`, and `RECOVERED_PREVIOUS_CHAT_HISTORY.md` so the current release and next dependency travel with the archive.

#### v0.61 continuity
Every future OmniShelf release must carry the complete accumulated history and enough implementation detail, rationale, validation status, known limitations and roadmap dependencies to continue development without reconstructing prior conversations.

### v0.62 — Unified Provider Search
- Added provider-neutral `lib/unified-search.js` so users can search OmniShelf without choosing a provider first.
- Added smart provider routing based on canonical media type and query shape. ISBN-like queries route to Open Library; Game to IGDB; Movie/TV/Drama to TMDB; anime/manga/book families use AniList/Open Library combinations where appropriate; broad queries fan out across AniList, Open Library, TMDB and IGDB.
- Added explicit provider scope override so operators can constrain discovery without changing the underlying provider adapters.
- Added independent provider fan-out under v0.61 reliability instrumentation. A provider exception is isolated and returned as provider-level status/error information while successful providers continue contributing results.
- Added normalization of AniList, Open Library, TMDB and IGDB discovery responses into the canonical-style record shape already used by Review Queue, Identity and Unified Enrichment.
- Added deterministic discovery relevance scoring based on normalized title/alias/creator evidence. Discovery relevance is intentionally separate from identity confidence.
- Added catalog matching through the v0.59 identity engine so external results expose possible/strong matches, provider identity evidence and existing identity-group references without changing the catalog.
- Added discovery-only cross-provider grouping using strong identity evidence. Search returns clusters and lower-confidence relationships but never persists an identity decision, group, enrichment run or provider mutation.
- Added a first-class Search top-level UI with query, media type, provider scope, result limit, routing explanation, provider status cards, local catalog results, external results, relationship evidence, and Review Queue import.
- Added `GET /api/search`, `GET /api/search/route`, and `GET /api/search/demo-plan`.
- Added `npm run unified-search:selftest` with routing, demo fan-out, non-persistence, catalog inclusion/exclusion, stable result IDs, conservative type-mismatch and discovery-clustering assertions.
- Preserved every previous catalog, community, collection, saved view, data hub, review queue, provider, identity, enrichment, reliability, synchronization and AniList feature.

#### v0.62 architectural rationale
- Search is deliberately read-only. It is a discovery/composition layer, not a second ingestion or identity system.
- Provider adapters remain the authoritative source-specific integrations; the unified layer orchestrates them and does not duplicate their request logic.
- The v0.59 identity engine is reused for evidence, but search clustering is ephemeral. Only explicit Identity Studio actions can persist identity decisions.
- Catalog matches are displayed separately from provider results so “already in OmniShelf” remains distinct from “found externally”.
- Provider failures are isolated so one unavailable service cannot make unified discovery unusable.
- Smart routing reduces unnecessary upstream requests when the user's media intent is already clear, while broad search retains the full provider fan-out.
- The Review Queue remains the controlled bridge from external discovery to canonical catalog mutation.

#### v0.62 validation / continuity
- `npm run unified-search:selftest` passes 13/13 deterministic assertions.
- Existing reliability, identity, unified-enrichment, TMDB, IGDB and Open Library deterministic suites remain required regressions before release.
- Unified Search has an isolated HTTP E2E path for routing, demo search, provider-status reporting, partial-failure behavior, catalog separation, and Review Queue handoff.
- The release deliberately does not claim live provider search acceptance without external credentials/network access.
- `UNIFIED_PROVIDER_SEARCH.md`, `BUILD_VALIDATION-v0.62.md`, `RELEASE_NOTES-v0.62.md` and this cumulative history preserve enough implementation detail, rationale, validation evidence, known limits and roadmap dependency for future work to continue from the archive alone.

#### v0.62 next dependency
The next milestone is v0.63 — Final Data Governance Layer. It will formalize field-level source attribution, provider-vs-manual precedence, overwrite rules, stale-data policy, deletion safety, backup/restore verification, import/export preservation and audit history across the unified provider architecture.


### v0.63 — Final Data Governance Layer
- Added provider-neutral `lib/governance.js` above the canonical write boundary.
- Formalized field-level governance for title, type, year, description, creators, tags, aliases, coverUrl and externalLinks.
- Added explicit field-source attribution with catalog ID, provider, provider ID, source type, field and reason; existing v0.60 enrichment field provenance remains authoritative when present.
- Added deterministic scalar precedence aligned with unified enrichment, with manual ownership protection, same-provider refresh allowance, higher-precedence provider replacement, and explicit override inspection.
- Added local freshness policy and stale/unknown classification; missing timestamps are never silently treated as fresh.
- Added deletion-impact inspection covering identity groups, collections, review references, provider tombstone requirements and enrichment lineage.
- Added durable governance deletion tombstones while retaining the existing AniList sync tombstone path.
- Added bounded field-level before/after audit history for governed catalog writes.
- Added governance validation runs and a dedicated Governance UI/API surface.
- Added SHA-256 integrity manifests to full JSON workspace backups and restore-time tamper rejection; older un-hashed backups remain backward-compatible.
- Preserved governance state through backup/restore and catalog JSON export; CSV remains intentionally portable/flat.
- Integrated governance checks into manual catalog edits, Review Queue application, AniList/Open Library/TMDB/IGDB enrichment applies, and unified enrichment apply.
- Added `npm run governance:selftest` with deterministic checks for policy creation, source attribution, manual protection, empty-field fill, explicit override, freshness, deletion impact, deletion tombstones, field history, validation, backup integrity, tamper detection and policy-hash stability.
- Preserved all previous functionality and carried the complete cumulative project history from the original prototype through v0.63.

#### v0.63 architectural rationale
- Governance is a safety layer, not a provider replacement layer. Provider-native identities/raw payloads remain intact.
- Human-owned values should not be silently overwritten by external metadata. Provider enrichment remains explicit and auditable.
- Freshness is based on timestamps actually carried by canonical records rather than assumptions about provider behavior.
- Backup integrity is additive and migration-friendly, allowing older backups without hashes to remain restorable.

#### v0.63 validation / fixes
- Fixed a freshness-threshold environment lookup bug so undefined environment overrides fall back to policy defaults.
- Fixed governance source-decision argument handling so manual protection is correctly enforced for provider writes.
- Added regression coverage for stale detection and backup tamper detection.
- Verified the governance routes on an isolated server and preserved existing provider test suites.

#### v0.63 continuity
Every future OmniShelf build continues to carry this full project history, detailed implementation rationale, validation evidence, known boundaries and roadmap context inside the release archive.

#### v0.63 product continuity note — Asian dramas
The product direction explicitly retains Asian dramas as a first-class use case within the unified catalog rather than a separate subsystem. Future medium-specific UX and metadata work should accommodate Korean, Chinese, Japanese, Taiwanese, Thai, Hong Kong, Filipino, Vietnamese and other Asian drama industries, including native/original titles, romanized/international aliases, language and industry/country context, episode and airing structure, networks/platforms, cast/characters, and adaptation/related-work relationships.


### v0.64 — Catalog Experience & Discovery
- Started the product-experience phase after the planned provider-architecture roadmap completed at v0.63.
- Made a first-class Explore tab the default landing surface.
- Added catalog-first search with a direct bridge into Unified Provider Search for external discovery.
- Added quick medium shortcuts for Anime, Manga, Novel, Movie, TV, Drama, Game and Visual Novel.
- Added live catalog KPIs for total works, distinct media types, providers represented and collections.
- Added live Browse by medium cards from catalog facets.
- Added Recently added and Recently updated work rows using canonical timestamps.
- Added Popular Tags driven by the catalog's own tag vocabulary.
- Added a product-facing canonical work detail modal reusing `GET /api/catalog/:id`, with cover, metadata, creators, tags, collections, identity state, relationships and governance context.
- Added direct actions from Explore into Catalog and Unified Provider Search without creating a second data system.
- Added `lib/explore.js`, `GET /api/catalog/explore`, `POST /api/catalog/explore/selftest`, and `npm run catalog-experience:selftest`.
- Kept Explore read-only and preserved the existing identity, enrichment, reliability, unified-search and governance boundaries.
- Explicitly retained Drama as a first-class product navigation point because Asian dramas are a planned medium-specific experience, while deferring richer country/industry/language/airing normalization to the dedicated medium-experience phase.
- Validation: Catalog Experience 8/8; Unified Search 13/13; Reliability 8/8; Identity 10/10; Unified Enrichment 10/10; TMDB 17/17; IGDB 25/25; Open Library 5/5; isolated HTTP E2E 7/7.
- Shipped clean datastore with no synthetic test records; source manifest regenerated with zero mismatches; `preview.html` kept byte-identical to `public/index.html`.

#### v0.64 architectural rationale
- The product surface is intentionally a read layer over the mature canonical catalog rather than a second catalog implementation.
- Existing work-detail and catalog APIs are reused so governance/identity/enrichment state cannot diverge between UX surfaces.
- Product navigation is improved before adding more complex personalization/recommendation algorithms.
- Asian dramas are treated as a planned first-class use case without inventing unsupported metadata semantics.

#### v0.64 next dependency
v0.65 should build dedicated medium experience components, starting with Asian dramas: richer original/romanized/international titles, country/industry/language context, networks/platforms, episode/airing structure, cast/characters and adaptation relationships, while remaining inside the same canonical identity/enrichment/governance architecture.


### v0.65 — Dedicated Medium Experiences
- Began the dedicated medium-experience phase after the v0.64 general Explore surface.
- Added a first-class `Asian Dramas` product tab and a direct `?view=asian-dramas` entry point.
- Added `lib/asian-dramas.js` as a provider-neutral, read-only medium lens over canonical catalog records with normalized TMDB metadata.
- Added conservative regional classification for Korean, Chinese, Japanese, Taiwanese, Hong Kong, Thai, Filipino, Vietnamese, Indonesian, Malaysian, Singaporean, Indian, Bangladeshi and Pakistani drama profiles.
- Added explicit curated-label detection, country-first classification, and narrow language-only fallback signals; generic English/Chinese signals cannot classify ordinary TV records as Asian drama.
- Added original-title, alternate-title/international-title and optional explicit romanized-title presentation without inventing romanization.
- Added airing/upcoming/completed/unknown state classification using recorded air dates, status and production state.
- Added episode/season context, typical runtime, network and production-company context, creators, cast and related works.
- Added search and filters for title/alias/creator/network, regional industry, original language and state plus industry/language/year/state/genre/network facets.
- Added product-facing detail view with Catalog and Unified Search handoffs.
- Added deterministic demo fixtures and demo details without mutating the shipped datastore.
- Added `GET /api/medium/asian-dramas`, `/profiles`, detail lookup, and `POST /api/medium/asian-dramas/selftest`.
- Added `MEDIUM_EXPERIENCES.md`, `RELEASE_NOTES-v0.65.md`, and `BUILD_VALIDATION-v0.65.md`.
- Updated package/version metadata, README and current-state continuity through v0.65.

#### v0.65 architectural rationale
- The medium layer is deliberately a read model over the mature canonical catalog; it does not establish a separate Asian-drama database.
- Classification uses the strongest available identity signal and avoids broad language-only assumptions that could misclassify non-Asian TV.
- Title variants are preserved as data when sources provide them; romanization is treated as authoritative/curated data rather than a guessed transformation.
- Episode and season semantics reuse the existing TMDB normalized model rather than introducing provider-specific parallel fields.
- Streaming-platform availability is intentionally deferred because TMDB's Watch Providers surface carries a JustWatch attribution requirement and the current canonical TMDB integration does not yet persist that data.

#### v0.65 validation / fixes
- Added regression coverage for ambiguous-English non-classification and explicit K-Drama tag classification.
- Verified demo filtering, title-variant search, profile detection, episode metadata, network context and catalog-read-only behavior.
- Preserved the clean v0.64 datastore; no synthetic Asian-drama fixtures are shipped as catalog records.

#### v0.65 final validation evidence
- Deterministic Asian Drama self-test: 15/15.
- Existing regressions: Catalog Experience 8/8; Unified Provider Search 13/13; Reliability 8/8; Identity 10/10; Unified Enrichment 10/10; Governance 14/14; TMDB 17/17; IGDB 25/25; Open Library 5/5.
- Isolated HTTP E2E: 9/9, covering health/version, live read-only lens, supported profiles, demo non-persistence, industry filtering, original-title query, rich demo detail, self-test endpoint, and Asian Dramas UI route.
- Client JavaScript syntax check passed; `preview.html` is byte-identical to `public/index.html`.
- Clean datastore SHA-256: 8138ddf41ec7c690a003c9873419766e84062ebd6ed27ea5273b5e0e1bd0dfe4 before final documentation/manifest refresh.
- Source manifest regenerated and verified with zero mismatches; no synthetic Asian Drama records are shipped.

#### v0.65 continuity
Every future OmniShelf build continues to carry the complete project history, detailed implementation rationale, validation evidence, known boundaries and roadmap context inside the release archive.

#### v0.65 next dependency
v0.66 should deepen live Asian-drama discovery/ingestion quality and reusable medium-experience infrastructure, while maintaining the canonical identity/enrichment/governance boundaries.


### v0.66 — Medium Experience Framework & Asian Drama Deepening
- Began the reusable medium-experience framework after v0.65's first dedicated Asian Drama surface.
- Added `lib/medium-experiences.js` as a small registry describing core, dedicated and planned medium surfaces without duplicating the canonical catalog.
- Added `GET /api/mediums` and `POST /api/mediums/selftest` plus the Mediums product tab.
- Deepened Asian Drama provider discovery with profile-aware TMDB TV discovery, title search, regional classification, state/year/language filtering, deterministic ranking and per-result metadata-quality signals.
- Added catalog and cross-provider identity match evidence to live Asian Drama discovery results.
- Added explicit provider-detail inspection for a TMDB TV result before any import decision.
- Added controlled Asian Drama ingestion preview; the result is handed to the existing Review Queue only after an explicit UI action.
- Added a gated TMDB Watch Providers surface with a separate JustWatch attribution acknowledgment flag; demo mode is deterministic and live usage remains disabled by default.
- Extended the TMDB adapter to support `with_origin_country` / `with_original_language` discovery inputs and Watch Providers normalization.
- Preserved canonical catalog, identity, unified enrichment, reliability, unified search and governance boundaries.
- Carried the full cumulative project history and detailed implementation/rationale/validation context forward through v0.66.

#### v0.66 architectural rationale
- Medium-specific product experiences are views, not new catalog silos.
- Provider discovery should strengthen the user's ability to find works without bypassing review/governance controls.
- The first specialized medium experience should remain a reusable pattern for future Anime/Manga/Novel/Game/Visual Novel/stage experiences.
- Watch-provider availability is intentionally separated from canonical metadata because it has an additional source-attribution requirement.

#### v0.66 validation / fixes
- Added deterministic medium-registry coverage plus profile-aware provider-discovery checks, quality signals and multi-market coverage.
- Corrected multi-language profile routing so profiles with multiple supported languages are not narrowed to the first language unless explicitly requested.
- Corrected demo provider-detail and ingestion-preview flows to use the selected Asian Drama fixture; corrected demo availability links to preserve the inspected provider ID.
- Kept live availability behind the explicit Watch Providers and JustWatch attribution gates.
- Verified the Review Queue handoff through the existing 201 Created / `{ normalized: ... }` API contract.

#### v0.66 final validation evidence
- Medium Experience Framework: 7/7.
- Asian Drama: 18/18.
- Existing regressions: Catalog Experience 8/8; Unified Provider Search 13/13; Reliability 8/8; Identity 10/10; Unified Enrichment 10/10; Governance 14/14; TMDB 17/17; IGDB 25/25; Open Library 5/5.
- Isolated HTTP E2E: 18/18.
- Server/client syntax validation passed.
- No synthetic Asian Drama records shipped in the final datastore.
- `preview.html` synchronized to `public/index.html`; source manifest generated after final edits with zero mismatches.

#### v0.66 next dependency
v0.67 should improve core Catalog UX and medium-specific work pages now that the reusable medium-experience layer and Asian Drama provider workflow are in place.


### v0.67 — Core Catalog UX & Rich Work Pages
- Began the post-provider product-experience phase by making the canonical Catalog a primary everyday browsing surface.
- Added card-first Catalog rendering with a persistent list mode for dense selection and bulk-management tasks.
- Added medium quick shortcuts that reuse the canonical type filters rather than creating medium-specific catalog silos.
- Added richer catalog cards with cover, type, provider/year/status, description, creators, tags, selection and direct work actions.
- Added `lib/work-pages.js`, a provider-neutral read model for canonical works.
- Added `GET /api/catalog/:id/work-page` and `POST /api/catalog/work-page/selftest`.
- The rich work-page model combines canonical metadata with existing relations, collections, identity candidates/groups and enrichment state.
- Work pages present hero artwork, title variants, overview/storyline, metadata, creators, cast/crew, releases, relationships, collections, identity, enrichment, governance, gallery, external sources and provider-specific detail.
- Existing provider-specific structures remain authoritative; v0.67 does not invent new metadata or mutate provider records when a work is opened.
- Editing continues through the existing governed catalog PATCH path, keeping the v0.63 data-governance boundary intact.
- Existing Asian Drama metadata can flow through the same work-page presentation contract, preserving the v0.65-v0.66 regional/airing/title/network context without creating a separate catalog.

#### v0.67 architectural rationale
- Catalog UX is a read/presentation layer over the canonical catalog, not a second source of truth.
- Card view is optimized for discovery and visual scanning; list view is retained for dense maintenance and selection workflows.
- Work pages are richer than catalog cards but still read-only, so provider search, identity decisions, enrichment and governed writes stay in their existing boundaries.
- The work-page contract is provider-neutral but medium-aware through normalized metadata and provider-specific sections.

#### v0.67 validation / fixes
- Corrected the work-page route parameter extraction so canonical IDs are read from the correct URL segment.
- Corrected self-tests to assert the actual shared catalog card renderer rather than requiring a separate helper.
- Kept unified search regression compatible with the existing response contract where its `version` is the search-module schema version rather than the release version.
- Isolated all HTTP catalog mutations in disposable E2E copies; no synthetic work records are shipped.

#### v0.67 final validation evidence
- Work Page deterministic self-test: 7/7.
- Catalog UX deterministic self-test: 5/5.
- Catalog Experience regression: 8/8.
- Medium Experience Framework: 7/7.
- Asian Drama: 18/18.
- Unified Provider Search: 13/13.
- Provider Reliability: 8/8.
- Identity: 10/10.
- Unified Enrichment: 10/10.
- Data Governance: 14/14.
- TMDB: 17/17.
- IGDB: 25/25.
- Open Library: 5/5.
- Isolated HTTP E2E: 9/9.
- Server and client JavaScript syntax checks passed.
- `preview.html` is synchronized to `public/index.html`.
- The final source SHA-256 manifest is generated after all edits and verified with zero mismatches.
- The final datastore remains clean and contains no E2E test records.

#### v0.67 known boundaries
- The rich work page is currently presented as an in-app modal; v0.68 should add a dedicated navigable/deep-linkable work-page route.
- Live provider acceptance remains a separate external-credential/network task.
- Automated headless screenshot capture remains environment-dependent.

#### v0.67 next dependency
v0.68 should deepen the medium-specific work-page system and introduce standalone/deep-linkable work pages before the product shifts into a richer personal library experience.

### v0.68 — Standalone Work Pages & Deeper Medium-Specific Experiences
- Turned the v0.67 rich work-page read model into a true deep-linkable product route at `/work/:id`.
- Added browser-history aware standalone navigation, explicit back-to-OmniShelf behavior, dynamic document titles, and shareable work URLs.
- Added “Open page” actions to Catalog list/card surfaces while retaining the quick modal preview for lightweight inspection.
- Refactored the shared work-page renderer so the modal preview and standalone page consume the same canonical presentation contract.
- Added `mediumExperience` highlights to `lib/work-pages.js` for Asian Dramas, Games, Novels, Anime/Manga/Visual Novels, Film, and TV.
- Asian Drama work pages use conservative regional identification: explicit Drama type or unambiguous TMDB origin-country evidence; generic language signals are not sufficient.
- Added `STANDALONE_WORK_PAGES.md`, `RELEASE_NOTES-v0.68.md`, `BUILD_VALIDATION-v0.68.md`, `FINAL_RELEASE_CHECK-v0.68.txt`, and `scripts/standalone-work-selftest.js`.

#### v0.68 architectural rationale
- A canonical work should have a stable URL independent of whatever surrounding screen opened it.
- Modal previews remain useful for quick inspection, but the standalone page is the durable/shareable representation.
- Medium-specific presentation belongs in the work-page model, not in separate catalogs.
- Navigation state must not become a hidden data source; canonical data continues to come from `/api/catalog/:id/work-page` and governed write APIs.

#### v0.68 validation / fixes
- Added deterministic checks for the deep-link route, history transitions, standalone shell, shared work renderer, and medium-aware rendering.
- Verified Catalog → Open page → Work API navigation in an isolated HTTP copy using a disposable synthetic catalog; no test item ships.
- Verified the clean datastore remains empty and unaffected after all disposable E2E runs.

#### v0.68 known boundaries
- `/work/:id` reuses the existing application shell instead of introducing a separate server-rendered template.
- Live provider acceptance and automated headless screenshot capture remain environment dependent.

#### v0.68 final validation evidence
- Standalone Work Pages: 8/8.
- Work Page: 8/8.
- Catalog UX: 5/5.
- Catalog Experience: 8/8.
- Medium Experience Framework: 7/7.
- Asian Drama: 18/18.
- Unified Provider Search: 13/13.
- Provider Reliability: 8/8.
- Identity & Reconciliation: 10/10.
- Unified Enrichment: 10/10.
- Data Governance: 14/14.
- TMDB: 17/17.
- IGDB: 25/25.
- Open Library: 5/5.
- Isolated HTTP E2E: 3/3.
- Server/module and inline-client syntax validation passed.
- `preview.html` synchronized to `public/index.html`.


### v0.69 — Personal Library Experience
- Introduced a first-class personal library layer over the canonical catalog. The personal layer is intentionally separate from provider metadata and canonical work identity.
- Added `lib/library.js` with a versioned `library.profile` plus catalog-keyed personal records for status, progress, totals, progress units, personal 1–100 score, favorite state, notes, and lifecycle dates.
- Added conservative progress-unit inference by medium: episodes for screen/serial drama, chapters for manga/manhwa/manhua, pages for book/poetry families, hours for games, viewings for films, acts for plays, and generic units where no stronger unit exists.
- Added `GET /api/library`, `/api/library/stats`, `/api/library/:catalogId`, `PUT /api/library/:catalogId`, `POST /api/library/:catalogId/advance`, `DELETE /api/library/:catalogId`, and deterministic `POST /api/library/selftest`.
- Added a top-level My Library product tab with personal KPIs, filters, favorites, status views, sorting, pagination, progress bars, inline editing and removal.
- Added Add / Save / Advance / Remove personal-library controls to shared work pages in both modal and standalone modes. Work-page responses now return personal library state alongside canonical work data.
- Preserved the v0.68 medium-aware work-page presentation; v0.69 treats the personal relationship with a work as an additional layer rather than creating medium-specific catalogs.
- Added library state to full JSON backups and restore previews/apply flows. Restore filters orphaned library records whose catalog IDs are absent from the restored catalog.
- Added `PERSONAL_LIBRARY.md`, `RELEASE_NOTES-v0.69.md`, `BUILD_VALIDATION-v0.69.md`, `FINAL_RELEASE_CHECK-v0.69.txt`, and `scripts/library-selftest.js`.

#### v0.69 architectural rationale
- Canonical records answer “what is this work?”; personal library records answer “what am I doing with this work?”.
- Personal writes do not pass through provider precedence because they are not provider claims. They receive their own audit actions.
- The progress unit remains editable because provider totals are often incomplete or medium-specific. Known totals improve completion behavior but never replace user control.
- The local single-profile model is an intentional first boundary for future account scoping.

#### v0.69 fixes / validation notes
- Added deterministic library tests covering inference, status/score/favorite stats, completion percentage, and removal.
- Updated inherited standalone/work-page self-tests for the v0.69 version string.
- Added a backup-manifest library count so governance backup diagnostics describe personal-state preservation explicitly.
- Kept all HTTP mutation tests in disposable copies; the shipped datastore remains the clean release baseline.


#### v0.69 final validation evidence
- Personal Library: 7/7.
- Standalone Work Pages: 8/8.
- Work Page: 8/8.
- Catalog UX: 5/5.
- Catalog Experience: 8/8.
- Medium Framework: 7/7.
- Asian Drama: 18/18.
- Unified Provider Search: 13/13.
- Provider Reliability: 8/8.
- Cross-Provider Identity: 10/10.
- Unified Enrichment: 10/10.
- Final Data Governance: 14/14.
- TMDB: 17/17.
- IGDB: 25/25.
- Open Library: 5/5.
- Personal-library HTTP E2E: 18/18 in a disposable copy, including backup/restore and single/bulk canonical-delete cleanup.
- Server/module/client syntax validation passed.
- `preview.html` is byte-identical to `public/index.html`.
- Clean shipped datastore SHA-256: `37e7cf6f5f99edd4372034f2786732fb20c553a0ce005909222cab5236c82549`.

#### v0.69 known boundaries
- The current personal library is a single local workspace named “You”; there is not yet account authentication or multi-user isolation.
- Personal state is not yet automatically pushed to AniList or other providers.
- Provider live acceptance and automated Chromium screenshot capture remain external/environment-dependent.



# v0.70 — Everyday Personal Library Experience

v0.70 builds directly on the v0.69 personal-library layer. The release does not alter the canonical catalog/provider ownership model. Instead, it creates a provider-neutral read model for the user's day-to-day library behavior.

## Implementation
- Added `lib/library-experience.js` as a read-only presentation model over `lib/library.js`.
- Added `GET /api/library/overview` for personal dashboard data, quick shelves, measurable progress and medium summaries.
- Added `GET /api/library/medium/:type` for selectable medium-specific personal views.
- Added `LIBRARY_EXPERIENCE.md` and `scripts/library-experience-selftest.js`.
- Added `library:experience:selftest` to `package.json`.
- Expanded My Library UI with Continue, Plan to, Completed, Favorites and Recently Updated shelves, progress overview and medium lenses.
- Consolidated the library frontend around one canonical `loadLibraryExperience()` path.
- Updated the work-page read-model version to v0.70; personal library controls continue using the same v0.69 APIs.

## Product rationale
The v0.69 release proved that personal state can be stored cleanly beside canonical catalog data. v0.70 makes that state actionable: the first screen answers what to continue, what to plan next, what has been completed, what is favorite, what changed recently, and how each medium is progressing.

Medium views intentionally reuse canonical IDs and the existing personal-state record instead of branching into separate medium-specific databases. This keeps provider reconciliation, enrichment and governance independent of presentation.

## Validation boundary
The v0.70 deterministic library-experience suite covers the dashboard/read-model invariants. Full release validation also re-runs the prior provider, governance, catalog, identity, enrichment, medium and personal-library suites. Any HTTP E2E mutations are performed only against disposable workspace copies; the shipped datastore remains clean.

## Dependency / next step
AniList remains independent of this release. The My Library experience does not require live AniList access. The next product milestone can therefore continue without coupling personal-library availability to upstream provider response time or authorization.
