# AniList Unified Media Workspace — v0.50

## Purpose
A single view that connects an AniList media record to the rest of OmniShelf instead of forcing users through separate provider screens.

## Endpoint
`GET /api/anilist/workspace/media/:id?type=ANIME|MANGA`

Add `demo=1` for the deterministic local fixture.

## Lineage
The response includes AniList provider identity, normalized OmniShelf type, canonical catalog linkage, collections, sync state, tombstone state, and the source URL.

## Cross-domain data
Media assets, relations, characters, staff, studios, recommendations, reviews, statistics, and list-entry state are surfaced together.

## Safety
Demo mode is datastore-neutral. Live mode requires the existing AniList compliance/authorization gate.
