# OmniShelf v0.80 Build Validation

## Scope

Production Hardening over the v0.79 UI/UX & Accessibility release.

## v0.80-specific validation

- Production Hardening deterministic self-test: **11/11**.
- Production Hardening HTTP E2E: **16/16**.
- Security headers: request ID, `nosniff`, frame denial, referrer policy, permissions policy, CORP and CSP emitted.
- Request limits: URI/body bounds and JSON safety guards exercised.
- Workspace validation: clean workspace accepted; duplicate provider identity detected in deterministic validation.
- Atomic persistence: temporary-file + fsync + rename write path validated.
- Recovery: integrity-hashed backup creation/listing and explicit restore confirmation validated in a disposable workspace.
- Backup retention: five-snapshot retention contract exposed.
- Runtime shutdown and fatal-error logging paths are installed in the Node server.

## Full regression

- All executable `selftest` and `http-e2e` scripts in `package.json`: **35/35 suites passed — 422 checks**.
- No live provider acceptance is claimed; external provider tracks remain independently gated.

## Integrity

- All JavaScript source/test files pass `node --check`.
- Embedded client JavaScript passes syntax validation.
- `preview.html` and `public/index.html` are byte-identical.
- Shipped `data/store.json` contains no domain records.
- Runtime `logs/` and `data/.backups/` are not populated in the shipped archive.
- Source SHA-256 manifest covers **239 release files** (excluding the manifest itself) and is verified after archive extraction.
- ZIP integrity and single-root structure are verified from the extracted archive.
