# OmniShelf v0.77 — Universal Import / Export & Migration

## Purpose

v0.77 introduces a portable user-data format for moving OmniShelf personal data between installations without treating the operational provider datastore as user-owned content. It complements, rather than replaces, the full workspace backup system.

## Portable package

Portable JSON uses `format: omnishelf-portable` and schema version `1`. Packages are either `personal` or `workspace`.

Personal exports include the works referenced by the user's personal state, personal library records, durable personal history, Smart Library Collections and the local Community data needed to preserve the user's social context. Workspace exports include the full canonical catalog as well as those user/community layers.

Portable packages deliberately omit provider operational telemetry, raw provider payloads, reliability history, audit logs and governance operational history. Cover and asset data remain references rather than embedded remote bytes.

## Work identity and migration

During import, OmniShelf maps each exported work to the destination catalog in this order:

1. Exact provider + provider ID.
2. Shared external identifiers.
3. Existing v0.59 identity evidence and confidence scoring.
4. Otherwise create a new canonical work record during Apply.

Ambiguous identity matches are surfaced as `review` rows. They are not silently merged into an existing canonical record. The current Apply behavior preserves the imported work as a new canonical record when a match is not strong enough for automatic mapping.

## Personal-state policy

Existing destination library state supports three explicit policies:

- `keep-existing` — preserve the destination personal state for matched works.
- `newer` — apply imported personal state only when its `updatedAt` is newer.
- `import-overwrite` — replace matched personal state with the imported state.

The UI requires a confirmation before using `import-overwrite`.

## Community remapping

Community member IDs are local installation identifiers, so they are not preserved as primary IDs during migration. Members are matched by handle where possible; otherwise new local IDs are generated. Work references, follows, community reviews, likes and activities are remapped to the destination catalog/member graph. Repeated imports use portable markers to avoid duplicating imported history, reviews and activity.

## CSV

A portable library CSV is available for simple spreadsheet-oriented export. It contains one row per currently tracked library item with work identity fields and personal state: status, progress, progress unit, score, favorite, notes and lifecycle dates. CSV is export-only in v0.77; portable JSON is the lossless migration format.

## API

- `GET /api/data/portable/export?scope=personal|workspace&format=json`
- `GET /api/data/portable/export?scope=personal&format=csv`
- `POST /api/data/portable/import/preview`
- `POST /api/data/portable/import/apply`
- `POST /api/data/portable/selftest`

Portable import is preview-first. Existing canonical records are not silently overwritten, and all HTTP mutation tests use disposable workspaces.
