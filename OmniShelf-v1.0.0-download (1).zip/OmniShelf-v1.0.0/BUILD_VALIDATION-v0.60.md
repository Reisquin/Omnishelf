# OmniShelf v0.60 Build Validation

## Build target
Unified Enrichment Engine over v0.59 confirmed identity groups.

## Deterministic tests
- `npm run enrichment:selftest` — **10/10**
- `npm run identity:selftest` — **10/10** (v0.59 identity regression)
- `npm run tmdb:selftest` — **17/17**
- `npm run igdb:selftest` — **25/25**
- `npm run openlibrary:quality-test` — **5/5**

## HTTP E2E validation
The isolated server workflow was exercised on port 3111. Results: health **v0.60**, enrichment status **200**, demo preview **200**, real confirmed-group preview **200**, apply **200**, plan-hash mismatch **409**, changed-target/optimistic-concurrency **409**, backup export **200** with `enrichment`, and clean datastore restored afterward.

Required boundary:
1. health/version response is v0.60;
2. enrichment status/group routes;
3. datastore-neutral demo preview makes no write;
4. two-or-more-member identity group can be previewed;
5. preview returns plan hash and target timestamp;
6. apply updates only the selected target and writes field-level provenance;
7. a changed target returns HTTP 409;
8. a stale/different plan returns HTTP 409;
9. backup export contains `enrichment`;
10. restore preview reports enrichment runs;
11. clean shipped datastore contains no demo catalog or enrichment run;
12. preview HTML serves successfully and embedded JavaScript passes syntax validation.

Observed deterministic result: plan hashes remain stable across two previews when catalog state is unchanged, while the generation timestamp differs.

## Known environment limitation
Live external-provider acceptance is still governed by the provider-specific acceptance boundaries recorded in the earlier release history. v0.60 does not claim fresh live provider access merely because the local enrichment engine passes offline tests.

## Release hygiene
The package must have root directory `OmniShelf-v0.60/`, `VERSION.txt` = `0.60.0`, a regenerated `SOURCE_SHA256.txt`, a clean `data/store.json`, and cumulative project history through v0.60.
