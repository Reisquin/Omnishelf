# OmniShelf v0.58 Build Validation

## Build source

Built directly from the OmniShelf v0.57 release archive. Existing application code, clean datastore, cumulative history, and prior provider implementations were retained before adding the IGDB layer.

## Deterministic validation

Command:

```bash
npm run igdb:selftest
```

Result: **PASS — 25 checks**.

Covered by the suite:
- IGDB → canonical `Game` mapping.
- First-release year derivation.
- Platform and release-date normalization.
- Developer and publisher company extraction.
- Localization and alternate-title preservation.
- External game identifiers and age ratings.
- Artwork and screenshot asset normalization.
- Demo Provider Hub compatibility.
- Exact IGDB ID identity precedence.
- High-quality complete-fixture scoring.
- Preview-first enrichment.
- Preservation of manual title/description/creator metadata.
- Provider metadata/raw snapshot retention.
- Company/platform/collection/franchise entity bundle creation.
- IGDB image URL helper.
- Safe default unconfigured live state.

## Static validation

- `node --check lib/igdb.js` — PASS.
- `node --check lib/providers.js` — PASS.
- `node --check server.js` — PASS.
- `node --check scripts/igdb-offline-selftest.js` — PASS.
- `node --check scripts/igdb-live-acceptance.js` — PASS.
- `package.json` parse — PASS.
- `VERSION.txt` — `0.58.0`.
- `public/index.html` and `preview.html` are synchronized.

## Safety fixes found during validation

1. Demo Provider Hub search originally passed non-numeric IGDB fixture IDs into the strict IGDB normalizer. The demo path now uses the authoritative deterministic IGDB fixture model.
2. Exact provider identity could previously be reduced by later year/type scoring. Exact IGDB ID matches now remain hard `1.00` matches.
3. IGDB enrichment could otherwise reuse a non-IGDB numeric provider ID on a cross-provider canonical record. Explicit IGDB identity selection is now required for that scenario.
4. Common Review Queue create/apply now recognizes IGDB identity diagnostics and persists IGDB entities on approval/apply.
5. Client-credential token state is refreshed on the first 401 rather than remaining stale until process restart.

## Live external validation

Not claimed from this offline environment. Run the included operator procedure on a network-enabled machine with valid IGDB/Twitch application credentials:

```bash
npm run igdb:acceptance -- --plan
npm run igdb:acceptance -- --query=The\ Legend\ of\ Zelda
```

A blocked live run remains blocked; it is never treated as a successful acceptance.

## Datastore discipline

The shipped clean `data/store.json` remains a clean project baseline. Demo validation does not write demo records into the shipped datastore.

## Release continuity

The release carries the cumulative project history through v0.58, current state, recovered continuity files, roadmap, provider references, acceptance plans, release notes and validation material.
