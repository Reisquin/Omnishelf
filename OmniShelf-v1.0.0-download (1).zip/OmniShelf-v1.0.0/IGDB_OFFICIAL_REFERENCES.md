# IGDB Official References — OmniShelf v0.58

These official sources were consulted while implementing v0.58. Re-check them before public/commercial deployment because API behavior, authentication requirements and terms can change.

- IGDB API documentation: https://api-docs.igdb.com/index.html
- IGDB authentication / Twitch app flow: https://api-docs.igdb.com/#authentication
- IGDB games endpoint / query examples: https://api-docs.igdb.com/#game
- IGDB release-date endpoint: https://api-docs.igdb.com/#release-date
- IGDB screenshots: https://api-docs.igdb.com/#screenshot
- IGDB artworks: https://api-docs.igdb.com/#artwork
- IGDB image URL documentation: https://api-docs.igdb.com/#images
- Twitch application / authentication documentation: https://dev.twitch.tv/docs/authentication/getting-tokens-oauth/
- Twitch developer console guidance: https://dev.twitch.tv/docs/authentication/register-app/

Implementation decisions grounded in the official documentation consulted for v0.58:
- IGDB API calls use the v4 API through server-side POST requests.
- IGDB application access uses Twitch application credentials / bearer authorization.
- The browser does not call IGDB directly; OmniShelf's server performs provider requests.
- The adapter uses a conservative serialized request queue because the documented request rate is limited.
- Game fields are retrieved as a bounded rich-detail selection rather than an unbounded schema dump.
- Image URLs are derived from IGDB image IDs when needed and retained as remote references.
- The local project does not infer commercial authorization from possession of credentials.
