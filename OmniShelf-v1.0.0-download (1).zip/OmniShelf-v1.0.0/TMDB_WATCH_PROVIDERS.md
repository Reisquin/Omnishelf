# TMDB Watch Providers — OmniShelf v0.66

## Purpose
This surface supports medium-specific product experiences that need to tell a user where a TMDB title may be available without making provider availability part of the canonical work record by default.

## API
- `GET /api/tmdb/watch-providers/status`
- `GET /api/medium/asian-dramas/watch-providers/status`
- `GET /api/medium/asian-dramas/watch-providers?id=<tmdb-tv-id>&region=<ISO3166-1>`

## Safety and source boundary
Live Watch Providers requests are disabled by default. They require both:
- `TMDB_WATCH_PROVIDERS_ENABLED=true`
- `TMDB_JUSTWATCH_ATTRIBUTION_ACK=true`

The second gate records an explicit operator acknowledgement because TMDB's current Watch Providers documentation identifies JustWatch as the source for the availability data and requires JustWatch attribution.

The UI displays availability as a provider-derived read surface. v0.66 does not silently persist provider availability into canonical catalog metadata.

## Demo behavior
Demo mode is deterministic and does not contact TMDB. It returns a single local placeholder provider and a provider-specific TMDB link using the inspected fixture ID. Demo data is not written to the datastore.
