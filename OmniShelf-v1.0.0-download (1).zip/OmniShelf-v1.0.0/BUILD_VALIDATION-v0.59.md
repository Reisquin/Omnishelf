# OmniShelf v0.59 — Build Validation

## Release

- Version: `0.59.0`
- Milestone: Cross-Provider Identity & Reconciliation
- Base: OmniShelf v0.58
- Final datastore: clean baseline plus an empty persisted identity state; no test catalog rows are shipped.

## Static validation

- `node --check server.js` — PASS
- `node --check lib/identity.js` — PASS
- JavaScript self-checks for provider scripts — PASS
- `public/index.html` script syntax — PASS
- `preview.html` synchronized with `public/index.html` — PASS

## Deterministic provider regression

- `npm run tmdb:selftest` — PASS, 17/17
- `npm run igdb:selftest` — PASS, 25/25
- `npm run openlibrary:quality-test` — PASS, 5/5

## Identity deterministic suite

- `npm run identity:selftest` — PASS, 10/10

The suite verifies same-type confidence, type mismatch safety, ISBN normalization, rebuild persistence, group creation, group merge, field preference, rejection suppression, confirmed-pair consistency, and datastore-neutral demo behavior.

## HTTP smoke / end-to-end acceptance

An isolated server instance was used to avoid contamination from any other OmniShelf process. The test covered:

- `/api/health` reports v0.59.
- `/api/identity/status` reports the identity engine and thresholds.
- `/api/identity/analyze` demo mode returns the deterministic four-record/six-pair fixture.
- Manual catalog records can be created for reconciliation tests.
- `/api/identity/analyze` finds a cross-provider candidate.
- `/api/identity/decision` confirm creates a durable identity group.
- Confirming across two existing groups merges them without deleting member rows.
- `/api/identity/preference` persists a per-field preferred catalog source.
- `/api/identity/groups/:id` returns members, conflicts and preferences.
- Rejecting an unconfirmed candidate suppresses it on repeat analysis.
- Rejecting a pair already inside a confirmed group returns HTTP 409 instead of producing contradictory state.
- Full backup export is versioned 0.59 and includes identity state.
- Restore preview reports identity groups, decisions and runs.
- Identity references survive workspace backup/restore and are pruned against the restored catalog.

## Packaging validation

- Final archive root: `OmniShelf-v0.59/`
- `VERSION.txt` contains `0.59.0`.
- `package.json` contains version `0.59.0`.
- `PROJECT_HISTORY.md` contains the cumulative history through v0.59.
- `CURRENT_STATE.md` starts at v0.59 and points to v0.60 as the next milestone.
- `SUPPLIED_ARCHIVE_INDEX.md` records the supplied historical archives and current release lineage.
- `SOURCE_SHA256.txt` is regenerated after final source/document edits.
- ZIP integrity is checked with `unzip -t`.

## Live acceptance boundary

No live AniList, Open Library, TMDB or IGDB acceptance is claimed by this offline build. Each provider's operator-run acceptance procedure remains in its existing documentation. v0.59 itself is provider-neutral and can be validated completely offline because identity comparison, grouping and decision logic use local catalog data.

## Issues found and fixed during build

1. ISBNs containing punctuation did not initially match punctuation-free ISBNs. The identity external-identifier normalizer now canonicalizes ISBNs before comparison.
2. Exact IGDB provider IDs required hard precedence in the preceding v0.58 provider layer; the v0.59 identity comparator preserves exact identifiers as the strongest evidence.
3. A previously confirmed pair could have received a contradictory reject decision through the HTTP route. The route now blocks that state with HTTP 409 and documents a future explicit split/unlink operation as the correct reversal mechanism.
4. A rebuild test expected the pre-v0.59 fixture catalog size after the fixture was expanded. The validation assertion now matches the actual four-record fixture.
5. The shipped server startup/version response is sourced from the v0.59 `VERSION` constant so API and logs do not incorrectly identify the release as v0.58.
