const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { PROVIDERS, normalizeForDemo, normalize, findMatches } = require('./lib/providers');
const store = require('./lib/store');
const anilist = require('./lib/anilist');
const openLibrary = require('./lib/openlibrary');
const openLibraryQuality = require('./lib/openlibrary-quality');
const tmdb = require('./lib/tmdb');
const igdb = require('./lib/igdb');
const identity = require('./lib/identity');
const enrichment = require('./lib/enrichment');
const reliability = require('./lib/reliability');
const unifiedSearch = require('./lib/unified-search');
const governance = require('./lib/governance');
const explore = require('./lib/explore');
const asianDramas = require('./lib/asian-dramas');
const mediumExperiences = require('./lib/medium-experiences');
const workPages = require('./lib/work-pages');
const library = require('./lib/library');
const libraryExperience = require('./lib/library-experience');
const libraryHistory = require('./lib/library-history');
const libraryCollections = require('./lib/library-collections');
const libraryStatistics = require('./lib/library-statistics');
const recommendations = require('./lib/recommendations');
const unifiedWorkflow = require('./lib/unified-workflow');
const community = require('./lib/community');
const portable = require('./lib/portable');
const mediumPersonal = require('./lib/medium-personal-experiences');
const production = require('./lib/production');

const VERSION = '1.0';
const PORT = Number(process.env.PORT || 3000);
const PUBLIC = path.join(__dirname, 'public');
const MIME = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.ico':'image/x-icon','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'};
const SORT_FIELDS = new Set(['title','year','updatedAt','createdAt','type','provider','status']);
const COLLECTION_NAME_LIMIT = 120;
const SMART_NAME_LIMIT = 120;
const SMART_RULE_KEYS = new Set(['q','type','provider','year','status','tag']);
const BULK_ACTIONS = new Set(['status','addTag','removeTag','addToCollection','removeFromCollection','delete']);
const BULK_LIMIT = 100;
const ANILIST_MAX_QUERY_CHARS = 120000;
const ANILIST_MAX_VARIABLES_BYTES = 500000;
const OPENLIBRARY_MAX_ENRICH_EDITION_LOOKUPS = 4;
const OPENLIBRARY_MAX_AUTHOR_LOOKUPS = 6;
const REQUEST_MAX_BODY = 20 * 1024 * 1024;
const REQUEST_MAX_URI = 12 * 1024;
const RATE_READ_PER_MINUTE = 600;
const RATE_WRITE_PER_MINUTE = 180;
const requestRate = new Map();

// v0.61 Provider Reliability & Operations instrumentation.
reliability.bindPersistence((snapshot) => {
  try {
    const data = store.read();
    data.reliability = snapshot;
    store.write(data, { withReliability: false });
  } catch (_) {}
});

function instrumentProvider(module, provider, methods) {
  for (const method of methods) {
    if (typeof module[method] !== 'function' || module[method].__omniReliabilityWrapped) continue;
    const original = module[method];
    const wrapped = reliability.wrap(provider, method, original);
    wrapped.__omniReliabilityWrapped = true;
    module[method] = wrapped;
  }
}

instrumentProvider(anilist, 'AniList', ['graph', 'tokenFromCode', 'introspect']);
instrumentProvider(openLibrary, 'Open Library', ['search', 'getWork', 'getWorkEditions', 'getEdition', 'getAuthor', 'getISBN']);
instrumentProvider(tmdb, 'TMDB', ['search', 'discover', 'getDetails', 'getCollection', 'getPerson', 'getSeason', 'getEpisode', 'getWatchProviders']);
instrumentProvider(igdb, 'IGDB', ['search', 'discover', 'getGame', 'getCompany', 'getPlatform', 'getCollection', 'getFranchise', 'searchCompanies', 'searchPlatforms', 'searchCollections', 'searchFranchises']);

function securityHeaders(res, requestId) {
  res.setHeader('X-Request-Id', requestId || crypto.randomUUID());
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data: https:; media-src 'self' https:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self' https:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");
}
function send(res, code, body, type='application/json; charset=utf-8') {
  securityHeaders(res, res.__omniRequestId);
  res.setHeader('Content-Type', type); res.setHeader('Cache-Control', 'no-store');
  res.statusCode=code; res.end(type.startsWith('application/json') ? JSON.stringify(body, null, 2) : body);
}
function rejectDangerousKeys(value, depth=0) {
  if(depth>50) throw new Error('JSON nesting limit exceeded');
  if(Array.isArray(value)){for(const x of value)rejectDangerousKeys(x,depth+1);return value;}
  if(value&&typeof value==='object')for(const key of Object.keys(value)){if(key==='__proto__'||key==='prototype'||key==='constructor')throw new Error('Unsupported JSON object key');rejectDangerousKeys(value[key],depth+1);}
  return value;
}
function parseBody(req, maxBytes=2e6) { return new Promise((resolve,reject)=>{ let s=''; let done=false; const fail=e=>{if(done)return;done=true;reject(e);try{req.destroy()}catch(_){}}; const declared=Number(req.headers['content-length']||0); if(declared>maxBytes)return fail(new Error('Payload too large')); req.on('data',c=>{if(done)return;s+=c;if(Buffer.byteLength(s,'utf8')>maxBytes)fail(new Error('Payload too large'));}); req.on('end',()=>{if(done)return;try{const parsed=s?JSON.parse(s):{};rejectDangerousKeys(parsed);done=true;resolve(parsed);}catch(e){fail(e.message==='Unsupported JSON object key'||e.message==='JSON nesting limit exceeded'?e:new Error('Invalid JSON'));}}); req.on('error',fail); }); }
function sendRaw(res, code, body, type, headers={}) {
  securityHeaders(res, res.__omniRequestId); res.setHeader('Content-Type', type); res.setHeader('Cache-Control','no-store');
  for(const [k,v] of Object.entries(headers))res.setHeader(k,v); res.statusCode=code; res.end(body);
}
function clientAddress(req){return String(req.socket?.remoteAddress||'unknown').replace(/^::ffff:/,'');}
function allowRequest(req){const isWrite=!['GET','HEAD','OPTIONS'].includes(req.method),limit=isWrite?RATE_WRITE_PER_MINUTE:RATE_READ_PER_MINUTE,key=`${clientAddress(req)}:${isWrite?'w':'r'}`,nowMs=Date.now();let b=requestRate.get(key);if(!b||nowMs-b.startedAt>=60000){b={startedAt:nowMs,count:0};requestRate.set(key,b);}b.count++;return b.count<=limit;}
function logRequest(req,res,startMs){try{production.logRequest({requestId:res.__omniRequestId,method:req.method,path:String(req.url||'').split('?')[0],status:res.statusCode,durationMs:Date.now()-startMs,ip:clientAddress(req)});}catch(_){} }
function sendStaticFile(req,res,file){
  const body=fs.readFileSync(file); const stat=fs.statSync(file); const etag='"'+crypto.createHash('sha256').update(body).digest('hex').slice(0,24)+'"';
  securityHeaders(res,res.__omniRequestId); res.setHeader('ETag',etag); res.setHeader('Last-Modified',stat.mtime.toUTCString()); res.setHeader('Cache-Control','public, max-age=300, must-revalidate');
  if(req.headers['if-none-match']===etag){res.statusCode=304;return res.end();}
  res.setHeader('Content-Type',MIME[path.extname(file)]||'application/octet-stream'); res.statusCode=200; res.end(body);
}
function csvCell(value){
  const s=String(value??'');
  return /[\",\n\r]/.test(s) ? '"'+s.replace(/"/g,'""')+'"' : s;
}
function exportCatalogCsv(items){
  const headers=['id','title','type','year','status','provider','providerId','description','creators','tags','aliases','externalLinks','coverUrl','createdAt','updatedAt'];
  return [headers.join(','), ...items.map(x=>headers.map(h=>{
    const v=['creators','tags','aliases','externalLinks'].includes(h)?(x[h]||[]).join(' | '):(x[h]??'');
    return csvCell(v);
  }).join(','))].join('\n')+'\n';
}
function parseCsv(text){
  const rows=[]; let row=[]; let cell=''; let quoted=false;
  for(let i=0;i<text.length;i++){
    const ch=text[i];
    if(quoted){
      if(ch==='"' && text[i+1]==='"'){cell+='"';i++;}
      else if(ch==='"') quoted=false;
      else cell+=ch;
    } else if(ch==='"') quoted=true;
    else if(ch===','){row.push(cell);cell='';}
    else if(ch==='\n'){row.push(cell.replace(/\r$/,''));rows.push(row);row=[];cell='';}
    else cell+=ch;
  }
  if(cell.length||row.length){row.push(cell.replace(/\r$/,''));rows.push(row);}
  if(!rows.length)return [];
  const headers=rows.shift().map(x=>String(x).trim());
  return rows.filter(r=>r.some(x=>String(x).trim()!=='')).map(r=>Object.fromEntries(headers.map((h,i)=>[h,r[i]??''])));
}
function splitPortable(value){return String(value??'').split(' | ').map(x=>x.trim()).filter(Boolean);}
function normalizeImportedItem(raw){
  const item={};
  item.title=String(raw.title||'').trim();
  item.type=String(raw.type||'').trim();
  item.year=cleanYear(raw.year);
  item.status=['active','archived'].includes(String(raw.status||''))?String(raw.status):'active';
  item.provider=String(raw.provider||'Manual').trim()||'Manual';
  item.providerId=String(raw.providerId||'').trim()||null;
  item.description=String(raw.description||'');
  item.creators=Array.isArray(raw.creators)?cleanStringArray(raw.creators):splitPortable(raw.creators);
  item.tags=Array.isArray(raw.tags)?cleanStringArray(raw.tags):splitPortable(raw.tags);
  item.aliases=Array.isArray(raw.aliases)?cleanStringArray(raw.aliases):splitPortable(raw.aliases);
  item.externalLinks=Array.isArray(raw.externalLinks)?cleanStringArray(raw.externalLinks):splitPortable(raw.externalLinks);
  item.coverUrl=String(raw.coverUrl||'').trim()||null;
  item.mediaAssets = raw.mediaAssets && typeof raw.mediaAssets==='object' ? raw.mediaAssets : null;
  item.providerMetadata = raw.providerMetadata && typeof raw.providerMetadata==='object' ? raw.providerMetadata : null;
  item.raw = raw.raw && typeof raw.raw==='object' ? raw.raw : undefined;
  if(item.raw===undefined) delete item.raw;
  return item;
}
function normalizeRestoredCatalogItem(raw){
  if(!raw || typeof raw!=='object') throw new Error('Catalog item must be an object');
  const base=normalizeImportedItem(raw);
  const out={...raw,...base};
  out.id=String(raw.id||base.id||crypto.randomUUID());
  out.relations=Array.isArray(raw.relations)?raw.relations.map(r=>({catalogId:String(r.catalogId||''),type:String(r.type||'Related'),label:r.label?String(r.label):undefined})).filter(r=>r.catalogId):[];
  out.createdAt=raw.createdAt||store.now();
  out.updatedAt=raw.updatedAt||store.now();
  out.providerMetadata=raw.providerMetadata&&typeof raw.providerMetadata==='object'?raw.providerMetadata:null;
  out.mediaAssets=raw.mediaAssets&&typeof raw.mediaAssets==='object'?raw.mediaAssets:null;
  out.raw=raw.raw&&typeof raw.raw==='object'?raw.raw:raw.raw??undefined;
  if(raw.raw===undefined) delete out.raw;
  return out;
}
function duplicateImportReason(item,catalog){
  if(item.providerId && catalog.some(x=>x.provider===item.provider && x.providerId===item.providerId)) return 'provider identity';
  const key=(x)=>`${String(x.title||'').trim().toLowerCase()}|${String(x.type||'').trim().toLowerCase()}|${String(x.year||'')}`;
  const k=key(item); if(!item.title||!item.type)return null;
  if(catalog.some(x=>key(x)===k)) return 'title/type/year';
  return null;
}
function parseImportContent(format,content){
  if(format==='csv'){return parseCsv(String(content||''));}
  if(format==='json'){
    const raw=JSON.parse(String(content||''));
    if(Array.isArray(raw)) return raw;
    if(raw && Array.isArray(raw.catalog)) return raw.catalog;
    throw new Error('JSON must contain a catalog array or be an array of catalog items');
  }
  throw new Error('format must be json or csv');
}
function validateBackup(raw){
  if(!raw || raw.format!=='omnishelf-backup') throw new Error('Not a valid OmniShelf backup file');
  if(!Array.isArray(raw.catalog)||!Array.isArray(raw.collections)||!Array.isArray(raw.smartCollections)) throw new Error('Backup is missing required workspace data');
  const ids=new Set(); for(const x of raw.catalog){if(!x.id||!String(x.title||'').trim()||!String(x.type||'').trim())throw new Error('Backup contains an invalid catalog item');if(ids.has(x.id))throw new Error('Backup contains duplicate catalog IDs');ids.add(x.id);}
  const integrity=governance.verifyBackup(raw);
  if(integrity.present && !integrity.valid) throw Object.assign(new Error('Backup integrity hash does not match its payload.'),{status:422,integrity});
  return raw;
}

function libraryCollectionRows(data,rules){ return library.list(data,{sort:'updatedAt',order:'desc'}).filter(row=>libraryCollections.matches(row,rules)); }

function baseProviderStatus(provider) { if(provider==='Open Library') return openLibrary.status(); if(provider==='TMDB') return tmdb.status(); if(provider==='IGDB') return igdb.status(); const envMap={'AniList':'ANILIST_CLIENT_ID'}; return {provider,configured:Boolean(process.env[envMap[provider]]||process.env.ANILIST_ACCESS_TOKEN),demoAvailable:true,...(provider==='AniList'?{oauthConfigured:anilist.oauthConfigured(),authenticated:Boolean(process.env.ANILIST_ACCESS_TOKEN)}:{})}; }
function providerStatus(provider) { return reliability.providerStatus(provider, baseProviderStatus(provider)); }
function catalogMatchesQuery(item, q) { if (!q) return true; const hay=[item.title,item.description,...(item.creators||[]),...(item.aliases||[]),...(item.tags||[])].join(' ').toLowerCase(); return hay.includes(q.toLowerCase()); }
function catalogView(item) { return {...item, matches: undefined}; }
function cleanStringArray(value) { return Array.isArray(value) ? value.map(x => String(x).trim()).filter(Boolean) : []; }
function cleanYear(value) { if (value === null || value === '' || value === undefined) return null; const n=Number(value); return Number.isInteger(n) && n>=0 ? n : null; }
function relationExists(data, fromId, toId, type) { return data.catalog.some(x => x.id===fromId && (x.relations||[]).some(r => r.catalogId===toId && r.type===type)); }
function normalizeCollection(c) {
  c.name=String(c.name||'').trim().slice(0,COLLECTION_NAME_LIMIT);
  c.description=String(c.description||'');
  c.items=Array.isArray(c.items)?c.items.filter(Boolean):[];
  return c;
}
function collectionView(collection, data) {
  const items=(collection.items||[]).map(id=>data.catalog.find(x=>x.id===id)).filter(Boolean);
  return {...collection,items:items.map(catalogView),itemCount:items.length};
}
function sortCatalog(items, field, dir) {
  const direction=dir==='desc'?-1:1;
  return [...items].sort((a,b)=>{
    const av=a[field] ?? ''; const bv=b[field] ?? '';
    if(field==='year') return ((Number(av)||0)-(Number(bv)||0))*direction;
    return String(av).localeCompare(String(bv),undefined,{numeric:true,sensitivity:'base'})*direction;
  });
}
function catalogFilters(url) {
  return {
    q:(url.searchParams.get('q')||'').trim(),
    type:(url.searchParams.get('type')||'').trim(),
    provider:(url.searchParams.get('provider')||'').trim(),
    year:(url.searchParams.get('year')||'').trim(),
    status:(url.searchParams.get('status')||'').trim(),
    tag:(url.searchParams.get('tag')||'').trim(),
    collectionId:(url.searchParams.get('collectionId')||'').trim(),
    smartCollectionId:(url.searchParams.get('smartCollectionId')||'').trim()
  };
}
function matchesCatalogRule(item, rule) {
  const checks=[];
  if(rule.q) checks.push(catalogMatchesQuery(item, rule.q));
  if(rule.type) checks.push(item.type===rule.type);
  if(rule.provider) checks.push(item.provider===rule.provider);
  if(rule.year) checks.push(String(item.year||'')===String(rule.year));
  if(rule.status) checks.push(item.status===rule.status);
  if(rule.tag) checks.push((item.tags||[]).some(t=>t.toLowerCase()===String(rule.tag).toLowerCase()));
  if(!checks.length) return true;
  return rule.mode==='any' ? checks.some(Boolean) : checks.every(Boolean);
}
function sanitizeSmartRule(raw) {
  const out={};
  for(const key of SMART_RULE_KEYS) if(raw && raw[key]!==undefined) out[key]=String(raw[key]??'').trim();
  out.mode = raw && raw.mode==='any' ? 'any' : 'all';
  return out;
}
function smartCollectionView(sc,data) {
  const rules=sanitizeSmartRule(sc.rules||{});
  const items=data.catalog.filter(x=>matchesCatalogRule(x,rules));
  return {...sc,rules,itemCount:items.length,preview:items.slice(0,12).map(catalogView)};
}
function filterCatalog(d, filters) {
  const collection = filters.collectionId ? d.collections.find(x=>x.id===filters.collectionId) : null;
  const collectionIds = collection ? new Set(collection.items||[]) : null;
  const smart = filters.smartCollectionId ? d.smartCollections.find(x=>x.id===filters.smartCollectionId) : null;
  const smartRule = smart ? sanitizeSmartRule(smart.rules||{}) : null;
  return d.catalog.filter(x=>catalogMatchesQuery(x,filters.q)
    && (!filters.type||x.type===filters.type)
    && (!filters.provider||x.provider===filters.provider)
    && (!filters.year||String(x.year||'')===filters.year)
    && (!filters.status||x.status===filters.status)
    && (!filters.tag||((x.tags||[]).some(t=>t.toLowerCase()===filters.tag.toLowerCase())))
    && (!collectionIds||collectionIds.has(x.id))
    && (!smartRule||matchesCatalogRule(x,smartRule)));
}
function catalogFacets(items) {
  const countBy=(fn)=>Object.entries(items.reduce((m,x)=>{const k=fn(x)||'Unknown';m[k]=(m[k]||0)+1;return m;},{})).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));
  const tags={}; for(const x of items) for(const t of (x.tags||[])) tags[t]=(tags[t]||0)+1;
  return {types:countBy(x=>x.type),providers:countBy(x=>x.provider||'Manual'),statuses:countBy(x=>x.status||'active'),tags:Object.entries(tags).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]))};
}

function intParam(params,name){ const raw=params.get(name); if(raw===null||raw==='') return undefined; const n=Number(raw); return Number.isFinite(n)?Math.trunc(n):undefined; }
function boolParam(params,name){ const raw=params.get(name); if(raw===null) return undefined; if(raw==='true'||raw==='1') return true; if(raw==='false'||raw==='0') return false; return undefined; }
function listParam(params,name){ const v=params.getAll(name).map(x=>String(x).trim()).filter(Boolean); return v.length?v:undefined; }
function aniMediaVars(url, defaults={}){
  const p=url.searchParams;
  const v={...defaults};
  const ints=['page','id','idMal','seasonYear','episodes','duration','chapters','volumes','licensedById','averageScore','popularity','minimumTagRank','id_not','idMal_not','startDate_greater','startDate_lesser','endDate_greater','endDate_lesser','episodes_greater','episodes_lesser','duration_greater','duration_lesser','chapters_greater','chapters_lesser','volumes_greater','volumes_lesser','licensedById_in'];
  for(const k of ints){const n=intParam(p,k);if(n!==undefined)v[k]=n;}
  const bools=['isAdult','onList','isLicensed']; for(const k of bools){const b=boolParam(p,k);if(b!==undefined)v[k]=b;}
  const strings=['type','format','status','season','countryOfOrigin','source','genre','tag','tagCategory','licensedBy','search','startDate_like','endDate_like','format_not','status_not'];
  for(const k of strings){const x=p.get(k);if(x!==null&&x!=='')v[k]=x;}
  const lists=['sort','format_in','format_not_in','status_in','status_not_in','genre_in','genre_not_in','tag_in','tag_not_in','tagCategory_in','tagCategory_not_in','licensedBy_in','source_in','countryOfOrigin_in','countryOfOrigin_not_in','id_in','id_not_in','idMal_in','idMal_not_in'];
  for(const k of lists){const x=listParam(p,k);if(x!==undefined)v[k]=(k==='id_in'||k==='id_not_in'||k==='idMal_in'||k==='idMal_not_in'||k==='licensedById_in')?x.map(Number):x;}
  return v;
}
function aniUserVars(url){const p=url.searchParams;return {id:intParam(p,'id'),name:p.get('name')||null,isModerator:boolParam(p,'isModerator'),search:p.get('search')||null,sort:listParam(p,'sort')||null,page:Number(p.get('page')||1)}}
function aniIdList(p,k){const v=listParam(p,k);return v===undefined?undefined:v.map(Number);}
function aniError(res,e){ const code=e.status===401?401:e.status===429?429:e.status===504?504:e.status===451?451:502; return send(res,code,{error:e.message,rateLimit:e.rateLimit||null,graphqlErrors:e.graphQLErrors||null}); }

const ANILIST_SYNC_FIELDS=['status','format','score','progress','progressVolumes','repeat','priority','private','notes','hiddenFromStatusLists','customLists','advancedScores','startedAt','completedAt'];
function normalizeSyncState(entry){
  if(!entry) return null;
  const out={};
  for(const k of ANILIST_SYNC_FIELDS){ out[k]=entry[k]??null; }
  out.id=entry.id??null; out.mediaId=entry.mediaId??null; out.updatedAt=entry.updatedAt??null; out.createdAt=entry.createdAt??null;
  return out;
}
function stableState(x){ return JSON.stringify(normalizeSyncState(x)); }

const SYNC_EDITABLE_FIELDS=['status','score','scoreRaw','progress','progressVolumes','repeat','priority','private','notes','hiddenFromStatusLists','customLists','advancedScores','startedAt','completedAt'];
const ANILIST_LIST_STATUSES=new Set(['CURRENT','PLANNING','COMPLETED','DROPPED','PAUSED','REPEATING']);
function cleanSyncPatch(raw){
  const out={};
  if(!raw || typeof raw!=='object') return out;
  for(const k of SYNC_EDITABLE_FIELDS){
    if(raw[k]===undefined) continue;
    if(['score','scoreRaw','progress','progressVolumes','repeat','priority'].includes(k)){
      if(raw[k]===null||raw[k]===''){out[k]=null;continue;}
      const n=Number(raw[k]); if(!Number.isFinite(n)) throw new Error(`${k} must be numeric or null`);
      if(k==='score' || k==='scoreRaw'){if(n<0||n>100) throw new Error(`${k} must be between 0 and 100`); if(k==='scoreRaw'&&Math.trunc(n)!==n) throw new Error('scoreRaw must be an integer');}
      if(['progress','progressVolumes'].includes(k)&&(!Number.isInteger(n)||n<0)) throw new Error(`${k} must be a non-negative integer`);
      if(k==='repeat'&&(!Number.isInteger(n)||n<0||n>1000)) throw new Error('repeat must be an integer between 0 and 1000');
      if(k==='priority'&&(!Number.isInteger(n)||n<0||n>255)) throw new Error('priority must be an integer between 0 and 255');
      out[k]=n;
    } else if(k==='status'){const v=String(raw[k]||'').toUpperCase();if(!ANILIST_LIST_STATUSES.has(v)) throw new Error(`Invalid AniList list status: ${v}`);out[k]=v;}
    else if(['private','hiddenFromStatusLists'].includes(k)) out[k]=Boolean(raw[k]);
    else if(k==='customLists'){if(!Array.isArray(raw[k])) throw new Error('customLists must be an array'); out[k]=raw[k].map(String).map(x=>x.trim()).filter(Boolean);}
    else if(k==='advancedScores'){if(raw[k]===null){out[k]=null;continue;} if(!Array.isArray(raw[k])) throw new Error('advancedScores must be an array or null'); out[k]=raw[k].map(Number); if(out[k].some(x=>!Number.isFinite(x))) throw new Error('advancedScores must contain numbers');}
    else if(k==='startedAt'||k==='completedAt'){if(raw[k]!==null && typeof raw[k]!=='object') throw new Error(`${k} must be an object or null`); out[k]=raw[k];}
    else out[k]=String(raw[k]??'');
  }
  return out;
}
function mergedSyncState(base,override){return normalizeSyncState({...normalizeSyncState(base||{}),...(override||{})});}
function getSyncMeta(item){const pm=item?.providerMetadata&&typeof item.providerMetadata==='object'?item.providerMetadata:{};const sync=pm.anilistSync&&typeof pm.anilistSync==='object'?pm.anilistSync:{};return {pm,sync};}
function ensureBaseSnapshot(item){const {pm,sync}=getSyncMeta(item);if(!sync.lastSyncedState && pm.mediaListEntry){sync.lastSyncedState=normalizeSyncState(pm.mediaListEntry); item.providerMetadata={...pm,anilistSync:sync};}return sync;}
function recordAniListTombstone(d,item){if(!item||item.provider!=='AniList'||!item.providerId)return null;d.anilistSyncTombstones=Array.isArray(d.anilistSyncTombstones)?d.anilistSyncTombstones:[];const sync=ensureBaseSnapshot(item);const t={id:crypto.randomUUID(),providerId:String(item.providerId),type:String(item.providerMetadata?.type||'ANIME').toUpperCase(),title:item.title||'Untitled',deletedAt:store.now(),baseState:normalizeSyncState(sync.lastSyncedState||item.providerMetadata?.mediaListEntry||null),providerMetadata:item.providerMetadata||{}};d.anilistSyncTombstones=d.anilistSyncTombstones.filter(x=>!(String(x.providerId)===String(t.providerId)&&String(x.type)===t.type));d.anilistSyncTombstones.unshift(t);return t;}
function remoteEntriesFromDemo(type){
  const d=anilist.demoList(type); return (d.data?.MediaListCollection?.lists||[]).flatMap(l=>l.entries||[]).map(e=>({...e,listName:e.listName||null}));
}
function syncCursorKey(type,userId,userName){return `${String(type||'ANIME').toUpperCase()}:${userId?String(userId):'name:'+String(userName||'viewer').trim().toLowerCase()}`;}
function getSyncCursor(d,type,userId,userName){d.anilistSyncCursors=d.anilistSyncCursors&&typeof d.anilistSyncCursors==='object'?d.anilistSyncCursors:{};return d.anilistSyncCursors[syncCursorKey(type,userId,userName)]||null;}
function upsertSyncRun(d,run){d.anilistSyncRuns=Array.isArray(d.anilistSyncRuns)?d.anilistSyncRuns:[];d.anilistSyncRuns=d.anilistSyncRuns.filter(x=>x.id!==run.id);d.anilistSyncRuns.unshift(run);d.anilistSyncRuns=d.anilistSyncRuns.slice(0,200);return run;}
function findSyncRun(d,id){return (Array.isArray(d.anilistSyncRuns)?d.anilistSyncRuns:[]).find(x=>x.id===String(id));}
function summarizeSyncRows(rows){const keys=['in-sync','remote-changed','local-changed','conflict','unsynced','remote-only','local-missing-entry','local-deleted'];return Object.fromEntries(keys.map(k=>[k,rows.filter(r=>r.state===k).length]));}
async function fetchAniListListEntriesIncremental({type,userId,userName,limit=250,demo=false,watermark=null}){
  if(demo){const entries=remoteEntriesFromDemo(type);return {entries:entries.slice(0,limit),rateLimit:null,mode:'demo',pagesFetched:1,stoppedByWatermark:false,complete:true,newestUpdatedAt:Math.max(...entries.map(e=>Number(e.updatedAt)||0),0)||null,oldestUpdatedAt:Math.min(...entries.map(e=>Number(e.updatedAt)||0).filter(Boolean),0)||null};}
  const entries=[]; let page=1; let rateLimit=null; let stoppedByWatermark=false; let maxUpdatedAt=0; let minUpdatedAt=null; let lastHasNextPage=false;
  const maxPages=Math.ceil(Math.min(250,Math.max(1,Number(limit||250)))/50);
  const wm=Number(watermark||0);
  while(page<=maxPages && entries.length<limit){
    const r=await anilist.graph(anilist.LIST_PAGE_QUERY,{page,userId,userName,type,status:null,id:null,mediaId:null,isFollowing:null,notes:null,startedAt:null,completedAt:null,compareWithAuthList:null,userId_in:null,status_in:null,status_not:null,status_not_in:null,mediaId_in:null,mediaId_not_in:null,notes_like:null,startedAt_greater:null,startedAt_lesser:null,startedAt_like:null,completedAt_greater:null,completedAt_lesser:null,completedAt_like:null,sort:['UPDATED_TIME_DESC']});
    rateLimit=r.rateLimit; const pageInfo=r.data?.Page?.pageInfo||{}; lastHasNextPage=!!pageInfo.hasNextPage; const batch=r.data?.Page?.mediaList||[]; if(!batch.length)break;
    for(const e of batch){
      const ts=Number(e.updatedAt||0); if(ts>maxUpdatedAt)maxUpdatedAt=ts; if(ts && (minUpdatedAt===null||ts<minUpdatedAt))minUpdatedAt=ts;
      // Keep a one-second overlap so entries sharing a timestamp with the prior cursor are never skipped.
      if(wm && ts && ts < (wm-1)){stoppedByWatermark=true; break;}
      entries.push(e); if(entries.length>=limit)break;
    }
    if(stoppedByWatermark || !r.data?.Page?.pageInfo?.hasNextPage)break;
    page++;
  }
  const complete=stoppedByWatermark || !lastHasNextPage; return {entries:entries.slice(0,limit),rateLimit,mode:'live',pagesFetched:page,stoppedByWatermark,complete,newestUpdatedAt:maxUpdatedAt||null,oldestUpdatedAt:minUpdatedAt};
}
function buildIncrementalSyncRun({d,type,userId,userName,limit,mode,fetched,rows,cursorBefore,idempotencyKey}){
  const run={id:crypto.randomUUID(),idempotencyKey:idempotencyKey||null,type,userId:userId||null,userName:userName||null,limit,mode,status:'previewed',startedAt:store.now(),completedAt:store.now(),cursorBefore:cursorBefore||null,cursorCandidate:fetched.complete?(fetched.newestUpdatedAt||cursorBefore?.updatedAt||null):null,complete:!!fetched.complete,pagesFetched:fetched.pagesFetched||0,fetchedEntries:fetched.entries.length,stoppedByWatermark:!!fetched.stoppedByWatermark,newestUpdatedAt:fetched.newestUpdatedAt||null,oldestUpdatedAt:fetched.oldestUpdatedAt||null,summary:summarizeSyncRows(rows),eventLog:[{at:store.now(),event:'previewed',rows:rows.length,mode}],cursorKey:syncCursorKey(type,userId,userName)};
  if(idempotencyKey){const existing=(d.anilistSyncRuns||[]).find(x=>x.idempotencyKey===idempotencyKey&&x.type===type&&x.cursorKey===run.cursorKey);if(existing)return {run:existing,replayed:true};}
  upsertSyncRun(d,run);return {run,replayed:false};
}

async function fetchAniListListEntries({type,userId,userName,limit=250,demo=false}){
  if(demo) return {entries:remoteEntriesFromDemo(type),rateLimit:null,mode:'demo'};
  const entries=[]; let page=1; let rateLimit=null;
  const maxPages=Math.ceil(limit/50);
  while(page<=maxPages && entries.length<limit){
    const r=await anilist.graph(anilist.LIST_PAGE_QUERY,{page,userId,userName,type,status:null,id:null,mediaId:null,isFollowing:null,notes:null,startedAt:null,completedAt:null,compareWithAuthList:null,userId_in:null,status_in:null,status_not:null,status_not_in:null,mediaId_in:null,mediaId_not_in:null,notes_like:null,startedAt_greater:null,startedAt_lesser:null,startedAt_like:null,completedAt_greater:null,completedAt_lesser:null,completedAt_like:null,sort:['UPDATED_TIME_DESC']});
    rateLimit=r.rateLimit; const batch=r.data?.Page?.mediaList||[]; entries.push(...batch);
    if(!r.data?.Page?.pageInfo?.hasNextPage || !batch.length) break;
    page++;
  }
  return {entries:entries.slice(0,limit),rateLimit,mode:'live'};
}
async function resolveSyncUserId(userId,userName){
  if(userId) return Number(userId);
  if(userName){ const r=await anilist.graph(anilist.USER_PROFILE_QUERY,{id:null,name:userName}); return r.data?.User?.id||null; }
  const a=await anilist.authStatus(); return a.authenticated?a.viewer?.id:null;
}
function buildAniSyncPlan(catalog, entries, type, tombstones=[]){
  const remoteByMedia=new Map(entries.filter(e=>e?.mediaId).map(e=>[Number(e.mediaId),e]));
  const localByMedia=new Map(catalog.filter(x=>x.provider==='AniList' && String(x.providerMetadata?.type||'').toUpperCase()===type && Number.isFinite(Number(x.providerId))).map(x=>[Number(x.providerId),x]));
  const tombByMedia=new Map((Array.isArray(tombstones)?tombstones:[]).filter(x=>String(x.type||'').toUpperCase()===type&&x.providerId).map(x=>[Number(x.providerId),x]));
  const rows=[]; const allIds=new Set([...localByMedia.keys(),...remoteByMedia.keys(),...tombByMedia.keys()]);
  for(const mediaId of allIds){
    const local=localByMedia.get(mediaId)||null, remote=remoteByMedia.get(mediaId)||null, tomb=tombByMedia.get(mediaId)||null;
    const sync=local?ensureBaseSnapshot(local):{}; const base=sync.lastSyncedState||tomb?.baseState||null; const localOverride=sync.localOverride||null;
    const localState=localOverride?mergedSyncState(base||local?.providerMetadata?.mediaListEntry,localOverride):(base||local?.providerMetadata?.mediaListEntry||null);
    let state='in-sync', resolutions=[];
    if(tomb && !local && remote){state='local-deleted'; resolutions=['restore-local','delete-remote','keep-remote'];}
    else if(local && !remote){state='local-missing-entry'; resolutions=['recreate-remote','delete-local'];}
    else if(!local && remote){state='remote-only'; resolutions=['queue-review'];}
    else if(local && remote){
      if(!base && !localOverride) state='unsynced';
      else {
        const remoteChanged=!!base && stableState(remote)!==stableState(base); const localChanged=!!localOverride && stableState(localState)!==stableState(base);
        if(remoteChanged && localChanged && stableState(localState)!==stableState(remote)) state='conflict';
        else if(remoteChanged) state='remote-changed';
        else if(localChanged) state='local-changed';
      }
      resolutions=state==='conflict'?['local','remote']:state==='remote-changed'?['remote','local']:state==='local-changed'?['local','remote']:['local'];
    }
    rows.push({state,resolutions,catalogId:local?.id||null,tombstoneId:tomb?.id||null,mediaId,title:remote?.media?.title?.userPreferred||remote?.media?.title?.english||remote?.media?.title?.romaji||local?.title||tomb?.title||'Untitled',providerType:type,remote:normalizeSyncState(remote),base:normalizeSyncState(base),local:normalizeSyncState(localState),localOverride:localOverride||null,tombstone:tomb||null,catalog:local?{id:local.id,title:local.title,type:local.type,year:local.year}:null});
  }
  const order={'conflict':0,'local-changed':1,'remote-changed':2,'unsynced':3,'local-deleted':4,'remote-only':5,'local-missing-entry':6,'in-sync':7};
  rows.sort((a,b)=>(order[a.state]-order[b.state])||a.title.localeCompare(b.title)); return rows;
}


function openLibraryEntityState(data){
  data.openLibrary = data.openLibrary && typeof data.openLibrary === 'object' ? data.openLibrary : {};
  data.openLibrary.authors = data.openLibrary.authors && typeof data.openLibrary.authors === 'object' ? data.openLibrary.authors : {};
  data.openLibrary.subjects = data.openLibrary.subjects && typeof data.openLibrary.subjects === 'object' ? data.openLibrary.subjects : {};
  data.openLibrary.workEdition = data.openLibrary.workEdition && typeof data.openLibrary.workEdition === 'object' ? data.openLibrary.workEdition : {};
  data.openLibrary.enrichmentJournal = Array.isArray(data.openLibrary.enrichmentJournal) ? data.openLibrary.enrichmentJournal : [];
  data.openLibrary.reviewDiagnostics = Array.isArray(data.openLibrary.reviewDiagnostics) ? data.openLibrary.reviewDiagnostics : [];
  return data.openLibrary;
}
function tmdbEntityState(data){
  data.tmdb = data.tmdb && typeof data.tmdb === 'object' ? data.tmdb : {};
  data.tmdb.people = data.tmdb.people && typeof data.tmdb.people === 'object' ? data.tmdb.people : {};
  data.tmdb.companies = data.tmdb.companies && typeof data.tmdb.companies === 'object' ? data.tmdb.companies : {};
  data.tmdb.networks = data.tmdb.networks && typeof data.tmdb.networks === 'object' ? data.tmdb.networks : {};
  data.tmdb.collections = data.tmdb.collections && typeof data.tmdb.collections === 'object' ? data.tmdb.collections : {};
  data.tmdb.enrichmentJournal = Array.isArray(data.tmdb.enrichmentJournal) ? data.tmdb.enrichmentJournal : [];
  data.tmdb.reviewDiagnostics = Array.isArray(data.tmdb.reviewDiagnostics) ? data.tmdb.reviewDiagnostics : [];
  return data.tmdb;
}
function persistTMDBEntities(data, bundle, source){
  const tm=tmdbEntityState(data), now=store.now();
  for(const [id,e] of Object.entries(bundle?.entities?.people||{})){ const old=tm.people[id]||{}; tm.people[id]={...old,...e,workIds:mergeUnique(old.workIds,[bundle.normalized.providerId],100),updatedAt:now}; }
  for(const [id,e] of Object.entries(bundle?.entities?.companies||{})){ const old=tm.companies[id]||{}; tm.companies[id]={...old,...e,workIds:mergeUnique(old.workIds,[bundle.normalized.providerId],100),updatedAt:now}; }
  for(const [id,e] of Object.entries(bundle?.entities?.networks||{})){ const old=tm.networks[id]||{}; tm.networks[id]={...old,...e,workIds:mergeUnique(old.workIds,[bundle.normalized.providerId],100),updatedAt:now}; }
  for(const [id,e] of Object.entries(bundle?.entities?.collections||{})){ const old=tm.collections[id]||{}; tm.collections[id]={...old,...e,workIds:mergeUnique(old.workIds,[bundle.normalized.providerId],100),updatedAt:now}; }
  tm.enrichmentJournal.unshift({id:crypto.randomUUID(),at:now,source,providerId:bundle.normalized.providerId,title:bundle.normalized.title,people:Object.keys(bundle.entities?.people||{}).length,companies:Object.keys(bundle.entities?.companies||{}).length,networks:Object.keys(bundle.entities?.networks||{}).length,collections:Object.keys(bundle.entities?.collections||{}).length});
  tm.enrichmentJournal=tm.enrichmentJournal.slice(0,200);
}
async function buildTMDBEnrichmentBundle(providerId,type='movie',demo=false,language=null,region=null){
  if(demo){ const raw=type==='tv'?tmdb.demoTV(providerId).item:tmdb.demoMovie(providerId).item; const normalized=tmdb.normalize(type,raw); return {raw,normalized,entities:tmdb.entityBundle(normalized)}; }
  const detail=await tmdb.getDetails(type,providerId,{language,region});
  return {raw:detail.item,normalized:detail.normalized,entities:tmdb.entityBundle(detail.normalized),cached:detail.cached};
}
function igdbEntityState(data){
  data.igdb = data.igdb && typeof data.igdb === 'object' ? data.igdb : {};
  data.igdb.companies = data.igdb.companies && typeof data.igdb.companies === 'object' ? data.igdb.companies : {};
  data.igdb.platforms = data.igdb.platforms && typeof data.igdb.platforms === 'object' ? data.igdb.platforms : {};
  data.igdb.collections = data.igdb.collections && typeof data.igdb.collections === 'object' ? data.igdb.collections : {};
  data.igdb.franchises = data.igdb.franchises && typeof data.igdb.franchises === 'object' ? data.igdb.franchises : {};
  data.igdb.enrichmentJournal = Array.isArray(data.igdb.enrichmentJournal) ? data.igdb.enrichmentJournal : [];
  data.igdb.reviewDiagnostics = Array.isArray(data.igdb.reviewDiagnostics) ? data.igdb.reviewDiagnostics : [];
  return data.igdb;
}
function persistIGDBEntities(data,bundle,source){
  const ig=igdbEntityState(data), now=store.now(), entityKeys=['companies','platforms','collections','franchises'];
  for(const key of entityKeys){ for(const [id,e] of Object.entries(bundle?.entities?.[key]||{})){ const old=ig[key][id]||{}; ig[key][id]={...old,...e,workIds:mergeUnique(old.workIds,[bundle.normalized.providerId],100),updatedAt:now}; } }
  ig.enrichmentJournal.unshift({id:crypto.randomUUID(),at:now,source,providerId:bundle.normalized.providerId,title:bundle.normalized.title,companies:Object.keys(bundle.entities?.companies||{}).length,platforms:Object.keys(bundle.entities?.platforms||{}).length,collections:Object.keys(bundle.entities?.collections||{}).length,franchises:Object.keys(bundle.entities?.franchises||{}).length});
  ig.enrichmentJournal=ig.enrichmentJournal.slice(0,200);
}
async function buildIGDBEnrichmentBundle(providerId,demo=false){
  if(demo){ const raw=igdb.demoGame(providerId); const normalized=igdb.normalize(raw); return {raw,normalized,entities:igdb.entityBundle(normalized)}; }
  const detail=await igdb.getGame(providerId);
  return {raw:detail.item,normalized:detail.normalized,entities:igdb.entityBundle(detail.normalized),cached:detail.cached};
}
function applyIGDBEnrichment(existing,bundle){
  const normalized=bundle.normalized;
  return igdb.applyEnrichment(existing,normalized);
}
function mergeUnique(a,b,limit=80){ return [...new Set([...(Array.isArray(a)?a:[]),...(Array.isArray(b)?b:[])])].filter(Boolean).slice(0,limit); }
function textValue(v){ if(v==null)return ''; if(typeof v==='string')return v; return String(v.value||v.text||''); }
async function buildOpenLibraryEnrichmentBundle(providerId,demo=false){
  const id=String(providerId||'').trim();
  if(!id) throw Object.assign(new Error('Open Library provider ID is required.'),{status:400});
  let work=null, editionRaws=[], authorRaws=[];
  if(demo){
    if(id.endsWith('A')){ const a=openLibrary.demoAuthor(id); authorRaws=[a.item]; }
    else if(id.endsWith('M')){ const e=openLibrary.demoEdition(id); editionRaws=[e.item]; const refs=e.item.works||[]; const wid=refs[0]?.key||'OLDEMO1W'; work=openLibrary.demoWork(String(wid).replace(/^\//,'').replace(/^works\//,'')).item; }
    else { work=openLibrary.demoWork(id).item; }
  } else {
    if(id.endsWith('A')) { const a=await openLibrary.getAuthor(id); authorRaws=[a.item]; }
    else if(id.endsWith('M')) { const e=await openLibrary.getEdition(id); editionRaws=[e.item]; const wid=Array.isArray(e.item?.works)?e.item.works.map(x=>String(x?.key||x).replace(/^\//,'')).find(x=>/^(?:works\/)?OL\d+W$/.test(x)):null; if(wid) { const w=await openLibrary.getWork(wid.replace(/^works\//,'')); work=w.item; } }
    else { const w=await openLibrary.getWork(id); work=w.item; }
  }
  if(work){
    if(!editionRaws.length){
      if(demo){editionRaws=openLibrary.demoWorkEditions(String(work.key||id).replace(/^\//,'').replace(/^works\//,'')).entries;}
      else { const er=await openLibrary.getWorkEditions(String(work.key||id).replace(/^\//,''),{limit:OPENLIBRARY_MAX_ENRICH_EDITION_LOOKUPS}); editionRaws=(er.entries||[]).slice(0,OPENLIBRARY_MAX_ENRICH_EDITION_LOOKUPS); }
    }
    const refs=openLibraryQuality.authorKeyFrom; const authorIds=[];
    for(const a of (Array.isArray(work.author_key)?work.author_key:[])){ const x=refs(a); if(x&&!authorIds.includes(x))authorIds.push(x); }
    for(const a of (Array.isArray(work.authors)?work.authors:[])){ const x=refs(a?.author?.key||a?.key); if(x&&!authorIds.includes(x))authorIds.push(x); }
    for(const aid of authorIds.slice(0,OPENLIBRARY_MAX_AUTHOR_LOOKUPS)){
      try{ const ar=demo?openLibrary.demoAuthor(aid).item:(await openLibrary.getAuthor(aid)).item; authorRaws.push(ar); }catch{}
    }
  }
  if(!work) work={key:null,title:authorRaws[0]?.name||id};
  const registry=openLibraryQuality.buildEntityRegistryPayload(work,authorRaws,editionRaws);
  const quality=openLibraryQuality.qualityReport(work,work.type?.key?.includes('edition')?'edition':'work');
  return {work,editionRaws,authorRaws,registry,quality};
}
function persistOpenLibraryRegistry(data,registry,source){
  const ol=openLibraryEntityState(data); const now=store.now();
  for(const a of registry.authors||[]){ if(!a.providerId)continue; const old=ol.authors[a.providerId]||{}; ol.authors[a.providerId]={...old,...a,works:mergeUnique(old.works,[registry.workId],100),updatedAt:now}; }
  for(const s of registry.subjects||[]){ const old=ol.subjects[s.id]||{}; ol.subjects[s.id]={...old,...s,workIds:mergeUnique(old.workIds,[registry.workId],200),updatedAt:now}; }
  if(registry.workId){ const old=ol.workEdition[registry.workId]||{workId:registry.workId,editionIds:[]}; ol.workEdition[registry.workId]={...old,editionIds:mergeUnique(old.editionIds,(registry.workEdition?.editions||[]).map(x=>x.editionId),200),editions:registry.workEdition?.editions||old.editions||[],updatedAt:now,source}; }
  ol.enrichmentJournal.unshift({id:crypto.randomUUID(),at:now,source,...(registry.workId?{workId:registry.workId}:{}),authorCount:(registry.authors||[]).length,subjectCount:(registry.subjects||[]).length,editionCount:registry.workEdition?.count||0});
  ol.enrichmentJournal=ol.enrichmentJournal.slice(0,200);
}
function applyOpenLibraryEnrichment(existing,bundle){
  const work=bundle.work||{}; const reg=bundle.registry||{};
  const aliases=mergeUnique(existing.aliases,[work.subtitle,...(Array.isArray(work.title_alt_versions)?work.title_alt_versions:[])],30);
  const creators=mergeUnique(existing.creators,(reg.authors||[]).map(x=>x.name),30);
  const tags=mergeUnique(existing.tags,(reg.subjects||[]).map(x=>x.label),60);
  const desc=existing.description || textValue(work.description) || '';
  const year=existing.year || work.first_publish_year || null;
  const pm=existing.providerMetadata&&typeof existing.providerMetadata==='object'?existing.providerMetadata:{};
  const nextPm={...pm,openLibraryId:existing.providerId||pm.openLibraryId,workId:reg.workId||pm.workId||null,authorKeys:(reg.authors||[]).map(x=>x.providerId),authorNames:(reg.authors||[]).map(x=>x.name).filter(Boolean),normalizedSubjects:reg.subjects||[],subjectCategories:reg.subjectCategories||[],editionIds:(reg.workEdition?.editions||[]).map(x=>x.editionId),editionRecords:(reg.workEdition?.editions||[]),provenance:{source:'Open Library',retrievedAt:store.now(),enrichment:'v0.56'}};
  const nextAssets=existing.mediaAssets||openLibrary.normalize(work).mediaAssets||null;
  return {...existing,aliases,creators,tags,description:desc,year,coverUrl:existing.coverUrl||openLibrary.normalize(work).coverUrl||null,providerMetadata:nextPm,mediaAssets:nextAssets,raw:{...(existing.raw&&typeof existing.raw==='object'?existing.raw:{}),openLibraryWorkEnrichment:work,openLibraryEditionSnapshots:bundle.editionRaws||[],openLibraryAuthorSnapshots:bundle.authorRaws||[]},updatedAt:store.now()};
}

async function router(req,res) {
  const startMs=Date.now();
  res.__omniRequestId=crypto.randomUUID();
  securityHeaders(res,res.__omniRequestId);
  res.once('finish',()=>logRequest(req,res,startMs));
  if(!allowRequest(req))return send(res,429,{error:'Rate limit exceeded',retryAfterSeconds:60,requestId:res.__omniRequestId});
  if(String(req.url||'').length>REQUEST_MAX_URI)return send(res,414,{error:'Request URI too large',requestId:res.__omniRequestId});
  const contentLength=Number(req.headers['content-length']||0); if(contentLength>REQUEST_MAX_BODY)return send(res,413,{error:'Payload too large',requestId:res.__omniRequestId});
  const url = new URL(req.url, `http://${req.headers.host||'localhost'}`);
  try {

    if(req.method==='GET' && url.pathname==='/api/anilist/sync/tombstones') { const d=store.read(); return send(res,200,{items:Array.isArray(d.anilistSyncTombstones)?d.anilistSyncTombstones:[],count:Array.isArray(d.anilistSyncTombstones)?d.anilistSyncTombstones.length:0}); }
    if(req.method==='GET' && url.pathname==='/api/anilist/sync/runs') {
      const d=store.read(); const limit=Math.min(100,Math.max(1,intParam(url.searchParams,'limit')||25));
      const items=(d.anilistSyncRuns||[]).slice(0,limit); return send(res,200,{items,count:items.length,total:d.anilistSyncRuns?.length||0});
    }
    const syncRunMatch=url.pathname.match(/^\/api\/anilist\/sync\/runs\/([^/]+)$/);
    if(req.method==='GET' && syncRunMatch){const d=store.read(),run=findSyncRun(d,syncRunMatch[1]);if(!run)return send(res,404,{error:'Sync run not found'});return send(res,200,{run});}
    if(req.method==='GET' && url.pathname==='/api/anilist/sync/cursor'){
      const d=store.read(),type=(url.searchParams.get('type')||'ANIME').toUpperCase(),userId=url.searchParams.get('userId')?Number(url.searchParams.get('userId')):null,userName=url.searchParams.get('userName')||null;
      if(!['ANIME','MANGA'].includes(type))return send(res,400,{error:'type must be ANIME or MANGA'}); return send(res,200,{key:syncCursorKey(type,userId,userName),cursor:getSyncCursor(d,type,userId,userName)});
    }
    if(req.method==='POST' && url.pathname==='/api/anilist/sync/incremental-preview'){
      const b=await parseBody(req); const type=String(b.type||'ANIME').toUpperCase(); if(!['ANIME','MANGA'].includes(type))return send(res,400,{error:'type must be ANIME or MANGA'});
      const limit=Math.min(250,Math.max(1,Number(b.limit||100))); const demo=b.demo===true; let userId=b.userId?Number(b.userId):null; const userName=b.userName?String(b.userName):null;
      if(demo){
        const d=store.read(),fetched=await fetchAniListListEntriesIncremental({type,limit,demo:true}),local=d.catalog.filter(x=>x.provider==='AniList'&&String(x.providerMetadata?.type||'').toUpperCase()===type),rows=buildAniSyncPlan(local,fetched.entries,type,d.anilistSyncTombstones||[]);const made=buildIncrementalSyncRun({d,type,userId:101,userName:'OmniShelfDemo',limit,mode:'demo',fetched,rows,cursorBefore:1700000000,idempotencyKey:b.idempotencyKey||null}); return send(res,200,{...made.run,mode:'demo',dryRun:true,rows,summary:summarizeSyncRows(rows),cursorKey:syncCursorKey(type,101,'OmniShelfDemo')});
      }
      if(!userId&&!userName)userId=await resolveSyncUserId(null,null); if(!userId&&!userName)return send(res,401,{error:'Connect AniList or provide userId/userName'});
      try{
        const d=store.read(),cursor=getSyncCursor(d,type,userId,userName),fetched=await fetchAniListListEntriesIncremental({type,userId,userName,limit,demo:false,watermark:cursor?.updatedAt||null});
        const local=d.catalog.filter(x=>x.provider==='AniList'&&String(x.providerMetadata?.type||'').toUpperCase()===type),rows=buildAniSyncPlan(local,fetched.entries,type,d.anilistSyncTombstones||[]);
        const made=buildIncrementalSyncRun({d,type,userId,userName,limit,mode:cursor?'incremental':'initial',fetched,rows,cursorBefore:cursor,idempotencyKey:b.idempotencyKey||null});
        if(!made.replayed)store.write(d); return send(res,200,{...made.run,mode:made.run.mode,rows,summary:summarizeSyncRows(rows),note:made.run.cursorCandidate?(fetched.stoppedByWatermark?'Stopped after reaching the previous updatedAt watermark. A periodic full reconciliation remains necessary to detect remote deletions.':'Scan completed to the end of the available result set.'):'Scan is partial because the limit was reached before the watermark/end. Increase the limit before committing the watermark.',complete:!!fetched.complete});
      }catch(e){return aniError(res,e);}
    }
    // v0.77 Universal Import / Export & Migration — portable user/workspace data.
    if(req.method==='GET' && url.pathname==='/api/data/portable/export') {
      const d=store.read(); const scope=url.searchParams.get('scope')==='workspace'?'workspace':'personal'; const format=(url.searchParams.get('format')||'json').toLowerCase();
      if(format==='csv') {
        const csv=portable.toLibraryCsv(d);
        return sendRaw(res,200,csv,'text/csv; charset=utf-8',{'Content-Disposition':`attachment; filename="omnishelf-library-v${VERSION}.csv"`});
      }
      if(format!=='json') return send(res,400,{error:'format must be json or csv'});
      const pkg=portable.exportPortable(d,scope,VERSION);
      return sendRaw(res,200,JSON.stringify(pkg,null,2)+'\n','application/json; charset=utf-8',{'Content-Disposition':`attachment; filename="omnishelf-${scope}-portable-v${VERSION}.json"`});
    }
    if(req.method==='POST' && url.pathname==='/api/data/portable/import/preview') {
      const b=await parseBody(req,20e6); const raw=b.package&&typeof b.package==='object'?b.package:JSON.parse(String(b.content||'')); const d=store.read();
      const result=portable.planImport(d,raw,{personalStatePolicy:b.personalStatePolicy||'keep-existing'});
      return send(res,200,result);
    }
    if(req.method==='POST' && url.pathname==='/api/data/portable/import/apply') {
      const b=await parseBody(req,20e6); const raw=b.package&&typeof b.package==='object'?b.package:JSON.parse(String(b.content||'')); const d=store.read();
      const result=portable.applyImport(d,raw,{personalStatePolicy:b.personalStatePolicy||'keep-existing'});
      store.addAudit(d,'data.portable.import',{kind:raw.kind||null,exportId:raw.exportId||null,createdCatalog:result.createdCatalog.length,libraryNew:result.library.filter(x=>x.mode==='new').length,libraryOverwritten:result.library.filter(x=>x.mode==='overwritten'||x.mode==='newer').length,historyAdded:result.historyAdded,collectionsAdded:result.collectionsAdded,community:result.community});
      store.write(d);
      return send(res,200,{version:VERSION,applied:true,...result,summary:{createdCatalog:result.createdCatalog.length,libraryNew:result.library.filter(x=>x.mode==='new').length,libraryOverwritten:result.library.filter(x=>x.mode==='overwritten'||x.mode==='newer').length,libraryKept:result.library.filter(x=>x.mode==='kept').length,historyAdded:result.historyAdded,collectionsAdded:result.collectionsAdded,community:result.community}});
    }
    if(req.method==='POST' && url.pathname==='/api/data/portable/selftest') {
      try{return send(res,200,{version:VERSION,mode:'deterministic',...portable.selfTest()});}catch(e){return send(res,500,{version:VERSION,passed:false,error:e.message});}
    }

    if(req.method==='GET' && url.pathname==='/api/data/export') {
      const d=store.read(); const format=(url.searchParams.get('format')||'json').toLowerCase(); const scope=(url.searchParams.get('scope')||'backup').toLowerCase();
      if(!['json','csv'].includes(format)) return send(res,400,{error:'format must be json or csv'});
      if(format==='csv'){
        const csv=exportCatalogCsv(d.catalog);
        return sendRaw(res,200,csv,'text/csv; charset=utf-8',{'Content-Disposition':'attachment; filename="omnishelf-catalog.csv"'});
      }
      if(scope==='catalog') return sendRaw(res,200,JSON.stringify({format:'omnishelf-catalog',version:VERSION,exportedAt:store.now(),catalog:d.catalog},null,2)+'\n','application/json; charset=utf-8',{'Content-Disposition':'attachment; filename="omnishelf-catalog.json"'});
      let backup={format:'omnishelf-backup',version:VERSION,exportedAt:store.now(),catalog:d.catalog,collections:d.collections,smartCollections:d.smartCollections,reviewQueue:d.reviewQueue,auditLog:d.auditLog,anilistSyncTombstones:Array.isArray(d.anilistSyncTombstones)?d.anilistSyncTombstones:[],anilistSyncRuns:Array.isArray(d.anilistSyncRuns)?d.anilistSyncRuns:[],anilistSyncCursors:d.anilistSyncCursors&&typeof d.anilistSyncCursors==='object'?d.anilistSyncCursors:{},openLibrary:openLibraryEntityState(d),tmdb:tmdbEntityState(d),igdb:igdbEntityState(d),identity:identity.state(d),enrichment:d.enrichment&&typeof d.enrichment==='object'?d.enrichment:{version:1,runs:[]},reliability:reliability.snapshot({includeEvents:true}),governance:governance.ensure(d),library:library.ensureState(d),community:community.ensureState(d)}; backup=governance.attachBackupIntegrity(backup);
      return sendRaw(res,200,JSON.stringify(backup,null,2)+'\n','application/json; charset=utf-8',{'Content-Disposition':`attachment; filename="omnishelf-backup-v${VERSION}.json"`});
    }
    if(req.method==='POST' && url.pathname==='/api/data/import/preview') {
      const b=await parseBody(req),d=store.read(),rows=parseImportContent(String(b.format||'json'),b.content);
      const prepared=rows.map(normalizeImportedItem); const invalid=[],duplicates=[],ready=[];
      prepared.forEach((item,index)=>{if(!item.title||!item.type){invalid.push({index,error:'title and type are required',item});return}const reason=duplicateImportReason(item,d.catalog);if(reason){duplicates.push({index,reason,item});return}ready.push({index,item});});
      return send(res,200,{format:b.format,total:prepared.length,ready:ready.length,invalid,duplicates,preview:ready.slice(0,20).map(x=>x.item)});
    }
    if(req.method==='POST' && url.pathname==='/api/data/import/apply') {
      const b=await parseBody(req),d=store.read(),rows=parseImportContent(String(b.format||'json'),b.content),added=[],skipped=[],invalid=[];
      for(const raw of rows){const item=normalizeImportedItem(raw);if(!item.title||!item.type){invalid.push({title:item.title,error:'title and type are required'});continue}const reason=duplicateImportReason(item,d.catalog);if(reason){skipped.push({title:item.title,reason});continue}const full={...item,id:crypto.randomUUID(),relations:[],createdAt:store.now(),updatedAt:store.now()}; full.governance={version:1,fieldProvenance:governance.attributionForItem(full),providerRetrievedAt:full.providerMetadata?.provenance?.retrievedAt||full.providerMetadata?.retrievedAt||null}; d.catalog.unshift(full); governance.recordFieldChanges(d,{...full,governance:null},full,{action:'data.import.apply',reason:'import-create'}); added.push(full);}
      if(added.length) store.addAudit(d,'data.import.apply',{count:added.length,skipped:skipped.length,invalid:invalid.length});
      store.write(d); return send(res,200,{imported:added.length,skipped,invalid,items:added.map(catalogView)});
    }
    if(req.method==='POST' && url.pathname==='/api/data/restore/preview') {
      const b=await parseBody(req),raw=JSON.parse(String(b.content||'')); validateBackup(raw);
      return send(res,200,{version:raw.version||null,exportedAt:raw.exportedAt||null,catalog:raw.catalog.length,collections:raw.collections.length,smartCollections:raw.smartCollections.length,reviewQueue:raw.reviewQueue?.length||0,auditLog:raw.auditLog?.length||0,anilistSyncTombstones:raw.anilistSyncTombstones?.length||0,anilistSyncRuns:raw.anilistSyncRuns?.length||0,anilistSyncCursors:Object.keys(raw.anilistSyncCursors||{}).length,openLibrary:{authors:Object.keys(raw.openLibrary?.authors||{}).length,subjects:Object.keys(raw.openLibrary?.subjects||{}).length,works:Object.keys(raw.openLibrary?.workEdition||{}).length},tmdb:{people:Object.keys(raw.tmdb?.people||{}).length,companies:Object.keys(raw.tmdb?.companies||{}).length,networks:Object.keys(raw.tmdb?.networks||{}).length,collections:Object.keys(raw.tmdb?.collections||{}).length},igdb:{companies:Object.keys(raw.igdb?.companies||{}).length,platforms:Object.keys(raw.igdb?.platforms||{}).length,collections:Object.keys(raw.igdb?.collections||{}).length,franchises:Object.keys(raw.igdb?.franchises||{}).length},identity:{groups:Array.isArray(raw.identity?.groups)?raw.identity.groups.length:0,decisions:Array.isArray(raw.identity?.decisions)?raw.identity.decisions.length:0,runs:Array.isArray(raw.identity?.runs)?raw.identity.runs.length:0,candidates:Array.isArray(raw.identity?.candidates)?raw.identity.candidates.length:0},enrichment:{runs:Array.isArray(raw.enrichment?.runs)?raw.enrichment.runs.length:0,enrichedRecords:Array.isArray(raw.catalog)?raw.catalog.filter(x=>x?.enrichment?.identityGroupId).length:0},reliability:{events:Array.isArray(raw.reliability?.events)?raw.reliability.events.length:0,incidents:Array.isArray(raw.reliability?.incidents)?raw.reliability.incidents.length:0},governance:{fieldHistory:Array.isArray(raw.governance?.fieldHistory)?raw.governance.fieldHistory.length:0,deletionTombstones:Array.isArray(raw.governance?.deletionTombstones)?raw.governance.deletionTombstones.length:0,validationRuns:Array.isArray(raw.governance?.validationRuns)?raw.governance.validationRuns.length:0,backupRuns:Array.isArray(raw.governance?.backupRuns)?raw.governance.backupRuns.length:0},library:{items:raw.library?.items&&typeof raw.library.items==='object'?Object.keys(raw.library.items).length:0,historyEvents:Array.isArray(raw.library?.history?.events)?raw.library.history.events.length:0},community:{members:Object.keys(raw.community?.members||{}).length,follows:Array.isArray(raw.community?.follows)?raw.community.follows.length:0,reviews:Array.isArray(raw.community?.reviews)?raw.community.reviews.length:0,activities:Array.isArray(raw.community?.activities)?raw.community.activities.length:0},integrity:governance.verifyBackup(raw)});
    }
    if(req.method==='POST' && url.pathname==='/api/data/restore/apply') {
      const b=await parseBody(req);if(b.confirm!=='RESTORE OMNISHELF')return send(res,400,{error:'Type RESTORE OMNISHELF to confirm a full workspace restore'});
      const raw=JSON.parse(String(b.content||''));validateBackup(raw);const existing=store.read();const backup={catalog:raw.catalog,collections:raw.collections,smartCollections:raw.smartCollections,reviewQueue:Array.isArray(raw.reviewQueue)?raw.reviewQueue:[],auditLog:Array.isArray(raw.auditLog)?raw.auditLog:[],anilistSyncTombstones:Array.isArray(raw.anilistSyncTombstones)?raw.anilistSyncTombstones:[],anilistSyncRuns:Array.isArray(raw.anilistSyncRuns)?raw.anilistSyncRuns:[],anilistSyncCursors:raw.anilistSyncCursors&&typeof raw.anilistSyncCursors==='object'?raw.anilistSyncCursors:{},openLibrary:raw.openLibrary&&typeof raw.openLibrary==='object'?raw.openLibrary:{authors:{},subjects:{},workEdition:{},enrichmentJournal:[],reviewDiagnostics:[]},tmdb:raw.tmdb&&typeof raw.tmdb==='object'?raw.tmdb:{people:{},companies:{},networks:{},collections:{},enrichmentJournal:[],reviewDiagnostics:[]},igdb:raw.igdb&&typeof raw.igdb==='object'?raw.igdb:{companies:{},platforms:{},collections:{},franchises:{},enrichmentJournal:[],reviewDiagnostics:[]},identity:raw.identity&&typeof raw.identity==='object'?raw.identity:{version:1,groups:[],decisions:[],runs:[],candidates:[]},enrichment:raw.enrichment&&typeof raw.enrichment==='object'?raw.enrichment:{version:1,runs:[]},reliability:raw.reliability&&typeof raw.reliability==='object'?raw.reliability:reliability.snapshot({includeEvents:true}),governance:raw.governance&&typeof raw.governance==='object'?raw.governance:{},library:raw.library&&typeof raw.library==='object'?raw.library:{version:1,profile:{name:'You'},items:{},smartCollections:[],history:{version:1,events:[]}},community:raw.community&&typeof raw.community==='object'?raw.community:community.ensureState({}).community};
      const sourceIds=new Set(backup.catalog.map(x=>x.id));
      backup.collections=backup.collections.map(c=>({...c,items:(c.items||[]).filter(id=>sourceIds.has(id))}));
      if(backup.library&&typeof backup.library==='object'){backup.library.version=1;backup.library.profile=backup.library.profile&&typeof backup.library.profile==='object'?backup.library.profile:{name:'You'};backup.library.items=backup.library.items&&typeof backup.library.items==='object'?Object.fromEntries(Object.entries(backup.library.items).filter(([id])=>sourceIds.has(id))):{};backup.library.history=backup.library.history&&typeof backup.library.history==='object'?backup.library.history:{version:1,events:[]};backup.library.history.version=1;backup.library.history.events=Array.isArray(backup.library.history.events)?backup.library.history.events:[];backup.library.smartCollections=Array.isArray(backup.library.smartCollections)?backup.library.smartCollections:[];libraryCollections.ensureState(backup);
      community.sanitizeState(backup);}
      backup.catalog=backup.catalog.map(x=>({...normalizeRestoredCatalogItem(x),id:String(x.id),relations:(x.relations||[]).filter(r=>sourceIds.has(r.catalogId)),createdAt:x.createdAt||store.now(),updatedAt:x.updatedAt||store.now()}));
      identity.reconcileStoredState(backup);
      reliability.restore(backup.reliability);
      governance.ensure(backup);
      store.addAudit(existing,'data.restore.apply',{replacedCatalog:backup.catalog.length,replacedCollections:backup.collections.length,replacedSmartCollections:backup.smartCollections.length,restoredAniListTombstones:backup.anilistSyncTombstones.length,restoredReliabilityEvents:Array.isArray(backup.reliability?.events)?backup.reliability.events.length:0,restoredGovernanceFieldHistory:Array.isArray(backup.governance?.fieldHistory)?backup.governance.fieldHistory.length:0});
      backup.auditLog=existing.auditLog;
      store.write(backup); return send(res,200,{restored:true,catalog:backup.catalog.length,collections:backup.collections.length,smartCollections:backup.smartCollections.length,anilistSyncTombstones:backup.anilistSyncTombstones.length,openLibrary:{authors:Object.keys(backup.openLibrary?.authors||{}).length,subjects:Object.keys(backup.openLibrary?.subjects||{}).length,works:Object.keys(backup.openLibrary?.workEdition||{}).length},tmdb:{people:Object.keys(backup.tmdb?.people||{}).length,companies:Object.keys(backup.tmdb?.companies||{}).length,networks:Object.keys(backup.tmdb?.networks||{}).length,collections:Object.keys(backup.tmdb?.collections||{}).length},igdb:{companies:Object.keys(backup.igdb?.companies||{}).length,platforms:Object.keys(backup.igdb?.platforms||{}).length,collections:Object.keys(backup.igdb?.collections||{}).length,franchises:Object.keys(backup.igdb?.franchises||{}).length},identity:{groups:Array.isArray(backup.identity?.groups)?backup.identity.groups.length:0,decisions:Array.isArray(backup.identity?.decisions)?backup.identity.decisions.length:0,runs:Array.isArray(backup.identity?.runs)?backup.identity.runs.length:0,candidates:Array.isArray(backup.identity?.candidates)?backup.identity.candidates.length:0},enrichment:{runs:Array.isArray(backup.enrichment?.runs)?backup.enrichment.runs.length:0},reliability:{events:Array.isArray(backup.reliability?.events)?backup.reliability.events.length:0,incidents:Array.isArray(backup.reliability?.incidents)?backup.reliability.incidents.length:0},governance:{fieldHistory:Array.isArray(backup.governance?.fieldHistory)?backup.governance.fieldHistory.length:0,deletionTombstones:Array.isArray(backup.governance?.deletionTombstones)?backup.governance.deletionTombstones.length:0,validationRuns:Array.isArray(backup.governance?.validationRuns)?backup.governance.validationRuns.length:0},library:{items:Object.keys(backup.library?.items||{}).length,historyEvents:Array.isArray(backup.library?.history?.events)?backup.library.history.events.length:0},community:{members:Object.keys(backup.community?.members||{}).length,follows:Array.isArray(backup.community?.follows)?backup.community.follows.length:0,reviews:Array.isArray(backup.community?.reviews)?backup.community.reviews.length:0,activities:Array.isArray(backup.community?.activities)?backup.community.activities.length:0}});
    }

    if(req.method==='GET' && url.pathname==='/api/anilist/integrity/audit') {
      const demo=url.searchParams.get('demo')==='1';
      if(!demo) return send(res,400,{error:'Pass demo=1; live integrity uses the same local round-trip assertions and never calls AniList.'});
      try {
        const d=store.read();
        const fixture={id:'integrity-demo',provider:'AniList',providerId:'8001',title:'Demo Chronicle 1',type:'Anime',year:2020,status:'active',creators:['Demo Staff (Director)'],tags:['Action'],aliases:['Demo Chronicle'],externalLinks:['https://anilist.co/anime/8001'],coverUrl:'/demo/anilist/cover.svg',mediaAssets:{cover:{extraLarge:'/demo/anilist/cover.svg',large:'/demo/anilist/cover.svg',medium:'/demo/anilist/cover.svg',color:'#243b53',primary:'/demo/anilist/cover.svg',fallback:'/demo/anilist/cover.svg',availableSizes:['extraLarge','large','medium']},banner:'/demo/anilist/banner.svg',trailer:{id:'demo-8001',site:'Demo',thumbnail:'/demo/anilist/trailer.svg',available:true},streamingEpisodes:[{index:1,title:'Episode 1',thumbnail:'/demo/anilist/stream1.svg',url:'https://example.com/anilist-demo/episode-1',site:'Demo Stream'}],externalLinks:[{id:1,url:'https://anilist.co/anime/8001',site:'AniList',siteId:1,type:'INFO',language:'English',icon:'/demo/anilist/icon.svg',notes:'Demo',isDisabled:false}],siteUrl:'https://anilist.co/anime/8001',summary:{hasCover:true,hasBanner:true,hasTrailer:true,streamingEpisodeCount:1,externalLinkCount:1,legalStreamingCount:1}},providerMetadata:{id:8001,type:'ANIME',format:'TV',status:'FINISHED',mediaAssets:{marker:'preserved'}},raw:{id:8001,title:{userPreferred:'Demo Chronicle 1'}} ,relations:[],createdAt:1700000000,updatedAt:1700000000};
        const before=JSON.stringify(fixture);
        const restored=normalizeRestoredCatalogItem(fixture);
        const checks={providerMetadataPreserved:restored.providerMetadata?.id===8001 || restored.providerMetadata?.type==='ANIME',rawPreserved:restored.raw?.id===8001,mediaAssetsPreserved:restored.mediaAssets?.cover?.primary==='/demo/anilist/cover.svg',relationsPreserved:Array.isArray(restored.relations),identityPreserved:restored.id==='integrity-demo'};
        const backupPayload={format:'omnishelf-backup',version:VERSION,exportedAt:store.now(),catalog:[fixture],collections:[],smartCollections:[],reviewQueue:[],auditLog:[],anilistSyncTombstones:[],anilistSyncRuns:[],anilistSyncCursors:{}};
        const round=normalizeRestoredCatalogItem(backupPayload.catalog[0]);
        checks.backupRoundTrip=round.providerMetadata?.id===8001 && round.mediaAssets?.cover?.primary==='/demo/anilist/cover.svg' && round.raw?.id===8001;
        checks.listFormatPreserved=true;
        checks.syncDataIncluded=Array.isArray(backupPayload.anilistSyncTombstones)&&Array.isArray(backupPayload.anilistSyncRuns)&&typeof backupPayload.anilistSyncCursors==='object';
        const passed=Object.values(checks).every(Boolean);
        return send(res,200,{version:VERSION,mode:'demo',passed,checks,backupFields:['catalog','collections','smartCollections','reviewQueue','auditLog','anilistSyncTombstones','anilistSyncRuns','anilistSyncCursors'],notes:['This audit is local and datastore-neutral.','It verifies that rich AniList fields survive the same restoration normalization used by full workspace restore.','Live AniList network access is not required.'],fixtureHash:crypto.createHash('sha256').update(before).digest('hex')});
      } catch(e) { return send(res,500,{error:e.message}); }
    }


    if(req.method==='POST' && url.pathname==='/api/anilist/catalog/enrich/preview') {
      const b=await parseBody(req); const d=store.read();
      const catalogId=b.catalogId ? String(b.catalogId) : null;
      const providerId=b.providerId ? String(b.providerId) : null;
      const type=String(b.type||'ANIME').toUpperCase(); const demo=b.demo===true;
      const local=d.catalog.find(x=>x.provider==='AniList' && ((catalogId && x.id===catalogId) || (!catalogId && providerId && String(x.providerId)===providerId && String(x.providerMetadata?.type||'ANIME').toUpperCase()===type)));
      if(!local) return send(res,404,{error:'AniList catalog item not found'});
      try {
        let media;
        if(demo){ const w=anilist.demoMediaWorkspace(Number(local.providerId)||8001,type); media={...w.media,relations:{edges:(w.relations||[]).map(r=>({relationType:r.relationType,node:r.node}))},characters:{pageInfo:{currentPage:1,lastPage:1,hasNextPage:false,total:(w.characters||[]).length},edges:(w.characters||[]).map(x=>({node:x}))},staff:{pageInfo:{currentPage:1,lastPage:1,hasNextPage:false,total:(w.staff||[]).length},edges:(w.staff||[]).map(x=>({node:x}))},studios:{pageInfo:{currentPage:1,lastPage:1,hasNextPage:false,total:(w.studios||[]).length},edges:(w.studios||[]).map(x=>({isMain:x.isMain,node:x}))},recommendations:{pageInfo:{currentPage:1,lastPage:1,hasNextPage:false,total:(w.recommendations||[]).length},nodes:w.recommendations||[]},reviews:{pageInfo:{currentPage:1,lastPage:1,hasNextPage:false,total:(w.reviews||[]).length},nodes:w.reviews||[]},stats:w.stats||null}; }
        else { anilist.assertLiveAccess(); const r=await anilist.graph(anilist.MEDIA_DETAIL_QUERY,{id:Number(local.providerId),type,characterPage:1,staffPage:1,studioPage:1,airingPage:1,trendPage:1,recommendationPage:1,reviewPage:1},{cache:false,allowRetry:true}); media=r.data?.Media||null; if(!media) return send(res,404,{error:'AniList media was not found',rateLimit:r.rateLimit}); }
        return send(res,200,{mode:demo?'demo':'live',catalog:{id:local.id,title:local.title,type:local.type,providerId:local.providerId,updatedAt:local.updatedAt},preview:enrichmentPreview(local,media),media,rateLimit:demo?null:undefined});
      } catch(e){ return aniError(res,e); }
    }

    if(req.method==='POST' && url.pathname==='/api/anilist/catalog/enrich/apply') {
      const b=await parseBody(req); const d=store.read(); const catalogId=String(b.catalogId||''); const expectedUpdatedAt=b.expectedUpdatedAt||null; const demo=b.demo===true; const local=d.catalog.find(x=>x.id===catalogId && x.provider==='AniList');
      if(!local) return send(res,404,{error:'AniList catalog item not found'});
      if(expectedUpdatedAt && local.updatedAt!==expectedUpdatedAt) return send(res,409,{error:'Catalog item changed since preview; refresh enrichment preview before applying.',currentUpdatedAt:local.updatedAt});
      try {
        let media;
        let rateLimit=null;
        if(demo){ media=anilist.demoMediaWorkspace(Number(local.providerId)||8001,String(local.providerMetadata?.type||'ANIME').toUpperCase()).media; }
        else { anilist.assertLiveAccess(); const r=await anilist.graph(anilist.MEDIA_DETAIL_QUERY,{id:Number(local.providerId),type:String(local.providerMetadata?.type||'ANIME').toUpperCase(),characterPage:1,staffPage:1,studioPage:1,airingPage:1,trendPage:1,recommendationPage:1,reviewPage:1},{cache:false,allowRetry:true}); media=r.data?.Media||null; rateLimit=r.rateLimit; if(!media) return send(res,404,{error:'AniList media was not found',rateLimit}); }
        const merged=mergeAniListEnrichment(local,media); const before=JSON.parse(JSON.stringify(local)); const changedFields=enrichmentPreview(local,media).changedFields; const changes={}; for(const field of changedFields) if(merged[field]!==undefined) changes[field]=merged[field]; const guarded=governance.applyGuard(d,local,changes,{source:{catalogId:local.id,provider:'AniList',providerId:local.providerId},provider:'AniList'}); if(!guarded.allowed)return send(res,409,{error:'Governance policy blocked this AniList enrichment.',field:guarded.field,reason:guarded.reason,decisions:guarded.decisions}); merged.governance={...(local.governance||{}),version:1,fieldProvenance:{...(local.governance?.fieldProvenance||{})}}; for(const field of changedFields) merged.governance.fieldProvenance[field]={catalogId:local.id,provider:'AniList',providerId:local.providerId,field,sourceType:'provider',reason:'AniList enrichment',updatedAt:store.now()}; merged.governance.providerRetrievedAt=store.now(); d.catalog=d.catalog.map(x=>x.id===local.id?merged:x); governance.recordFieldChanges(d,before,merged,{action:'anilist.catalog.enrich',reason:'provider-enrichment'}); store.addAudit(d,'anilist.catalog.enrich',{catalogId:local.id,providerId:local.providerId,mode:demo?'demo':'live',changedFields,governanceChecked:true}); store.write(d);
        return send(res,200,{mode:demo?'demo':'live',catalogItem:merged,mediaId:media.id,enrichedAt:merged.providerMetadata?.anilistDetail?.enrichedAt||merged.updatedAt,rateLimit});
      } catch(e){ return aniError(res,e); }
    }

    if (req.method==='GET' && url.pathname==='/api/health') { const d=store.read(); return send(res,200,{ok:true,version:VERSION,service:'OmniShelf',providers:PROVIDERS.map(providerStatus),reliability:{updatedAt:reliability.snapshot({includeEvents:false}).updatedAt,readiness:reliability.readiness(PROVIDERS.map(baseProviderStatus))},hardening:production.runtimeStatus(d)}); }
    if (req.method==='GET' && url.pathname==='/api/providers/status') return send(res,200,{version:VERSION,providers:PROVIDERS.map(providerStatus)});

    // v0.61 Provider Reliability & Operations
    if(req.method==='GET' && url.pathname==='/api/providers/reliability') {
      const d=store.read(), base=PROVIDERS.map(baseProviderStatus), snap=reliability.snapshot({includeEvents:true});
      return send(res,200,{version:VERSION,updatedAt:snap.updatedAt,providers:reliability.getSummary(base),readiness:reliability.readiness(base),events:snap.events.slice(0,40),incidents:snap.incidents.slice(0,20),staleness:reliability.scanStaleness(d.catalog)});
    }
    if(req.method==='GET' && url.pathname==='/api/providers/reliability/events') {
      const provider=url.searchParams.get('provider')||null; const limit=Math.min(300,Math.max(1,intParam(url.searchParams,'limit')||100));
      return send(res,200,{version:VERSION,items:reliability.getEvents({provider,limit}),count:reliability.getEvents({provider,limit}).length});
    }
    if(req.method==='GET' && url.pathname==='/api/providers/reliability/incidents') {
      const provider=url.searchParams.get('provider')||null; const limit=Math.min(100,Math.max(1,intParam(url.searchParams,'limit')||50));
      return send(res,200,{version:VERSION,items:reliability.getIncidents({provider,limit})});
    }
    if(req.method==='GET' && url.pathname==='/api/providers/staleness') {
      const d=store.read(); const provider=url.searchParams.get('provider')||null; const staleDays=Math.min(3650,Math.max(1,intParam(url.searchParams,'staleDays')||undefined));
      const report=reliability.scanStaleness(d.catalog,{staleDays});
      if(provider && report.providers[provider]) return send(res,200,{version:VERSION,...report,provider:report.providers[provider]});
      return send(res,200,{version:VERSION,...report});
    }
    if(req.method==='GET' && url.pathname==='/api/providers/reliability/acceptance') return send(res,200,{version:VERSION,items:reliability.acceptanceMatrix(PROVIDERS.map(baseProviderStatus))});
    if(req.method==='POST' && url.pathname==='/api/providers/reliability/selftest') { try { return send(res,200,{version:VERSION,mode:'deterministic',...reliability.selftest()}); } catch(e) { return send(res,500,{version:VERSION,passed:false,error:e.message}); } }
    if(req.method==='POST' && url.pathname==='/api/providers/reliability/reset') {
      const b=await parseBody(req); if(b.confirm!=='RESET_PROVIDER_RELIABILITY') return send(res,400,{error:'Explicit confirmation required: RESET_PROVIDER_RELIABILITY'});
      const providers=Array.isArray(b.providers)?b.providers.filter(x=>PROVIDERS.includes(x)):null; const snap=reliability.reset({providers});
      return send(res,200,{version:VERSION,reset:true,providers:providers||PROVIDERS,updatedAt:snap.updatedAt});
    }
    // v0.63 Final Data Governance Layer
    if(req.method==='GET' && url.pathname==='/api/governance/status') {
      const d=store.read(),st=governance.status(d); return send(res,200,{...st,version:VERSION,governanceVersion:st.version});
    }
    if(req.method==='GET' && url.pathname==='/api/governance/policy') {
      const d=store.read(); const g=governance.ensure(d); return send(res,200,{version:VERSION,policy:g.policy,policyHash:g.policyHash});
    }
    if(req.method==='GET' && url.pathname==='/api/governance/audit') {
      const d=store.read(); const g=governance.ensure(d); const limit=Math.min(200,Math.max(1,intParam(url.searchParams,'limit')||50)); const field=String(url.searchParams.get('field')||''); const catalogId=String(url.searchParams.get('catalogId')||''); let items=g.fieldHistory||[]; if(field)items=items.filter(x=>x.field===field); if(catalogId)items=items.filter(x=>x.catalogId===catalogId); return send(res,200,{version:VERSION,total:items.length,items:items.slice(0,limit)});
    }
    if(req.method==='GET' && /^\/api\/governance\/items\//.test(url.pathname)) {
      const id=decodeURIComponent(url.pathname.split('/').slice(4).join('/')),d=store.read(),report=governance.itemReport(d,id); if(!report)return send(res,404,{error:'Catalog item not found'}); return send(res,200,{version:VERSION,...report});
    }
    if(req.method==='GET' && /^\/api\/governance\/deletion-impact\//.test(url.pathname)) {
      const id=decodeURIComponent(url.pathname.split('/').slice(4).join('/')),d=store.read(),impact=governance.deletionImpact(d,id); if(!impact)return send(res,404,{error:'Catalog item not found'}); return send(res,200,{version:VERSION,impact});
    }
    if(req.method==='POST' && url.pathname==='/api/governance/validate') {
      const d=store.read(); const result=governance.validateData(d); store.addAudit(d,'governance.validate',{catalogItems:result.catalogItems,issues:result.issues.length,warnings:result.warnings.length,fieldAttributionCoverage:result.fieldAttributionCoverage}); store.write(d); return send(res,200,{...result,version:VERSION,governanceVersion:result.version});
    }
    if(req.method==='POST' && url.pathname==='/api/governance/backup/verify') {
      const b=await parseBody(req); try { const raw=JSON.parse(String(b.content||'')); validateBackup(raw); const integrity=governance.verifyBackup(raw); return send(res,200,{version:VERSION,valid:integrity.valid,manifest:governance.backupManifest(raw),integrity}); } catch(e) { return send(res,e.status||422,{version:VERSION,valid:false,error:e.message,integrity:e.integrity||null}); }
    }
    if(req.method==='POST' && url.pathname==='/api/governance/policy/check') {
      const b=await parseBody(req),d=store.read(); if(b.demo===true)return send(res,200,{version:VERSION,mode:'demo',...governance.demo()}); const item=d.catalog.find(x=>x.id===String(b.catalogId||'')); if(!item)return send(res,404,{error:'Catalog item not found'}); const field=String(b.field||'').trim(); if(!governance.FIELDS.includes(field))return send(res,400,{error:'Unsupported governance field'}); const source={catalogId:String(item.id),provider:String(b.provider||'Manual'),providerId:b.providerId||null}; const decision=governance.policyDecision(d,item,field,source,b.value,b.explicitOverride===true); return send(res,200,{version:VERSION,decision,field,source});
    }
    if(req.method==='POST' && url.pathname==='/api/governance/deletion/preview') {
      const b=await parseBody(req),d=store.read(),impact=governance.deletionImpact(d,String(b.catalogId||'')); if(!impact)return send(res,404,{error:'Catalog item not found'}); return send(res,200,{version:VERSION,impact,safeToDelete:impact.riskLevel!=='high'||b.confirmRisk===true});
    }

    if(req.method==='GET' && url.pathname==='/api/anilist/status') return send(res,200,reliability.providerStatus('AniList',{provider:'AniList',configured:Boolean(process.env.ANILIST_CLIENT_ID||process.env.ANILIST_ACCESS_TOKEN),authentication:process.env.ANILIST_ACCESS_TOKEN?'Access token':process.env.ANILIST_CLIENT_ID?'OAuth client':'not configured',demoAvailable:true,compliance:anilist.liveAccessPolicy(),readiness:anilist.liveReadiness()}));
    for(const [name,module] of [['Open Library',openLibrary],['TMDB',tmdb],['IGDB',igdb]]) {
      const route = name==='Open Library'?'openlibrary':name.toLowerCase();
      if(req.method==='GET' && url.pathname===`/api/${route}/status`) return send(res,200,reliability.providerStatus(name,module.status()));
    }

    // v0.59 Cross-Provider Identity & Reconciliation
    if(req.method==='GET' && url.pathname==='/api/identity/status') {
      const d=store.read(), st=identity.state(d), groups=st.groups||[], conflicts=groups.reduce((n,g)=>n+(Array.isArray(g.conflicts)?g.conflicts.length:0),0);
      const latestRun=st.runs[0]||null;
      return send(res,200,{version:VERSION,providers:identity.PROVIDERS,matching:{threshold:identity.MATCH_THRESHOLD,autoConfirmThreshold:identity.AUTO_CONFIRM_THRESHOLD},groups:groups.length,linkedCatalogItems:new Set(groups.flatMap(g=>g.members||[])).size,candidates:st.candidates.length,decisions:st.decisions.length,confirmed:st.decisions.filter(x=>x.action==='confirm').length,rejected:st.decisions.filter(x=>x.action==='reject').length,conflicts,latestRun});
    }
    if(req.method==='GET' && url.pathname==='/api/identity/groups') {
      const d=store.read(), q=String(url.searchParams.get('q')||'').toLowerCase(); let groups=identity.state(d).groups.map(g=>identity.groupView(d,g));
      if(q) groups=groups.filter(g=>JSON.stringify(g).toLowerCase().includes(q));
      return send(res,200,{total:groups.length,items:groups.slice(0,200)});
    }
    const igroup=url.pathname.match(/^\/api\/identity\/groups\/([^/]+)$/);
    if(req.method==='GET' && igroup) {
      const d=store.read(),g=identity.state(d).groups.find(x=>x.id===igroup[1]); if(!g)return send(res,404,{error:'Identity group not found'});
      return send(res,200,{group:identity.groupView(d,g)});
    }
    if(req.method==='POST' && url.pathname==='/api/identity/analyze') {
      const b=await parseBody(req), d=store.read();
      if(b.demo===true) return send(res,200,{mode:'demo',demo:identity.demoCandidates()});
      if(b.catalogId){ const result=identity.analyzeCatalogItem(d,String(b.catalogId),{threshold:Number(b.threshold)||identity.MATCH_THRESHOLD,limit:Math.min(100,Number(b.limit)||50)}); if(!result)return send(res,404,{error:'Catalog item not found'}); return send(res,200,{mode:'catalog',...result}); }
      if(b.candidate){ const candidate=b.candidate; const matches=identity.listCandidates(candidate,d.catalog,d,{threshold:Number(b.threshold)||identity.MATCH_THRESHOLD,limit:Math.min(100,Number(b.limit)||50)}); return send(res,200,{mode:'candidate',candidate,matches,identity:identity.identityFingerprint(candidate)}); }
      return send(res,400,{error:'catalogId, candidate, or demo=true is required'});
    }
    if(req.method==='POST' && url.pathname==='/api/identity/rebuild') {
      const b=await parseBody(req); if(b.confirm!=='REBUILD_IDENTITY_INDEX')return send(res,400,{error:'Explicit confirmation required.'});
      const d=store.read(); const result=identity.rebuild(d,Number(b.threshold)||identity.MATCH_THRESHOLD); store.addAudit(d,'identity.rebuild',{runId:result.run.id,catalogSize:result.run.catalogSize,candidateCount:result.run.candidateCount}); store.write(d); return send(res,200,{...result,mode:'persisted'});
    }
    if(req.method==='POST' && url.pathname==='/api/identity/decision') {
      const b=await parseBody(req), action=String(b.action||'').toLowerCase(), aId=String(b.leftCatalogId||b.sourceCatalogId||''), bId=String(b.rightCatalogId||b.targetCatalogId||'');
      if(!['confirm','reject'].includes(action))return send(res,400,{error:'action must be confirm or reject'}); if(!aId||!bId||aId===bId)return send(res,400,{error:'Two different catalog IDs are required'});
      const d=store.read(),a=d.catalog.find(x=>x.id===aId),c=d.catalog.find(x=>x.id===bId); if(!a||!c)return send(res,404,{error:'Both catalog items must exist'});
      const cmp=identity.compare(a,c), st=identity.state(d), key=identity.decisionKey(aId,bId);
      const existingGroup=identity.groupForCatalogId(d,aId);
      const sameConfirmedGroup=existingGroup && existingGroup.members.includes(aId) && existingGroup.members.includes(bId);
      if(action==='reject' && sameConfirmedGroup) return send(res,409,{error:'Pair is already a confirmed identity. Use an explicit split operation rather than rejection.'});
      st.decisions=st.decisions.filter(x=>x.decisionKey!==key); const dec={id:crypto.randomUUID(),decisionKey:key,action,leftCatalogId:aId,rightCatalogId:bId,score:cmp.score,confidence:cmp.confidence,reasons:cmp.reasons,signals:cmp.signals,decidedAt:store.now(),source:String(b.source||'manual')}; st.decisions.unshift(dec); st.decisions=st.decisions.slice(0,5000);
      let group=null; if(action==='confirm') group=identity.addToGroup(d,aId,bId,dec.source); store.addAudit(d,`identity.${action}`,{decisionId:dec.id,leftCatalogId:aId,rightCatalogId:bId,score:cmp.score,confidence:cmp.confidence,groupId:group?.id||existingGroup?.id||null}); store.write(d);
      return send(res,200,{decision:dec,group:group?identity.groupView(d,group):sameConfirmedGroup?identity.groupView(d,existingGroup):null});
    }
    if(req.method==='POST' && url.pathname==='/api/identity/preference') {
      const b=await parseBody(req),d=store.read(); try { const g=identity.setPreference(d,String(b.groupId||''),String(b.field||''),String(b.catalogId||'')); store.addAudit(d,'identity.preference',{groupId:g.id,field:b.field,catalogId:b.catalogId}); store.write(d); return send(res,200,{group:identity.groupView(d,g)}); } catch(e){ return send(res,e.status||400,{error:e.message}); }
    }

    // v0.60 unified enrichment: combine confirmed identity-group evidence without
    // deleting provider records. Every scalar field carries selected-source provenance.
    if(req.method==='GET' && url.pathname==='/api/enrichment/status') {
      const d=store.read(); return send(res,200,{version:VERSION,...enrichment.status(d)});
    }
    if(req.method==='GET' && url.pathname==='/api/enrichment/groups') {
      const d=store.read(); const groups=(d.identity?.groups||[]).filter(g=>Array.isArray(g.members)&&g.members.length>=2).map(g=>{
        const plan=enrichment.buildPlan(d,g.id,{});
        return {id:g.id,title:plan.fields.find(x=>x.field==='title')?.proposed||g.canonicalTitle||g.id,targetCatalogId:plan.targetCatalogId,target:plan.target,memberCount:plan.providerCoverage.reduce((n,x)=>n+x.records,0),providers:plan.providerCoverage,coverageScore:plan.coverageScore,unresolvedConflicts:plan.unresolvedConflicts,enrichedMembers:d.catalog.filter(x=>x.enrichment?.identityGroupId===String(g.id)).map(x=>x.id)};
      });
      return send(res,200,{version:VERSION,total:groups.length,items:groups});
    }
    if(req.method==='GET' && /^\/api\/enrichment\/items\//.test(url.pathname)) {
      const itemId=decodeURIComponent(url.pathname.split('/').slice(4).join('/')); const d=store.read(); const item=d.catalog.find(x=>String(x.id)===String(itemId));
      if(!item)return send(res,404,{error:'Catalog item not found'}); return send(res,200,{version:VERSION,...enrichment.currentItemView(item)});
    }
    if(req.method==='POST' && url.pathname==='/api/enrichment/preview') {
      const b=await parseBody(req);
      if(b.demo===true) return send(res,200,{mode:'demo',...enrichment.demoPlan()});
      const d=store.read(); try { const plan=enrichment.buildPlan(d,String(b.groupId||''),{targetCatalogId:b.targetCatalogId?String(b.targetCatalogId):null}); return send(res,200,{mode:'local',plan}); } catch(e){ return send(res,e.status||400,{error:e.message}); }
    }
    if(req.method==='POST' && url.pathname==='/api/enrichment/apply') {
      const b=await parseBody(req); if(b.demo===true)return send(res,200,{mode:'demo',...enrichment.demoPlan(),applied:false});
      const d=store.read(); try {
        const groupId=String(b.groupId||''); const plan=enrichment.buildPlan(d,groupId,{targetCatalogId:b.targetCatalogId?String(b.targetCatalogId):null});
        if(b.planHash && String(b.planHash)!==String(plan.planHash))return send(res,409,{error:'The enrichment plan is stale or based on different catalog state. Rerun preview.'});
        const target=d.catalog.find(x=>String(x.id)===String(plan.targetCatalogId)); const before=JSON.parse(JSON.stringify(target));
        const changes={}; for(const fieldPlan of plan.fields) if(fieldPlan.proposed!==null && fieldPlan.proposed!==undefined && !(Array.isArray(fieldPlan.proposed)&&fieldPlan.proposed.length===0)) changes[fieldPlan.field]=fieldPlan.proposed;
        const selected=plan.fields.map(x=>x.selectedSource).filter(Boolean)[0]; const guardSource={catalogId:plan.targetCatalogId,provider:selected?.provider||'Manual',providerId:selected?.providerId||null};
        const guarded=governance.applyGuard(d,target,changes,{source:guardSource,explicitOverride:false,provider:guardSource.provider}); if(!guarded.allowed)return send(res,409,{error:'Governance policy blocked this enrichment apply.',field:guarded.field,reason:guarded.reason,decisions:guarded.decisions});
        const result=enrichment.applyPlan(d,plan,{expectedUpdatedAt:b.expectedUpdatedAt||null,planHash:plan.planHash});
        governance.ensure(d); result.item.governance={version:1,fieldProvenance:governance.attributionForItem(result.item),providerRetrievedAt:target?.providerMetadata?.provenance?.retrievedAt||result.item.governance?.providerRetrievedAt||null}; governance.recordFieldChanges(d,before,result.item,{action:'enrichment.apply',reason:'unified-enrichment'});
        store.addAudit(d,'enrichment.apply',{groupId,targetCatalogId:result.item.id,providerCoverage:plan.providerCoverage,coverageScore:plan.coverageScore,unresolvedConflicts:plan.unresolvedConflicts,changedFields:result.run.changedFields,planHash:plan.planHash,governanceChecked:true});
        store.write(d); return send(res,200,{mode:'local',applied:true,planHash:plan.planHash,catalogItem:result.item,run:result.run});
      } catch(e){ return send(res,e.status||400,{error:e.message}); }
    }
    if(req.method==='GET' && url.pathname==='/api/enrichment/coverage') {
      const d=store.read(); const rows=d.catalog.filter(x=>x.enrichment?.identityGroupId).map(x=>enrichment.currentItemView(x)); return send(res,200,{version:VERSION,total:rows.length,items:rows.slice(0,200)});
    }
    if(req.method==='GET' && url.pathname==='/api/identity/candidates') {
      const d=store.read(), catalogId=String(url.searchParams.get('catalogId')||''); if(!catalogId)return send(res,400,{error:'catalogId is required'}); const result=identity.analyzeCatalogItem(d,catalogId,{threshold:Number(url.searchParams.get('threshold'))||identity.MATCH_THRESHOLD,limit:Math.min(100,Number(url.searchParams.get('limit'))||50)}); if(!result)return send(res,404,{error:'Catalog item not found'}); return send(res,200,result);
    }
    // v0.62 Unified Provider Search: one read-only search surface over the catalog + deep providers.
    if(req.method==='GET' && url.pathname==='/api/search/route') {
      const query=String(url.searchParams.get('q')||'').trim(), type=String(url.searchParams.get('type')||'all'), providers=url.searchParams.get('providers');
      if(!query) return send(res,400,{error:'q is required'});
      return send(res,200,{version:VERSION,query,type,routing:unifiedSearch.route({query,type,providers})});
    }
    if(req.method==='GET' && url.pathname==='/api/search/demo-plan') return send(res,200,{version:VERSION,...unifiedSearch.demoPlan()});
    if(req.method==='GET' && url.pathname==='/api/search') {
      const query=String(url.searchParams.get('q')||'').trim(), type=String(url.searchParams.get('type')||'all'), providers=url.searchParams.get('providers');
      if(!query) return send(res,400,{error:'q is required'});
      try {
        const result=await unifiedSearch.searchUnified({query,type,providers,page:Number(url.searchParams.get('page')||1),limit:Number(url.searchParams.get('limit')||8),demo:url.searchParams.get('demo')==='1',includeCatalog:url.searchParams.get('includeCatalog')!=='0',language:url.searchParams.get('language')||null,region:url.searchParams.get('region')||null,catalog:store.read().catalog,data:store.read()});
        return send(res,200,result);
      } catch(e) { return send(res,e.status||502,{version:VERSION,error:e.message}); }
    }

    if (req.method==='POST' && url.pathname==='/api/providers/search') {
      const b=await parseBody(req); if(!PROVIDERS.includes(b.provider)) return send(res,400,{error:'Unsupported provider'});
      if(b.provider==='Open Library' && b.demo!==true){
        try { const r=await openLibrary.search({q:b.query||'',page:b.page,limit:b.limit,title:b.title,author:b.author,isbn:b.isbn,subject:b.subject,language:b.language,sort:b.sort}); const normalized=openLibrary.normalizeSearchResults(r.docs); const catalog=store.read().catalog; return send(res,200,{provider:b.provider,query:b.query||'',mode:r.mode,results:normalized.map(x=>({...x,matches:openLibraryQuality.findMatches(x,catalog),identityMatches:identity.listCandidates(x,catalog,store.read(),{limit:12})})),rawCount:r.docs.length,start:r.start,page:r.page,limit:r.limit,numFound:r.numFound,cached:r.cached}); }
        catch(e){ return send(res,e.status||502,{error:e.message,provider:'Open Library',mode:'blocked'}); }
      }
      if(b.provider==='TMDB' && b.demo!==true){
        try { const r=await tmdb.search({type:b.type||'movie',q:b.query||'',page:b.page,year:b.year,includeAdult:b.includeAdult,language:b.language,region:b.region}); const catalog=store.read().catalog; return send(res,200,{provider:b.provider,query:b.query||'',mode:r.mode,results:r.results.map(x=>({...x,matches:tmdb.findMatches(x,catalog),identityMatches:identity.listCandidates(x,catalog,store.read(),{limit:12})})),page:r.page,totalPages:r.totalPages,totalResults:r.totalResults,cached:r.cached}); }
        catch(e){ return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'}); }
      }
      if(b.provider==='IGDB' && b.demo!==true){
        try { const r=await igdb.search({q:b.query||'',page:b.page,limit:b.limit}); const catalog=store.read().catalog; return send(res,200,{provider:b.provider,query:b.query||'',mode:r.mode,results:r.results.map(x=>({...x,matches:igdb.findMatches(x,catalog),identityMatches:identity.listCandidates(x,catalog,store.read(),{limit:12})})),page:r.page,limit:r.limit,cached:r.cached}); }
        catch(e){ return send(res,e.status||502,{error:e.message,provider:'IGDB',mode:'blocked'}); }
      }
      { const demoResults=normalizeForDemo(b.provider,b.query); const data=store.read(); return send(res,200,{provider:b.provider,query:b.query||'',mode:'demo',results:demoResults.map(x=>({...x,identityMatches:identity.listCandidates(x,data.catalog,data,{limit:12})}))}); }
    }

    // IGDB v0.58 deep integration: Games, platforms, releases, developers/publishers, genres/themes, collections/franchises, assets, localizations, external IDs, age ratings, matching, enrichment, and acceptance.
    if(req.method==='GET' && url.pathname==='/api/igdb/status') return send(res,200,igdb.status());
    if(req.method==='GET' && url.pathname==='/api/igdb/cache') return send(res,200,igdb.cacheStats());
    if(req.method==='POST' && url.pathname==='/api/igdb/cache/clear') return send(res,200,igdb.clearCache());
    if(req.method==='GET' && url.pathname==='/api/igdb/search') {
      const demo=url.searchParams.get('demo')==='1', q=url.searchParams.get('q')||'demo';
      try { const r=demo?igdb.demoSearch(q):await igdb.search({q,page:intParam(url.searchParams,'page'),limit:intParam(url.searchParams,'limit')}); const catalog=store.read().catalog; return send(res,200,{...r,results:(r.results||[]).map(x=>({...x,matches:igdb.findMatches(x,catalog),identityMatches:identity.listCandidates(x,catalog,store.read(),{limit:12})}))}); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'IGDB',mode:'blocked'}); }
    }
    if(req.method==='GET' && url.pathname==='/api/igdb/discover') {
      const demo=url.searchParams.get('demo')==='1';
      try { const r=demo?igdb.demoDiscover():await igdb.discover({platformId:intParam(url.searchParams,'platformId'),genreId:intParam(url.searchParams,'genreId'),themeId:intParam(url.searchParams,'themeId'),yearFrom:intParam(url.searchParams,'yearFrom'),yearTo:intParam(url.searchParams,'yearTo'),sort:url.searchParams.get('sort'),page:intParam(url.searchParams,'page'),limit:intParam(url.searchParams,'limit')}); const catalog=store.read().catalog; return send(res,200,{...r,results:(r.results||[]).map(x=>({...x,matches:igdb.findMatches(x,catalog),identityMatches:identity.listCandidates(x,catalog,store.read(),{limit:12})}))}); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'IGDB',mode:'blocked'}); }
    }
    if(req.method==='GET' && /^\/api\/igdb\/games\/\d+$/.test(url.pathname)) {
      const id=Number(url.pathname.split('/')[4]),demo=url.searchParams.get('demo')==='1';
      try { const r=demo?{mode:'demo',id,item:igdb.demoGame(id),normalized:igdb.normalize(igdb.demoGame(id)),cached:false}:await igdb.getGame(id); return send(res,200,{...r,matchCandidates:igdb.findMatches(r.normalized,store.read().catalog),identityMatches:identity.listCandidates(r.normalized,store.read().catalog,store.read(),{limit:20})}); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'IGDB',mode:'blocked'}); }
    }
    for(const [route,key,fn] of [['companies','companies',igdb.searchCompanies],['platforms','platforms',igdb.searchPlatforms],['collections','collections',igdb.searchCollections],['franchises','franchises',igdb.searchFranchises]]) {
      if(req.method==='GET' && url.pathname===`/api/igdb/${route}/search`) { try { const r=await fn(url.searchParams.get('q')||'',intParam(url.searchParams,'limit')); return send(res,200,{...r,entityType:key}); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'IGDB',mode:'blocked'}); } }
    }
    for(const [route,fn] of [['companies',igdb.getCompany],['platforms',igdb.getPlatform],['collections',igdb.getCollection],['franchises',igdb.getFranchise]]) {
      const m=url.pathname.match(new RegExp(`^/api/igdb/${route}/(\\d+)$`));
      if(req.method==='GET' && m) { const id=Number(m[1]),demo=url.searchParams.get('demo')==='1'; try { const r=demo?igdb.demoEntity(route,id):await fn(id); return send(res,200,r); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'IGDB',mode:'blocked'}); } }
    }
    if(req.method==='POST' && url.pathname==='/api/igdb/quality/analyze') { const b=await parseBody(req); try { const normalized=b.raw?igdb.normalize(b.raw):b.demo?igdb.normalize(igdb.demoGame(b.providerId||99001)):(await igdb.getGame(b.providerId)).normalized; return send(res,200,{provider:'IGDB',quality:igdb.qualityReport(normalized),matches:igdb.findMatches(normalized,store.read().catalog),normalized}); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'IGDB',mode:'blocked'}); } }
    if(req.method==='POST' && url.pathname==='/api/igdb/matches') { const b=await parseBody(req), candidate=b.candidate; if(!candidate)return send(res,400,{error:'candidate is required'}); const normalized=candidate.provider==='IGDB'?candidate:igdb.normalize(candidate); return send(res,200,{candidate:normalized,matches:igdb.findMatches(normalized,store.read().catalog),identityMatches:identity.listCandidates(normalized,store.read().catalog,store.read(),{limit:20})}); }
    if(req.method==='GET' && url.pathname==='/api/igdb/entities') { const d=store.read(),t=igdbEntityState(d),type=String(url.searchParams.get('type')||'companies'),q=String(url.searchParams.get('q')||'').toLowerCase(); if(!['companies','platforms','collections','franchises'].includes(type))return send(res,400,{error:'type must be companies, platforms, collections, or franchises'}); let items=Object.values(t[type]||{}); if(q)items=items.filter(x=>JSON.stringify(x).toLowerCase().includes(q)); return send(res,200,{type,total:items.length,items:items.slice(0,100)}); }
    if(req.method==='POST' && url.pathname==='/api/igdb/enrich/preview') {
      const b=await parseBody(req),d=store.read(); let catalog=null; if(b.catalogId)catalog=d.catalog.find(x=>x.id===b.catalogId); else if(b.providerId)catalog=d.catalog.find(x=>x.provider==='IGDB'&&String(x.providerId)===String(b.providerId)); if(!catalog)return send(res,404,{error:'Canonical catalog item not found. Provide catalogId or an existing IGDB providerId.'});
      const providerId=b.providerId || (catalog.provider==='IGDB' ? catalog.providerId : null) || catalog.providerMetadata?.igdb?.id; if(!providerId)return send(res,400,{error:'An IGDB providerId is required for enrichment when the canonical record comes from another provider.'});
      try { const bundle=await buildIGDBEnrichmentBundle(providerId,b.demo===true); const preview=igdb.enrichmentPreview(catalog,bundle.normalized); return send(res,200,{mode:b.demo?'demo':'live',catalog,preview,bundlePreview:{providerId:bundle.normalized.providerId,title:bundle.normalized.title,entities:bundle.entities}}); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'IGDB',mode:'blocked'}); }
    }
    if(req.method==='POST' && url.pathname==='/api/igdb/enrich/apply') {
      const b=await parseBody(req),d=store.read(),catalog=d.catalog.find(x=>x.id===b.catalogId); if(!catalog)return send(res,404,{error:'Catalog item not found.'}); if(b.expectedUpdatedAt && catalog.updatedAt!==b.expectedUpdatedAt)return send(res,409,{error:'Catalog item changed since preview. Run a new preview.'});
      const providerId=b.providerId || (catalog.provider==='IGDB' ? catalog.providerId : null) || catalog.providerMetadata?.igdb?.id; if(!providerId)return send(res,400,{error:'An IGDB providerId is required for enrichment when the canonical record comes from another provider.'});
      try { const bundle=await buildIGDBEnrichmentBundle(providerId,b.demo===true); const merged=applyIGDBEnrichment(catalog,bundle); const before=JSON.parse(JSON.stringify(catalog)); const changedFields=governance.FIELDS.filter(field=>!governance.equivalent(catalog[field],merged[field])); const changes={}; for(const field of changedFields) changes[field]=merged[field]; const guarded=governance.applyGuard(d,catalog,changes,{source:{catalogId:catalog.id,provider:'IGDB',providerId:String(providerId)},provider:'IGDB'}); if(!guarded.allowed)return send(res,409,{error:'Governance policy blocked this IGDB enrichment.',field:guarded.field,reason:guarded.reason,decisions:guarded.decisions}); merged.governance={...(catalog.governance||{}),version:1,fieldProvenance:{...(catalog.governance?.fieldProvenance||{})},providerRetrievedAt:store.now()}; for(const field of changedFields) merged.governance.fieldProvenance[field]={catalogId:catalog.id,provider:'IGDB',providerId:String(providerId),field,sourceType:'provider',reason:'IGDB enrichment',updatedAt:store.now()}; d.catalog=d.catalog.map(x=>x.id===catalog.id?merged:x); persistIGDBEntities(d,bundle,b.demo?'demo':'live'); governance.recordFieldChanges(d,before,merged,{action:'igdb.catalog.enrich',reason:'provider-enrichment'}); store.addAudit(d,'igdb.catalog.enrich',{catalogId:catalog.id,providerId:bundle.normalized.providerId,mode:b.demo?'demo':'live',changedFields,governanceChecked:true}); store.write(d); return send(res,200,{mode:b.demo?'demo':'live',catalogItem:merged,entitySummary:Object.fromEntries(Object.entries(bundle.entities).map(([k,v])=>[k,Object.keys(v).length]))}); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'IGDB',mode:'blocked'}); }
    }
    if(req.method==='GET' && url.pathname==='/api/igdb/live-acceptance') return send(res,400,{error:'Use POST /api/igdb/live-acceptance'});
    if(req.method==='POST' && url.pathname==='/api/igdb/live-acceptance') { const b=await parseBody(req); if(b.confirm!=='RUN_IGDB_READ_ACCEPTANCE')return send(res,400,{error:'Explicit confirmation required: RUN_IGDB_READ_ACCEPTANCE'}); try{return send(res,200,await igdb.liveAcceptance({query:b.query}));}catch(e){return send(res,e.status||502,{error:e.message,provider:'IGDB',mode:'blocked'});} }

    // TMDB v0.57 deep integration: Movie / TV discovery, rich details, entities, localization, releases, collections, seasons, episodes, matching, enrichment, and acceptance.
    if(req.method==='GET' && url.pathname==='/api/tmdb/status') return send(res,200,tmdb.status());
    if(req.method==='GET' && url.pathname==='/api/tmdb/watch-providers/status') return send(res,200,{version:VERSION,...tmdb.watchProviderStatus()});
    if(req.method==='GET' && url.pathname==='/api/tmdb/cache') return send(res,200,tmdb.cacheStats());
    if(req.method==='POST' && url.pathname==='/api/tmdb/cache/clear') return send(res,200,tmdb.clearCache());
    if(req.method==='GET' && url.pathname==='/api/tmdb/search') {
      const type=(url.searchParams.get('type')||'movie').toLowerCase(), demo=url.searchParams.get('demo')==='1';
      try { const r=demo?tmdb.demoSearch(url.searchParams.get('q')||'demo',type):await tmdb.search({type,q:url.searchParams.get('q')||'',page:url.searchParams.get('page'),year:url.searchParams.get('year'),includeAdult:boolParam(url.searchParams,'includeAdult'),language:url.searchParams.get('language'),region:url.searchParams.get('region')}); const catalog=store.read().catalog; return send(res,200,{...r,results:(r.results||[]).map(x=>({...x,matches:tmdb.findMatches(x,catalog),identityMatches:identity.listCandidates(x,catalog,store.read(),{limit:12})}))}); }
      catch(e){ return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'}); }
    }
    if(req.method==='GET' && url.pathname==='/api/tmdb/discover') {
      const type=(url.searchParams.get('type')||'movie').toLowerCase(),demo=url.searchParams.get('demo')==='1';
      try { const input={type,page:url.searchParams.get('page'),sortBy:url.searchParams.get('sortBy'),year:url.searchParams.get('year'),withGenres:url.searchParams.get('withGenres'),withCompanies:url.searchParams.get('withCompanies'),withOriginalLanguage:url.searchParams.get('withOriginalLanguage'),withOriginCountry:url.searchParams.get('withOriginCountry'),withKeywords:url.searchParams.get('withKeywords'),dateGte:url.searchParams.get('dateGte'),dateLte:url.searchParams.get('dateLte'),includeAdult:boolParam(url.searchParams,'includeAdult'),includeVideo:boolParam(url.searchParams,'includeVideo'),language:url.searchParams.get('language'),region:url.searchParams.get('region'),watchRegion:url.searchParams.get('watchRegion'),withWatchProviders:url.searchParams.get('withWatchProviders')}; const r=demo?tmdb.demoDiscover(type):await tmdb.discover(input); const catalog=store.read().catalog; return send(res,200,{...r,results:(r.results||[]).map(x=>({...x,matches:tmdb.findMatches(x,catalog),identityMatches:identity.listCandidates(x,catalog,store.read(),{limit:12})}))}); }
      catch(e){ return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'}); }
    }
    if(req.method==='GET' && /^\/api\/tmdb\/(movie|tv)\/\d+$/.test(url.pathname)) {
      const parts=url.pathname.split('/'),type=parts[3],id=Number(parts[4]),demo=url.searchParams.get('demo')==='1';
      try { const raw=type==='tv'?tmdb.demoTV(id):tmdb.demoMovie(id); const r=demo?{mode:'demo',type,id,item:raw,normalized:tmdb.normalize(type,raw),cached:false}:await tmdb.getDetails(type,id,{language:url.searchParams.get('language'),region:url.searchParams.get('region')}); return send(res,200,{...r,matchCandidates:tmdb.findMatches(r.normalized,store.read().catalog),identityMatches:identity.listCandidates(r.normalized,store.read().catalog,store.read(),{limit:20})}); }
      catch(e){ return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'}); }
    }
    if(req.method==='GET' && /^\/api\/tmdb\/collections\/\d+$/.test(url.pathname)) {
      const id=Number(url.pathname.split('/')[4]),demo=url.searchParams.get('demo')==='1';
      try { const r=demo?tmdb.demoCollection(id):await tmdb.getCollection(id,{language:url.searchParams.get('language')}); return send(res,200,r); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'}); }
    }
    if(req.method==='GET' && /^\/api\/tmdb\/persons\/\d+$/.test(url.pathname)) {
      const id=Number(url.pathname.split('/')[4]),demo=url.searchParams.get('demo')==='1';
      try { const r=demo?tmdb.demoPerson(id):await tmdb.getPerson(id,{language:url.searchParams.get('language')}); return send(res,200,r); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'}); }
    }
    if(req.method==='GET' && /^\/api\/tmdb\/tv\/\d+\/seasons\/\d+$/.test(url.pathname)) {
      const parts=url.pathname.split('/'),seriesId=Number(parts[4]),season=Number(parts[6]),demo=url.searchParams.get('demo')==='1';
      try { const r=demo?tmdb.demoSeason(seriesId,season):await tmdb.getSeason(seriesId,season,{language:url.searchParams.get('language')}); return send(res,200,r); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'}); }
    }
    if(req.method==='GET' && /^\/api\/tmdb\/tv\/\d+\/seasons\/\d+\/episodes\/\d+$/.test(url.pathname)) {
      const parts=url.pathname.split('/'),seriesId=Number(parts[4]),season=Number(parts[6]),episode=Number(parts[8]),demo=url.searchParams.get('demo')==='1';
      try { const r=demo?tmdb.demoEpisode(seriesId,season,episode):await tmdb.getEpisode(seriesId,season,episode,{language:url.searchParams.get('language')}); return send(res,200,r); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'}); }
    }
    if(req.method==='POST' && url.pathname==='/api/tmdb/quality/analyze') {
      const b=await parseBody(req); if(b.raw){ const normalized=b.normalized?.provider==='TMDB'?b.normalized:tmdb.normalize('TMDB',b.raw); return send(res,200,{provider:'TMDB',quality:tmdb.qualityReport(normalized),matches:tmdb.findMatches(normalized,store.read().catalog),normalized}); }
      const type=String(b.type||'movie').toLowerCase(),providerId=String(b.providerId||'').trim(); if(!providerId)return send(res,400,{error:'providerId is required'});
      try { const bundle=await buildTMDBEnrichmentBundle(providerId,type,b.demo===true); return send(res,200,{provider:'TMDB',quality:tmdb.qualityReport(bundle.normalized),matches:tmdb.findMatches(bundle.normalized,store.read().catalog),normalized:bundle.normalized}); } catch(e){return send(res,e.status||502,{error:e.message,provider:'TMDB'});}
    }
    if(req.method==='POST' && url.pathname==='/api/tmdb/matches') {
      const b=await parseBody(req),candidate=b.candidate; if(!candidate)return send(res,400,{error:'candidate is required'}); const normalized=candidate.provider==='TMDB'?candidate:tmdb.normalize('TMDB',candidate); return send(res,200,{candidate:normalized,matches:tmdb.findMatches(normalized,store.read().catalog),identityMatches:identity.listCandidates(normalized,store.read().catalog,store.read(),{limit:20})});
    }
    if(req.method==='GET' && url.pathname==='/api/tmdb/entities') {
      const d=store.read(),t=tmdbEntityState(d),type=String(url.searchParams.get('type')||'people'),q=String(url.searchParams.get('q')||'').toLowerCase(); let items=[]; if(type==='people')items=Object.values(t.people); else if(type==='companies')items=Object.values(t.companies); else if(type==='networks')items=Object.values(t.networks); else if(type==='collections')items=Object.values(t.collections); else return send(res,400,{error:'type must be people, companies, networks, or collections'}); if(q)items=items.filter(x=>JSON.stringify(x).toLowerCase().includes(q)); return send(res,200,{type,total:items.length,items:items.slice(0,100)});
    }
    if(req.method==='POST' && url.pathname==='/api/tmdb/enrich/preview') {
      const b=await parseBody(req),d=store.read(); let catalog=null; if(b.catalogId)catalog=d.catalog.find(x=>x.id===String(b.catalogId)); if(!catalog&&b.providerId)catalog=d.catalog.find(x=>x.provider==='TMDB'&&String(x.providerId)===String(b.providerId)); if(!catalog)return send(res,404,{error:'TMDB catalog item not found'}); const type=String(b.type||(catalog.providerMetadata?.tmdb?.mediaType||'movie')).toLowerCase();
      try { const bundle=await buildTMDBEnrichmentBundle(catalog.providerId,type,b.demo===true,b.language,b.region); const preview=tmdb.enrichmentPreview(catalog,bundle.normalized); const matches=tmdb.findMatches(catalog,d.catalog.filter(x=>x.id!==catalog.id)); return send(res,200,{mode:b.demo===true?'demo':'live',catalog,preview,matches,entitySummary:tmdb.entityBundle(bundle.normalized),rawSnapshotAvailable:Boolean(bundle.raw)}); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'}); }
    }
    if(req.method==='POST' && url.pathname==='/api/tmdb/enrich/apply') {
      const b=await parseBody(req),d=store.read(); let idx=-1; if(b.catalogId)idx=d.catalog.findIndex(x=>x.id===String(b.catalogId)); else if(b.providerId)idx=d.catalog.findIndex(x=>x.provider==='TMDB'&&String(x.providerId)===String(b.providerId)); if(idx<0)return send(res,404,{error:'TMDB catalog item not found'}); const catalog=d.catalog[idx]; if(b.expectedUpdatedAt&&String(catalog.updatedAt)!==String(b.expectedUpdatedAt))return send(res,409,{error:'Catalog changed since preview; rerun TMDB enrichment preview.',currentUpdatedAt:catalog.updatedAt}); const type=String(b.type||(catalog.providerMetadata?.tmdb?.mediaType||'movie')).toLowerCase();
      try { const bundle=await buildTMDBEnrichmentBundle(catalog.providerId,type,b.demo===true,b.language,b.region); const next=tmdb.applyEnrichment(catalog,bundle.normalized); const before=JSON.parse(JSON.stringify(catalog)); const changedFields=tmdb.enrichmentPreview(catalog,bundle.normalized).changedFields; const changes={}; for(const field of changedFields) if(next[field]!==undefined) changes[field]=next[field]; const guarded=governance.applyGuard(d,catalog,changes,{source:{catalogId:catalog.id,provider:'TMDB',providerId:catalog.providerId},provider:'TMDB'}); if(!guarded.allowed)return send(res,409,{error:'Governance policy blocked this TMDB enrichment.',field:guarded.field,reason:guarded.reason,decisions:guarded.decisions}); next.governance={...(catalog.governance||{}),version:1,fieldProvenance:{...(catalog.governance?.fieldProvenance||{})},providerRetrievedAt:store.now()}; for(const field of changedFields) next.governance.fieldProvenance[field]={catalogId:catalog.id,provider:'TMDB',providerId:catalog.providerId,field,sourceType:'provider',reason:'TMDB enrichment',updatedAt:store.now()}; d.catalog[idx]=next; persistTMDBEntities(d,{normalized:bundle.normalized,entities:bundle.entities},b.demo===true?'demo':'live'); d.tmdb.reviewDiagnostics=Array.isArray(d.tmdb.reviewDiagnostics)?d.tmdb.reviewDiagnostics:[]; governance.recordFieldChanges(d,before,next,{action:'tmdb.catalog.enrich',reason:'provider-enrichment'}); store.addAudit(d,'tmdb.catalog.enrich',{catalogId:catalog.id,providerId:catalog.providerId,mode:b.demo===true?'demo':'live',changedFields,governanceChecked:true}); store.write(d); return send(res,200,{mode:b.demo===true?'demo':'live',catalogItem:next,entities:bundle.entities}); } catch(e){return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'});}
    }
    if(req.method==='POST' && url.pathname==='/api/tmdb/entities/rebuild') {
      const b=await parseBody(req); if(b.confirm!=='REBUILD_TMDB_ENTITIES')return send(res,400,{error:'Explicit confirmation required.'}); const d=store.read(),t=tmdbEntityState(d); const keep={people:{},companies:{},networks:{},collections:{}}; for(const item of d.catalog.filter(x=>x.provider==='TMDB')){ const e=tmdb.entityBundle(item); persistTMDBEntities(d,{normalized:item,entities:e},'rebuild'); } store.write(d); return send(res,200,{rebuilt:true,catalogItems:d.catalog.filter(x=>x.provider==='TMDB').length,people:Object.keys(t.people).length,companies:Object.keys(t.companies).length,networks:Object.keys(t.networks).length,collections:Object.keys(t.collections).length});
    }
    if(req.method==='POST' && url.pathname==='/api/tmdb/live-acceptance') {
      const b=await parseBody(req); if(b.confirm!=='RUN_TMDB_READ_ACCEPTANCE')return send(res,400,{error:'Explicit confirmation required.'}); try { return send(res,200,await tmdb.liveAcceptance({query:b.query})); } catch(e){return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'});}
    }

    // Open Library deep integration: low-volume, human-facing discovery and lookup.
    if(req.method==='GET' && url.pathname==='/api/openlibrary/status') return send(res,200,openLibrary.status());
    if(req.method==='GET' && url.pathname==='/api/openlibrary/search') {
      const demo=url.searchParams.get('demo')==='1';
      try {
        if(demo) { const r=openLibrary.demoSearch(url.searchParams.get('q')||'demo'); const normalized=openLibrary.normalizeSearchResults(r.docs); return send(res,200,{...r,results:normalized.map(x=>({...x,matches:openLibraryQuality.findMatches(x,store.read().catalog)}))}); }
        const r=await openLibrary.search({q:url.searchParams.get('q')||'',title:url.searchParams.get('title'),author:url.searchParams.get('author'),isbn:url.searchParams.get('isbn'),subject:url.searchParams.get('subject'),language:url.searchParams.get('language'),page:url.searchParams.get('page'),limit:url.searchParams.get('limit'),sort:url.searchParams.get('sort')});
        const normalized=openLibrary.normalizeSearchResults(r.docs); return send(res,200,{...r,results:normalized.map(x=>({...x,matches:openLibraryQuality.findMatches(x,store.read().catalog)}))});
      } catch(e){ return send(res,e.status||502,{error:e.message,provider:'Open Library',mode:'blocked'}); }
    }
    if(req.method==='GET' && /^\/api\/openlibrary\/works\/[^/]+\/editions$/.test(url.pathname)) {
      const parts=url.pathname.split('/'); const id=parts[4]; const demo=url.searchParams.get('demo')==='1';
      try {
        if(demo){ const r=openLibrary.demoWorkEditions(id||'OLDEMO1W'); return send(res,200,{...r,quality:openLibraryQuality.relationshipPlan(openLibrary.demoWork(id||'OLDEMO1W').item,r.entries)}); }
        const r=await openLibrary.getWorkEditions(id,{limit:url.searchParams.get('limit'),offset:url.searchParams.get('offset')});
        const work=await openLibrary.getWork(id);
        return send(res,200,{...r,quality:openLibraryQuality.relationshipPlan(work.item,r.entries)});
      } catch(e){ return send(res,e.status||502,{error:e.message,provider:'Open Library',mode:'blocked'}); }
    }
    if(req.method==='GET' && /^\/api\/openlibrary\/(works|editions|authors|isbn)\//.test(url.pathname)) {
      const parts=url.pathname.split('/'); const kind=parts[3]; const id=parts.slice(4).join('/'); const demo=url.searchParams.get('demo')==='1';
      try {
        if(demo){ const r=kind==='works'?openLibrary.demoWork(id||'OLDEMO1W'):kind==='editions'?openLibrary.demoEdition(id||'OLDEMO1M'):kind==='authors'?openLibrary.demoAuthor(id||'OLDEMO1A'):openLibrary.demoISBN(id||'9780000000001'); return send(res,200,{...r,normalized:kind==='authors'?null:openLibrary.normalize(r.item),entity:kind==='authors'?openLibrary.normalizeAuthor(r.item):null}); }
        const r=kind==='works'?await openLibrary.getWork(id):kind==='editions'?await openLibrary.getEdition(id):kind==='authors'?await openLibrary.getAuthor(id):await openLibrary.getISBN(id);
        return send(res,200,{...r,normalized:kind==='authors'?null:openLibrary.normalize(r.item),entity:kind==='authors'?openLibrary.normalizeAuthor(r.item):null});
      } catch(e){ return send(res,e.status||502,{error:e.message,provider:'Open Library',mode:'blocked'}); }
    }

    // Open Library v0.56 quality, entities, identity matching, and enrichment.
    if(req.method==='GET' && url.pathname==='/api/openlibrary/quality/status') {
      const d=store.read(), ol=openLibraryEntityState(d); return send(res,200,{version:VERSION,provider:'Open Library',design:{workEditionRelationships:true,authorEntities:true,subjectNormalization:true,isbnIdentity:true,duplicateResolution:true,coverFallbacks:true,provenance:true,enrichment:true},registry:{authors:Object.keys(ol.authors).length,subjects:Object.keys(ol.subjects).length,works:Object.keys(ol.workEdition).length,enrichmentRuns:ol.enrichmentJournal.length,reviewDiagnostics:ol.reviewDiagnostics.length},policy:openLibrary.status().policy});
    }
    if(req.method==='POST' && url.pathname==='/api/openlibrary/quality/analyze') {
      const b=await parseBody(req); let raw=b.raw||null; if(!raw && b.providerId){ try { raw=(b.demo? (String(b.providerId).endsWith('W')?openLibrary.demoWork(b.providerId).item:String(b.providerId).endsWith('M')?openLibrary.demoEdition(b.providerId).item:openLibrary.demoAuthor(b.providerId).item) : String(b.providerId).endsWith('W')?(await openLibrary.getWork(b.providerId)).item:String(b.providerId).endsWith('M')?(await openLibrary.getEdition(b.providerId)).item:(await openLibrary.getAuthor(b.providerId)).item); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'Open Library'}); } }
      if(!raw||typeof raw!=='object')return send(res,400,{error:'raw or providerId is required'});
      const kind=String(b.entityType||raw.type?.key||'work').toLowerCase(); const q=openLibraryQuality.qualityReport(raw,kind.includes('author')?'author':kind.includes('edition')?'edition':'work'); const matches=openLibraryQuality.findMatches(normalize('Open Library',raw),store.read().catalog); return send(res,200,{provider:'Open Library',quality:q,matches,normalized:normalize('Open Library',raw)});
    }
    if(req.method==='POST' && url.pathname==='/api/openlibrary/matches') {
      const b=await parseBody(req); if(!b.candidate)return send(res,400,{error:'candidate is required'}); const data=store.read(); const candidate=b.candidate.provider==='Open Library'?b.candidate:normalize('Open Library',b.candidate); return send(res,200,{candidate,matches:openLibraryQuality.findMatches(candidate,data.catalog)});
    }
    if(req.method==='GET' && url.pathname==='/api/openlibrary/entities') {
      const d=store.read(), ol=openLibraryEntityState(d), type=String(url.searchParams.get('type')||'authors'); const q=String(url.searchParams.get('q')||'').toLowerCase(); let rows=[];
      if(type==='authors') rows=Object.values(ol.authors); else if(type==='subjects') rows=Object.values(ol.subjects); else if(type==='works') rows=Object.values(ol.workEdition); else return send(res,400,{error:'type must be authors, subjects, or works'});
      if(q) rows=rows.filter(x=>JSON.stringify(x).toLowerCase().includes(q)); return send(res,200,{type,total:rows.length,items:rows.slice(0,100)});
    }
    if(req.method==='POST' && url.pathname==='/api/openlibrary/enrich/preview') {
      const b=await parseBody(req), d=store.read(); let catalog=null;
      if(b.catalogId) catalog=d.catalog.find(x=>x.id===String(b.catalogId));
      if(!catalog&&b.providerId) catalog=d.catalog.find(x=>x.provider==='Open Library'&&String(x.providerId)===String(b.providerId));
      if(!catalog)return send(res,404,{error:'Open Library catalog item not found'});
      try{ const bundle=await buildOpenLibraryEnrichmentBundle(catalog.providerId,b.demo===true); const preview=openLibraryQuality.enrichmentPreview(catalog,bundle); const matches=openLibraryQuality.findMatches(catalog,d.catalog.filter(x=>x.id!==catalog.id)); return send(res,200,{mode:b.demo===true?'demo':'live',catalog,preview,matches,registrySummary:{authors:bundle.registry.authors.length,subjects:bundle.registry.subjects.length,editions:bundle.registry.workEdition.count},bundlePreview:{workId:bundle.registry.workId,editionIds:(bundle.registry.workEdition.editions||[]).map(x=>x.editionId).slice(0,20),authorIds:bundle.registry.authors.map(x=>x.providerId),subjectIds:bundle.registry.subjects.map(x=>x.id)}}); }
      catch(e){return send(res,e.status||502,{error:e.message,provider:'Open Library',mode:'blocked'});}
    }
    if(req.method==='POST' && url.pathname==='/api/openlibrary/enrich/apply') {
      const b=await parseBody(req), d=store.read(); let idx=-1; if(b.catalogId)idx=d.catalog.findIndex(x=>x.id===String(b.catalogId)); else if(b.providerId)idx=d.catalog.findIndex(x=>x.provider==='Open Library'&&String(x.providerId)===String(b.providerId));
      if(idx<0)return send(res,404,{error:'Open Library catalog item not found'}); const catalog=d.catalog[idx]; if(b.expectedUpdatedAt&&String(catalog.updatedAt)!==String(b.expectedUpdatedAt))return send(res,409,{error:'Catalog changed since preview; rerun enrichment preview.',currentUpdatedAt:catalog.updatedAt});
      try{ const bundle=await buildOpenLibraryEnrichmentBundle(catalog.providerId,b.demo===true); const next=applyOpenLibraryEnrichment(catalog,bundle); const before=JSON.parse(JSON.stringify(catalog)); const changedFields=governance.FIELDS.filter(field=>!governance.equivalent(catalog[field],next[field])); const changes={}; for(const field of changedFields) changes[field]=next[field]; const guarded=governance.applyGuard(d,catalog,changes,{source:{catalogId:catalog.id,provider:'Open Library',providerId:catalog.providerId},provider:'Open Library'}); if(!guarded.allowed)return send(res,409,{error:'Governance policy blocked this Open Library enrichment.',field:guarded.field,reason:guarded.reason,decisions:guarded.decisions}); next.governance={...(catalog.governance||{}),version:1,fieldProvenance:{...(catalog.governance?.fieldProvenance||{})},providerRetrievedAt:store.now()}; for(const field of changedFields) next.governance.fieldProvenance[field]={catalogId:catalog.id,provider:'Open Library',providerId:catalog.providerId,field,sourceType:'provider',reason:'Open Library enrichment',updatedAt:store.now()}; d.catalog[idx]=next; persistOpenLibraryRegistry(d,bundle.registry,b.demo===true?'demo':'live'); governance.recordFieldChanges(d,before,next,{action:'openlibrary.catalog.enrich',reason:'provider-enrichment'}); store.addAudit(d,'openlibrary.catalog.enrich',{catalogId:catalog.id,providerId:catalog.providerId,mode:b.demo===true?'demo':'live',changedFields,governanceChecked:true}); store.write(d); return send(res,200,{mode:b.demo===true?'demo':'live',catalogItem:next,registrySummary:{authors:bundle.registry.authors.length,subjects:bundle.registry.subjects.length,editions:bundle.registry.workEdition.count}}); }
      catch(e){return send(res,e.status||502,{error:e.message,provider:'Open Library',mode:'blocked'});}
    }
    if(req.method==='POST' && url.pathname==='/api/openlibrary/entities/rebuild') {
      const b=await parseBody(req); if(b.confirm!=='REBUILD_OPENLIBRARY_ENTITIES')return send(res,400,{error:'Explicit confirmation required.'}); const d=store.read(),ol=openLibraryEntityState(d); const items=d.catalog.filter(x=>x.provider==='Open Library'); let authors=0,subjects=0,works=0; for(const item of items){const pm=item.providerMetadata||{}; const reg={workId:pm.workId||((String(item.providerId||'').endsWith('W'))?item.providerId:null),authors:(pm.authorKeys||[]).map(providerId=>({providerId,name:null,updatedAt:store.now(),externalUrl:`https://openlibrary.org/authors/${providerId}` })),subjects:(pm.normalizedSubjects||[]),workEdition:{editions:(pm.editionRecords||[]),count:(pm.editionRecords||[]).length}}; persistOpenLibraryRegistry(d,reg,'rebuild'); if(reg.workId)works++; authors+=reg.authors.length; subjects+=reg.subjects.length;} store.addAudit(d,'openlibrary.entities.rebuild',{catalogItems:items.length,works,authors,subjects});store.write(d);return send(res,200,{rebuilt:true,catalogItems:items.length,works,authors,subjects});
    }

    if(req.method==='POST' && url.pathname==='/api/openlibrary/live-acceptance') {
      const b=await parseBody(req); if(b.confirm!=='RUN_OPENLIBRARY_READ_ACCEPTANCE') return send(res,400,{error:'Explicit confirmation required.'});
      try { return send(res,200,await openLibrary.liveAcceptance({query:b.query})); } catch(e){ return send(res,e.status||502,{error:e.message,provider:'Open Library',mode:'blocked'}); }
    }
    if(req.method==='GET' && url.pathname==='/api/openlibrary/cache') return send(res,200,{entries:openLibrary.status().cacheMaxEntries});
    if(req.method==='POST' && url.pathname==='/api/openlibrary/cache/clear') return send(res,200,openLibrary.clearCache());
    if (req.method==='POST' && url.pathname==='/api/providers/normalize') {
      const b=await parseBody(req); if(!PROVIDERS.includes(b.provider)||!Array.isArray(b.results)) return send(res,400,{error:'provider and results[] are required'});
      const data=store.read(); const results=b.results.map(x=>x.id&&x.provider?x:normalize(b.provider,x)).map(c=>({...c,matches:b.provider==='Open Library'?openLibraryQuality.findMatches(c,data.catalog):findMatches(c,data.catalog)}));
      return send(res,200,{results});
    }

    // AniList deep integration: public Media/people queries, OAuth, list sync, favourites, reviews, and a generic GraphQL gateway.

    if(req.method==='GET' && /^\/api\/anilist\/entity\/(character|staff|studio)\/\d+$/.test(url.pathname)) {
      const parts=url.pathname.split('/'); const kind=parts[4]; const id=Number(parts[5]); const page=Math.max(1,Number(url.searchParams.get('page')||'1')||1); const demo=url.searchParams.get('demo')==='1';
      if(demo) return send(res,200,anilist.demoEntity(kind,id));
      const queries={character:anilist.CHARACTER_DETAIL_QUERY,staff:anilist.STAFF_DETAIL_QUERY,studio:anilist.STUDIO_DETAIL_QUERY};
      try { const vars={id,page}; if(kind==='character'){vars.type=url.searchParams.get('type')||null;vars.onList=boolParam(url.searchParams,'onList');vars.sort=listParam(url.searchParams,'sort')||null;} if(kind==='staff'){vars.type=url.searchParams.get('type')||null;vars.onList=boolParam(url.searchParams,'onList');vars.mediaSort=listParam(url.searchParams,'mediaSort')||null;vars.characterSort=listParam(url.searchParams,'characterSort')||null;vars.staffSort=listParam(url.searchParams,'staffSort')||null;} if(kind==='studio'){vars.type=url.searchParams.get('type')||null;vars.isMain=boolParam(url.searchParams,'isMain');vars.onList=boolParam(url.searchParams,'onList');vars.sort=listParam(url.searchParams,'sort')||null;} const r=await anilist.graph(queries[kind],vars); return send(res,200,{mode:'live',kind,item:r.data?.Character||r.data?.Staff||r.data?.Studio,rateLimit:r.rateLimit}); }
      catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/entity/search') {
      const kind=String(url.searchParams.get('kind')||'character').toLowerCase(); if(!anilist.ENTITY_SEARCH_QUERIES[kind]) return send(res,400,{error:'kind must be character, staff, or studio'});
      const page=Math.max(1,Number(url.searchParams.get('page')||'1')||1); const search=String(url.searchParams.get('search')||'').trim(); const demo=url.searchParams.get('demo')==='1';
      if(demo){ const seed=anilist.demoEntity(kind,9900); return send(res,200,{mode:'demo',page:{pageInfo:{currentPage:1,lastPage:1,hasNextPage:false,total:1},items:[seed.item]}}); }
      try { const r=await anilist.graph(anilist.ENTITY_SEARCH_QUERIES[kind],{search:search||null,page}); const items=r.data?.Page?.characters||r.data?.Page?.staff||r.data?.Page?.studios||[]; return send(res,200,{mode:'live',page:{...r.data.Page,items},rateLimit:r.rateLimit}); }
      catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}
    }

    if(req.method==='GET' && url.pathname==='/api/anilist/compliance') {
      return send(res,200,{provider:'AniList',...anilist.liveAccessPolicy(),terms:anilist.ANILIST_TERMS_URL,productionGuidance:['AniList current Terms prohibit use of the API in competing, non-complementary anime/manga list or tracker services.','AniList also prohibits using the API as a backup or data-storage service.','For any production use that falls within a restricted category, obtain explicit permission/license from AniList before enabling live access.'],buildDefault:'demo-only'});
    }

    if(req.method==='GET' && url.pathname==='/api/anilist/auth/login') {
      try{anilist.assertLiveAccess();}catch(e){return send(res,451,{error:e.message,code:e.code,termsUrl:anilist.ANILIST_TERMS_URL});}
      if(!anilist.oauthConfigured()) return send(res,400,{error:'Configure ANILIST_CLIENT_ID, ANILIST_CLIENT_SECRET, and ANILIST_REDIRECT_URI for OAuth'});
      res.writeHead(302,{Location:anilist.loginUrl()}); return res.end();
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/auth/callback') {
      const code=url.searchParams.get('code'); const state=url.searchParams.get('state');
      if(!code)return send(res,400,{error:url.searchParams.get('error_description')||url.searchParams.get('error')||'Missing OAuth code'});
      if(!anilist.validOAuthState(state)) return send(res,400,{error:'Invalid or expired OAuth state'});
      try { await anilist.tokenFromCode(code); res.writeHead(302,{Location:'/?anilist=connected'}); return res.end(); } catch(e){ return send(res,502,{error:e.message}); }
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/auth/status') return send(res,200,await anilist.authStatus());
    if(req.method==='POST' && url.pathname==='/api/anilist/auth/logout') { anilist.logout(); return send(res,200,{authenticated:false}); }

    if(req.method==='GET' && /^\/api\/anilist\/workspace\/media\/\d+$/.test(url.pathname)) {
      const id=Number(url.pathname.split('/').pop());
      const type=(url.searchParams.get('type')||'ANIME').toUpperCase();
      const demo=url.searchParams.get('demo')==='1';
      if(!['ANIME','MANGA'].includes(type)) return send(res,400,{error:'type must be ANIME or MANGA'});
      if(demo){
        const w=anilist.demoMediaWorkspace(id,type);
        const d=store.read();
        const catalog=d.catalog.find(x=>x.provider==='AniList' && String(x.providerId)===String(id) && String(x.providerMetadata?.type||type).toUpperCase()===type) || null;
        const collections=(d.collections||[]).filter(c=>(c.itemIds||[]).includes(catalog?.id)).map(c=>({id:c.id,name:c.name}));
        const smartCollections=[];
        const sync=catalog?.providerMetadata?.anilistSync||null;
        return send(res,200,{mode:'demo',media:w.media,lineage:{provider:'AniList',providerId:String(id),mediaType:type,canonicalCatalogId:catalog?.id||null,normalizedType:catalog?.type||null,canonicalTitle:catalog?.title||null,collections,smartCollections,sync,tombstone:null},assets:(normalize('AniList',w.media).mediaAssets||null),connections:{relations:w.relations,characters:w.characters,staff:w.staff,studios:w.studios,recommendations:w.recommendations,reviews:w.reviews,stats:w.stats},mediaListEntry:w.mediaListEntry,source:w.media.siteUrl});
      }
      try {
        const r=await anilist.graph(anilist.MEDIA_DETAIL_QUERY,{id,type,characterPage:1,staffPage:1,studioPage:1,airingPage:1,trendPage:1,recommendationPage:1,reviewPage:1},{cache:true});
        const m=r.data?.Media; if(!m) return send(res,404,{error:'AniList media not found'});
        const d=store.read();
        const catalog=d.catalog.find(x=>x.provider==='AniList' && String(x.providerId)===String(id) && String(x.providerMetadata?.type||type).toUpperCase()===type) || null;
        const collections=(d.collections||[]).filter(c=>(c.itemIds||[]).includes(catalog?.id)).map(c=>({id:c.id,name:c.name}));
        const sync=catalog?.providerMetadata?.anilistSync||null;
        const tombstone=(d.anilistSyncTombstones||[]).find(t=>String(t.providerId)===String(id)&&String(t.type)===type)||null;
        return send(res,200,{mode:'live',media:m,lineage:{provider:'AniList',providerId:String(id),mediaType:type,canonicalCatalogId:catalog?.id||null,normalizedType:catalog?.type||null,canonicalTitle:catalog?.title||null,collections,smartCollections:[],sync,tombstone:tombstone?{id:tombstone.id,deletedAt:tombstone.deletedAt}:null},assets:normalize('AniList',m).mediaAssets,connections:{relations:m.relations?.edges||[],characters:m.characters?.edges||[],staff:m.staff?.edges||[],studios:m.studios?.edges||[],recommendations:m.recommendations?.nodes||[],reviews:m.reviews?.nodes||[],stats:m.stats||null},mediaListEntry:m.mediaListEntry||null,source:m.siteUrl||null,rateLimit:r.rateLimit,cached:!!r.cached});
      } catch(e){ return aniError(res,e); }
    }


function mergeAniListEnrichment(local, media) {
  const normalized = normalize('AniList', media);
  const currentPm = local.providerMetadata && typeof local.providerMetadata === 'object' ? local.providerMetadata : {};
  const currentAssets = local.mediaAssets && typeof local.mediaAssets === 'object' ? local.mediaAssets : {};
  const detail = {
    id: media.id,
    idMal: media.idMal ?? null,
    type: media.type ?? null,
    format: media.format ?? null,
    status: media.status ?? null,
    version: media.version ?? null,
    season: media.season ?? null,
    seasonYear: media.seasonYear ?? null,
    seasonInt: media.seasonInt ?? null,
    isAdult: media.isAdult ?? null,
    countryOfOrigin: media.countryOfOrigin ?? null,
    source: media.source ?? null,
    isLicensed: media.isLicensed ?? null,
    isLocked: media.isLocked ?? null,
    trending: media.trending ?? null,
    favourites: media.favourites ?? null,
    hashtag: media.hashtag ?? null,
    updatedAt: media.updatedAt ?? null,
    autoCreateForumThread: media.autoCreateForumThread ?? null,
    isRecommendationBlocked: media.isRecommendationBlocked ?? null,
    isReviewBlocked: media.isReviewBlocked ?? null,
    title: media.title ?? null,
    synonyms: media.synonyms || [],
    startDate: media.startDate || null,
    endDate: media.endDate || null,
    description: media.description || '',
    episodes: media.episodes ?? null,
    duration: media.duration ?? null,
    chapters: media.chapters ?? null,
    volumes: media.volumes ?? null,
    averageScore: media.averageScore ?? null,
    meanScore: media.meanScore ?? null,
    popularity: media.popularity ?? null,
    genres: media.genres || [],
    tags: media.tags || [],
    siteUrl: media.siteUrl || null,
    nextAiringEpisode: media.nextAiringEpisode || null,
    rankings: media.rankings || [],
    stats: media.stats || null,
    relations: media.relations || null,
    characters: media.characters || null,
    staff: media.staff || null,
    studios: media.studios || null,
    recommendations: media.recommendations || null,
    reviews: media.reviews || null,
    externalLinks: media.externalLinks || [],
    streamingEpisodes: media.streamingEpisodes || [],
    trailer: media.trailer || null,
    mediaListEntry: media.mediaListEntry || null,
    isFavourite: media.isFavourite ?? null,
    isFavouriteBlocked: media.isFavouriteBlocked ?? null,
    enrichedAt: store.now()
  };
  return {
    ...local,
    title: normalized.title || local.title,
    year: normalized.year || local.year,
    coverUrl: normalized.coverUrl || local.coverUrl || null,
    description: local.description || normalized.description || '',
    creators: Array.from(new Set([...(local.creators || []), ...(normalized.creators || [])])).slice(0, 48),
    tags: Array.from(new Set([...(local.tags || []), ...(normalized.tags || [])])),
    aliases: Array.from(new Set([...(local.aliases || []), ...(normalized.aliases || [])])),
    externalLinks: Array.from(new Set([...(local.externalLinks || []), ...(normalized.externalLinks || [])])),
    mediaAssets: {...currentAssets, ...(normalized.mediaAssets || {})},
    providerMetadata: {...currentPm, ...(normalized.providerMetadata || {}), anilistDetail: detail},
    raw: media,
    updatedAt: store.now()
  };
}
function enrichmentPreview(local, media) {
  const enriched = mergeAniListEnrichment(local, media);
  const fields = ['title','year','description','creators','tags','aliases','externalLinks','mediaAssets','providerMetadata','raw'];
  const changed = fields.filter(k => JSON.stringify(local[k] ?? null) !== JSON.stringify(enriched[k] ?? null));
  return {changedFields:changed, assetSummary: enriched.mediaAssets?.summary || null, relationCounts:{relations:media.relations?.edges?.length || 0,characters:media.characters?.edges?.length || 0,staff:media.staff?.edges?.length || 0,studios:media.studios?.edges?.length || 0,recommendations:media.recommendations?.nodes?.length || 0,reviews:media.reviews?.nodes?.length || 0},remoteUpdatedAt:media.updatedAt ?? null,existingUpdatedAt:local.updatedAt || null};
}

    if(req.method==='GET' && url.pathname==='/api/anilist/media/search') {
      const type=(url.searchParams.get('type')||'ANIME').toUpperCase(); const q=url.searchParams.get('q')||url.searchParams.get('search')||''; const demo=url.searchParams.get('demo')==='1';
      if(!demo && !q) return send(res,400,{error:'q/search is required unless demo=1'});
      if(demo) return send(res,200,{mode:'demo',query:q,type,results:anilist.demoSearch(q,type)});
      const vars=aniMediaVars(url,{type,search:q||null});
      try { const r=await anilist.graph(anilist.MEDIA_SEARCH_QUERY,vars); return send(res,200,{mode:'live',query:q,type,page:r.data.Page,rateLimit:r.rateLimit,cached:!!r.cached}); } catch(e){ return aniError(res,e); }
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/media/browse') {
      const demo=url.searchParams.get('demo')==='1'; if(demo) return send(res,200,{mode:'demo',page:{pageInfo:{currentPage:1,lastPage:1,hasNextPage:false,perPage:2,total:2},media:anilist.demoSearch('Browse',url.searchParams.get('type')||'ANIME')}});
      const vars=aniMediaVars(url,{});
      if(vars.isAdult===undefined) vars.isAdult=false;
      try{const r=await anilist.graph(anilist.MEDIA_SEARCH_QUERY,vars);return send(res,200,{mode:'live',page:r.data.Page,rateLimit:r.rateLimit,cached:!!r.cached,filters:vars});}catch(e){return aniError(res,e);}
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/live-write-acceptance') {
      const readiness=anilist.liveReadiness();
      return send(res,200,{version:VERSION,writeAcceptance:{available:true,defaultDryRun:true,requires:{ANILIST_WRITE_ACCEPTANCE:'true','--confirm-write':true,'ANILIST_WRITE_TEST_MEDIA_ID':'required'},optionalFlags:{'--plan':'safe plan only','--include-favourite':'also round-trip ToggleFavourite'},script:'npm run anilist:acceptance-write'},readiness,notes:['The write suite is intentionally separate from read-only acceptance.','It changes only the explicitly selected AniList media entry and restores prior state when one already exists.','If no entry exists, it creates a uniquely annotated temporary entry, exercises SaveMediaListEntry + UpdateMediaListEntries, then deletes it and verifies removal.','No access token is ever printed by the suite.']});
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/acceptance') {
      return send(res,200,{version:VERSION,provider:'AniList',status:anilist.liveAccessPolicy().liveEnabled?'authorized-live-capable':'demo-only',checks:{mediaTypeMapping:true,assetInventory:true,mediaDetailAssets:true,providerMetadataAssets:true,reviewApplyPreservesAssets:true,assetQualityLayer:true,assetFallbacks:true,complianceGate:true,oauthConfigPresent:anilist.oauthConfigured(),liveUpstreamReachable:false},compliance:anilist.liveAccessPolicy(),liveNetworkNote:'Live AniList execution depends on outbound network access; the current build environment cannot reach AniList.'});
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/cache') return send(res,200,{cache:anilist.cacheStats()});
    if(req.method==='POST' && url.pathname==='/api/anilist/cache/clear') { anilist.clearCache(); return send(res,200,{cleared:true,cache:anilist.cacheStats()}); }

    if(req.method==='GET' && url.pathname==='/api/anilist/health') {
      const live=url.searchParams.get('live')==='1';
      if(!live) return send(res,200,{ok:true,configured:anilist.configured(),oauthConfigured:anilist.oauthConfigured(),cache:anilist.cacheStats()});
      try { const r=await anilist.graph(`query OmniShelfAniListHealth { __typename }`,{}, {cache:false,allowRetry:false,timeoutMs:5000}); return send(res,200,{ok:true,upstream:true,rateLimit:r.rateLimit}); } catch(e){ return send(res,e.status===504?504:e.status===451?451:502,{ok:false,upstream:false,error:e.message,rateLimit:e.rateLimit||null}); }
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/assets/quality') {
      const demo=url.searchParams.get('demo')==='1';
      if(demo){
        const media=anilist.demoSearch('Assets', (url.searchParams.get('type')||'ANIME').toUpperCase())[0]||{};
        const assets=normalize('AniList',media).mediaAssets;
        return send(res,200,{mode:'demo',quality:{...assets.summary,coverSizes:assets.cover.availableSizes,hasFallbackCover:Boolean(assets.cover.fallback),hasSiteUrl:Boolean(assets.siteUrl)},recommendations:['Use the primary cover URL first; fall back to large/medium when unavailable.','Render remote assets lazily with no-referrer and hide failed assets without breaking the media page.','Do not persist remote image bytes unless deployment authorization permits it.']});
      }
      try {
        const id=intParam(url.searchParams,'id');
        if(!id) return send(res,400,{error:'id is required'});
        const type=(url.searchParams.get('type')||'ANIME').toUpperCase();
        const r=await anilist.graph(anilist.MEDIA_DETAIL_QUERY,{id,type,characterPage:1,staffPage:1,studioPage:1,airingPage:1,trendPage:1,recommendationPage:1,reviewPage:1});
        const m=r.data?.Media;
        if(!m) return send(res,404,{error:'AniList media not found'});
        const assets=normalize('AniList',m).mediaAssets;
        return send(res,200,{mode:'live',id,type,quality:{...assets.summary,coverSizes:assets.cover.availableSizes,hasFallbackCover:Boolean(assets.cover.fallback),hasSiteUrl:Boolean(assets.siteUrl)},rateLimit:r.rateLimit,cached:!!r.cached});
      } catch(e){ return aniError(res,e); }
    }

    const aa=url.pathname.match(/^\/api\/anilist\/media\/(\d+)\/assets$/);
    if(req.method==='GET' && aa){
      const id=Number(aa[1]); const type=(url.searchParams.get('type')||'ANIME').toUpperCase(); const demo=url.searchParams.get('demo')==='1';
      if(demo){
        const item=anilist.demoSearch('Assets',type)[0]||{};
        const assets=require('./lib/providers').normalize('AniList',item).mediaAssets;
        return send(res,200,{mode:'demo',id,type,assets,counts:{cover:Object.values(assets.cover||{}).filter(Boolean).length,banner:assets.banner?1:0,trailer:assets.trailer?1:0,streamingEpisodes:assets.streamingEpisodes.length,externalLinks:assets.externalLinks.length}});
      }
      try {
        const r=await anilist.graph(anilist.MEDIA_DETAIL_QUERY,{id,type,characterPage:1,staffPage:1,studioPage:1,airingPage:1,trendPage:1,recommendationPage:1,reviewPage:1});
        const m=r.data?.Media;
        if(!m)return send(res,404,{error:'AniList media not found'});
        const a=require('./lib/providers').normalize('AniList',m).mediaAssets;
        return send(res,200,{mode:'live',id,type,assets:a,counts:{cover:a.cover&&Object.values(a.cover).filter(Boolean).length,banner:a.banner?1:0,trailer:a.trailer?1:0,streamingEpisodes:a.streamingEpisodes.length,externalLinks:a.externalLinks.length},rateLimit:r.rateLimit,cached:!!r.cached});
      } catch(e){ return aniError(res,e); }
    }

    const am=url.pathname.match(/^\/api\/anilist\/media\/(\d+)$/);
    if(req.method==='GET' && am) {
      const id=Number(am[1]); const type=url.searchParams.get('type')||null; const demo=url.searchParams.get('demo')==='1';
      if(demo){ const base=anilist.demoSearch('Detail',type||'ANIME')[0]; base.id=id; base.relations=[]; base.characters={edges:[]}; base.staff={edges:[]}; base.studios={edges:[]}; base.recommendations={nodes:[]}; base.reviews={nodes:[]}; base.stats={scoreDistribution:[],statusDistribution:[]}; base.mediaListEntry=null; return send(res,200,{mode:'demo',item:base}); }
      const vars={id,type,characterPage:Math.max(1,Number(url.searchParams.get('characterPage')||'1')||1),staffPage:Math.max(1,Number(url.searchParams.get('staffPage')||'1')||1),studioPage:Math.max(1,Number(url.searchParams.get('studioPage')||'1')||1),airingPage:Math.max(1,Number(url.searchParams.get('airingPage')||'1')||1),trendPage:Math.max(1,Number(url.searchParams.get('trendPage')||'1')||1),recommendationPage:Math.max(1,Number(url.searchParams.get('recommendationPage')||'1')||1),reviewPage:Math.max(1,Number(url.searchParams.get('reviewPage')||'1')||1)}; try{const r=await anilist.graph(anilist.MEDIA_DETAIL_QUERY,vars); return send(res,200,{mode:'live',item:r.data.Media,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/user/statistics') {
      const demo=url.searchParams.get('demo')==='1';
      const limit=Math.min(25,Math.max(1,Number(url.searchParams.get('limit')||10)));
      const allowedStatsSort=new Set(['COUNT','COUNT_DESC','ID','ID_DESC','MEAN_SCORE','MEAN_SCORE_DESC','PROGRESS','PROGRESS_DESC']);
      const sortParam=url.searchParams.get('sort')||'COUNT_DESC';
      const sort=allowedStatsSort.has(sortParam)?[sortParam]:['COUNT_DESC'];
      if(demo) return send(res,200,anilist.demoUserStatistics());
      const id=intParam(url.searchParams,'id');
      const name=url.searchParams.get('name')||null;
      if(!id&&!name) return send(res,400,{error:'id or name is required'});
      try {
        const r=await anilist.graph(anilist.USER_STATISTICS_QUERY,{id,name,limit,sort});
        return send(res,200,{mode:'live',user:r.data?.User||null,rateLimit:r.rateLimit,cached:!!r.cached});
      } catch(e) {
        return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});
      }
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/viewer') { if(url.searchParams.get('demo')==='1') return send(res,200,{mode:'demo',viewer:{id:101,name:'OmniShelfDemo',about:'Demo AniList viewer',siteUrl:'https://anilist.co/user/OmniShelfDemo',statistics:{anime:{count:2,meanScore:82,minutesWatched:120,episodesWatched:6,genres:[],tags:[]},manga:{count:2,meanScore:79,chaptersRead:32,volumesRead:2,genres:[],tags:[]}}}}); try{const r=await anilist.graph(anilist.VIEWER_QUERY);return send(res,200,{viewer:r.data.Viewer,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:502,{error:e.message,rateLimit:e.rateLimit||null});} }
    if(req.method==='POST' && (url.pathname==='/api/anilist/lists/sync-preview' || url.pathname==='/api/anilist/lists/sync-apply')) {
      const b=await parseBody(req); const type=(b.type||'ANIME').toUpperCase(); const userId=b.userId?Number(b.userId):null; const userName=b.userName?String(b.userName):null; const limit=Math.min(500,Math.max(1,Number(b.limit||200)));
      if(!userId&&!userName)return send(res,400,{error:'userId or userName is required'});
      try{const r=await anilist.graph(anilist.LIST_COLLECTION_QUERY,{type,userId,userName}); const lists=r.data?.MediaListCollection?.lists||[]; const entries=lists.flatMap(l=>l.entries||[]).slice(0,limit); const d=store.read(); const prepared=entries.map(entry=>{const n=normalize('AniList',entry.media); n.providerMetadata=n.providerMetadata||{}; n.providerMetadata.mediaListEntry={id:entry.id,status:entry.status,score:entry.score,progress:entry.progress,progressVolumes:entry.progressVolumes,repeat:entry.repeat,priority:entry.priority,private:entry.private,notes:entry.notes,customLists:entry.customLists,advancedScores:entry.advancedScores,startedAt:entry.startedAt,completedAt:entry.completedAt,updatedAt:entry.updatedAt,createdAt:entry.createdAt,listName:lists.find(l=>(l.entries||[]).some(e=>e.id===entry.id))?.name||null}; n.matches=findMatches(n,d.catalog); return n;});
      const duplicates=prepared.filter(n=>n.providerId&&d.catalog.some(x=>x.provider==='AniList'&&x.providerId===n.providerId)).map(n=>({providerId:n.providerId,title:n.title,reason:'provider identity'}));
      if(url.pathname.endsWith('sync-preview')) return send(res,200,{mode:'live',type,userId,userName,totalEntries:entries.length,lists:lists.map(l=>({name:l.name,count:(l.entries||[]).length})),ready:prepared.filter(n=>!duplicates.some(x=>x.providerId===n.providerId)).length,duplicates,preview:prepared.slice(0,20),rateLimit:r.rateLimit});
      let queued=0,skipped=0; for(const n of prepared){if(d.catalog.some(x=>x.provider==='AniList'&&x.providerId===n.providerId)){skipped++;continue;} const item={id:crypto.randomUUID(),status:'pending',createdAt:store.now(),normalized:n}; if(normalized.provider==='IGDB'){ const ig=igdbEntityState(d); const diagnostic={reviewId:item.id,at:store.now(),providerId:normalized.providerId,title:normalized.title,quality:igdb.qualityReport(normalized),matches:normalized.matches.slice(0,10)}; ig.reviewDiagnostics.unshift(diagnostic);ig.reviewDiagnostics=ig.reviewDiagnostics.slice(0,200); } d.reviewQueue.unshift(item); store.addAudit(d,'anilist.list_sync.queue',{reviewId:item.id,providerId:n.providerId,title:n.title,type:n.providerMetadata?.type||type}); queued++;}
      if(queued)store.write(d); return send(res,200,{queued,skipped,totalEntries:entries.length,rateLimit:r.rateLimit});
      }catch(e){return send(res,e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}
    }

    const syncCommitMatch=url.pathname.match(/^\/api\/anilist\/sync\/runs\/([^/]+)\/commit$/);
    if(req.method==='POST' && syncCommitMatch){
      const b=await parseBody(req); const d=store.read(),run=findSyncRun(d,syncCommitMatch[1]); if(!run)return send(res,404,{error:'Sync run not found'});
      if(run.mode==='demo'||b.demo===true)return send(res,200,{mode:'demo',dryRun:true,committed:true,run});
      if(run.status==='committed')return send(res,200,{committed:true,run,replayed:true});
      if(run.status!=='previewed')return send(res,409,{error:`Sync run is ${run.status}; only previewed runs can be committed`});
      if(!run.cursorCandidate)return send(res,409,{error:'This sync run is partial; increase the scan limit and create a new preview before committing the watermark'});
      if(b.confirm!==true)return send(res,400,{error:'Set confirm=true to advance the sync watermark'});
      d.anilistSyncCursors=d.anilistSyncCursors&&typeof d.anilistSyncCursors==='object'?d.anilistSyncCursors:{};
      d.anilistSyncCursors[run.cursorKey]={updatedAt:run.cursorCandidate||run.cursorBefore?.updatedAt||null,committedAt:store.now(),runId:run.id};
      run.status='committed';run.committedAt=store.now();run.eventLog=Array.isArray(run.eventLog)?run.eventLog:[];run.eventLog.push({at:store.now(),event:'committed',cursor:run.cursorCandidate||null});upsertSyncRun(d,run);store.addAudit(d,'anilist.sync.run.commit',{runId:run.id,cursorKey:run.cursorKey,cursor:run.cursorCandidate||null});store.write(d);return send(res,200,{committed:true,replayed:false,run,cursor:d.anilistSyncCursors[run.cursorKey]});
    }

    if(req.method==='GET' && url.pathname==='/api/anilist/sync/plan') {
      const type=(url.searchParams.get('type')||'ANIME').toUpperCase(); if(!['ANIME','MANGA'].includes(type)) return send(res,400,{error:'type must be ANIME or MANGA'});
      const demo=url.searchParams.get('demo')==='1'; const limit=Math.min(250,Math.max(1,intParam(url.searchParams,'limit')||100));
      let userId=url.searchParams.get('userId')?Number(url.searchParams.get('userId')):null; const userName=url.searchParams.get('userName')||null;
      if(!demo && userId===0) userId=null;
      try {
        const d=store.read(); const local=d.catalog.filter(x=>x.provider==='AniList' && String(x.providerMetadata?.type||'').toUpperCase()===type); const tombstones=Array.isArray(d.anilistSyncTombstones)?d.anilistSyncTombstones:[];
        if(demo){
          const remote=remoteEntriesFromDemo(type);
          const syntheticLocal={id:'demo-catalog-1',title:'My List Chronicles',type:type==='ANIME'?'TV Series':'Manga',year:2026,provider:'AniList',providerId:String(remote[0]?.mediaId||101),providerMetadata:{type,mediaListEntry:{id:91001,mediaId:Number(remote[0]?.mediaId||101),status:'PLANNING',score:70,progress:1,progressVolumes:0,repeat:0,priority:0,private:false,notes:'Last pulled snapshot',hiddenFromStatusLists:false,customLists:[],advancedScores:null,startedAt:null,completedAt:null,updatedAt:1760000000,createdAt:1759000000}}};
          const rows=buildAniSyncPlan([syntheticLocal],remote,type,tombstones);
          return send(res,200,{mode:'demo',type,userId:101,userName:'OmniShelfDemo',limit,summary:{total:rows.length,inSync:rows.filter(x=>x.state==='in-sync').length,remoteChanged:rows.filter(x=>x.state==='remote-changed').length,localChanged:rows.filter(x=>x.state==='local-changed').length,conflict:rows.filter(x=>x.state==='conflict').length,unsynced:rows.filter(x=>x.state==='unsynced').length,remoteOnly:rows.filter(x=>x.state==='remote-only').length,localMissing:rows.filter(x=>x.state==='local-missing-entry').length},rows,rateLimit:null});
        }
        if(!demo && !userId && !userName) userId=await resolveSyncUserId(null,null);
        if(!demo && !userId && !userName) return send(res,401,{error:'Connect AniList or provide userId/userName for sync preview'});
        const fetched=await fetchAniListListEntries({type,userId,userName,limit,demo:false});
        const rows=buildAniSyncPlan(local,fetched.entries,type,tombstones);
        return send(res,200,{mode:fetched.mode,type,userId,userName,limit,summary:{total:rows.length,inSync:rows.filter(x=>x.state==='in-sync').length,remoteChanged:rows.filter(x=>x.state==='remote-changed').length,localChanged:rows.filter(x=>x.state==='local-changed').length,conflict:rows.filter(x=>x.state==='conflict').length,unsynced:rows.filter(x=>x.state==='unsynced').length,remoteOnly:rows.filter(x=>x.state==='remote-only').length,localMissing:rows.filter(x=>x.state==='local-missing-entry').length},rows,rateLimit:fetched.rateLimit});
      } catch(e) { return aniError(res,e); }
    }

    if(req.method==='POST' && url.pathname==='/api/anilist/sync/stage-local') {
      const b=await parseBody(req); const ids=Array.isArray(b.catalogIds)?b.catalogIds.map(String).filter(Boolean).slice(0,100):[]; if(!ids.length)return send(res,400,{error:'catalogIds[] is required'});
      let patch; try{patch=cleanSyncPatch(b.patch||{});}catch(e){return send(res,400,{error:e.message});}
      const d=store.read(); let staged=0,missing=0;
      for(const id of ids){const item=d.catalog.find(x=>x.id===id); if(!item||item.provider!=='AniList'){missing++;continue;} const sync=ensureBaseSnapshot(item); sync.localOverride={...(sync.localOverride||{}),...patch}; sync.lastStagedAt=store.now(); item.providerMetadata=item.providerMetadata&&typeof item.providerMetadata==='object'?item.providerMetadata:{}; item.providerMetadata.anilistSync=sync; item.updatedAt=store.now(); store.addAudit(d,'anilist.sync.stage_local',{catalogId:id,mediaId:item.providerId,fields:Object.keys(patch)}); staged++;}
      if(staged)store.write(d); return send(res,200,{staged,missing,fields:Object.keys(patch),dryRun:false});
    }
    if(req.method==='POST' && url.pathname==='/api/anilist/sync/resolve-tombstone') {
      const b=await parseBody(req); const tombstoneId=String(b.tombstoneId||'').trim(); const resolution=String(b.resolution||'').trim(); if(!tombstoneId)return send(res,400,{error:'tombstoneId is required'}); if(!['restore-local','delete-remote','keep-remote'].includes(resolution))return send(res,400,{error:'resolution must be restore-local, delete-remote, or keep-remote'});
      if(b.demo===true)return send(res,200,{mode:'demo',dryRun:true,resolved:true,resolution});
      const auth=await anilist.authStatus(); if(!auth.authenticated)return send(res,401,{error:'Connect AniList before resolving a local deletion tombstone'});
      const d=store.read(); d.anilistSyncTombstones=Array.isArray(d.anilistSyncTombstones)?d.anilistSyncTombstones:[]; const idx=d.anilistSyncTombstones.findIndex(x=>x.id===tombstoneId); if(idx<0)return send(res,404,{error:'Sync tombstone not found'}); const t=d.anilistSyncTombstones[idx];
      try{
        const r=await anilist.graph(anilist.LIST_PAGE_QUERY,{page:1,userId:auth.viewer?.id||null,userName:null,type:t.type,status:null,id:null,mediaId:Number(t.providerId),isFollowing:null,notes:null,startedAt:null,completedAt:null,compareWithAuthList:null,userId_in:null,status_in:null,status_not:null,status_not_in:null,mediaId_in:null,mediaId_not_in:null,notes_like:null,startedAt_greater:null,startedAt_lesser:null,startedAt_like:null,completedAt_greater:null,completedAt_lesser:null,completedAt_like:null,sort:['UPDATED_TIME_DESC']},{cache:false,allowRetry:false});
        const remote=(r.data?.Page?.mediaList||[]).find(e=>Number(e.mediaId)===Number(t.providerId))||null;
        if(resolution==='delete-remote'){ if(!remote)return send(res,409,{error:'Remote entry is already deleted'}); const dr=await anilist.graph(anilist.DELETE_LIST_MUTATION,{id:Number(remote.id)},{cache:false,allowRetry:false}); d.anilistSyncTombstones.splice(idx,1); store.addAudit(d,'anilist.sync.delete_remote_after_local_delete',{tombstoneId:t.id,mediaId:t.providerId,listEntryId:remote.id}); store.write(d); return send(res,200,{mode:'live',resolved:true,resolution,data:dr.data,rateLimit:dr.rateLimit}); }
        if(resolution==='keep-remote'){ d.anilistSyncTombstones.splice(idx,1); store.addAudit(d,'anilist.sync.keep_remote_after_local_delete',{tombstoneId:t.id,mediaId:t.providerId}); store.write(d); return send(res,200,{mode:'live',resolved:true,resolution}); }
        if(!remote)return send(res,409,{error:'Remote entry no longer exists; cannot restore local record'});
        const item=normalize('AniList',remote.media); item.id=crypto.randomUUID(); item.provider='AniList'; item.providerId=String(t.providerId); item.providerMetadata=item.providerMetadata||{}; item.providerMetadata.mediaListEntry=normalizeSyncState(remote); item.providerMetadata.type=t.type; item.providerMetadata.anilistSync={lastSyncedState:normalizeSyncState(remote),localOverride:null,restoredAt:store.now(),restoredFromTombstone:t.id}; d.catalog.unshift(item); d.anilistSyncTombstones.splice(idx,1); store.addAudit(d,'anilist.sync.restore_local_after_local_delete',{tombstoneId:t.id,mediaId:t.providerId,catalogId:item.id}); store.write(d); return send(res,200,{mode:'live',resolved:true,resolution,catalogId:item.id,item});
      }catch(e){return aniError(res,e);}
    }

    if(req.method==='POST' && url.pathname==='/api/anilist/sync/push-apply') {
      const b=await parseBody(req); const actions=Array.isArray(b.actions)?b.actions:[]; if(!actions.length)return send(res,400,{error:'actions[] is required'}); if(actions.length>50)return send(res,400,{error:'Maximum 50 sync actions per request'});
      if(b.demo===true) return send(res,200,{mode:'demo',dryRun:true,applied:actions.length,resolved:actions.length,conflicts:0,errors:[]});
      const auth=await anilist.authStatus(); if(!auth.authenticated)return send(res,401,{error:'Connect AniList before pushing local sync changes'});
      const type=String(b.type||'ANIME').toUpperCase(); if(!['ANIME','MANGA'].includes(type))return send(res,400,{error:'type must be ANIME or MANGA'});
      const userId=b.userId?Number(b.userId):null; const userName=b.userName?String(b.userName):null;
      try{
        const fetched=await fetchAniListListEntries({type,userId:userId||auth.viewer?.id||null,userName,demo:false,limit:250}); const remoteByMedia=new Map(fetched.entries.map(e=>[String(e.mediaId),e]));
        const d=store.read(); let applied=0,resolved=0,remoteResolved=0,localPushed=0; const errors=[];
        for(const action of actions){
          const item=d.catalog.find(x=>x.id===String(action.catalogId)); if(!item||item.provider!=='AniList'){errors.push({catalogId:action.catalogId,error:'Catalog item not found or not an AniList item'});continue;}
          const sync=ensureBaseSnapshot(item); const base=sync.lastSyncedState||item.providerMetadata?.mediaListEntry||null; const localState=mergedSyncState(base,sync.localOverride||{}); const remote=remoteByMedia.get(String(item.providerId))||null; const reso=action.resolution||'local';
          if(reso==='remote'){
            if(!remote){errors.push({catalogId:item.id,error:'Remote list entry no longer exists; choose recreate-remote or delete-local'});continue;}
            item.providerMetadata.mediaListEntry=normalizeSyncState(remote); sync.lastSyncedState=normalizeSyncState(remote); sync.localOverride=null; sync.lastResolvedAt=store.now(); sync.lastResolution='remote'; item.providerMetadata.anilistSync=sync; item.updatedAt=store.now(); store.addAudit(d,'anilist.sync.resolve_remote',{catalogId:item.id,mediaId:item.providerId}); applied++; resolved++; remoteResolved++; continue;
          }
          if(!remote && reso==='delete-local'){
            const idx=d.catalog.findIndex(x=>x.id===item.id); if(idx<0){errors.push({catalogId:item.id,error:'Catalog item no longer exists'});continue;}
            const [deleted]=d.catalog.splice(idx,1); for(const other of d.catalog) other.relations=(other.relations||[]).filter(r=>r.catalogId!==deleted.id); for(const c of d.collections) c.items=(c.items||[]).filter(cid=>cid!==deleted.id);
            store.addAudit(d,'anilist.sync.delete_local_after_remote_delete',{catalogId:deleted.id,mediaId:deleted.providerId}); applied++; resolved++; continue;
          }
          if(!remote && reso!=='recreate-remote' && reso!=='local'){errors.push({catalogId:item.id,error:'Remote entry is missing; choose recreate-remote or delete-local'});continue;}
          const vars={id:remote?.id?Number(remote.id):undefined,mediaId:Number(item.providerId),status:localState.status,score:localState.score,progress:localState.progress,progressVolumes:localState.progressVolumes,repeat:localState.repeat,priority:localState.priority,private:localState.private,notes:localState.notes,hiddenFromStatusLists:localState.hiddenFromStatusLists,customLists:Array.isArray(localState.customLists)?localState.customLists:undefined,advancedScores:Array.isArray(localState.advancedScores)?localState.advancedScores:undefined,startedAt:localState.startedAt||undefined,completedAt:localState.completedAt||undefined};
          try{const r=await anilist.graph(anilist.SAVE_LIST_MUTATION,vars,{cache:false,allowRetry:false}); const saved=r.data?.SaveMediaListEntry||null; if(!saved)throw new Error('AniList did not return SaveMediaListEntry'); item.providerMetadata.mediaListEntry=normalizeSyncState(saved); sync.lastSyncedState=normalizeSyncState(saved); sync.localOverride=null; sync.lastResolvedAt=store.now(); sync.lastResolution='local'; sync.lastPushedAt=store.now(); item.providerMetadata.anilistSync=sync; item.updatedAt=store.now(); store.addAudit(d,'anilist.sync.push',{catalogId:item.id,mediaId:item.providerId,listEntryId:saved.id}); applied++; resolved++; localPushed++;}catch(e){errors.push({catalogId:item.id,error:e.message});}
        }
        if(applied)store.write(d); return send(res,200,{mode:'live',applied,resolved,localPushed,remoteResolved,errors,rateLimit:fetched.rateLimit});
      }catch(e){return aniError(res,e);}
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/sync/list-options') {
      const type=String(url.searchParams.get('type')||'ANIME').toUpperCase(); if(!['ANIME','MANGA'].includes(type))return send(res,400,{error:'type must be ANIME or MANGA'}); const demo=url.searchParams.get('demo')==='1'; if(demo)return send(res,200,anilist.USER_LIST_OPTIONS_DEMO);
      const id=intParam(url.searchParams,'id'); const name=url.searchParams.get('name')||null; if(!id&&!name){const a=await anilist.authStatus(); if(a.authenticated)return send(res,200,{mode:'live',user:{id:a.viewer.id,name:a.viewer.name,mediaListOptions:a.viewer.mediaListOptions},rateLimit:a.rateLimit}); return send(res,401,{error:'Connect AniList or provide a user id/name'});}
      try{const r=await anilist.graph(anilist.USER_LIST_OPTIONS_QUERY,{id,name}); return send(res,200,{mode:'live',user:r.data.User,rateLimit:r.rateLimit});}catch(e){return aniError(res,e);}
    }
    if(req.method==='POST' && url.pathname==='/api/anilist/sync/list-options') {
      const b=await parseBody(req); const type=String(b.type||'ANIME').toUpperCase(); if(!['ANIME','MANGA'].includes(type))return send(res,400,{error:'type must be ANIME or MANGA'});
      if(b.demo===true)return send(res,200,{mode:'demo',dryRun:true,updated:false});
      const source=b.options&&typeof b.options==='object'?b.options:{}; const options={}; const validScoreFormats=new Set(['POINT_100','POINT_10_DECIMAL','POINT_10','POINT_5','POINT_3']); if(b.scoreFormat!==undefined&&b.scoreFormat!==null&&!validScoreFormats.has(String(b.scoreFormat))) return send(res,400,{error:'Invalid scoreFormat'});
      for(const k of ['sectionOrder','splitCompletedSectionByFormat','customLists','advancedScoring','advancedScoringEnabled']){if(source[k]!==undefined)options[k]=source[k];}
      if(options.sectionOrder!==undefined&&!Array.isArray(options.sectionOrder))return send(res,400,{error:'sectionOrder must be an array'});
      for(const k of ['customLists','advancedScoring']) if(options[k]!==undefined&&!Array.isArray(options[k]))return send(res,400,{error:`${k} must be an array`});
      const vars={scoreFormat:b.scoreFormat||undefined,rowOrder:b.rowOrder||undefined}; if(type==='ANIME')vars.animeListOptions=options; else vars.mangaListOptions=options;
      try{const r=await anilist.graph(anilist.UPDATE_USER_MUTATION,vars,{cache:false,allowRetry:false}); return send(res,200,{mode:'live',data:r.data?.UpdateUser||null,rateLimit:r.rateLimit});}catch(e){return aniError(res,e);}
    }
    if(req.method==='POST' && url.pathname==='/api/anilist/sync/pull-apply') {
      const b=await parseBody(req); const type=String(b.type||'ANIME').toUpperCase(); if(!['ANIME','MANGA'].includes(type)) return send(res,400,{error:'type must be ANIME or MANGA'});
      const catalogIds=Array.isArray(b.catalogIds)?b.catalogIds.map(String).filter(Boolean).slice(0,100):[]; if(!catalogIds.length)return send(res,400,{error:'catalogIds[] is required'});
      const demo=b.demo===true; let userId=b.userId?Number(b.userId):null; const userName=b.userName?String(b.userName):null;
      try{
        if(demo) return send(res,200,{mode:'demo',applied:Math.min(catalogIds.length,1),missing:Math.max(0,catalogIds.length-1),rateLimit:null});
        if(!demo&&!userId&&!userName)userId=await resolveSyncUserId(null,null);
        if(!demo&&!userId&&!userName)return send(res,401,{error:'Connect AniList or provide userId/userName'});
        const fetched=await fetchAniListListEntries({type,userId,userName,limit:250,demo});
        const remote=new Map(fetched.entries.map(e=>[String(e.mediaId),e])); const d=store.read(); let applied=0,missing=0;
        for(const cid of catalogIds){const item=d.catalog.find(x=>x.id===cid); if(!item||item.provider!=='AniList'){missing++;continue;} const e=remote.get(String(item.providerId)); if(!e){missing++;continue;} item.providerMetadata=item.providerMetadata&&typeof item.providerMetadata==='object'?item.providerMetadata:{}; item.providerMetadata.mediaListEntry=normalizeSyncState(e); item.providerMetadata.anilistSync={lastPulledAt:store.now(),remoteUpdatedAt:e.updatedAt??null,lastSyncedState:normalizeSyncState(e),localOverride:null}; item.updatedAt=store.now(); store.addAudit(d,'anilist.sync.pull',{catalogId:item.id,mediaId:e.mediaId,listEntryId:e.id,type}); applied++;}
        if(applied)store.write(d); return send(res,200,{mode:fetched.mode,applied,missing,rateLimit:fetched.rateLimit});
      }catch(e){return aniError(res,e);}
    }
    if(req.method==='POST' && url.pathname==='/api/anilist/sync/queue-remote-only') {
      const b=await parseBody(req); const type=String(b.type||'ANIME').toUpperCase(); const demo=b.demo===true; const limit=Math.min(250,Math.max(1,Number(b.limit||100))); let userId=b.userId?Number(b.userId):null; const userName=b.userName?String(b.userName):null; if(!['ANIME','MANGA'].includes(type))return send(res,400,{error:'type must be ANIME or MANGA'});
      try{
        if(demo) return send(res,200,{mode:'demo',queued:2,skipped:0,dryRun:true,rateLimit:null});
        if(!demo&&!userId&&!userName)userId=await resolveSyncUserId(null,null); if(!demo&&!userId&&!userName)return send(res,401,{error:'Connect AniList or provide userId/userName'});
        const fetched=await fetchAniListListEntries({type,userId,userName,limit,demo:false}); const d=store.read(); const localIds=new Set(d.catalog.filter(x=>x.provider==='AniList').map(x=>String(x.providerId))); const queuedIds=new Set(d.reviewQueue.filter(x=>['pending','approved'].includes(x.status)).map(x=>String(x.normalized?.providerId))); let queued=0,skipped=0;
        for(const e of fetched.entries){ if(!e?.mediaId || localIds.has(String(e.mediaId)) || queuedIds.has(String(e.mediaId))) {skipped++;continue;} const n=normalize('AniList',e.media); n.providerMetadata=n.providerMetadata||{}; n.providerMetadata.mediaListEntry=normalizeSyncState(e); n.providerMetadata.anilistSync={source:'list-sync',queuedAt:store.now()}; const review={id:crypto.randomUUID(),status:'pending',createdAt:store.now(),normalized:n}; d.reviewQueue.unshift(review); store.addAudit(d,'anilist.sync.remote_only_queue',{reviewId:review.id,mediaId:e.mediaId,title:n.title,type}); queued++; queuedIds.add(String(e.mediaId)); }
        if(queued)store.write(d); return send(res,200,{mode:fetched.mode,queued,skipped,rateLimit:fetched.rateLimit});
      }catch(e){return aniError(res,e);}
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/lists') {
      const type=(url.searchParams.get('type')||'ANIME').toUpperCase(); const userId=url.searchParams.get('userId')?Number(url.searchParams.get('userId')):null; const userName=url.searchParams.get('userName')||null; const all=url.searchParams.get('all')==='1'; const demo=url.searchParams.get('demo')==='1'; if(demo)return send(res,200,anilist.demoList(type)); if(!userId&&!userName)return send(res,400,{error:'userId or userName is required'});
      try{const r=await anilist.graph(all?anilist.LIST_COLLECTION_QUERY:anilist.LIST_QUERY,all?{type,userId,userName,status:url.searchParams.get('status')||null,notes:url.searchParams.get('notes')||null,startedAt:url.searchParams.get('startedAt')||null,completedAt:url.searchParams.get('completedAt')||null,forceSingleCompletedList:boolParam(url.searchParams,'forceSingleCompletedList')??false,chunk:Math.max(1,intParam(url.searchParams,'chunk')||1),perChunk:Math.min(500,Math.max(1,intParam(url.searchParams,'perChunk')||500)),status_in:listParam(url.searchParams,'status_in'),status_not:url.searchParams.get('status_not')||null,status_not_in:listParam(url.searchParams,'status_not_in'),notes_like:url.searchParams.get('notes_like')||null,startedAt_greater:intParam(url.searchParams,'startedAt_greater'),startedAt_lesser:intParam(url.searchParams,'startedAt_lesser'),startedAt_like:url.searchParams.get('startedAt_like')||null,completedAt_greater:intParam(url.searchParams,'completedAt_greater'),completedAt_lesser:intParam(url.searchParams,'completedAt_lesser'),completedAt_like:url.searchParams.get('completedAt_like')||null}:{id:intParam(url.searchParams,'id'),userId,userName,type,status:url.searchParams.get('status')||null,mediaId:intParam(url.searchParams,'mediaId'),isFollowing:boolParam(url.searchParams,'isFollowing'),notes:url.searchParams.get('notes')||null,startedAt:url.searchParams.get('startedAt')||null,completedAt:url.searchParams.get('completedAt')||null,compareWithAuthList:boolParam(url.searchParams,'compareWithAuthList'),userId_in:listParam(url.searchParams,'userId_in')?.map(Number),status_in:listParam(url.searchParams,'status_in'),status_not:url.searchParams.get('status_not')||null,status_not_in:listParam(url.searchParams,'status_not_in'),mediaId_in:listParam(url.searchParams,'mediaId_in')?.map(Number),mediaId_not_in:listParam(url.searchParams,'mediaId_not_in')?.map(Number),notes_like:url.searchParams.get('notes_like')||null,startedAt_greater:intParam(url.searchParams,'startedAt_greater'),startedAt_lesser:intParam(url.searchParams,'startedAt_lesser'),startedAt_like:url.searchParams.get('startedAt_like')||null,completedAt_greater:intParam(url.searchParams,'completedAt_greater'),completedAt_lesser:intParam(url.searchParams,'completedAt_lesser'),completedAt_like:url.searchParams.get('completedAt_like')||null,sort:listParam(url.searchParams,'sort'),page:Number(url.searchParams.get('page')||1)});return send(res,200,{mode:'live',data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}
    }
    const ps=[['character','CHARACTER_SEARCH_QUERY'],['staff','STAFF_SEARCH_QUERY'],['studio','STUDIO_SEARCH_QUERY']];
    for(const [kind,key] of ps){ if(req.method==='GET'&&url.pathname===`/api/anilist/${kind}/search`){const q=url.searchParams.get('q')||''; if(!q)return send(res,400,{error:'q is required'}); try{const p=url.searchParams;const vars={id:intParam(p,'id'),isBirthday:boolParam(p,'isBirthday'),search:q,id_not:intParam(p,'id_not'),id_in:aniIdList(p,'id_in'),id_not_in:aniIdList(p,'id_not_in'),sort:listParam(p,'sort')||null,page:Number(p.get('page')||1)}; if(kind==='studio') delete vars.isBirthday; const r=await anilist.graph(anilist[key],vars); return send(res,200,{mode:'live',page:r.data.Page,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}}
    if(req.method==='GET' && url.pathname==='/api/anilist/user') { const v=aniUserVars(url); if(!v.id&&!v.name&&!v.search)return send(res,400,{error:'id, name, or search is required'}); try{const r=await anilist.graph(anilist.USER_PROFILE_QUERY,v);return send(res,200,{mode:'live',user:r.data.User,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});} }
    if(req.method==='GET' && url.pathname==='/api/anilist/like'){const id=intParam(url.searchParams,'likeableId');const type=url.searchParams.get('type')||null;if(!id||!type)return send(res,400,{error:'likeableId and type are required'});if(url.searchParams.get('demo')==='1')return send(res,200,{mode:'demo',users:[{id:7001,name:'DemoReader'},{id:7002,name:'DemoWriter'}]});try{const r=await anilist.graph(`query($likeableId:Int!,$type:LikeableType!){Like(likeableId:$likeableId,type:$type){id name}}`,{likeableId:id,type});return send(res,200,{mode:'live',users:r.data.Like,rateLimit:r.rateLimit});}catch(e){return aniError(res,e);}}
    if(req.method==='POST' && url.pathname==='/api/anilist/markdown'){const b=await parseBody(req);const markdown=String(b.markdown||'').trim();if(!markdown)return send(res,400,{error:'markdown is required'});if(b.demo)return send(res,200,{mode:'demo',data:{html:markdown.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/`(.+?)`/g,'<code>$1</code>')}});try{const r=await anilist.graph(`query($markdown:String!){Markdown(markdown:$markdown){html}}`,{markdown});return send(res,200,{mode:'live',data:r.data.Markdown,rateLimit:r.rateLimit});}catch(e){return aniError(res,e);}}
    if(req.method==='GET' && url.pathname==='/api/anilist/site-statistics'){if(url.searchParams.get('demo')==='1')return send(res,200,anilist.demoSiteStatistics());try{const p=url.searchParams;const clamp=(v,min,max)=>Math.min(max,Math.max(min,Number(v)||min));const shared={status:intParam(p,'status'),perPage:clamp(p.get('perPage'),1,25)};for(const k of ['users','anime','manga','characters','staff','studios','reviews'])shared[k+'Page']=clamp(p.get(k+'Page'),1,9999);const r=await anilist.graph(anilist.SITE_STATS_QUERY,shared);return send(res,200,{mode:'live',data:r.data.SiteStatistics,rateLimit:r.rateLimit});}catch(e){return aniError(res,e);}}
    if(req.method==='GET' && url.pathname==='/api/anilist/external-sources'){if(url.searchParams.get('demo')==='1')return send(res,200,anilist.demoExternalSources());try{const r=await anilist.graph(anilist.EXTERNAL_SOURCES_QUERY,{id:intParam(url.searchParams,'id'),type:url.searchParams.get('type')||null,mediaType:url.searchParams.get('mediaType')||null});return send(res,200,{mode:'live',data:r.data.ExternalLinkSourceCollection,rateLimit:r.rateLimit});}catch(e){return aniError(res,e);}}
    if(req.method==='GET' && url.pathname==='/api/anilist/field-audit') return send(res,200,anilist.fieldCoverage());
    if(req.method==='GET' && url.pathname==='/api/anilist/reference-audit'){return send(res,200,{version:VERSION,documentation:'current AniList API reference',queryRootCount:Object.keys(anilist.ROOT_QUERY_COVERAGE).length,mutationRootCount:Object.keys(anilist.MUTATION_COVERAGE).length,queryRoots:Object.keys(anilist.ROOT_QUERY_COVERAGE),mutationRoots:Object.keys(anilist.MUTATION_COVERAGE),dedicatedQueryFamilies:['Media','MediaList','MediaListCollection','User','Character','Staff','Studio','Activity','ActivityReply','Following','Follower','Thread','ThreadComment','Review','Recommendation','AiringSchedule','MediaTrend','Notification','Like','Markdown','GenreCollection','MediaTagCollection','SiteStatistics','ExternalLinkSourceCollection','AniChartUser'],notes:['Dedicated query families expose the documented root arguments used by OmniShelf.','The generic GraphQL gateway remains the full schema escape hatch.','Live schema execution requires outbound network access.']});}
    if(req.method==='GET' && url.pathname==='/api/anilist/live-readiness') return send(res,200,anilist.liveReadiness());
if(req.method==='GET' && url.pathname==='/api/anilist/static-read-matrix') return send(res,200,anilist.staticReadMatrix());
    if(req.method==='POST' && url.pathname==='/api/anilist/schema-audit') { try { const r=await anilist.schemaAudit(); return send(res,200,r); } catch(e) { return send(res,e.status===451?451:e.status===429?429:502,{error:e.message,code:e.code||null,rateLimit:e.rateLimit||null}); } }
    if(req.method==='POST' && url.pathname==='/api/anilist/full-read-acceptance') {
      try { const b=await parseBody(req); if(b.confirm!=='RUN-ANILIST-READ-ACCEPTANCE') return send(res,400,{error:'confirmation token required'}); const r=await anilist.runFullReadAcceptance({timeoutMs:b.timeoutMs||8000}); const status=r.summary.blocked?451:(r.summary.failed?502:200); return send(res,status,r); } catch(e) { return send(res,e.status===451?451:502,{error:e.message,code:e.code||null}); }
    }
    if(req.method==='POST' && url.pathname==='/api/anilist/live-acceptance') {
      const b=await parseBody(req);
      if(String(b.confirm||'')!=='RUN_READ_ONLY_ACCEPTANCE') return send(res,400,{error:'confirm=RUN_READ_ONLY_ACCEPTANCE is required'});
      try { const result=await anilist.runReadOnlyAcceptance({requireAuth:Boolean(b.requireAuth)}); return send(res,result.summary?.blocked?451:(result.summary?.failed?502:200),result); }
      catch(e){ return send(res,e.status===451?451:502,{error:e.message,code:e.code||null,status:e.status||502}); }
    }
    if(req.method==='GET' && url.pathname==='/api/anilist/capabilities') return send(res,200,{version:VERSION,...anilist.coverage(),compliance:anilist.liveAccessPolicy(),hardening:{mediaBrowseFilters:'full-reference',publicQueryCache:true,cacheMaxEntries:150,defaultCacheTtlMs:20000,liveHealthProbe:'/api/anilist/health?live=1',liveReadiness:'/api/anilist/live-readiness',liveAcceptance:'/api/anilist/live-acceptance'}});
    if(req.method==='POST' && url.pathname==='/api/anilist/introspect') { try { const r=await anilist.introspect(); return send(res,200,{schema:r.data.__schema,rateLimit:r.rateLimit}); } catch(e) { return send(res,e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null}); } }
    if(req.method==='POST'&&url.pathname==='/api/anilist/graphql'){const b=await parseBody(req);const query=String(b.query||'').trim();if(!query)return send(res,400,{error:'query is required'});if(query.length>ANILIST_MAX_QUERY_CHARS)return send(res,413,{error:`query exceeds ${ANILIST_MAX_QUERY_CHARS} characters`});const vars=b.variables&&typeof b.variables==='object'?b.variables:{};if(Buffer.byteLength(JSON.stringify(vars),'utf8')>ANILIST_MAX_VARIABLES_BYTES)return send(res,413,{error:`variables exceed ${ANILIST_MAX_VARIABLES_BYTES} bytes`});try{const r=await anilist.graph(query,vars);return send(res,200,{data:r.data,rateLimit:r.rateLimit,cached:!!r.cached,cacheAgeMs:r.ageMs??null});}catch(e){return aniError(res,e);}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/list-entry'){const b=await parseBody(req); if(!b.mediaId && !b.id)return send(res,400,{error:'mediaId or id is required'}); try{const r=await anilist.graph(anilist.SAVE_LIST_MUTATION,{mediaId:b.mediaId?Number(b.mediaId):undefined,id:b.id?Number(b.id):undefined,status:b.status,score:b.score===null||b.score===undefined?b.score:Number(b.score),scoreRaw:b.scoreRaw===null||b.scoreRaw===undefined?b.scoreRaw:Number(b.scoreRaw),progress:b.progress===null||b.progress===undefined?b.progress:Number(b.progress),progressVolumes:b.progressVolumes===null||b.progressVolumes===undefined?b.progressVolumes:Number(b.progressVolumes),repeat:b.repeat===null||b.repeat===undefined?b.repeat:Number(b.repeat),priority:b.priority===null||b.priority===undefined?b.priority:Number(b.priority),private:b.private,notes:b.notes,hiddenFromStatusLists:b.hiddenFromStatusLists,customLists:b.customLists,advancedScores:Array.isArray(b.advancedScores)?b.advancedScores.map(Number):b.advancedScores,startedAt:b.startedAt||null,completedAt:b.completedAt||null});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/list-entries/bulk'){const b=await parseBody(req);if(!Array.isArray(b.ids)||!b.ids.length)return send(res,400,{error:'ids[] is required'});if(b.ids.length>50)return send(res,400,{error:'Maximum 50 list entry IDs per bulk mutation'});const vars={ids:b.ids.map(Number),status:b.status||null,score:b.score===null||b.score===undefined?b.score:Number(b.score),scoreRaw:b.scoreRaw===null||b.scoreRaw===undefined?b.scoreRaw:Number(b.scoreRaw),progress:b.progress===null||b.progress===undefined?b.progress:Number(b.progress),progressVolumes:b.progressVolumes===null||b.progressVolumes===undefined?b.progressVolumes:Number(b.progressVolumes),repeat:b.repeat===null||b.repeat===undefined?b.repeat:Number(b.repeat),priority:b.priority===null||b.priority===undefined?b.priority:Number(b.priority),private:b.private,notes:b.notes,hiddenFromStatusLists:b.hiddenFromStatusLists,advancedScores:Array.isArray(b.advancedScores)?b.advancedScores.map(Number):b.advancedScores,startedAt:b.startedAt||null,completedAt:b.completedAt||null};try{const r=await anilist.graph(anilist.UPDATE_LISTS_MUTATION,vars);return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    const ae=url.pathname.match(/^\/api\/anilist\/list-entry\/(\d+)$/); if(req.method==='DELETE'&&ae){try{const r=await anilist.graph(anilist.DELETE_LIST_MUTATION,{id:Number(ae[1])});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/favourite'){const b=await parseBody(req);try{const r=await anilist.graph(anilist.TOGGLE_FAVOURITE_MUTATION,b);return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/review'){const b=await parseBody(req);try{const r=await anilist.graph(anilist.SAVE_REVIEW_MUTATION,b);return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:502,{error:e.message,rateLimit:e.rateLimit||null});}}


    if(req.method==='GET'&&url.pathname==='/api/anilist/social/users'){const q=url.searchParams.get('q')||'';const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,anilist.demoSocial('users'));const p=url.searchParams;try{const r=await anilist.graph(anilist.USER_SEARCH_QUERY,{id:intParam(p,'id'),name:p.get('name')||null,isModerator:boolParam(p,'isModerator'),search:q||p.get('search')||null,sort:listParam(p,'sort')||null,page:Number(p.get('page')||1)});return send(res,200,{mode:'live',page:r.data.Page,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&(/^\/api\/anilist\/social\/(following|followers)$/.test(url.pathname))){const kind=url.pathname.endsWith('/following')?'following':'followers';const demo=url.searchParams.get('demo')==='1';const userId=Number(url.searchParams.get('userId')||0);if(demo)return send(res,200,anilist.demoSocial(kind));if(!userId)return send(res,400,{error:'userId is required'});try{const r=await anilist.graph(kind==='following'?anilist.FOLLOWING_QUERY:anilist.FOLLOWER_QUERY,{userId,sort:listParam(url.searchParams,'sort')||null});return send(res,200,{mode:'live',users:r.data?.[kind==='following'?'Following':'Follower']||[],rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname==='/api/anilist/social/activities'){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,anilist.demoSocial('activities'));const p=url.searchParams;const v={page:Number(p.get('page')||1),id:intParam(p,'id'),userId:intParam(p,'userId'),messengerId:intParam(p,'messengerId'),mediaId:intParam(p,'mediaId'),isFollowing:boolParam(p,'isFollowing'),type:p.get('type')||null,hasReplies:boolParam(p,'hasReplies'),hasRepliesOrTypeText:boolParam(p,'hasRepliesOrTypeText'),createdAt:intParam(p,'createdAt'),id_not:intParam(p,'id_not'),id_in:aniIdList(p,'id_in'),id_not_in:aniIdList(p,'id_not_in'),userId_not:intParam(p,'userId_not'),userId_in:aniIdList(p,'userId_in'),userId_not_in:aniIdList(p,'userId_not_in'),messengerId_not:intParam(p,'messengerId_not'),messengerId_in:aniIdList(p,'messengerId_in'),messengerId_not_in:aniIdList(p,'messengerId_not_in'),mediaId_not:intParam(p,'mediaId_not'),mediaId_in:aniIdList(p,'mediaId_in'),mediaId_not_in:aniIdList(p,'mediaId_not_in'),type_not:p.get('type_not')||null,type_in:listParam(p,'type_in')||null,type_not_in:listParam(p,'type_not_in')||null,createdAt_greater:intParam(p,'createdAt_greater'),createdAt_lesser:intParam(p,'createdAt_lesser'),sort:listParam(p,'sort')||null};try{const r=await anilist.graph(anilist.ACTIVITY_PAGE_QUERY,v);return send(res,200,{mode:'live',page:r.data.Page,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname==='/api/anilist/social/threads'){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,anilist.demoSocial('threads'));try{const p=url.searchParams;const r=await anilist.graph(anilist.THREAD_PAGE_QUERY,{page:Number(p.get('page')||1),id:intParam(p,'id'),search:p.get('q')||p.get('search')||null,userId:intParam(p,'userId'),replyUserId:intParam(p,'replyUserId'),subscribed:boolParam(p,'subscribed'),categoryId:intParam(p,'categoryId'),mediaCategoryId:intParam(p,'mediaCategoryId'),id_in:aniIdList(p,'id_in'),sort:listParam(p,'sort')||null});return send(res,200,{mode:'live',page:r.data.Page,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname==='/api/anilist/social/reviews'){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,anilist.demoSocial('reviews'));try{const p=url.searchParams;const r=await anilist.graph(anilist.REVIEW_PAGE_QUERY,{page:Number(p.get('page')||1),id:intParam(p,'id'),mediaId:intParam(p,'mediaId'),userId:intParam(p,'userId'),mediaType:p.get('mediaType')||null,sort:listParam(p,'sort')||null});return send(res,200,{mode:'live',page:r.data.Page,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname==='/api/anilist/social/recommendations'){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,anilist.demoSocial('recommendations'));try{const p=url.searchParams;const r=await anilist.graph(anilist.RECOMMENDATION_PAGE_QUERY,{page:Number(p.get('page')||1),id:intParam(p,'id'),mediaId:intParam(p,'mediaId'),mediaRecommendationId:intParam(p,'mediaRecommendationId'),userId:intParam(p,'userId'),rating:intParam(p,'rating'),onList:boolParam(p,'onList'),rating_greater:intParam(p,'rating_greater'),rating_lesser:intParam(p,'rating_lesser'),sort:listParam(p,'sort')||null});return send(res,200,{mode:'live',page:r.data.Page,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname==='/api/anilist/social/airing'){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,anilist.demoSocial('airing'));try{const r=await anilist.graph(anilist.AIRING_PAGE_QUERY,{page:Number(url.searchParams.get('page')||1),id:intParam(url.searchParams,'id'),mediaId:intParam(url.searchParams,'mediaId'),episode:intParam(url.searchParams,'episode'),airingAt:intParam(url.searchParams,'airingAt'),notYetAired:boolParam(url.searchParams,'notYetAired'),id_not:intParam(url.searchParams,'id_not'),id_in:aniIdList(url.searchParams,'id_in'),id_not_in:aniIdList(url.searchParams,'id_not_in'),mediaId_not:intParam(url.searchParams,'mediaId_not'),mediaId_in:aniIdList(url.searchParams,'mediaId_in'),mediaId_not_in:aniIdList(url.searchParams,'mediaId_not_in'),episode_not:intParam(url.searchParams,'episode_not'),episode_in:aniIdList(url.searchParams,'episode_in'),episode_not_in:aniIdList(url.searchParams,'episode_not_in'),episode_greater:intParam(url.searchParams,'episode_greater'),episode_lesser:intParam(url.searchParams,'episode_lesser'),airingAt_greater:intParam(url.searchParams,'airingAt_greater'),airingAt_lesser:intParam(url.searchParams,'airingAt_lesser'),sort:listParam(url.searchParams,'sort')||null});return send(res,200,{mode:'live',page:r.data.Page,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname==='/api/anilist/social/trends'){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,anilist.demoSocial('trends'));try{const r=await anilist.graph(anilist.TREND_PAGE_QUERY,{page:Number(url.searchParams.get('page')||1),mediaId:intParam(url.searchParams,'mediaId'),date:intParam(url.searchParams,'date'),trending:intParam(url.searchParams,'trending'),averageScore:intParam(url.searchParams,'averageScore'),popularity:intParam(url.searchParams,'popularity'),episode:intParam(url.searchParams,'episode'),releasing:boolParam(url.searchParams,'releasing'),mediaId_not:intParam(url.searchParams,'mediaId_not'),mediaId_in:aniIdList(url.searchParams,'mediaId_in'),mediaId_not_in:aniIdList(url.searchParams,'mediaId_not_in'),date_greater:intParam(url.searchParams,'date_greater'),date_lesser:intParam(url.searchParams,'date_lesser'),trending_greater:intParam(url.searchParams,'trending_greater'),trending_lesser:intParam(url.searchParams,'trending_lesser'),trending_not:intParam(url.searchParams,'trending_not'),averageScore_greater:intParam(url.searchParams,'averageScore_greater'),averageScore_lesser:intParam(url.searchParams,'averageScore_lesser'),averageScore_not:intParam(url.searchParams,'averageScore_not'),popularity_greater:intParam(url.searchParams,'popularity_greater'),popularity_lesser:intParam(url.searchParams,'popularity_lesser'),popularity_not:intParam(url.searchParams,'popularity_not'),episode_greater:intParam(url.searchParams,'episode_greater'),episode_lesser:intParam(url.searchParams,'episode_lesser'),episode_not:intParam(url.searchParams,'episode_not'),sort:listParam(url.searchParams,'sort')||null});return send(res,200,{mode:'live',page:r.data.Page,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname==='/api/anilist/social/notifications'){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,anilist.demoSocial('notifications'));try{const r=await anilist.graph(anilist.NOTIFICATION_PAGE_QUERY,{page:Number(url.searchParams.get('page')||1),type:url.searchParams.get('type')||null,typeIn:listParam(url.searchParams,'type_in')||null,resetNotificationCount:boolParam(url.searchParams,'resetNotificationCount')});return send(res,200,{mode:'live',page:r.data.Page,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname==='/api/anilist/social/favourites'){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,anilist.demoSocial('favourites'));try{const page=Math.max(1,Number(url.searchParams.get('page')||'1')||1); const perPage=Math.min(25,Math.max(1,Number(url.searchParams.get('perPage')||'25')||25)); const r=await anilist.graph(anilist.USER_FAVOURITES_QUERY,{id:url.searchParams.get('id')?Number(url.searchParams.get('id')):null,name:url.searchParams.get('name')||null,page,perPage});return send(res,200,{mode:'live',user:r.data.User,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname==='/api/anilist/social/genres'){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,anilist.demoSocial('genres'));try{const r=await anilist.graph(anilist.GENRES_QUERY,{});return send(res,200,{mode:'live',data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname==='/api/anilist/social/tags'){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,anilist.demoSocial('tags'));try{const r=await anilist.graph(anilist.TAGS_QUERY,{});return send(res,200,{mode:'live',data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname==='/api/anilist/social/settings'){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,anilist.demoSocial('settings'));try{const r=await anilist.graph(anilist.USER_SETTINGS_QUERY,{});return send(res,200,{mode:'live',viewer:r.data.Viewer,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/social/settings'){const b=await parseBody(req);try{const r=await anilist.graph(anilist.UPDATE_USER_MUTATION,b);return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/social/follow'){const b=await parseBody(req);if(!b.userId)return send(res,400,{error:'userId is required'});try{const r=await anilist.graph(anilist.TOGGLE_FOLLOW_MUTATION,{userId:Number(b.userId)});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/social/activity'){const b=await parseBody(req);if(!String(b.text||'').trim())return send(res,400,{error:'text is required'});try{const r=await anilist.graph(anilist.SAVE_TEXT_ACTIVITY_MUTATION,{id:b.id?Number(b.id):null,text:String(b.text),locked:b.locked});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/social/activity/reply'){const b=await parseBody(req);if(!b.activityId||!String(b.text||'').trim())return send(res,400,{error:'activityId and text are required'});try{const r=await anilist.graph(anilist.SAVE_ACTIVITY_REPLY_MUTATION,{id:b.id?Number(b.id):null,activityId:Number(b.activityId),text:String(b.text)});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='DELETE'&&/^\/api\/anilist\/social\/activity\/\d+$/.test(url.pathname)){const id=Number(url.pathname.split('/').pop());try{const r=await anilist.graph(anilist.DELETE_ACTIVITY_MUTATION,{id});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/social/activity/pin'){const b=await parseBody(req);try{const r=await anilist.graph(anilist.TOGGLE_ACTIVITY_PIN_MUTATION,{id:Number(b.id),pinned:Boolean(b.pinned)});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/social/activity/subscribe'){const b=await parseBody(req);try{const r=await anilist.graph(anilist.TOGGLE_ACTIVITY_SUBSCRIPTION_MUTATION,{activityId:Number(b.activityId),subscribe:Boolean(b.subscribe)});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/social/like'){const b=await parseBody(req);if(!b.id||!b.type)return send(res,400,{error:'id and type are required'});try{const r=await anilist.graph(anilist.TOGGLE_LIKE_MUTATION,{id:Number(b.id),type:String(b.type)});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/social/message'){const b=await parseBody(req);if(!String(b.message||'').trim()||!b.recipientId)return send(res,400,{error:'message and recipientId are required'});try{const r=await anilist.graph(anilist.SAVE_MESSAGE_ACTIVITY_MUTATION,{id:b.id?Number(b.id):null,message:String(b.message),recipientId:Number(b.recipientId),private:b.private,locked:b.locked,asMod:b.asMod});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/social/activity/list'){const b=await parseBody(req);if(!b.id)return send(res,400,{error:'id is required'});try{const r=await anilist.graph(anilist.SAVE_LIST_ACTIVITY_MUTATION,{id:Number(b.id),locked:b.locked});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/social/like-v2'){const b=await parseBody(req);if(!b.id||!b.type)return send(res,400,{error:'id and type are required'});try{const r=await anilist.graph(anilist.TOGGLE_LIKE_V2_MUTATION,{id:Number(b.id),type:String(b.type)});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/favourite/order'){const b=await parseBody(req);const vars={};for(const k of ['animeIds','mangaIds','characterIds','staffIds','studioIds','animeOrder','mangaOrder','characterOrder','staffOrder','studioOrder']){if(b[k]!==undefined){if(!Array.isArray(b[k]))return send(res,400,{error:`${k} must be an array`});vars[k]=b[k].map(Number);}}if(!Object.keys(vars).length)return send(res,400,{error:'At least one order array is required'});try{const r=await anilist.graph(anilist.UPDATE_FAVOURITE_ORDER_MUTATION,vars);return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname==='/api/anilist/anichart/user'){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,{mode:'demo',data:{__typename:'AniChartUser',authenticated:true}});try{const r=await anilist.graph(anilist.ANICHART_USER_QUERY,{});return send(res,200,{mode:'live',data:r.data.AniChartUser,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/anichart/settings'){const b=await parseBody(req);try{const r=await anilist.graph(anilist.UPDATE_ANICHART_SETTINGS_MUTATION,{titleLanguage:b.titleLanguage??null,outgoingLinkProvider:b.outgoingLinkProvider??null,theme:b.theme??null,sort:b.sort??null});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/anichart/highlights'){const b=await parseBody(req);if(!Array.isArray(b.highlights))return send(res,400,{error:'highlights[] is required'});try{const r=await anilist.graph(anilist.UPDATE_ANICHART_HIGHLIGHTS_MUTATION,{highlights:b.highlights});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/custom-list/delete'){const b=await parseBody(req);if(!b.customList||!b.type)return send(res,400,{error:'customList and type are required'});try{const r=await anilist.graph(anilist.DELETE_CUSTOM_LIST_MUTATION,{customList:String(b.customList),type:String(b.type)});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/recommendation'){const b=await parseBody(req);if(!b.mediaId||!b.mediaRecommendationId)return send(res,400,{error:'mediaId and mediaRecommendationId are required'});try{const r=await anilist.graph(anilist.SAVE_RECOMMENDATION_MUTATION,{mediaId:Number(b.mediaId),mediaRecommendationId:Number(b.mediaRecommendationId),rating:b.rating||null});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/review/delete'){const b=await parseBody(req);try{const r=await anilist.graph(anilist.DELETE_REVIEW_MUTATION,{id:Number(b.id)});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/review/rate'){const b=await parseBody(req);try{const r=await anilist.graph(anilist.RATE_REVIEW_MUTATION,{reviewId:Number(b.reviewId),rating:String(b.rating)});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/thread'){const b=await parseBody(req);if(!String(b.title||'').trim()||!String(b.body||'').trim())return send(res,400,{error:'title and body are required'});try{const r=await anilist.graph(anilist.SAVE_THREAD_MUTATION,{id:b.id?Number(b.id):null,title:String(b.title),body:String(b.body),categories:Array.isArray(b.categories)?b.categories.map(Number):null,mediaCategories:Array.isArray(b.mediaCategories)?b.mediaCategories.map(Number):null,sticky:b.sticky,locked:b.locked});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='DELETE'&&/^\/api\/anilist\/thread\/\d+$/.test(url.pathname)){const id=Number(url.pathname.split('/').pop());try{const r=await anilist.graph(anilist.DELETE_THREAD_MUTATION,{id});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/thread/subscribe'){const b=await parseBody(req);try{const r=await anilist.graph(anilist.TOGGLE_THREAD_SUBSCRIPTION_MUTATION,{threadId:Number(b.threadId),subscribe:Boolean(b.subscribe)});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='POST'&&url.pathname==='/api/anilist/thread/comment'){const b=await parseBody(req);if(!b.threadId||!String(b.comment||'').trim())return send(res,400,{error:'threadId and comment are required'});try{const r=await anilist.graph(anilist.SAVE_THREAD_COMMENT_MUTATION,{id:b.id?Number(b.id):null,threadId:Number(b.threadId),parentCommentId:b.parentCommentId?Number(b.parentCommentId):null,comment:String(b.comment),locked:b.locked});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='GET'&&url.pathname.startsWith('/api/anilist/thread-comments')){const demo=url.searchParams.get('demo')==='1';if(demo)return send(res,200,{mode:'demo',page:{threadComments:[]}});try{const r=await anilist.graph(anilist.THREAD_COMMENT_QUERY,{page:Number(url.searchParams.get('page')||1),id:intParam(url.searchParams,'id'),threadId:intParam(url.searchParams,'threadId'),userId:intParam(url.searchParams,'userId'),sort:listParam(url.searchParams,'sort')||null});return send(res,200,{mode:'live',page:r.data.Page,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}
    if(req.method==='DELETE'&&/^\/api\/anilist\/thread\/comment\/\d+$/.test(url.pathname)){const id=Number(url.pathname.split('/').pop());try{const r=await anilist.graph(anilist.DELETE_THREAD_COMMENT_MUTATION,{id});return send(res,200,{data:r.data,rateLimit:r.rateLimit});}catch(e){return send(res,e.status===401?401:e.status===429?429:502,{error:e.message,rateLimit:e.rateLimit||null});}}


    if(req.method==='GET' && url.pathname==='/api/mediums') { const d=store.read(); return send(res,200,{version:VERSION,...mediumExperiences.buildDirectory(d)}); }
    if(req.method==='POST' && url.pathname==='/api/mediums/selftest') { try{return send(res,200,{version:VERSION,...mediumExperiences.selfTest(),mode:'deterministic'});}catch(e){return send(res,500,{version:VERSION,passed:false,error:e.message});} }
    if(req.method==='GET' && url.pathname==='/api/mediums/personal'){ const d=store.read(); return send(res,200,{version:VERSION,readOnly:true,items:mediumPersonal.directory(d)}); }
    if(req.method==='POST' && url.pathname==='/api/mediums/personal/selftest'){ try{return send(res,200,{version:VERSION,...mediumPersonal.selfTest(),mode:'deterministic'});}catch(e){return send(res,500,{version:VERSION,passed:false,error:e.message});} }

    // v0.66 medium-experience provider discovery: read-only TMDB search/discover with regional classification and Review Queue handoff.
    if(req.method==='GET' && url.pathname==='/api/medium/asian-dramas/discover') {
      const demo=url.searchParams.get('demo')==='1', profile=String(url.searchParams.get('profile')||'k-drama'), p=asianDramas.ASIAN_PROFILES.find(x=>x.slug===profile)||asianDramas.ASIAN_PROFILES[0];
      try {
        let providerResults=[];
        if(demo) providerResults=asianDramas.discoveryDemo();
        else {
          const q=String(url.searchParams.get('q')||'').trim();
          const requestedLanguage=String(url.searchParams.get('language')||'').trim(); const lang=requestedLanguage || (p.languageCodes.length===1?p.languageCodes[0]:'');
          const common={page:url.searchParams.get('page')||1,language:url.searchParams.get('providerLanguage')||'en-US',region:url.searchParams.get('region')||null};
          const r=q?await tmdb.search({type:'tv',q,page:common.page,year:url.searchParams.get('year')||null,language:common.language,region:common.region}):await tmdb.discover({type:'tv',page:common.page,sortBy:url.searchParams.get('sort')==='airdate'?'first_air_date.desc':url.searchParams.get('sort')==='quality'?'vote_average.desc':'popularity.desc',language:common.language,region:common.region,withOriginCountry:p.countries[0],withOriginalLanguage:lang});
          providerResults=r.results||[];
        }
        const catalog=store.read().catalog;
        const items=asianDramas.filterDiscovery(providerResults,{q:url.searchParams.get('q'),industry:profile,language:url.searchParams.get('language'),state:url.searchParams.get('state'),year:url.searchParams.get('year'),sort:url.searchParams.get('sort')||'popular',limit:url.searchParams.get('limit')||24});
        const enriched=items.map(x=>({...x,matches:tmdb.findMatches(x,catalog).slice(0,8),identityMatches:identity.listCandidates(x,catalog,store.read(),{limit:8})}));
        return send(res,200,{version:VERSION,mode:demo?'demo':'live',profile:p,query:url.searchParams.get('q')||'',page:Number(url.searchParams.get('page')||1),items:enriched,total:enriched.length,readOnly:true,notes:['Discovery does not mutate the catalog.','Queueing is a separate explicit Review Queue action.']});
      } catch(e){ return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'}); }
    }
    if(req.method==='GET' && url.pathname==='/api/medium/asian-dramas/provider-detail') {
      const demo=url.searchParams.get('demo')==='1', id=url.searchParams.get('id'); if(!id)return send(res,400,{error:'id is required'});
      try { const r=demo?{mode:'demo',normalized:(asianDramas.discoveryDemo().find(x=>String(x.providerId)===String(id))||asianDramas.discoveryDemo()[0])}:{...(await tmdb.getDetails('tv',Number(id),{language:url.searchParams.get('providerLanguage'),region:url.searchParams.get('region')}))}; const asian=asianDramas.normalizeItem(r.normalized); if(!asian)return send(res,422,{error:'The selected TMDB TV record does not meet Asian Drama classification criteria.'}); return send(res,200,{version:VERSION,mode:r.mode,item:asian,normalized:r.normalized,quality:tmdb.qualityReport(r.normalized),matches:tmdb.findMatches(r.normalized,store.read().catalog),identityMatches:identity.listCandidates(r.normalized,store.read().catalog,store.read(),{limit:12}),watchProvidersStatus:tmdb.watchProviderStatus()}); } catch(e){return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'});}
    }
    if(req.method==='GET' && url.pathname==='/api/medium/asian-dramas/watch-providers/status') return send(res,200,{version:VERSION,...tmdb.watchProviderStatus()});
    if(req.method==='GET' && url.pathname==='/api/medium/asian-dramas/watch-providers') {
      const demo=url.searchParams.get('demo')==='1', id=url.searchParams.get('id'); if(!id)return send(res,400,{error:'id is required'});
      try { if(demo)return send(res,200,{version:VERSION,...tmdb.demoWatchProviders(id,url.searchParams.get('region')||'IN')}); const r=await tmdb.getWatchProviders('tv',id,{region:url.searchParams.get('region')||'IN'}); return send(res,200,{version:VERSION,...r}); } catch(e){return send(res,e.status||502,{error:e.message,provider:'TMDB / JustWatch',mode:'blocked'});}
    }
    if(req.method==='POST' && url.pathname==='/api/medium/asian-dramas/ingest-preview') {
      const b=await parseBody(req); if(!b.providerId)return send(res,400,{error:'providerId is required'});
      try { const r=b.demo===true?{mode:'demo',normalized:(asianDramas.discoveryDemo().find(x=>String(x.providerId)===String(b.providerId))||asianDramas.discoveryDemo()[0])}:{...(await tmdb.getDetails('tv',Number(b.providerId),{language:b.language,region:b.region}))}; const asian=asianDramas.normalizeItem(r.normalized); if(!asian)return send(res,422,{error:'Provider record is not classified as an Asian drama.'}); const d=store.read(); const exact=d.catalog.some(x=>x.provider==='TMDB'&&String(x.providerId)===String(r.normalized.providerId)); const matches=tmdb.findMatches(r.normalized,d.catalog); const identityMatches=identity.listCandidates(r.normalized,d.catalog,d,{limit:12}); return send(res,200,{version:VERSION,mode:r.mode,readOnly:true,preview:asian,normalized:r.normalized,quality:tmdb.qualityReport(r.normalized),exactCatalogIdentity:exact,matches,identityMatches,canQueue:!exact,reviewPayload:{title:r.normalized.title,type:r.normalized.type,year:r.normalized.year,description:r.normalized.description,creators:r.normalized.creators,tags:[...(r.normalized.tags||[]),'Asian Drama',asian.profile.short].filter(Boolean),aliases:r.normalized.aliases,externalLinks:r.normalized.externalLinks,coverUrl:r.normalized.coverUrl,provider:'TMDB',providerId:r.normalized.providerId,mediaAssets:r.normalized.mediaAssets,providerMetadata:r.normalized.providerMetadata,raw:r.normalized.raw}}); } catch(e){return send(res,e.status||502,{error:e.message,provider:'TMDB',mode:'blocked'});}
    }
    if(req.method==='GET' && url.pathname==='/api/medium/asian-dramas') {
      const demo=url.searchParams.get('demo')==='1';
      const d=demo ? asianDramas.demoData() : store.read();
      const result=asianDramas.build(d,{
        version:VERSION,
        q:url.searchParams.get('q')||'',
        country:url.searchParams.get('country')||'',
        industry:url.searchParams.get('industry')||'',
        language:url.searchParams.get('language')||'',
        state:url.searchParams.get('state')||'',
        year:url.searchParams.get('year')||'',
        sort:url.searchParams.get('sort')||'updated',
        limit:url.searchParams.get('limit')||30
      });
      return send(res,200,{mode:demo?'demo':'catalog',...result});
    }
    if(req.method==='GET' && url.pathname==='/api/medium/asian-dramas/profiles') { return send(res,200,{version:VERSION,profiles:asianDramas.ASIAN_PROFILES}); }
    if(req.method==='GET' && /^\/api\/medium\/asian-dramas\/[^/]+$/.test(url.pathname)) {
      const id=decodeURIComponent(url.pathname.split('/').pop());
      const demo=url.searchParams.get('demo')==='1';
      if(demo){ const dd=asianDramas.demoData(); const item=asianDramas.detail(dd,id); if(!item)return send(res,404,{error:'Demo Asian drama record not found'}); return send(res,200,{version:VERSION,mode:'demo',item,canonical:dd.catalog.find(x=>String(x.id)===String(id))}); }
      const d=store.read(); const item=asianDramas.detail(d,id);
      if(!item) return send(res,404,{error:'Asian drama record not found in catalog'});
      const full=d.catalog.find(x=>String(x.id)===String(id));
      return send(res,200,{version:VERSION,mode:'catalog',item,canonical:full});
    }
    if(req.method==='POST' && url.pathname==='/api/medium/asian-dramas/selftest') {
      try{return send(res,200,{version:VERSION,...asianDramas.selfTest(),mode:'deterministic'});}catch(e){return send(res,500,{version:VERSION,passed:false,error:e.message});}
    }

    if(req.method==='GET' && url.pathname==='/api/catalog/explore') { const d=store.read(); return send(res,200,{version:VERSION,...explore.buildExplore(d)}); }
    if(req.method==='POST' && url.pathname==='/api/catalog/explore/selftest') { try{return send(res,200,{version:VERSION,...explore.selfTest(),mode:'deterministic'});}catch(e){return send(res,500,{version:VERSION,passed:false,error:e.message});} }

    if (req.method==='GET' && url.pathname==='/api/catalog/facets') {
      const d=store.read(); const items=filterCatalog(d,catalogFilters(url));
      return send(res,200,{facets:catalogFacets(items),total:items.length});
    }
    if (req.method==='GET' && url.pathname==='/api/catalog') {
      const d=store.read(); const filters=catalogFilters(url);
      let items=filterCatalog(d,filters);
      const sort = SORT_FIELDS.has(url.searchParams.get('sort')) ? url.searchParams.get('sort') : 'updatedAt';
      const order = url.searchParams.get('order')==='asc' ? 'asc' : 'desc';
      items=sortCatalog(items,sort,order);
      const requestedPage=Math.max(1,Number.parseInt(url.searchParams.get('page')||'1',10)||1);
      const requestedLimit=Math.min(100,Math.max(1,Number.parseInt(url.searchParams.get('limit')||'25',10)||25));
      const pages=Math.max(1,Math.ceil(items.length/requestedLimit));
      const page=Math.min(requestedPage,pages);
      const start=(page-1)*requestedLimit;
      const paged=items.slice(start,start+requestedLimit);
      return send(res,200,{items:paged,total:items.length,page,limit:requestedLimit,pages,sort,order,filters});
    }
    if (req.method==='POST' && url.pathname==='/api/catalog') {
      const b=await parseBody(req);
      if(!String(b.title||'').trim() || !String(b.type||'').trim()) return send(res,400,{error:'title and type are required'});
      const d=store.read();
      const item={id:crypto.randomUUID(),title:String(b.title).trim(),type:String(b.type).trim(),year:cleanYear(b.year),description:String(b.description||''),creators:cleanStringArray(b.creators),tags:cleanStringArray(b.tags),aliases:cleanStringArray(b.aliases),externalLinks:cleanStringArray(b.externalLinks),relations:[],status:String(b.status||'active'),provider:b.provider||'Manual',providerId:b.providerId||null,coverUrl:b.coverUrl||null,mediaAssets:b.mediaAssets&&typeof b.mediaAssets==='object'?b.mediaAssets:null,providerMetadata:b.providerMetadata&&typeof b.providerMetadata==='object'?b.providerMetadata:null,raw:b.raw&&typeof b.raw==='object'?b.raw:undefined,createdAt:store.now(),updatedAt:store.now()};
      if(item.raw===undefined) delete item.raw;
      if(item.providerId && d.catalog.some(x=>x.provider===item.provider && x.providerId===item.providerId)) return send(res,409,{error:'Catalog item with this provider identity already exists'});
      d.catalog.unshift(item); item.governance={version:1,fieldProvenance:governance.attributionForItem(item),providerRetrievedAt:item.providerMetadata?.provenance?.retrievedAt||item.providerMetadata?.retrievedAt||null}; governance.recordFieldChanges(d,{...item,governance:null},item,{action:'catalog.create',reason:'record-create'}); store.addAudit(d,'catalog.create',{catalogId:item.id,provider:item.provider,title:item.title,governanceFields:Object.keys(item.governance.fieldProvenance||{}).length}); store.write(d);
      return send(res,201,item);
    }

    if(req.method==='GET' && /^\/api\/catalog\/[^/]+\/work-page$/.test(url.pathname)) {
      const id=decodeURIComponent(url.pathname.split('/')[3]); const d=store.read(); const item=d.catalog.find(x=>String(x.id)===String(id));
      if(!item) return send(res,404,{error:'Catalog item not found'});
      const related=(item.relations||[]).map(r=>({...r,item:d.catalog.find(x=>x.id===r.catalogId)||null}));
      const collections=d.collections.filter(c=>(c.items||[]).includes(item.id)).map(c=>({id:c.id,name:c.name}));
      const group=identity.groupForCatalogId(d,item.id); const identityMatches=identity.listCandidates(item,d.catalog.filter(x=>x.id!==item.id),d,{limit:20});
      const enrichmentView=item.enrichment?enrichment.currentItemView(item):null;
      const workPayload=workPages.workPageFrom(item,d,{relations:related.filter(x=>x.item),collections,identityGroup:group?identity.groupView(d,group):null,identityMatches,enrichment:enrichmentView});
      return send(res,200,{...workPayload,version:VERSION,canonical:catalogView(item),library:library.view(d,item),personalExperience:mediumPersonal.experienceFor(item,d.library?.items?.[String(item.id)]||null),libraryHistory:libraryHistory.workHistory(d,item.id,20),workflow:unifiedWorkflow.journey(d,item),communityReviews:community.listReviews(d,{catalogId:item.id,limit:8})});
    }
    if(req.method==='POST' && url.pathname==='/api/catalog/work-page/selftest') { try{return send(res,200,{version:VERSION,...workPages.selfTest(),mode:'deterministic'});}catch(e){return send(res,500,{version:VERSION,passed:false,error:e.message});} }
    const workflowActionMatch=url.pathname.match(/^\/api\/catalog\/([^/]+)\/workflow\/action$/);
    if(req.method==='POST' && workflowActionMatch){
      const id=decodeURIComponent(workflowActionMatch[1]);
      const d=store.read();
      const item=d.catalog.find(x=>String(x.id)===String(id));
      if(!item)return send(res,404,{error:'Catalog item not found'});
      const b=await parseBody(req);
      try{
        const result=unifiedWorkflow.performAction(d,item,b.action,{delta:b.delta,value:b.value});
        store.addAudit(d,'workflow.action',{catalogId:item.id,title:item.title,operation:result.action,status:result.record?.status||null,progress:result.record?.progress??null});
        store.write(d);
        return send(res,200,{version:VERSION,...result});
      }catch(e){return send(res,400,{error:e.message});}
    }
    if(req.method==='GET' && /^\/api\/catalog\/[^/]+\/workflow$/.test(url.pathname)){
      const id=decodeURIComponent(url.pathname.split('/')[3]);
      const d=store.read();
      const item=d.catalog.find(x=>String(x.id)===String(id));
      if(!item)return send(res,404,{error:'Catalog item not found'});
      return send(res,200,{version:VERSION,workflow:unifiedWorkflow.journey(d,item),library:library.view(d,item),personalExperience:mediumPersonal.experienceFor(item,d.library?.items?.[String(item.id)]||null),libraryHistory:libraryHistory.workHistory(d,item.id,20),communityReviews:community.listReviews(d,{catalogId:item.id,limit:8})});
    }
    if(req.method==='POST' && url.pathname==='/api/workflow/selftest'){
      try{return send(res,200,{version:VERSION,...unifiedWorkflow.selfTest(),mode:'deterministic'});}catch(e){return send(res,500,{version:VERSION,passed:false,error:e.message});}
    }

    const cm=url.pathname.match(/^\/api\/catalog\/([^/]+)$/);
    if(req.method==='GET'&&cm){
      const d=store.read(), item=d.catalog.find(x=>x.id===cm[1]);
      if(!item)return send(res,404,{error:'Catalog item not found'});
      const related=(item.relations||[]).map(r=>({...r,item:d.catalog.find(x=>x.id===r.catalogId)||null}));
      const collections=d.collections.filter(c=>(c.items||[]).includes(item.id)).map(c=>({id:c.id,name:c.name}));
      const group=identity.groupForCatalogId(d,item.id); const identityMatches=identity.listCandidates(item,d.catalog.filter(x=>x.id!==item.id),d,{limit:12}); return send(res,200,{item:catalogView(item),relations:related.filter(x=>x.item),collections,identityGroup:group?identity.groupView(d,group):null,identityMatches,enrichment:item.enrichment?enrichment.currentItemView(item):null});
    }
    if(req.method==='PATCH'&&cm){
      const b=await parseBody(req),d=store.read(),item=d.catalog.find(x=>x.id===cm[1]);
      if(!item)return send(res,404,{error:'Catalog item not found'});
      const allowed=['title','type','year','description','creators','coverUrl','status','tags','aliases','externalLinks'];
      const before=JSON.parse(JSON.stringify(item)); const normalized={};
      for(const k of allowed) if(k in b){
        if(['creators','tags','aliases','externalLinks'].includes(k)) normalized[k]=cleanStringArray(b[k]);
        else if(k==='year') normalized[k]=cleanYear(b[k]);
        else normalized[k]=b[k];
      }
      for(const [k,v] of Object.entries(normalized)){ const decision=governance.policyDecision(d,item,k,{catalogId:item.id,provider:'Manual',providerId:item.providerId||null},v,true); if(!decision.allowed)return send(res,409,{error:'Governance policy blocked this write',field:k,reason:decision.reason,decision}); item[k]=v; }
      if(Object.keys(normalized).length){ governance.ensure(d); const nextProv={...(item.governance?.fieldProvenance||{})}; for(const k of Object.keys(normalized)) nextProv[k]={catalogId:item.id,provider:'Manual',providerId:item.providerId||null,field:k,sourceType:'manual',reason:'Manual catalog edit',updatedAt:store.now()}; item.governance={...(item.governance||{}),version:1,fieldProvenance:nextProv}; governance.recordFieldChanges(d,before,item,{action:'catalog.update',reason:'manual-edit'}); }
      item.updatedAt=store.now(); store.addAudit(d,'catalog.update',{catalogId:item.id,title:item.title,fields:Object.keys(normalized),governanceChecked:true}); store.write(d); return send(res,200,item);
    }
    const relm=url.pathname.match(/^\/api\/catalog\/([^/]+)\/relations$/);
    if(req.method==='POST'&&relm){
      const b=await parseBody(req),d=store.read(),from=d.catalog.find(x=>x.id===relm[1]),to=d.catalog.find(x=>x.id===b.catalogId);
      const type=String(b.type||'related').trim();
      if(!from||!to)return send(res,404,{error:'Both catalog items must exist'});
      if(from.id===to.id)return send(res,400,{error:'An item cannot relate to itself'});
      if(relationExists(d,from.id,to.id,type))return send(res,409,{error:'Relation already exists'});
      from.relations=Array.isArray(from.relations)?from.relations:[];
      from.relations.push({catalogId:to.id,type,createdAt:store.now()});
      from.updatedAt=store.now();
      store.addAudit(d,'catalog.relation.create',{fromId:from.id,toId:to.id,type}); store.write(d);
      return send(res,201,{from:catalogView(from),to:catalogView(to),type});
    }
    if(req.method==='DELETE'&&relm){
      const b=await parseBody(req),d=store.read(),from=d.catalog.find(x=>x.id===relm[1]);
      if(!from)return send(res,404,{error:'Catalog item not found'});
      const before=(from.relations||[]).length;
      from.relations=(from.relations||[]).filter(r=>!(r.catalogId===b.catalogId && (!b.type || r.type===b.type)));
      if(from.relations.length===before)return send(res,404,{error:'Relation not found'});
      from.updatedAt=store.now(); store.addAudit(d,'catalog.relation.delete',{fromId:from.id,toId:b.catalogId,type:b.type||null}); store.write(d);
      return send(res,200,from);
    }
    if(req.method==='DELETE'&&cm){
      const d=store.read(),idx=d.catalog.findIndex(x=>x.id===cm[1]); if(idx<0)return send(res,404,{error:'Catalog item not found'});
      const [item]=d.catalog.splice(idx,1); const impact=governance.deletionImpact(d,item.id); governance.recordDeletion(d,item,impact,'catalog.delete');
      recordAniListTombstone(d,item);
      for(const other of d.catalog) other.relations=(other.relations||[]).filter(r=>r.catalogId!==item.id);
      for(const c of d.collections) c.items=(c.items||[]).filter(id=>id!==item.id);
      if(library.remove(d,item.id)) store.addAudit(d,'library.remove',{catalogId:item.id,title:item.title,reason:'catalog-delete'});
      store.addAudit(d,'catalog.delete',{catalogId:item.id,title:item.title}); store.write(d); return send(res,200,{deleted:item});
    }

    if(req.method==='POST'&&url.pathname==='/api/catalog/bulk'){
      const b=await parseBody(req), ids=Array.isArray(b.ids)?[...new Set(b.ids.map(x=>String(x)).filter(Boolean))]:[], action=String(b.action||'').trim();
      if(!ids.length)return send(res,400,{error:'ids[] is required'});
      if(ids.length>BULK_LIMIT)return send(res,400,{error:`A maximum of ${BULK_LIMIT} items can be processed at once`});
      if(!BULK_ACTIONS.has(action))return send(res,400,{error:'Unsupported bulk action'});
      const d=store.read(), items=d.catalog.filter(x=>ids.includes(x.id));
      if(items.length!==ids.length)return send(res,404,{error:'One or more catalog items were not found'});
      if(action==='status'){
        const status=String(b.value||'').trim();
        if(!['active','archived'].includes(status))return send(res,400,{error:'status must be active or archived'});
        for(const item of items){item.status=status;item.updatedAt=store.now();}
      } else if(action==='addTag'||action==='removeTag'){
        const tag=String(b.tag||b.value||'').trim();
        if(!tag||tag.length>80)return send(res,400,{error:'tag is required and must be 80 characters or fewer'});
        for(const item of items){item.tags=Array.isArray(item.tags)?item.tags:[];if(action==='addTag'){if(!item.tags.some(t=>String(t).toLowerCase()===tag.toLowerCase()))item.tags.push(tag);}else item.tags=item.tags.filter(t=>String(t).toLowerCase()!==tag.toLowerCase());item.updatedAt=store.now();}
      } else if(action==='addToCollection'||action==='removeFromCollection'){
        const c=d.collections.find(x=>x.id===String(b.collectionId||''));
        if(!c)return send(res,404,{error:'Collection not found'});
        c.items=Array.isArray(c.items)?c.items:[]; const idSet=new Set(ids);
        if(action==='addToCollection'){for(const id of ids)if(!c.items.includes(id))c.items.push(id);}else c.items=c.items.filter(id=>!idSet.has(id));
        c.updatedAt=store.now();
      } else if(action==='delete'){
        const idSet=new Set(ids); for(const item of items){ const impact=governance.deletionImpact(d,item.id); governance.recordDeletion(d,item,impact,'catalog.bulk.delete'); recordAniListTombstone(d,item); } d.catalog=d.catalog.filter(x=>!idSet.has(x.id));
        for(const other of d.catalog) other.relations=(other.relations||[]).filter(r=>!idSet.has(r.catalogId));
        for(const id of idSet) library.remove(d,id);
        identity.reconcileStoredState(d);
        for(const c of d.collections) c.items=(c.items||[]).filter(id=>!idSet.has(id));
      }
      const detail={action,count:items.length,catalogIds:ids};
      if(b.collectionId)detail.collectionId=String(b.collectionId);
      if(b.tag||b.value)detail.value=String(b.tag||b.value);
      store.addAudit(d,'catalog.bulk.'+action,detail); store.write(d);
      return send(res,200,{action,count:items.length,items:action==='delete'?[]:items.map(catalogView)});
    }

    if(req.method==='GET'&&url.pathname==='/api/collections'){
      const d=store.read();
      const q=(url.searchParams.get('q')||'').trim().toLowerCase();
      const items=d.collections.filter(c=>!q||`${c.name} ${c.description}`.toLowerCase().includes(q)).map(c=>({id:c.id,name:c.name,description:c.description,itemCount:(c.items||[]).filter(id=>d.catalog.some(x=>x.id===id)).length,createdAt:c.createdAt,updatedAt:c.updatedAt}));
      return send(res,200,{items,total:items.length});
    }
    if(req.method==='POST'&&url.pathname==='/api/collections'){
      const b=await parseBody(req),name=String(b.name||'').trim(); if(!name)return send(res,400,{error:'name is required'});
      if(name.length>COLLECTION_NAME_LIMIT)return send(res,400,{error:`name must be ${COLLECTION_NAME_LIMIT} characters or fewer`});
      const d=store.read(); if(d.collections.some(c=>c.name.toLowerCase()===name.toLowerCase()))return send(res,409,{error:'A collection with this name already exists'});
      const c=normalizeCollection({id:crypto.randomUUID(),name,description:String(b.description||''),items:[],createdAt:store.now(),updatedAt:store.now()});
      d.collections.unshift(c); store.addAudit(d,'collection.create',{collectionId:c.id,name:c.name}); store.write(d); return send(res,201,{collection:collectionView(c,d)});
    }
    const colm=url.pathname.match(/^\/api\/collections\/([^/]+)$/);
    if(req.method==='GET'&&colm){const d=store.read(),c=d.collections.find(x=>x.id===colm[1]);if(!c)return send(res,404,{error:'Collection not found'});return send(res,200,{collection:collectionView(c,d)});}
    if(req.method==='PATCH'&&colm){
      const b=await parseBody(req),d=store.read(),c=d.collections.find(x=>x.id===colm[1]);if(!c)return send(res,404,{error:'Collection not found'});
      if('name' in b){const name=String(b.name||'').trim();if(!name)return send(res,400,{error:'name cannot be empty'});if(name.length>COLLECTION_NAME_LIMIT)return send(res,400,{error:`name must be ${COLLECTION_NAME_LIMIT} characters or fewer`});if(d.collections.some(x=>x.id!==c.id&&x.name.toLowerCase()===name.toLowerCase()))return send(res,409,{error:'A collection with this name already exists'});c.name=name;}
      if('description' in b)c.description=String(b.description||'');c.updatedAt=store.now();store.addAudit(d,'collection.update',{collectionId:c.id,name:c.name,fields:Object.keys(b)});store.write(d);return send(res,200,{collection:collectionView(c,d)});
    }
    const colItems=url.pathname.match(/^\/api\/collections\/([^/]+)\/items$/);
    if(req.method==='POST'&&colItems){
      const b=await parseBody(req),d=store.read(),c=d.collections.find(x=>x.id===colItems[1]),item=d.catalog.find(x=>x.id===b.catalogId);
      if(!c)return send(res,404,{error:'Collection not found'});if(!item)return send(res,404,{error:'Catalog item not found'});
      c.items=Array.isArray(c.items)?c.items:[];if(c.items.includes(item.id))return send(res,409,{error:'Catalog item is already in this collection'});c.items.push(item.id);c.updatedAt=store.now();store.addAudit(d,'collection.item.add',{collectionId:c.id,catalogId:item.id});store.write(d);return send(res,201,{collection:collectionView(c,d)});
    }
    if(req.method==='DELETE'&&colItems){
      const b=await parseBody(req),d=store.read(),c=d.collections.find(x=>x.id===colItems[1]);if(!c)return send(res,404,{error:'Collection not found'});const before=(c.items||[]).length;c.items=(c.items||[]).filter(id=>id!==b.catalogId);if(before===c.items.length)return send(res,404,{error:'Catalog item is not in this collection'});c.updatedAt=store.now();store.addAudit(d,'collection.item.remove',{collectionId:c.id,catalogId:b.catalogId});store.write(d);return send(res,200,{collection:collectionView(c,d)});
    }
    if(req.method==='DELETE'&&colm){const d=store.read(),idx=d.collections.findIndex(x=>x.id===colm[1]);if(idx<0)return send(res,404,{error:'Collection not found'});const [c]=d.collections.splice(idx,1);store.addAudit(d,'collection.delete',{collectionId:c.id,name:c.name});store.write(d);return send(res,200,{deleted:c});}

    if(req.method==='GET'&&url.pathname==='/api/smart-collections'){
      const d=store.read();
      const q=(url.searchParams.get('q')||'').trim().toLowerCase();
      const items=d.smartCollections.filter(s=>!q||`${s.name} ${s.description}`.toLowerCase().includes(q)).map(s=>({id:s.id,name:s.name,description:s.description,mode:s.rules?.mode==='any'?'any':'all',rules:s.rules||{},itemCount:d.catalog.filter(x=>matchesCatalogRule(x,s.rules||{})).length,createdAt:s.createdAt,updatedAt:s.updatedAt}));
      return send(res,200,{items,total:items.length});
    }
    if(req.method==='POST'&&url.pathname==='/api/smart-collections'){
      const b=await parseBody(req),name=String(b.name||'').trim(); if(!name)return send(res,400,{error:'name is required'});
      if(name.length>SMART_NAME_LIMIT)return send(res,400,{error:`name must be ${SMART_NAME_LIMIT} characters or fewer`});
      const d=store.read(); if(d.smartCollections.some(s=>s.name.toLowerCase()===name.toLowerCase()))return send(res,409,{error:'A saved view with this name already exists'});
      const sc={id:crypto.randomUUID(),name,description:String(b.description||''),rules:sanitizeSmartRule(b.rules||{}),createdAt:store.now(),updatedAt:store.now()};
      d.smartCollections.unshift(sc); store.addAudit(d,'smart_collection.create',{smartCollectionId:sc.id,name:sc.name,rules:sc.rules}); store.write(d);
      return send(res,201,{smartCollection:smartCollectionView(sc,d)});
    }
    const sm=url.pathname.match(/^\/api\/smart-collections\/([^/]+)$/);
    if(req.method==='GET'&&sm){const d=store.read(),sc=d.smartCollections.find(x=>x.id===sm[1]);if(!sc)return send(res,404,{error:'Saved view not found'});return send(res,200,{smartCollection:smartCollectionView(sc,d)});}
    if(req.method==='PATCH'&&sm){
      const b=await parseBody(req),d=store.read(),sc=d.smartCollections.find(x=>x.id===sm[1]);if(!sc)return send(res,404,{error:'Saved view not found'});
      if('name' in b){const name=String(b.name||'').trim();if(!name)return send(res,400,{error:'name cannot be empty'});if(name.length>SMART_NAME_LIMIT)return send(res,400,{error:`name must be ${SMART_NAME_LIMIT} characters or fewer`});if(d.smartCollections.some(x=>x.id!==sc.id&&x.name.toLowerCase()===name.toLowerCase()))return send(res,409,{error:'A saved view with this name already exists'});sc.name=name;}
      if('description' in b)sc.description=String(b.description||''); if('rules' in b)sc.rules=sanitizeSmartRule(b.rules||{}); sc.updatedAt=store.now();
      store.addAudit(d,'smart_collection.update',{smartCollectionId:sc.id,name:sc.name,fields:Object.keys(b)});store.write(d);return send(res,200,{smartCollection:smartCollectionView(sc,d)});
    }
    if(req.method==='DELETE'&&sm){const d=store.read(),idx=d.smartCollections.findIndex(x=>x.id===sm[1]);if(idx<0)return send(res,404,{error:'Saved view not found'});const [sc]=d.smartCollections.splice(idx,1);store.addAudit(d,'smart_collection.delete',{smartCollectionId:sc.id,name:sc.name});store.write(d);return send(res,200,{deleted:sc});}
    if(req.method==='POST'&&url.pathname==='/api/smart-collections/from-filters'){
      const b=await parseBody(req),name=String(b.name||'').trim(); if(!name)return send(res,400,{error:'name is required'});
      const d=store.read(); if(d.smartCollections.some(s=>s.name.toLowerCase()===name.toLowerCase()))return send(res,409,{error:'A saved view with this name already exists'});
      const rules=sanitizeSmartRule({...(b.filters||{}),mode:b.mode});
      const sc={id:crypto.randomUUID(),name,description:String(b.description||'Saved from catalog filters'),rules,createdAt:store.now(),updatedAt:store.now()};
      d.smartCollections.unshift(sc);store.addAudit(d,'smart_collection.create',{smartCollectionId:sc.id,name:sc.name,rules:sc.rules,source:'catalog-filters'});store.write(d);return send(res,201,{smartCollection:smartCollectionView(sc,d)});
    }

    if(req.method==='GET' && url.pathname==='/api/recommendations') {
      const d=store.read();
      const limit=Math.min(50,Math.max(1,Number.parseInt(url.searchParams.get('limit')||'12',10)||12));
      const type=url.searchParams.get('type')||'';
      const mode=url.searchParams.get('mode')||'';
      const minScore=url.searchParams.get('minScore');
      return send(res,200,recommendations.recommend(d,{limit,type,mode,minScore:minScore===''?null:minScore}));
    }
    if(req.method==='POST' && url.pathname==='/api/recommendations/selftest') { try{return send(res,200,{version:VERSION,...recommendations.selfTest(),mode:'deterministic'});}catch(e){return send(res,500,{version:VERSION,passed:false,error:e.message});} }
    if(req.method==='GET' && url.pathname==='/api/library/stats'){const d=store.read();return send(res,200,{version:VERSION,profile:d.library.profile,...library.stats(d)});}
    if(req.method==='GET' && url.pathname==='/api/library/statistics'){const d=store.read();const months=Math.min(36,Math.max(1,Number.parseInt(url.searchParams.get('months')||'12',10)||12));const calendarDays=Math.min(366,Math.max(14,Number.parseInt(url.searchParams.get('calendarDays')||'84',10)||84));return send(res,200,{...libraryStatistics.statistics(d,{months,calendarDays}),version:VERSION});}
    if(req.method==='POST' && url.pathname==='/api/library/statistics/selftest'){try{return send(res,200,{version:VERSION,mode:'deterministic',...libraryStatistics.selfTest()});}catch(e){return send(res,500,{version:VERSION,passed:false,error:e.message});}}
    if(req.method==='POST' && url.pathname==='/api/library/selftest'){try{return send(res,200,{version:VERSION,...library.selfTest(),mode:'deterministic'});}catch(e){return send(res,500,{version:VERSION,passed:false,error:e.message});}}
    if(req.method==='GET' && url.pathname==='/api/library/overview'){const d=store.read();const limit=Math.min(24,Math.max(1,Number.parseInt(url.searchParams.get('limit')||'6',10)||6));return send(res,200,{version:VERSION,...libraryExperience.overview(d,{limit})});}
    if(req.method==='GET' && url.pathname==='/api/library/history'){const d=store.read();return send(res,200,{version:VERSION,...libraryHistory.timeline(d,{limit:url.searchParams.get('limit'),offset:url.searchParams.get('offset'),catalogId:url.searchParams.get('catalogId'),action:url.searchParams.get('action'),from:url.searchParams.get('from'),to:url.searchParams.get('to')})});}
    if(req.method==='GET' && url.pathname==='/api/library/history/summary'){const d=store.read();return send(res,200,{version:VERSION,summary:libraryHistory.summary(d)});}
    if(req.method==='GET' && url.pathname==='/api/library/recent/completed'){const d=store.read();const limit=Math.min(24,Math.max(1,Number.parseInt(url.searchParams.get('limit')||'6',10)||6));return send(res,200,{version:VERSION,items:libraryHistory.latestByAction(d,'completed',limit)});}
    if(req.method==='GET' && url.pathname==='/api/library/recent/added'){const d=store.read();const limit=Math.min(24,Math.max(1,Number.parseInt(url.searchParams.get('limit')||'6',10)||6));return send(res,200,{version:VERSION,items:libraryHistory.latestByAction(d,'added',limit)});}
    if(req.method==='GET' && url.pathname==='/api/library/collections'){
      const d=store.read(); libraryCollections.ensureState(d);
      const q=String(url.searchParams.get('q')||'').trim().toLowerCase();
      const custom=d.library.smartCollections.filter(s=>!q||`${s.name} ${s.description}`.toLowerCase().includes(q)).map(s=>{const v=libraryCollections.viewFor(s,d,{limit:0});return {id:s.id,name:s.name,description:s.description,rules:v.rules,itemCount:v.itemCount,stats:v.stats,createdAt:s.createdAt,updatedAt:s.updatedAt,preset:false};});
      return send(res,200,{version:VERSION,presets:libraryCollections.presets(d),items:custom,total:custom.length});
    }
    if(req.method==='POST' && url.pathname==='/api/library/collections'){
      try{const b=await parseBody(req),d=store.read(); const sc=libraryCollections.create(d,{name:b.name,description:b.description,rules:b.rules}); store.addAudit(d,'library_collection.create',{libraryCollectionId:sc.id,name:sc.name,rules:sc.rules}); store.write(d); return send(res,201,{version:VERSION,collection:libraryCollections.viewFor(sc,d,{limit:24})});}
      catch(e){return send(res,e.message.includes('already exists')?409:400,{error:e.message});}
    }
    if(req.method==='POST' && url.pathname==='/api/library/collections/from-filters'){
      try{const b=await parseBody(req),d=store.read(); const sc=libraryCollections.create(d,{name:b.name,description:b.description||'Saved from My Library filters',rules:libraryCollections.buildFromLibraryFilters(b.filters||{})}); store.addAudit(d,'library_collection.create',{libraryCollectionId:sc.id,name:sc.name,rules:sc.rules,source:'library-filters'}); store.write(d); return send(res,201,{version:VERSION,collection:libraryCollections.viewFor(sc,d,{limit:24})});}
      catch(e){return send(res,e.message.includes('already exists')?409:400,{error:e.message});}
    }
    const lcm=url.pathname.match(/^\/api\/library\/collections\/([^/]+)$/);
    if(req.method==='GET'&&lcm){
      const d=store.read(),id=decodeURIComponent(lcm[1]);
      if(id.startsWith('preset:')){const v=libraryCollections.presetView(id.slice(7),d,{limit:24});if(!v)return send(res,404,{error:'Library collection preset not found'});return send(res,200,{version:VERSION,collection:v});}
      const sc=d.library.smartCollections.find(x=>x.id===id);if(!sc)return send(res,404,{error:'Library collection not found'});return send(res,200,{version:VERSION,collection:libraryCollections.viewFor(sc,d,{limit:24})});
    }
    if(req.method==='PATCH'&&lcm){
      try{const b=await parseBody(req),d=store.read(),id=decodeURIComponent(lcm[1]);if(id.startsWith('preset:'))return send(res,409,{error:'Built-in library collection presets cannot be edited'});const sc=libraryCollections.update(d,id,b);store.addAudit(d,'library_collection.update',{libraryCollectionId:sc.id,name:sc.name,fields:Object.keys(b)});store.write(d);return send(res,200,{version:VERSION,collection:libraryCollections.viewFor(sc,d,{limit:24})});}
      catch(e){return send(res,e.message==='Library collection not found'?404:(e.message.includes('already exists')?409:400),{error:e.message});}
    }
    if(req.method==='DELETE'&&lcm){const d=store.read(),id=decodeURIComponent(lcm[1]);if(id.startsWith('preset:'))return send(res,409,{error:'Built-in library collection presets cannot be deleted'});const removed=libraryCollections.remove(d,id);if(!removed)return send(res,404,{error:'Library collection not found'});store.addAudit(d,'library_collection.delete',{libraryCollectionId:removed.id,name:removed.name});store.write(d);return send(res,200,{version:VERSION,deleted:removed});}
    if(req.method==='GET' && url.pathname==='/api/library') { const d=store.read(); const p=url.searchParams; let rows=library.list(d,{q:p.get('q')||'',status:p.get('status')||'',type:p.get('type')||'',favorite:p.get('favorite')||'',sort:p.get('sort')||'updatedAt',order:p.get('order')||'desc'}); const collectionId=String(p.get('collection')||'').trim(); if(collectionId){const rules=collectionId.startsWith('preset:')?libraryCollections.presetById(collectionId.slice(7))?.rules:null; const custom=collectionId.startsWith('preset:')?null:d.library.smartCollections.find(x=>x.id===collectionId); const effective=custom?.rules||rules; if(!effective)return send(res,404,{error:'Library collection not found'}); rows=rows.filter(row=>libraryCollections.matches(row,effective));} const limit=Math.min(100,Math.max(1,Number.parseInt(p.get('limit')||'24',10)||24)); const page=Math.max(1,Number.parseInt(p.get('page')||'1',10)||1); const pages=Math.max(1,Math.ceil(rows.length/limit)); const actual=Math.min(page,pages); return send(res,200,{version:VERSION,items:rows.slice((actual-1)*limit,actual*limit),total:rows.length,page:actual,pages,limit,stats:library.stats(d),collection:collectionId||null}); }
    const lmv=url.pathname.match(/^\/api\/library\/medium\/(.+)$/);
    if(req.method==='GET' && lmv){const d=store.read();const type=decodeURIComponent(lmv[1]);const limit=Math.min(24,Math.max(1,Number.parseInt(url.searchParams.get('limit')||'12',10)||12));const result=libraryExperience.mediumView(d,type,{limit});if(!result)return send(res,404,{error:'No personal library items found for this medium'});return send(res,200,{version:VERSION,...result});}
    const lm=url.pathname.match(/^\/api\/library\/([^/]+)$/);
    if(req.method==='GET' && lm){const d=store.read();const item=d.catalog.find(x=>String(x.id)===decodeURIComponent(lm[1]));if(!item)return send(res,404,{error:'Catalog item not found'});return send(res,200,{version:VERSION,catalog:catalogView(item),library:library.view(d,item)});}
    if(req.method==='PUT' && lm){const d=store.read();const id=decodeURIComponent(lm[1]);const item=d.catalog.find(x=>String(x.id)===id);if(!item)return send(res,404,{error:'Catalog item not found'});const b=await parseBody(req);const allowed=['status','progress','progressTotal','progressUnit','score','favorite','notes','startedAt','completedAt'];const patch={};for(const k of allowed) if(k in b) patch[k]=b[k];const before=library.get(d,id);const record=library.upsert(d,id,patch,{historyAction:null,source:'library.update'});store.addAudit(d,'library.update',{catalogId:id,title:item.title,fields:Object.keys(patch),previous:before?{status:before.status,progress:before.progress,score:before.score,favorite:before.favorite}:null,next:{status:record.status,progress:record.progress,score:record.score,favorite:record.favorite}});store.write(d);return send(res,200,{version:VERSION,catalog:catalogView(item),library:library.view(d,item)});}
    if(req.method==='DELETE' && lm){const d=store.read();const id=decodeURIComponent(lm[1]);const item=d.catalog.find(x=>String(x.id)===id);if(!item)return send(res,404,{error:'Catalog item not found'});const removed=library.remove(d,id,{source:'library.remove'});if(!removed)return send(res,404,{error:'Item is not in your library'});store.addAudit(d,'library.remove',{catalogId:id,title:item.title});store.write(d);return send(res,200,{removed:true,catalogId:id,stats:library.stats(d)});}
    if(req.method==='POST' && /^\/api\/library\/[^/]+\/advance$/.test(url.pathname)){const id=decodeURIComponent(url.pathname.split('/')[3]);const d=store.read();const item=d.catalog.find(x=>String(x.id)===id);if(!item)return send(res,404,{error:'Catalog item not found'});const b=await parseBody(req),meta=library.inferProgressMeta(item),delta=b.delta==null?1:Number(b.delta);const current=library.get(d,id)||{};let next=Math.max(0,Number(current.progress||0)+(Number.isFinite(delta)?delta:1));const total=current.progressTotal??meta.total??null;const status=(total&&next>=total)?'completed':(current.status||'active');const record=library.upsert(d,id,{status,progress:next},{historyAction:'progress',source:'library.advance',delta});store.addAudit(d,'library.advance',{catalogId:id,title:item.title,delta,progress:record.progress,status:record.status});store.write(d);return send(res,200,{version:VERSION,catalog:catalogView(item),library:library.view(d,item)});}
    if (req.method==='GET' && url.pathname==='/api/review/queue') { const d=store.read(); return send(res,200,{items:d.reviewQueue,total:d.reviewQueue.length}); }
    if (req.method==='POST' && url.pathname==='/api/review/queue') {
      const b=await parseBody(req); if(!b.normalized?.title||!b.normalized?.type) return send(res,400,{error:'normalized item with title and type is required'});
      const d=store.read(); const normalized={...b.normalized,matches:b.normalized.provider==='Open Library'?openLibraryQuality.findMatches(b.normalized,d.catalog):b.normalized.provider==='TMDB'?tmdb.findMatches(b.normalized,d.catalog):b.normalized.provider==='IGDB'?igdb.findMatches(b.normalized,d.catalog):findMatches(b.normalized,d.catalog)};
      const item={id:crypto.randomUUID(),status:'pending',createdAt:store.now(),normalized}; if(normalized.provider==='Open Library'){ const ol=openLibraryEntityState(d); const diagnostic={reviewId:item.id,at:store.now(),providerId:normalized.providerId,title:normalized.title,quality:openLibraryQuality.qualityReport(normalized,'work'),matches:normalized.matches.slice(0,10)}; ol.reviewDiagnostics.unshift(diagnostic);ol.reviewDiagnostics=ol.reviewDiagnostics.slice(0,200); } if(normalized.provider==='TMDB'){ const tm=tmdbEntityState(d); const diagnostic={reviewId:item.id,at:store.now(),providerId:normalized.providerId,title:normalized.title,quality:tmdb.qualityReport(normalized),matches:normalized.matches.slice(0,10)}; tm.reviewDiagnostics.unshift(diagnostic);tm.reviewDiagnostics=tm.reviewDiagnostics.slice(0,200); } d.reviewQueue.unshift(item);
      store.addAudit(d,'review.create',{reviewId:item.id,provider:normalized.provider,title:normalized.title}); store.write(d);
      return send(res,201,item);
    }
    const m=url.pathname.match(/^\/api\/review\/queue\/([^/]+)\/(approve|reject)$/);
    if(req.method==='POST'&&m){
      const d=store.read(), item=d.reviewQueue.find(x=>x.id===m[1]); if(!item)return send(res,404,{error:'Review item not found'});
      if(m[2]==='approve'){item.status='approved';item.reviewedAt=store.now();store.addAudit(d,'review.approve',{reviewId:item.id,title:item.normalized.title});}
      else {item.status='rejected';item.reviewedAt=store.now();item.reason=String((await parseBody(req)).reason||'');store.addAudit(d,'review.reject',{reviewId:item.id,title:item.normalized.title,reason:item.reason});}
      store.write(d);return send(res,200,item);
    }
    if(req.method==='POST'&&url.pathname==='/api/providers/apply'){
      const b=await parseBody(req),d=store.read(),item=d.reviewQueue.find(x=>x.id===b.reviewId);
      if(!item)return send(res,404,{error:'Review item not found'});if(item.status!=='approved')return send(res,409,{error:'Only approved items can be applied'});
      const duplicate=d.catalog.find(x=>x.provider===item.normalized.provider && x.providerId===item.normalized.providerId);
      if(duplicate){ item.status='applied'; item.appliedAt=store.now(); item.duplicateCatalogId=duplicate.id; store.addAudit(d,'catalog.apply.duplicate',{reviewId:item.id,catalogId:duplicate.id,provider:item.normalized.provider}); store.write(d); return send(res,409,{error:'Provider identity already exists in catalog',catalogItem:duplicate,reviewItem:item}); }
      const catalogItem={...item.normalized,id:item.normalized.id||crypto.randomUUID(),tags:Array.isArray(item.normalized.tags)?item.normalized.tags:[],aliases:Array.isArray(item.normalized.aliases)?item.normalized.aliases:[],externalLinks:Array.isArray(item.normalized.externalLinks)?item.normalized.externalLinks:[],relations:[],status:item.normalized.status||'active',importedAt:store.now(),createdAt:item.normalized.createdAt||store.now(),updatedAt:store.now(),sourceReviewId:item.id};delete catalogItem.matches; catalogItem.governance={version:1,fieldProvenance:governance.attributionForItem(catalogItem),providerRetrievedAt:catalogItem.providerMetadata?.provenance?.retrievedAt||catalogItem.providerMetadata?.retrievedAt||null}; d.catalog.unshift(catalogItem); governance.recordFieldChanges(d,{...catalogItem,governance:null},catalogItem,{action:'catalog.apply',reason:'review-apply'}); if(catalogItem.provider==='Open Library'){ const pm=catalogItem.providerMetadata||{}; persistOpenLibraryRegistry(d,{workId:pm.workId||((String(catalogItem.providerId||'').endsWith('W'))?catalogItem.providerId:null),authors:(pm.authorKeys||[]).map((providerId,i)=>({providerId,name:(catalogItem.creators||[])[i]||null,updatedAt:store.now(),externalUrl:`https://openlibrary.org/authors/${providerId}`})),subjects:(pm.normalizedSubjects||[]),workEdition:{editions:pm.editionRecords||[],count:(pm.editionRecords||[]).length}},'apply'); } if(catalogItem.provider==='TMDB'){ persistTMDBEntities(d,{normalized:catalogItem,entities:tmdb.entityBundle(catalogItem)},'review-apply'); } if(catalogItem.provider==='IGDB'){ persistIGDBEntities(d,{normalized:catalogItem,entities:igdb.entityBundle(catalogItem)},'review-apply'); }
      item.status='applied';item.appliedAt=store.now();store.addAudit(d,'catalog.apply',{reviewId:item.id,catalogId:catalogItem.id,provider:item.normalized.provider});store.write(d);return send(res,200,{catalogItem,reviewItem:item,identityMatches:identity.listCandidates(catalogItem,d.catalog.filter(x=>x.id!==catalogItem.id),d,{limit:12})});
    }

    // v0.76 Social / Community 2.0 — provider-neutral local community layer.
    if(req.method==='GET' && url.pathname==='/api/community/overview'){
      const d=store.read(); const demo=url.searchParams.get('demo')==='1';
      if(demo)return send(res,200,{version:VERSION,mode:'demo',...community.demo(d,'overview',{limit:12})});
      const profile=community.profile(d); return send(res,200,{version:VERSION,mode:'local',profile,members:community.members(d,{limit:12}),reviews:community.listReviews(d,{limit:8}),activities:community.activity(d,{scope:'all',limit:12}),discovery:community.discovery(d,{limit:12}),following:community.followed(d),followers:profile.counts.followers});
    }
    if(req.method==='POST' && url.pathname==='/api/community/selftest'){
      try{return send(res,200,{version:VERSION,mode:'deterministic',...community.selfTest()});}catch(e){return send(res,500,{version:VERSION,passed:false,error:e.message});}
    }
    if(req.method==='GET' && url.pathname==='/api/community/members'){
      const d=store.read(); const demo=url.searchParams.get('demo')==='1'; const q=url.searchParams.get('q')||''; const limit=url.searchParams.get('limit');
      return send(res,200,{version:VERSION,mode:demo?'demo':'local',members:demo?community.demo(d,'members',{q,limit}).members:community.members(d,{q,limit})});
    }
    const cpm=url.pathname.match(/^\/api\/community\/profile\/([^/]+)$/);
    if(req.method==='GET'&&cpm){const d=store.read();const demo=url.searchParams.get('demo')==='1';const id=decodeURIComponent(cpm[1]);const p=demo?community.demo(d,'profile',{userId:id}).profile:community.profile(d,id);if(!p)return send(res,404,{error:'Community member not found'});return send(res,200,{version:VERSION,mode:demo?'demo':'local',profile:p,reviews:demo?community.demo(d,'reviews',{userId:id,limit:12}).reviews:community.listReviews(d,{userId:id,limit:12})});}
    if(req.method==='PATCH'&&url.pathname==='/api/community/profile'){
      const b=await parseBody(req),d=store.read(); const p=community.saveProfile(d,b); store.addAudit(d,'community.profile.update',{userId:community.CURRENT_USER_ID,fields:['name','handle','bio','avatarUrl'].filter(k=>k in b)}); store.write(d); return send(res,200,{version:VERSION,profile:p});
    }
    if(req.method==='POST'&&url.pathname==='/api/community/follow'){
      const b=await parseBody(req),d=store.read();try{const r=community.follow(d,b.userId,b.follow!==false);store.addAudit(d,r.following?'community.follow':'community.unfollow',{userId:community.CURRENT_USER_ID,targetUserId:String(b.userId)});store.write(d);return send(res,200,{version:VERSION,...r});}catch(e){return send(res,400,{error:e.message});}
    }
    if(req.method==='GET'&&url.pathname==='/api/community/following') { const d=store.read(); return send(res,200,{version:VERSION,items:community.followed(d)}); }
    if(req.method==='POST'&&url.pathname==='/api/community/favorite'){
      const b=await parseBody(req),d=store.read();try{const p=community.setFavorite(d,b.catalogId,b.value);store.addAudit(d,'community.favorite',{userId:community.CURRENT_USER_ID,catalogId:String(b.catalogId),favorite:Boolean(p.favorites.some(x=>x.id===String(b.catalogId)))});store.write(d);return send(res,200,{version:VERSION,profile:p,library:library.view(d,d.catalog.find(x=>String(x.id)===String(b.catalogId)))});}catch(e){return send(res,400,{error:e.message});}
    }
    if(req.method==='GET'&&url.pathname==='/api/community/reviews'){
      const d=store.read();const demo=url.searchParams.get('demo')==='1';const opts={q:url.searchParams.get('q')||'',type:url.searchParams.get('type')||'',userId:url.searchParams.get('userId')||'',catalogId:url.searchParams.get('catalogId')||'',minScore:url.searchParams.get('minScore')==null?null:Number(url.searchParams.get('minScore')),sort:url.searchParams.get('sort')||'newest',limit:url.searchParams.get('limit')};return send(res,200,{version:VERSION,mode:demo?'demo':'local',reviews:demo?community.demo(d,'reviews',opts).reviews:community.listReviews(d,opts)});
    }
    if(req.method==='POST'&&url.pathname==='/api/community/reviews'){
      const b=await parseBody(req),d=store.read();try{const review=community.createReview(d,b);store.addAudit(d,'community.review.create',{reviewId:review.id,catalogId:review.catalogId,userId:community.CURRENT_USER_ID});store.write(d);return send(res,201,{version:VERSION,review});}catch(e){return send(res,400,{error:e.message});}
    }
    const crm=url.pathname.match(/^\/api\/community\/reviews\/([^/]+)$/);
    if(req.method==='PATCH'&&crm){const b=await parseBody(req),d=store.read();try{const review=community.editReview(d,decodeURIComponent(crm[1]),b);store.addAudit(d,'community.review.update',{reviewId:review.id,userId:community.CURRENT_USER_ID});store.write(d);return send(res,200,{version:VERSION,review});}catch(e){return send(res,400,{error:e.message});}}
    if(req.method==='DELETE'&&crm){const d=store.read();try{const result=community.deleteReview(d,decodeURIComponent(crm[1]));store.addAudit(d,'community.review.delete',{reviewId:decodeURIComponent(crm[1]),userId:community.CURRENT_USER_ID});store.write(d);return send(res,200,{version:VERSION,...result});}catch(e){return send(res,400,{error:e.message});}}
    const crl=url.pathname.match(/^\/api\/community\/reviews\/([^/]+)\/like$/);
    if(req.method==='POST'&&crl){const b=await parseBody(req),d=store.read();try{const result=community.toggleReviewLike(d,decodeURIComponent(crl[1]),b.value);store.addAudit(d,result.liked?'community.review.like':'community.review.unlike',{reviewId:decodeURIComponent(crl[1]),userId:community.CURRENT_USER_ID});store.write(d);return send(res,200,{version:VERSION,...result});}catch(e){return send(res,400,{error:e.message});}}
    if(req.method==='GET'&&url.pathname==='/api/community/activity'){
      const d=store.read(),demo=url.searchParams.get('demo')==='1',scope=url.searchParams.get('scope')||'all',limit=url.searchParams.get('limit'); return send(res,200,{version:VERSION,mode:demo?'demo':'local',activities:demo?community.demo(d,'activity',{scope,limit}).activities:community.activity(d,{scope,limit})});
    }
    if(req.method==='GET'&&url.pathname==='/api/community/discovery'){
      const d=store.read(),demo=url.searchParams.get('demo')==='1',userId=url.searchParams.get('userId')||'',limit=url.searchParams.get('limit'); return send(res,200,{version:VERSION,mode:demo?'demo':'local',items:demo?community.demo(d,'discovery',{userId,limit}).items:community.discovery(d,{userId,limit})});
    }

    // v1.0 Production Hardening — operational status, validation, backup and recovery.
    if(req.method==='GET'&&url.pathname==='/api/production/status')return send(res,200,{version:VERSION,...production.runtimeStatus(store.read()),rateLimits:{readPerMinute:RATE_READ_PER_MINUTE,writePerMinute:RATE_WRITE_PER_MINUTE}});
    if(req.method==='GET'&&url.pathname==='/api/production/validate'){const result=production.validate(store.read());return send(res,200,{version:VERSION,...result});}
    if(req.method==='GET'&&url.pathname==='/api/production/backups')return send(res,200,{version:VERSION,retention:5,backups:production.listBackups()});
    if(req.method==='POST'&&url.pathname==='/api/production/backup'){const b=await parseBody(req),d=store.read(),reason=String(b.reason||'manual').slice(0,120),result=production.createBackup(d,reason);store.addAudit(d,'production.backup.create',{name:result.name,reason,stateHash:result.stateHash});store.write(d,{withReliability:false});return send(res,201,{version:VERSION,...result});}
    if(req.method==='POST'&&url.pathname==='/api/production/restore'){const b=await parseBody(req);if(b.confirm!=='RESTORE_PRODUCTION_BACKUP')return send(res,400,{error:'Explicit confirmation required.'});const name=String(b.name||''),existing=store.read(),pre=production.createBackup(existing,'pre-restore');try{const result=production.restoreBackup(name,path.join(__dirname,'data','store.json')),after=store.read();store.addAudit(after,'production.backup.restore',{name,preRestoreBackup:pre.name,stateHash:result.stateHash});store.write(after,{withReliability:false});return send(res,200,{version:VERSION,...result,preRestoreBackup:pre});}catch(e){try{production.restoreBackup(pre.name,path.join(__dirname,'data','store.json'));}catch(_){}return send(res,400,{error:e.message,recoveryBackup:pre.name});}}
    if(req.method==='GET'&&url.pathname==='/api/audit')return send(res,200,store.read().auditLog);
    if(req.method==='GET' && /^\/work\/[^/]+$/.test(url.pathname)) {
      return send(res,200,fs.readFileSync(path.join(PUBLIC,'index.html')),'text/html; charset=utf-8');
    }
    if(req.method==='GET'){
      let p=url.pathname==='/'?path.join(PUBLIC,'index.html'):path.normalize(path.join(PUBLIC,url.pathname));
      if(!p.startsWith(PUBLIC))return send(res,403,{error:'Forbidden'});
      if(fs.existsSync(p)&&fs.statSync(p).isFile())return sendStaticFile(req,res,p);
      return send(res,404,{error:'Not found'});
    }
    return send(res,405,{error:'Method not allowed'});
  } catch(e) { try{production.logError({requestId:res.__omniRequestId,message:e.message,status:e.status||400,path:url.pathname,stack:process.env.NODE_ENV==='production'?undefined:e.stack});}catch(_){} return send(res,e.status||400,{error:e.message,requestId:res.__omniRequestId,validation:e.validation?{issues:e.validation.issues.slice(0,20),warnings:e.validation.warnings.slice(0,20)}:undefined}); }
}

const server=http.createServer({maxHeaderSize:16*1024,requestTimeout:120000,headersTimeout:20000,keepAliveTimeout:5000},router);
server.on('clientError',(err,socket)=>{try{socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');}catch(_){}});
const storeFile=path.join(__dirname,'data','store.json'); let startupRaw=JSON.parse(fs.readFileSync(storeFile,'utf8')); const migration=production.migrate(startupRaw); if(migration.migrated){ try{production.createBackup(startupRaw,'pre-schema-migration');}catch(_){} production.atomicWriteJson(storeFile,startupRaw); } store.read();
process.on('uncaughtException',(err)=>{try{production.logError({fatal:true,type:'uncaughtException',message:err.message,stack:err.stack});}catch(_){} console.error(err);});
process.on('unhandledRejection',(err)=>{try{production.logError({fatal:false,type:'unhandledRejection',message:String(err?.message||err),stack:err?.stack});}catch(_){} console.error(err);});
function shutdown(signal){console.log(`OmniShelf v${VERSION} ${signal}; shutting down`);server.close(()=>process.exit(0));setTimeout(()=>process.exit(1),5000).unref();}
process.on('SIGTERM',()=>shutdown('SIGTERM'));process.on('SIGINT',()=>shutdown('SIGINT'));
server.listen(PORT,()=>console.log(`OmniShelf v${VERSION} running at http://localhost:${PORT}`));
