# OmniShelf v0.76 — Build Validation

**Release:** v0.76 — Social / Community 2.0  
**Date:** 2026-10-07  
**Base:** v0.75 — Unified Discovery → Library

## Product validation

- Community deterministic self-test: **9/9**.
- Community HTTP E2E: **8/8** in a disposable workspace.
- Local profile, follow/unfollow and network counts validated.
- Current-user community favorite projection reuses `lib/library.js` favorite state rather than a duplicate personal-favorites store.
- Public community review create/edit/delete and likes validated.
- Explicit All / Following / Mine community activity scopes validated.
- Community-driven discovery from followed members' public favorites validated.
- Work Page exposes a read-only `communityReviews` projection and a direct community-review handoff.
- Full workspace backup export includes community state.
- Restore sanitizes community member favorites, follow edges, reviews, likes and activities against the restored catalog/member graph.
- Demo community mode is read-only and non-persistent.

## Regression validation

The inherited v0.75 deterministic matrix remains green, and v0.76 adds the Community suite:

**22 deterministic suites / 237 individual checks passed.**

The 22 suites cover Personal Library, Library Experience, Library History, Smart Library Collections, Personal Statistics 2.0, Recommendations 2.0, Unified Workflow, Catalog UX, Catalog Experience, Medium Experience Framework, Asian Dramas, Work Pages, Standalone Work Pages, Unified Provider Search, Provider Reliability, Cross-Provider Identity, Unified Enrichment, Final Data Governance, Open Library quality/offline coverage, TMDB offline coverage, IGDB offline coverage, and Social / Community 2.0.

**6 disposable HTTP E2E suites / 81 individual checks passed:**
- Personal Library Experience: **19/19**
- Smart Library Collections: **17/17**
- Personal Statistics 2.0: **15/15**
- Recommendations 2.0: **14/14**
- Unified Discovery → Library Workflow: **8/8**
- Social / Community 2.0: **8/8**

All HTTP mutation tests run against disposable workspaces and leave the shipped datastore untouched.

## Code validation

- Node syntax checks pass for `server.js`, `lib/community.js`, updated recommendation/work-page modules, deterministic self-tests and HTTP E2E scripts.
- The inline client code extracted from `public/index.html` passes `node --check`.
- `preview.html` is byte-identical to `public/index.html`.
- The shipped `data/store.json` is clean after validation.

## Boundaries

- The local Community layer performs no AniList, Open Library, TMDB or IGDB writes.
- Provider ratings/reviews remain provider metadata and are not silently turned into local community reviews.
- Production authentication and multi-user security isolation are intentionally not claimed in v0.76; the local `you` identity is a product/data-model foundation.
- AniList authorization and live acceptance remain an independent external dependency.

## Release-state validation

- Cumulative `PROJECT_HISTORY.md`, `CURRENT_STATE.md`, `README.md` and `SUPPLIED_ARCHIVE_INDEX.md` updated for v0.76.
- `VERSION.txt` and `package.json` report **0.76.0**.
- Source hash manifest regenerated after all release content was finalized.
- Archive extracted successfully; ZIP integrity passed.
- Archive contains exactly one `OmniShelf-v0.76` root directory.
