# OmniShelf v0.63 — Final Data Governance

## Purpose

v0.63 is the governance boundary above the canonical catalog and provider layers. It makes data provenance explicit, protects human-owned values from ordinary provider overwrite, surfaces freshness uncertainty, makes deletion impact inspectable, and adds integrity verification for JSON workspace backups.

## Canonical governance model

Supported governed fields are `title`, `type`, `year`, `description`, `creators`, `tags`, `aliases`, `coverUrl`, and `externalLinks`.

Each non-empty field can expose a source reference containing catalog ID, provider, provider ID, source type, field, and reason. Existing v0.60 enrichment provenance remains authoritative when present; otherwise governance infers the source from the record's provider identity. This allows older records to be audited without requiring a destructive migration.

## Precedence and overwrite policy

- Manual is the highest default scalar source and ordinary manual edits are always permitted.
- A non-empty manually attributed field is protected from ordinary provider overwrite.
- A provider can refresh a field already owned by that same provider.
- A higher-precedence provider can replace a lower-precedence provider value when no manual protection applies.
- Lower-precedence provider writes are blocked unless an explicit override is supplied through the governance policy check surface.
- Unified enrichment remains preview-first and uses v0.59 identity-group field preferences before its deterministic v0.60 provider precedence.

## Freshness policy

Default governance freshness windows are local OmniShelf policy values, not provider guarantees:

- AniList: 30 days
- TMDB: 30 days
- IGDB: 30 days
- Open Library: 180 days
- Manual: not applicable

Provider records without a recognized retrieval timestamp are reported as `unknown`, not silently treated as fresh. Environment variables can override provider-specific thresholds (`OMNI_STALE_ANILIST_DAYS`, `OMNI_STALE_OPENLIBRARY_DAYS`, `OMNI_STALE_TMDB_DAYS`, `OMNI_STALE_IGDB_DAYS`).

## Deletion safety

Before deletion, the governance layer can report identity-group membership, collection references, review references, provider-backed tombstone requirement, enrichment lineage, and a risk level. Provider records receive durable governance deletion tombstones. Existing AniList-specific tombstones remain intact for sync safety. Identity reconciliation continues to prune orphaned group references after catalog deletion.

## Audit history

`data.governance.fieldHistory` records field-level before/after changes for governed catalog writes, including source, action, reason and timestamp. Retention is bounded by the governance policy. The existing top-level `auditLog` remains the broader workspace audit stream.

## Backup / restore integrity

JSON workspace backups now contain a `backupIntegrity` manifest using SHA-256 over the complete backup payload excluding the integrity manifest itself. The restore validator rejects a payload whose recorded hash does not match. Older backups without an integrity manifest remain backward-compatible.

Governance state is included in full JSON backup/restore: policy, field history, deletion tombstones, validation runs and backup manifests. Catalog JSON export preserves each item's governance metadata. CSV remains a deliberately portable, flat format and does not attempt to encode the full governance graph.

## APIs

- `GET /api/governance/status`
- `GET /api/governance/policy`
- `GET /api/governance/audit?field=&catalogId=&limit=`
- `GET /api/governance/items/:catalogId`
- `GET /api/governance/deletion-impact/:catalogId`
- `POST /api/governance/validate`
- `POST /api/governance/backup/verify`
- `POST /api/governance/policy/check`
- `POST /api/governance/deletion/preview`

## UI

A first-class **Governance** tab exposes attribution coverage, conflicts, stale/unknown provider freshness, audit history, policy precedence, deletion impact, backup verification and a deterministic policy demonstration.

## Boundaries

Governance does not claim provider ownership of facts that were never retrieved. Live provider authorization/acceptance remains separate. CSV is portable export, not a complete workspace snapshot. A direct provider adapter may still store provider-native raw metadata; governance controls the canonical record write boundary rather than replacing provider-specific schemas.
