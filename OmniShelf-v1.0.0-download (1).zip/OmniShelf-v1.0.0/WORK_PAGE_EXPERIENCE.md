# OmniShelf Work Page Experience — v0.68

## Purpose
v0.67 introduces a richer work-level presentation without changing the canonical data model. The work page is a read model over an existing catalog item and its already-persisted provider/identity/enrichment/governance state.

## API
- `GET /api/catalog/:id/work-page`
- `POST /api/catalog/work-page/selftest`

The work-page endpoint returns the provider-neutral read model plus the canonical catalog representation. It does not create identity decisions, enrichment runs or provider writes.

## Presentation model
The page is organized around:
1. Hero — cover, backdrop, title, type, provider, status and year.
2. Title variants — original/alternate titles already present in the canonical/provider metadata.
3. At-a-glance metadata — languages, origin/country, genres/tags, networks, companies, structure and status.
4. Story — description and, where available, normalized storyline.
5. People — creators, directors, writers, cast and crew already stored in normalized metadata.
6. Gallery — existing media asset references; bytes are not downloaded merely by opening the page.
7. Relationships — existing canonical relations.
8. Collections — existing list/collection memberships.
9. Identity — confirmed cross-provider group and candidate count when available.
10. Enrichment — existing unified-enrichment coverage/conflict state.
11. Governance — field-count/provenance retrieval context.
12. Sources — provider/external URLs.
13. Provider detail — provider-specific information preserved by the deep adapters.

## Medium behavior
The work-page renderer is intentionally provider-neutral. Medium-specific presentation comes from normalized metadata:
- TV/movie records can expose seasons, episodes, runtimes, networks and release dates.
- Games can expose game status/type and IGDB-specific systems already preserved by v0.58.
- Open Library records can expose work/edition lineage and author/subject identifiers from v0.56.
- AniList records can expose format/status/season/episode/chapter/volume/studio fields preserved by the existing AniList layer.
- Asian Drama records inherit the shared title, original-language, origin-country, network and airing metadata introduced in v0.65/v0.66.

## Safety and ownership
- The page is read-only.
- Editing remains on the existing governed `PATCH /api/catalog/:id`.
- Opening a page cannot create or reject an identity relationship.
- Opening a page cannot apply unified enrichment.
- Opening a page cannot change provider data.
- E2E tests use disposable datastore copies.

## Known next improvement
v0.68 should add a dedicated URL/deep-link route and richer standalone work pages, so a work can be opened, shared and navigated independently of the Catalog modal.


## v0.68 standalone navigation
The shared work-page contract is now used by the dedicated `/work/:id` route as well as the quick modal preview.
