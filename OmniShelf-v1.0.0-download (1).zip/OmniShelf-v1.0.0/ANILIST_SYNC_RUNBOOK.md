# OmniShelf AniList Sync Runbook — v0.43

## Sync model

OmniShelf keeps three distinct pieces of sync state for each AniList-linked catalog item:

1. `lastSyncedState` — the last successful remote list snapshot.
2. `localOverride` — local changes staged but not yet pushed.
3. `anilistSyncTombstones` — deletion intent/state retained after local deletion.

v0.43 adds a workspace-level journal and per-user/type watermark:

- `anilistSyncRuns[]` records preview/commit runs and their idempotency keys.
- `anilistSyncCursors{}` stores the last explicitly committed AniList `updatedAt` watermark.

## Incremental refresh

AniList's current `Page.mediaList` reference supports ordering by `MediaListSort` but does not expose a dedicated `updatedAt > cursor` filter. OmniShelf therefore scans pages ordered by `UPDATED_TIME_DESC` and stops at the previous watermark, with a one-second overlap to avoid timestamp-tie gaps.

A scan that reaches the watermark/end can produce a `cursorCandidate`. A scan cut short by the item limit cannot advance the cursor.

## Remote deletions

Incremental refresh cannot discover a list entry that no longer exists on AniList. Periodic full reconciliation remains required for deletion detection. The v0.42 tombstone model remains authoritative for explicit local/remote deletion resolution.

## Idempotency

`POST /api/anilist/sync/incremental-preview` accepts an optional `idempotencyKey`. Repeating the same key for the same user/type/cursor identity returns the prior run instead of creating another run.

## Watermark commit

Preview never advances the watermark. `POST /api/anilist/sync/runs/:id/commit` requires `confirm=true`, only accepts complete previewed runs, and is idempotent once committed.

## Backup continuity

Full OmniShelf backups include `anilistSyncTombstones`, `anilistSyncRuns`, and `anilistSyncCursors`. This is required so the project can resume safely after an export/import or future conversation handoff.

## Important external constraint

Live AniList calls could not be executed in the build environment because outbound DNS/network access was unavailable. Production use should re-run the live checks in an environment with AniList network access and with credentials configured.
