# OmniShelf v0.70 — Everyday Personal Library Experience

## What changed
- Added a read-only personal library overview model and API.
- Added Continue, Plan to, Completed and Favorites quick shelves.
- Added a measurable progress dashboard that reports finite totals only when the medium/work metadata provides one.
- Added Recently Updated personal shelf content.
- Added per-medium personal library statistics and selectable medium-specific views.
- Added compact continuation cards with direct Open and one-click progress actions.
- Kept the existing full library search, filters, sorting, pagination and inline editing workflow.
- Kept the v0.69 personal-state contract and backup/restore behavior intact.
- Cleaned the library frontend into one canonical loader path for the v0.70 experience.
- Added deterministic Library Experience and isolated HTTP E2E coverage.

## Architectural rationale
v0.69 established personal library state. v0.70 makes that state useful as a daily product surface without changing the underlying ownership boundary: providers describe canonical works, the canonical catalog reconciles those works, and the personal layer records how the user is experiencing them.

Medium-specific personal views are presentation/read-model features over the same canonical catalog IDs. They do not create separate Anime, Manga, Novel, Game or other databases.

## AniList boundary
AniList remains an independent provider track. v0.70 does not make My Library dependent on AniList availability and does not enable live AniList operations.

## Known boundaries
- The personal library remains a single local workspace (`You`).
- Mixed-medium totals are displayed as raw units rather than being combined into a meaningless universal unit; aggregate percentage is limited to records with finite totals.
- Automatic synchronization of personal state to AniList or other external services remains outside this release.
