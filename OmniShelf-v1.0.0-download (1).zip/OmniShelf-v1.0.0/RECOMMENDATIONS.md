# Recommendations 2.0

OmniShelf recommendations are a derived, read-only view over canonical catalog data plus the user's personal library and history. They do not create or mutate catalog/provider records.

## Personal signal
Positive signal comes from favorites, high personal scores, completed and active/re-experiencing items, and weaker planning/paused engagement. Dropped items produce negative signal and are not recommended themselves. Personal signal is propagated across medium/type, tags, creators, provider, and release decade.

## Candidate scoring
Candidates are catalog works not already present in the personal library. The rank combines personal overlap, explicit catalog relationships, available provider ratings, and a bounded popularity signal. When personal history is too sparse, OmniShelf falls back to discovery mode rather than pretending there is a strong personal profile.

## Explainability
Each result includes up to three reasons, such as a direct relation to a highly engaged work, creator overlap, thematic overlap, medium affinity, or strong provider/catalog quality.

## Controls
The endpoint and UI support `mode`, `type`, `minScore`, and `limit`. `personalized` requires a sufficiently strong profile; `discovery` is useful for new/empty libraries; `all` keeps the full score without the automatic discovery uplift.

## Non-goals
Recommendations do not call AniList, TMDB, IGDB, or Open Library live. Provider APIs remain catalog/enrichment concerns; recommendation generation uses the provider metadata already present in the canonical catalog.
