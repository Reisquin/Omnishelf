# OmniShelf v0.63 — Final Data Governance Layer

## Release goal

Complete the provider architecture's governance boundary so canonical catalog data remains explainable, safe to update, safe to delete, and verifiable after backup/restore.

## Included

- Added `lib/governance.js` with provider-neutral field attribution, precedence, overwrite protection, freshness policy, deletion-impact analysis, deletion tombstones, field-level audit history, deterministic validation, and backup integrity hashing.
- Added persistent `data.governance` state to the datastore.
- Added lazy governance attribution for legacy catalog items so existing records can be audited without a destructive migration.
- Integrated governance checks into manual catalog edits, Review Queue provider application, AniList/Open Library/TMDB/IGDB enrichment applies, and unified enrichment apply.
- Added governance records for provider retrieval freshness when enrichment metadata exposes a retrieval timestamp.
- Added JSON backup `backupIntegrity` SHA-256 manifest and restore-time verification; older backups without a manifest remain accepted.
- Preserved governance state through workspace restore and catalog JSON export.
- Added deletion-impact inspection and durable governance deletion tombstones while retaining the existing AniList sync tombstone mechanism.
- Added Governance UI and governance API surfaces.
- Added `npm run governance:selftest` with deterministic coverage for manual protection, provider precedence, explicit override, freshness, deletion impact, audit history and backup tamper detection.
- Preserved all prior AniList, Open Library, TMDB, IGDB, identity, enrichment, reliability, unified-search, catalog, Community, Collections, Saved Views, Data Hub, Review Queue, synchronization and continuity work.

## Safety decisions

- Governance is conservative: a provider cannot silently replace a manually attributed non-empty field.
- Search remains read-only; identity remains explicit; enrichment remains preview-first.
- Backup integrity is additive and backward-compatible with older un-hashed backups.
- Freshness is treated as an observation based on timestamps actually carried by canonical records, not a provider guarantee.

## Validation

- Governance deterministic suite: 14/14
- Unified Search regression: 13/13
- Reliability regression: 8/8
- Identity regression: 10/10
- Unified Enrichment regression: 10/10
- TMDB regression: 17/17
- IGDB regression: 25/25
- Open Library regression: 5/5
- Isolated HTTP E2E: 18/18
- Source manifest: 120 entries, 0 mismatches
- ZIP integrity: PASS
- Preview mirror: PASS

Headless screenshot capture is not claimed because the container browser runtime remains environment-limited. Live provider acceptance remains separate and is not claimed without credentials/network/authorization.

## Next

The original provider-architecture roadmap ends at v0.63. Future work should now focus on turning the mature data infrastructure into an exceptional user product experience while preserving this governance boundary.
