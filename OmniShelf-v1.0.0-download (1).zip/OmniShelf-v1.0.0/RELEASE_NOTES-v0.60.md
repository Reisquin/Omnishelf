# OmniShelf v0.60 — Unified Enrichment Engine

## Purpose
v0.60 converts the confirmed cross-provider identities from v0.59 into a practical enrichment workflow. One selected catalog member can be enriched using evidence from all members of a confirmed identity group while provider-native records remain intact.

## What changed
- Added `lib/enrichment.js` with deterministic field policy, conflict detection, list merging, provider coverage, plan hashing and safe apply.
- Added scalar precedence by field and identity-group field-preference overrides.
- Added normalized de-duplication for creators, tags, aliases and external links.
- Added field-level provenance for every proposed/applied field.
- Added explicit conflict buckets for scalar disagreement.
- Added optimistic concurrency (`updatedAt`) and deterministic plan hash checks.
- Added persistent enrichment run journal and per-record enrichment lineage.
- Added Unified Enrichment UI and demo.
- Added enrichment-aware catalog detail output and backup/restore preservation.
- Added deterministic `npm run enrichment:selftest`.

## Safety
- No provider-native catalog member is deleted or silently rewritten by the enrichment engine.
- Apply is explicit and only operates on the selected target record.
- A plan generated against one target state cannot be applied after that target changes.
- Conflict evidence remains visible even when a preferred value is selected.
- Demo mode is datastore-neutral.

## Known limitations
- v0.60 consumes provider evidence already present in a confirmed identity group. It does not yet orchestrate broad live refreshes across all providers.
- Source precedence is a deterministic baseline and should evolve under the later data-governance milestone.
- Reversing a chosen enrichment requires restoring the target from backup or explicitly editing the affected fields; a dedicated field-level rollback/history UI is future work.

## Next
v0.61 — Provider Reliability & Operations.
