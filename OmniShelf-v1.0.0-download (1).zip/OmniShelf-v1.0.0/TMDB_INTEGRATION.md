# TMDB Integration — OmniShelf v0.57

## Purpose
TMDB is the third provider to receive a deep integration treatment after AniList and Open Library. The v0.57 architecture keeps TMDB provider payloads separate from the canonical catalog until normalization, matching, Review Queue approval, or explicit enrichment.

## Supported provider surfaces
- Movie search
- TV search
- Movie discover
- TV discover
- Movie detail
- TV detail
- Collections
- People
- TV seasons
- TV episodes

## Canonical mapping
| TMDB | OmniShelf |
|---|---|
| Movie | Movie |
| TV | TV |

Cross-provider identity is deliberately not solved in v0.57. A TMDB candidate is first compared to the existing catalog using TMDB-specific evidence. v0.59 is the planned cross-provider identity/reconciliation milestone.

## Normalized metadata
A normalized TMDB work can preserve:
- provider ID and TMDB URLs
- title, original title and alternate titles
- release date / first-air date / last-air date
- status, runtime, episode runtime, season and episode counts
- genres and keywords
- original/spoken languages and origin countries
- production companies and TV networks
- creators, directors, writers, cast and crew
- season inventory
- collection membership
- IMDb, TVDB, Wikidata and other returned external IDs
- translations
- posters, backdrops and logos
- videos/trailers as remote references
- recommendations and similar IDs
- TMDB raw provider payload and provenance

## Request discipline
Live requests use server-side credentials, a five-minute memory cache, a 150-entry cache bound, and serialized pacing at approximately one request every 250ms. The adapter performs a single bounded retry after HTTP 429 and respects `Retry-After` when it is supplied. Search/discover pages and normalized results are bounded to avoid accidentally creating bulk-harvesting behavior.

## Asset policy
TMDB artwork is not copied into the datastore. Normalized records carry remote image references generated from the TMDB image host. Demo mode uses deterministic local SVG fixtures so the UI can be exercised without external requests.

## Review / apply flow
TMDB discovery can be queued into the existing Review Queue. The review item carries normalized data, match candidates, and quality diagnostics. On approval, the canonical catalog record is created and TMDB entities are persisted.

Canonical enrichment is preview-first and protected by `expectedUpdatedAt` so a stale browser preview cannot silently overwrite a catalog record changed by somebody else. Non-empty manual title/description/creator/tag/alias values are preserved.

## Entity registry
The persistent TMDB registry currently stores:
- people
- production companies
- networks
- collections
- enrichment journal
- Review Queue diagnostics

The registry can be rebuilt from approved TMDB catalog records.

## Demo IDs
The local deterministic fixtures use IDs in the 9000 range and are never sent to TMDB. They exist only for offline testing of the normalization/UI pipeline.

## v0.66 medium-experience extensions
v0.66 extends the existing TV discovery surface for the reusable medium-experience layer.
- `with_origin_country` can be passed for profile-aware Asian Drama discovery.
- `with_original_language` remains optional; profiles with multiple supported languages are not artificially narrowed to the first language unless the user explicitly selects one.
- The Asian Drama discovery route classifies provider results after normalization rather than treating TMDB country/language filters as proof on their own.
- TV Watch Providers is exposed through a separate, read-only adapter with explicit configuration and attribution gates.
- Demo Watch Provider links preserve the inspected provider ID so offline inspection cannot point to an unrelated fixture.
