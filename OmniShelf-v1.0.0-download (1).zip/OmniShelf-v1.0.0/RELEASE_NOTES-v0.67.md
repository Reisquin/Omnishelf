# OmniShelf v0.67 — Core Catalog UX & Rich Work Pages

## Summary
v0.67 shifts OmniShelf further into product experience. The canonical Catalog now supports visual card browsing and a compact list mode, while each catalog record can open a richer provider-aware work page.

## Added
- Card-first Catalog UX.
- Persistent card/list preference using browser local storage.
- Medium quick filters over the canonical catalog.
- Richer catalog cards with covers, metadata, creators, tags and work actions.
- `lib/work-pages.js` provider-neutral work-page model.
- `GET /api/catalog/:id/work-page`.
- `POST /api/catalog/work-page/selftest`.
- Rich work-page hero, title variants, metadata, story, people, gallery, relationships, collections, identity, enrichment, governance, source and provider-detail sections.
- Full cumulative history through v0.67.

## Compatibility
The v0.59 identity graph, v0.60 enrichment layer, v0.61 reliability layer, v0.62 unified search, v0.63 governance boundary, v0.64 Catalog Experience, v0.65 Asian Drama medium and v0.66 Medium Experience Framework remain intact.

## Design boundary
The work page is a read model. It does not create provider records, identity decisions, enrichment runs or governed writes. Existing catalog editing remains the canonical write path.

## Validation fixes
- Corrected work-page route ID extraction.
- Corrected Catalog UX self-test to inspect the actual shared catalog renderer.
- Kept Unified Provider Search regression aligned with its existing response schema.

## Known limits
- Current work-page presentation is an in-app modal; dedicated/deep-linkable work-page navigation is planned for v0.68.
- Live provider acceptance still requires external credentials/network access.
- Automated screenshot capture remains environment-dependent.
