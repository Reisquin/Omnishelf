# OmniShelf v0.66 — Build Validation

## Release scope
Reusable Medium Experience Framework + Asian Drama provider discovery and controlled ingestion.

## Static validation
- `node --check server.js` — PASS
- `node --check lib/tmdb.js` — PASS
- `node --check lib/asian-dramas.js` — PASS
- `node --check lib/medium-experiences.js` — PASS
- `public/index.html` inline JavaScript syntax — PASS (1 inline script block)

## Deterministic suites
- Medium Experience Framework — 7/7
- Asian Drama — 18/18
- Catalog Experience regression — 8/8
- Unified Provider Search regression — 13/13
- Provider Reliability regression — 8/8
- Identity regression — 10/10
- Unified Enrichment regression — 10/10
- Data Governance regression — 14/14
- TMDB regression — 17/17
- IGDB regression — 25/25
- Open Library regression — 5/5

## HTTP end-to-end validation
Isolated server on a dedicated local port — 21/21:
1. Health/version
2. Medium directory
3. Medium framework self-test
4. Regional profile listing
5. K-Drama discovery
6. Taiwanese discovery
7. C-Drama discovery
8. Provider-detail inspection
9. Watch Provider status gate
10. Demo Watch Providers
11. Live Watch Providers blocked without explicit gate
12. Live TMDB discovery blocked without credentials
13. Ingestion preview
14. Review Queue handoff
15. Review Queue persistence
16. Review Queue approval
17. Pending-state removal after approval
18. Catalog API validity
19. Review Queue approval boundary
20. Mediums UI route
21. Asian Drama self-test HTTP endpoint

The isolated E2E copy was allowed to mutate its own Review Queue during testing; the shipped release datastore was not used for these mutations.

## v0.66 fixes discovered during validation
- Removed unnecessary default-language narrowing for profiles that support multiple languages.
- Provider-detail demo now resolves the selected fixture from the Asian Drama discovery fixture set instead of returning a generic US TV fixture.
- Ingestion preview uses the same selected demo fixture as provider-detail.
- Ingestion preview explicitly reports `readOnly: true`.
- Demo Watch Provider links now use the inspected fixture ID.
- Review Queue validation uses the established 201 Created contract and `{ normalized: ... }` handoff shape.

## Data integrity
- Demo discovery and provider-detail operations are read-only and do not populate the canonical catalog.
- No synthetic Asian Drama fixture records are shipped.
- Final datastore is restored/verified clean before packaging.
- Source SHA-256 manifest is generated after all final edits and verified with zero mismatches.
- `preview.html` is synchronized byte-for-byte with `public/index.html`.

## External/live boundaries
- No live TMDB acceptance is claimed in this environment because credentials/network access are not available.
- Watch Providers remains disabled by default and separately gated for JustWatch attribution.
- Headless visual screenshot capture is environment-dependent; no automated screenshot pass is claimed.
