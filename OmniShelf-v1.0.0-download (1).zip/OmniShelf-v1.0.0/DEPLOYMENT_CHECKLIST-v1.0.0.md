# OmniShelf 1.0.0 — Production Deployment Checklist

## Before launch
- [ ] Deploy the exact 1.0.0 archive.
- [ ] Configure persistent workspace storage.
- [ ] Supply secrets and environment configuration outside the repository.
- [ ] Keep provider modes at safe defaults until separately authorized/accepted.
- [ ] Put OmniShelf behind HTTPS / the intended reverse proxy boundary.
- [ ] Configure backup storage and retention.
- [ ] Configure operational log collection/rotation.

## Launch smoke
- [ ] `npm start` starts cleanly.
- [ ] `/api/health` reports version `1.0` and healthy state.
- [ ] `/api/production/status` and `/api/production/validate` pass.
- [ ] Discover → Work Page → Library → Track → Finish → Review → Recommend works.
- [ ] Community, Import/Export, Smart Collections, Statistics and System surfaces load.
- [ ] Keyboard, responsive and reduced-motion behavior is verified.
- [ ] A recovery backup is created before accepting real user data.

## Provider acceptance
- [ ] Run each provider's documented live acceptance from a network-enabled authorized environment.
- [ ] Do not treat demo/offline success as live acceptance.
- [ ] Enable AniList live writes only after the documented authorization and write-acceptance gates are satisfied.

## Rollback
- [ ] Preserve the previous release archive.
- [ ] Take a pre-restore backup before destructive recovery actions.
- [ ] Restore only after integrity validation and explicit confirmation.
