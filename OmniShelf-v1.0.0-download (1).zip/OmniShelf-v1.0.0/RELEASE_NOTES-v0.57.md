# OmniShelf v0.57 — Release Notes

## Headline
TMDB becomes a deep Movie/TV provider integrated into the same canonical Search → Normalize → Match → Review → Apply architecture already established for AniList and Open Library.

## What changed
- TMDB Movie and TV search/discovery
- Rich Movie/TV metadata and normalization
- Credits, people, companies, networks and collections
- Release dates, seasons and episode structure
- Localization, alternate titles and external IDs
- Remote image/video references and deterministic offline fixtures
- Identity diagnostics and quality scoring
- Review Queue integration
- Canonical enrichment with stale-preview protection
- Persistent TMDB entity registry
- TMDB live-read acceptance harness
- Provider attribution in the UI
- Full cumulative project history carried forward

## What is not claimed
- Live TMDB acceptance has not been run in this offline build environment.
- TMDB authorization/licensing approval is not inferred from having credentials.
- Cross-provider identity reconciliation is not complete until v0.59.
- TMDB write mutations are not part of this release.
