# Unified Enrichment — v0.60

## Role in OmniShelf
The v0.59 identity graph answers **“Which catalog records represent the same work?”**. v0.60 answers **“Given that identity decision, how should useful metadata be combined into one selected canonical target?”**

## Input boundary
Only members of an existing confirmed `identity.groups[]` entry are eligible. The engine does not infer new identities and does not automatically call external providers. This keeps enrichment downstream of explicit identity decisions and avoids using fuzzy matches as write authority.

## Supported fields
Scalar: `title`, `type`, `year`, `description`, `coverUrl`.

List-like: `creators`, `tags`, `aliases`, `externalLinks`.

## Source precedence
Every scalar field first checks the identity group's explicit `fieldPreferences[field]` catalog ID. If that preferred member has a non-empty value, it wins. Otherwise the deterministic default order is: 

- `title`: Manual → AniList → TMDB → Open Library → IGDB
- `type`: Manual → AniList → TMDB → Open Library → IGDB
- `year`: Manual → Open Library → TMDB → AniList → IGDB
- `description`: Manual → AniList → TMDB → Open Library → IGDB
- `creators`, `tags`, `aliases`, `coverUrl`, `externalLinks`: Manual → AniList → TMDB → Open Library → IGDB for tie ordering; list-like fields still union rather than selecting a single source.

The precedence is a baseline policy, not a claim that one provider is globally authoritative. Later governance can add provider/field-specific rules without changing the identity graph.

## Conflict behavior
For scalar fields, values are bucketed by normalized equivalence. More than one bucket becomes an explicit conflict. The plan still selects one proposed value so the target can be made internally coherent, but the competing values and their source records remain attached in `enrichment.fieldProvenance[field]`.

For list-like fields, values are merged with normalization and de-duplication. This is intentionally additive.

## Apply safety
A preview contains `targetBeforeUpdatedAt` and `planHash`. Apply recomputes the plan from the current datastore. The plan hash deliberately excludes generation time, so a valid plan remains stable across the re-check. Apply is rejected when the target timestamp or plan content no longer matches.

## Persistent state
`data.enrichment.version` and `data.enrichment.runs[]` store the run journal. Enriched catalog targets receive an `enrichment` object containing the identity group, target, provider coverage, coverage score, unresolved conflict fields, field-level provenance, and policy metadata.

## APIs
- `GET /api/enrichment/status`
- `GET /api/enrichment/groups`
- `GET /api/enrichment/items/:catalogId`
- `GET /api/enrichment/coverage`
- `POST /api/enrichment/preview`
- `POST /api/enrichment/apply`

## UI
The Unified Enrichment top-level tab provides a group browser, coverage/status KPIs, datastore-neutral demo, preview controls, per-field proposed values, source evidence, conflict markers, plan hash and explicit Apply.

## Future extensions
- provider-specific live refresh orchestration
- field-level rollback/version history
- richer field governance and stale-data policy
- enrichment scheduling and reliability telemetry
- unified provider search feeding new records into the identity graph
