# Open Library Live Acceptance — v0.56

This is an operator-run, read-only acceptance suite for a network-enabled deployment.

## Plan

1. Search one user-requested query through the Search API.
2. Resolve one Work when returned.
3. Resolve one bounded Work → Edition relationship set.
4. Resolve one Edition when available.
5. Resolve one Author when available.
6. Resolve one ISBN when available.
7. Verify remote cover URL policy and that the adapter does not persist cover image bytes.

No Open Library mutation is performed.

## Configuration

Set identified-request configuration server-side:

```env
OPENLIBRARY_USER_AGENT=OmniShelf/0.56
OPENLIBRARY_CONTACT=your-real-contact@example.com
```

## Commands

Plan only:

```bash
npm run openlibrary:acceptance -- --plan
```

Live read-only acceptance:

```bash
npm run openlibrary:acceptance
```

The UI also exposes the acceptance plan. A live run should only be considered complete when executed on a network-enabled deployment with a valid identified-request configuration.
