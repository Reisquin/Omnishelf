# OmniShelf v0.64 — Catalog Experience & Discovery

## Summary
v0.64 starts the product-experience phase. After v0.63 completed the provider architecture, this release turns the canonical catalog into a more approachable Explore experience without weakening the underlying data and governance model.

## What changed
### Explore landing surface
The former operations-first Catalog tab is no longer the default entry point. Explore is now the first surface, with a large catalog search, medium shortcuts, live KPIs, browse-by-medium cards, recently added/updated sections, popular tags and a bridge into Unified Provider Search.

### Product-facing work details
Explore can open a canonical work in a focused modal that reuses the existing catalog detail API. It shows core metadata, creator/tag context, collections, identity state, relationships and governance status.

### Server support
`lib/explore.js` centralizes the Explore read model. `GET /api/catalog/explore` returns the summary, facets and curated lists consumed by the UI. `POST /api/catalog/explore/selftest` exposes the deterministic module test through the same local server boundary.

### Continuity
- `CATALOG_EXPERIENCE.md` records the product UX architecture and boundaries.
- `BUILD_VALIDATION-v0.64.md` records exact validation results.
- `PROJECT_HISTORY.md`, `CURRENT_STATE.md`, `README.md`, `SUPPLIED_ARCHIVE_INDEX.md` and the recovered project conversation remain cumulative and are updated through v0.64.

## Safety / non-goals
- No second catalog was introduced.
- Explore never persists identity decisions.
- Explore never writes provider data.
- No synthetic test records are shipped.
- Asian-drama support remains an explicit product direction, but country/industry/language normalization is not falsely claimed as complete in this milestone.

## Next dependency
v0.65 should build the first dedicated medium experience layer, with particular attention to Asian dramas and other media whose metadata/airing structures do not fit a generic title list.
