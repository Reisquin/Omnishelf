# OmniShelf v0.57 Build Validation

## Source
Built directly from the OmniShelf v0.56 release archive and preserved the inherited datastore/history before adding the v0.57 TMDB layer.

## Static checks
- `node --check server.js`
- `node --check lib/tmdb.js`
- `node --check lib/providers.js`
- `node --check lib/store.js`
- `node --check scripts/tmdb-offline-selftest.js`
- `node --check scripts/tmdb-live-acceptance.js`

## Deterministic provider tests
`npm run tmdb:selftest` validates normalization, release-date regions, collections, TV season/episode structure, exact-ID matching, quality scoring, enrichment preview, and entity-bundle generation without network access.

## HTTP smoke tests
The app should return HTTP 200 for:
- `/`
- `/preview.html`
- `/api/health`
- `/api/tmdb/status`
- `/api/tmdb/search?type=movie&q=demo&demo=1`
- `/api/tmdb/search?type=tv&q=demo&demo=1`
- `/api/tmdb/discover?type=movie&demo=1`
- `/api/tmdb/movie/9001?demo=1`
- `/api/tmdb/tv/9002?demo=1`
- `/api/tmdb/collections/9100?demo=1`
- `/api/tmdb/persons/9102?demo=1`
- `/api/tmdb/tv/9002/seasons/1?demo=1`
- `/api/tmdb/tv/9002/seasons/1/episodes/1?demo=1`

## Browser / preview invariant
`preview.html` is copied from the final served `public/index.html` after all release modifications, preventing UI drift.

## Data safety
The release datastore is kept at the clean v0.56 starting state unless an explicit local test modifies it. Packaging restores the clean datastore before final ZIP creation.

## Live limitations
Live TMDB acceptance remains operator-run. This build environment does not provide a reliable path to claim live upstream success.

## Recorded execution results

- Node syntax checks: passed for `server.js`, `lib/tmdb.js`, `lib/providers.js`, `lib/store.js`, and both TMDB acceptance/self-test scripts.
- `npm run tmdb:selftest`: passed, 17 deterministic checks; Movie and TV normalization, release-date regions, collection mapping, TV season/episode structure, exact identity matching, quality score, enrichment preview and entity bundles all passed.
- Isolated HTTP smoke test: passed 15 checks covering health, TMDB status, Movie/TV demo search, Movie/TV detail, release regions, collection, entity endpoints, TV discovery, season and episode endpoints.
- Routing hardening: verified TMDB nested season/episode routes are resolved before the broader TV-detail route, and TV detail requests do not append the Movie-only `release_dates` resource.
- Compatibility hardening: verified the inherited `/api/health` endpoint and current-release version reporting identify v0.57 while historical lower-level AniList coverage provenance remains preserved.
- Review Queue integration: passed in an isolated copy; TMDB review diagnostics were persisted during the test. The test copy was discarded and the release datastore was not changed.
- Clean datastore: the release `data/store.json` SHA-256 matches the supplied v0.56 baseline exactly: `767d36ac9f31895d926d2366edf29a101fdd1b9b027cc467ffd6dfb7bbac9920`.
- Served `public/index.html` and `preview.html`: byte-identical after release modifications.
- Embedded browser JavaScript: passed syntax validation as one 123,489-byte inline script block.
- Live TMDB acceptance: not run because the build environment has no configured TMDB credential and live acceptance must be operator-run on a network-enabled machine.
