# OmniShelf v0.61 — Provider Reliability & Operations

## Purpose

v0.61 adds the operational layer around the four deep providers: AniList, Open Library, TMDB and IGDB. The canonical catalog remains the system of record; reliability telemetry observes provider-backed operations without allowing one provider outage to destabilize the rest of OmniShelf.

## Operational model

### Provider health
Each provider has an in-memory operational state persisted into the workspace's `reliability` section whenever the server records an operation. Metrics include operation count, blocked calls, successes, failures, cache hits/misses, aggregate and average latency, last success/failure, last error, consecutive transient failures, circuit state, circuit-open count, degradation timestamps, and the latest observed upstream rate-limit information.

### Retries and backoff
Provider adapters keep their provider-specific request behavior and now use the shared exponential-backoff policy for transient retry decisions where the adapter retries. `Retry-After` is honored when it is available, with bounded waits. v0.61 does not invent a provider-specific limit when the upstream response does not expose one; it records only what the provider reports or what the adapter already knows from its documented integration contract.

### Circuit isolation
A provider circuit opens after three consecutive transient failures by default. While open, new live operations for that provider fail fast with `PROVIDER_CIRCUIT_OPEN` instead of repeatedly hammering an unavailable upstream service. After the configurable cooldown, one operation is allowed as a half-open recovery probe. Success closes the circuit; failure reopens it.

Configuration:

```text
OMNI_PROVIDER_FAILURE_THRESHOLD=3
OMNI_PROVIDER_CIRCUIT_COOLDOWN_MS=30000
```

Circuit state is per provider; an IGDB outage cannot block TMDB, Open Library or AniList.

### Cache observability
Successful provider operations expose whether the result came from cache. The reliability state tracks cache hits and misses separately from upstream failures. Provider-specific cache TTL and size policies remain defined by each adapter.

### Stale-provider data
The reliability layer scans canonical catalog records for the newest provider retrieval/enrichment timestamp it can actually identify. By default, data older than 90 days is classified as stale. Missing timestamps are classified as `unknown`, never silently treated as fresh.

```text
OMNI_STALE_DAYS=90
```

Supported timestamp sources include provider provenance and the established AniList enrichment timestamp paths. The scanner is intentionally conservative because historical provider records may not contain a retrieval timestamp.

## Persistence and backup

`data/store.json` carries the `reliability` object alongside catalog, identity and enrichment state. Workspace backup/export therefore carries provider operational history, incidents and health state. Restore accepts older backups without reliability state and keeps the current runtime operational state in that case; v0.61 backups restore the saved reliability snapshot explicitly.

## APIs

- `GET /api/providers/reliability` — provider health, readiness, recent events/incidents and stale-data report.
- `GET /api/providers/reliability/events?provider=&limit=` — bounded operational event log.
- `GET /api/providers/reliability/incidents?provider=&limit=` — circuit/open incident log.
- `GET /api/providers/staleness?provider=&staleDays=` — provider-backed freshness analysis.
- `GET /api/providers/reliability/acceptance` — per-provider offline and live acceptance command matrix.
- `POST /api/providers/reliability/selftest` — deterministic operational self-test; no provider network access.
- `POST /api/providers/reliability/reset` — explicitly reset operational metrics/circuits.
- `GET /api/providers/status` and `/api/health` — provider status now includes reliability state.

Provider-specific status endpoints (`/api/anilist/status`, `/api/openlibrary/status`, `/api/tmdb/status`, `/api/igdb/status`) also expose the corresponding reliability summary.

## UI

The top-level **Reliability** tab provides provider cards, circuit state, latency/failure metrics, operational event log, freshness/stale-data view, acceptance matrix and controlled reset/self-test actions.

Open directly with:

```text
http://localhost:3000/?view=reliability
```

## Acceptance boundary

Reliability self-tests are deterministic and offline. Live acceptance remains separate for each provider because credentials, network reachability and provider-specific authorization are external conditions. v0.61 never treats a configured credential as evidence of production authorization.

## Relationship to v0.60

v0.60's Unified Enrichment Engine is preserved unchanged as the local, preview-first merge layer. v0.61 adds the operational controls required before broad multi-provider live refresh orchestration and unified search.
