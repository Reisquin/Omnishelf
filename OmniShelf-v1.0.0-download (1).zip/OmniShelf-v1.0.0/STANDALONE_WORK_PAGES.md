# OmniShelf v0.68 — Standalone Work Pages

## Purpose
v0.68 turns the v0.67 rich work-page read model into a real navigable product surface. A canonical work now has a dedicated `/work/:id` URL that can be opened directly, shared, bookmarked, or reached from Catalog cards.

## Navigation model
- `GET /work/:id` serves the same OmniShelf application shell so the browser can deep-link directly to a canonical work without creating a second frontend.
- Client routing detects `/work/:id`, hides the catalog/admin shell, fetches `GET /api/catalog/:id/work-page`, and renders the standalone work page.
- In-app “Open page” actions use `history.pushState` so navigation does not require a full page reload.
- The standalone page provides an explicit back action and preserves the normal Catalog handoff.

## Medium-aware work presentation
The existing provider-neutral work-page model now exposes `mediumExperience`. v0.68 adds medium-specific highlight groups for: Asian Dramas, Games, Novels, Anime/Manga/Visual Novels, Film, and TV. These are derived from already-normalized canonical/provider metadata and do not create separate catalogs.

### Asian Drama emphasis
Asian drama work pages surface the regional profile where it can be determined from explicit drama type or unambiguous TMDB origin-country metadata, plus original language, network, episode/season counts, airing status, and related provider information. The system does not invent romanized titles or infer an Asian profile from generic language alone.

## Safety boundaries
- Opening a work is read-only.
- Provider records remain untouched.
- Editing still uses the governed canonical catalog PATCH path.
- Identity, enrichment, reliability, and governance data are presented from their existing canonical sources.

## Validation
The standalone route is covered by deterministic client checks plus isolated HTTP tests using a disposable datastore. The shipped datastore remains clean.
