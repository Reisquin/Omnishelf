# OmniShelf v0.61 — Build Validation

## Scope

This release hardens AniList, Open Library, TMDB and IGDB operations with provider-neutral reliability telemetry, bounded event/incident history, circuit isolation, retry/backoff coordination, cache observability, stale-data detection, readiness/acceptance reporting, and a first-class Reliability UI workspace. The existing canonical catalog, v0.59 identity graph and v0.60 unified enrichment layer remain intact.

## Deterministic offline validation

| Suite | Result |
|---|---:|
| `npm run reliability:selftest` | **8/8** |
| `npm run identity:selftest` | **10/10** |
| `npm run enrichment:selftest` | **10/10** |
| `npm run tmdb:selftest` | **17/17** |
| `npm run igdb:selftest` | **25/25** |
| `npm run openlibrary:quality-test` | **5/5** |

Reliability checks cover success accounting, cache observability, transient circuit opening, outage isolation, exponential backoff/Retry-After behavior, stale-data detection, the provider acceptance matrix, and provider-status composition.

## HTTP end-to-end validation

An isolated Node server was started on a non-default test port against a disposable copy of the workspace. The following passed:

1. `/api/health` reports v0.61 and four providers with reliability state.
2. All provider-specific status routes expose their reliability state.
3. Three missing-TMDB-credential failures are recorded against TMDB only and do not open its transient-outage circuit.
4. TMDB demo mode continues to work after the live-access failures.
5. Staleness reporting returns a valid zero-stale empty-catalog report.
6. Provider event filtering returns the expected TMDB operation events.
7. Acceptance matrix exposes all four providers.
8. Full backup export includes reliability telemetry.
9. Restore preview preserves reliability event counts.
10. Full restore preserves reliability telemetry and returns a successful restore result.
11. Explicit reliability reset clears operational state, and the persisted disposable datastore is clean afterward.

## Backup / persistence validation

The v0.61 backup payload contains `reliability` with provider state, bounded events and incidents. Restore accepts the v0.61 snapshot and rehydrates the in-memory reliability state before writing the restored workspace. A final reset test verified zero catalog records and zero reliability events in the disposable datastore.

## Source / syntax validation

JavaScript syntax checks passed for:

- `server.js`
- `lib/reliability.js`
- `lib/anilist.js`
- `lib/openlibrary.js`
- `lib/tmdb.js`
- `lib/igdb.js`
- `scripts/provider-reliability-selftest.js`

The release preview is a byte-identical copy of `public/index.html` after packaging preparation. The UI file contains the Reliability tab, provider cards, event log, stale-data view, acceptance matrix, self-test action and explicit reset action.

## Defects found during validation and fixed

- `reliability.providerStatus()` existed but was not exported from `lib/reliability.js`; this broke `/api/health` and provider status routes. The export and a dedicated regression check were added.
- Cache-hit accounting was initially omitted from reliability success bookkeeping; it was added and covered by the self-test.
- `Retry-After` handling initially treated an explicit `null` as zero delay; the retry policy now distinguishes missing values from a real zero delay.
- Initial shell E2E harness attempts had pipeline/stdin assumptions and an incorrect staleness response key; the harness was corrected to exercise the documented API response shape. These were test-harness issues, not shipped application defects.

## Live acceptance boundary

No live provider acceptance is claimed in this environment. Real AniList, Open Library, TMDB and IGDB acceptance still depends on external credentials, network reachability and each provider's own authorization/usage conditions. v0.61 includes the provider-specific commands and the operational acceptance matrix needed for an operator-run networked validation.

## Packaging checks

Before packaging:

- `VERSION.txt` is `0.61.0`.
- `package.json` is `0.61.0` and exposes `reliability:selftest`.
- `public/index.html` and `preview.html` match exactly.
- Source SHA-256 manifest is regenerated after all release edits.
- The shipped datastore contains no synthetic test catalog records or reliability events.
- The ZIP is tested for readable integrity after creation.

## Continuity

`PROJECT_HISTORY.md`, `CURRENT_STATE.md`, `README.md`, `RECOVERED_PREVIOUS_CHAT_HISTORY.md`, `SUPPLIED_ARCHIVE_INDEX.md`, release notes and validation docs carry the accumulated project history through v0.61. The next dependency is v0.62 Unified Provider Search.
