# OmniShelf v0.72 — Smart Library Collections

v0.72 adds dynamic rule-based Smart Library Collections on top of the v0.71 personal library and history architecture.

## Highlights

- Built-in Continue, Plan to, Completed, Favorites, 90+ Rated, and Recently Updated collections.
- Custom personal collections with all/any rule matching.
- Rules can combine medium/provider/year/tag criteria with personal status, favorite, score, progress, notes and recency conditions.
- Smart collections can be applied directly from the My Library filter bar.
- Save the current library filters as a reusable smart collection.
- Edit and delete custom collections without touching catalog data.
- Smart collection counts and previews recalculate from live personal state.
- Full backup/restore preserves smart library collections.
- Catalog-level Saved Views remain separate and unchanged.

## AniList

The AniList integration is preserved unchanged. v0.72 does not depend on AniList authorization or live API acceptance.

## Validation

See `BUILD_VALIDATION-v0.72.md` for the deterministic regression matrix, isolated HTTP checks, archive verification and source manifest results.

## Next milestone

v0.73 — Personal Statistics 2.0.
