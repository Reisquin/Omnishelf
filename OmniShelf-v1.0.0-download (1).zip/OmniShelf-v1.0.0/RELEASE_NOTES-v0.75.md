# OmniShelf v0.75 — Unified Discovery → Library

## Summary
v0.75 turns the existing discovery, Work Page, personal library and recommendation features into a coherent provider-neutral user journey.

## Added
- `lib/unified-workflow.js` with deterministic state-aware journey logic.
- `scripts/unified-workflow-selftest.js` and `npm run unified-workflow:selftest`.
- `GET /api/catalog/:id/workflow`.
- `POST /api/catalog/:id/workflow/action`.
- `POST /api/workflow/selftest`.
- Work Page `workflow` payload and a state-aware **Your journey** panel.
- Durable Work Page handoffs from Explore cards and catalog search results.

## Preserved
- Canonical catalog/provider ownership model.
- Personal Library and History data model.
- Smart Library Collections and Statistics 2.0.
- Recommendations 2.0.
- Medium-aware progress units.
- Provider identity/enrichment/governance boundaries.

## Explicit boundary
The journey includes a Review checkpoint but does not introduce a new personal review database. Existing personal score/notes remain available now; publishable/community review functionality remains a later Social / Community milestone.
