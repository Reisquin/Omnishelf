# OmniShelf v0.71 — Personal Library History & Timeline

## What changed
- Added a durable personal-library history stream under `data.library.history`.
- Every meaningful personal-library add/update/progress/completion/status/session/favorite/score/note/date/remove change now creates a structured history event.
- Added history summaries including total events, completion events, rewatch/reread/replay session starts, active days, and activity timestamps.
- Added recent completed and recent added projections.
- Added `GET /api/library/history`, `/api/library/history/summary`, `/api/library/recent/completed`, and `/api/library/recent/added`.
- Added a Personal Activity timeline and History at a glance to My Library.
- Added Recent Milestones for recently finished, recently added, and re-experienced works.
- Added per-work Personal History to the Work Page.
- Preserved removed personal records in the historical event stream so personal activity remains understandable after a library removal.
- Preserved personal history through full backup/export and restore.
- Added deterministic history coverage and expanded isolated HTTP E2E validation.

## Architectural rationale
v0.70 made the personal library useful as a daily workspace. v0.71 adds the temporal layer: current library state answers where a work is now; history answers how the user got there. History is keyed by canonical catalog ID but stores a title/type snapshot so the timeline remains readable for removal events. Rewatch/reread/replay starts are represented as explicit session events instead of overwriting prior activity.

## AniList boundary
AniList remains independent from the personal-library history system. No history feature depends on AniList authorization, live API availability, or external synchronization.

## Known boundaries
- History is a local single-workspace event stream for `You`.
- History is capped at 2,000 events to keep the local datastore bounded; older events are discarded once the cap is exceeded.
- Cross-device or external-service personal-history synchronization remains outside this release.
