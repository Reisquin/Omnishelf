# OmniShelf v0.80 — Production Hardening

## What changed

v0.80 is the production-hardening milestone after v0.79 UI/UX & Accessibility Finalization.

The release adds a provider-neutral runtime safety layer for:

- explicit workspace schema versioning and deterministic startup migration
- atomic datastore writes
- structural workspace validation
- security response headers and request IDs
- bounded request URI/body handling
- JSON nesting and dangerous-key protection
- per-client read/write rate limits
- request/error logging with bounded rotation
- Node timeout and malformed-client handling
- graceful shutdown and fatal error capture
- integrity-checked recovery backups
- explicit, pre-restore-safe workspace recovery
- first-class System UI for status, validation and recovery

No second domain datastore is introduced. Existing provider, catalog, personal-state, Community and medium-personal architectures remain intact.

## New scripts

- `npm run production:selftest`
- `npm run production:http-e2e`

## Validation

The complete executable regression matrix passed, including all inherited self-tests/E2Es plus the v0.80 production-hardening suite. See `BUILD_VALIDATION-v0.80.md` and `FINAL_RELEASE_CHECK-v0.80.txt` for the release evidence.
