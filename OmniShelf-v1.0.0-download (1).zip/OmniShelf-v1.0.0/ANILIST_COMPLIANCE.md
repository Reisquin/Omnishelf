# OmniShelf AniList Compliance Gate

OmniShelf defaults to `ANILIST_MODE=demo`. Live AniList traffic is disabled unless the deployment operator explicitly sets:

```text
ANILIST_MODE=authorized
ANILIST_AUTHORIZED_USE=true
```

This switch is an operational safeguard only. It is not a grant of rights or a substitute for permission/license.

Before enabling live access, review AniList current Terms of Use: https://docs.anilist.co/guide/terms-of-use

The current Terms state that the API is not to be used in competing, non-complementary anime/manga list or tracker services and is not to be used as a backup or data-storage service. Any production use that falls within a restricted category requires confirmation from AniList before the live gate should be enabled.

Demo mode remains available for local development and UI/contract testing.
