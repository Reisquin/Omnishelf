# OmniShelf v0.78 Build Validation

## Release
**Version:** 0.78.0  
**Feature:** Full Medium-by-Medium Personal Experiences  
**Base:** v0.77 Universal Import / Export & Migration

## Deterministic validation
All 24 deterministic suites completed successfully:

- Open Library Quality — 5/5
- TMDB Offline — 17/17
- IGDB Offline — 25/25
- Identity & Reconciliation — 10/10
- Unified Enrichment — 10/10
- Provider Reliability — 8/8
- Unified Provider Search — 13/13
- Final Data Governance — 14/14
- Catalog Experience — 8/8
- Asian Drama — 18/18
- Medium Experience Framework — 9/9
- Work Page — 9/9
- Catalog UX — 5/5
- Standalone Work Pages — 8/8
- Personal Library — 7/7
- Library Experience — 16/16
- Library History — 8/8
- Library Collections — 7/7
- Personal Statistics — 14/14
- Recommendations — 10/10
- Unified Workflow — 12/12
- Social / Community — 9/9
- Portable Migration — 8/8
- Medium Personal Experiences — 15/15

**Total:** 24/24 suites, **265/265 checks**.

## HTTP E2E validation
All HTTP tests run against disposable copies of the release workspace:

- Personal Library Experience — 19/19
- Smart Library Collections — 17/17
- Personal Statistics — 15/15
- Recommendations — 14/14
- Unified Discovery → Library — 8/8
- Social / Community — 8/8
- Universal Portable Migration — 7/7
- Medium Personal Experiences — 15/15

**Total:** 8/8 suites, **103/103 checks**.

## v0.78-specific acceptance
The release verifies that all 18 canonical medium types have a personal experience profile and that representative media expose distinct semantics:

- Anime / TV → episode-oriented viewing.
- Manga / Manhwa / Manhua → chapter-oriented reading with optional volume/page units.
- Novel / Light Novel / Novella / Short Story / Narrative Poetry → page-oriented reading where known.
- Web Novel → chapter-oriented reading.
- Visual Novel → unit/hour/route-oriented playthrough tracking.
- Game → hour/session-oriented play tracking.
- Movie → viewing-oriented tracking.
- Comics → issue/chapter/page tracking.
- Poetry → piece/page/poem tracking.
- Play → act/scene/page tracking.
- Short Story Collection → story/page tracking.

Unit-specific total inference was explicitly tested so alternate units use only totals belonging to that same unit.

## Integration checks
- Personal Library consumes the new registry without changing its persistent schema.
- Empty supported media remain viewable through the existing medium route.
- Work Page read models expose `personalExperience`.
- Unified Workflow uses medium-specific start/resume/advance/finish labels.
- Community, Recommendations, Smart Collections, Statistics and portable migration continue operating over the same personal-state records.
- No live provider requests are required by v0.78 behavior.

## Syntax / runtime
- Node syntax checks passed for all `.js` source files and test scripts.
- Embedded `<script>` blocks in `public/index.html` passed `node --check`.
- Server smoke test and `/api/health` returned HTTP 200.
- `/api/mediums/personal` returned all 18 profiles.

## Release integrity
- `preview.html` copied from final `public/index.html` and byte comparison passed.
- Shipped `data/store.json` verified clean after all tests.
- Source SHA-256 manifest regenerated after final source/documentation changes.
- Final archive contains 227 files / 236 ZIP entries under exactly one `OmniShelf-v0.78` root; extraction and ZIP integrity checks passed.

## External acceptance boundary
No AniList/Open Library/TMDB/IGDB live acceptance is claimed by v0.78. Existing provider acceptance harnesses remain separately documented and gated.
