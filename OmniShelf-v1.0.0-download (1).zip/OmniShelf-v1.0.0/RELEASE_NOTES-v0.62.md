# OmniShelf v0.62 — Unified Provider Search

## Release goal

Make discovery provider-neutral: the user searches OmniShelf, while the application selects relevant deep providers, normalizes their results, checks the canonical catalog, and presents one coherent discovery surface without mutating persistent identity state.

## Included

- `lib/unified-search.js` provider-neutral search orchestration.
- Smart routing for ISBN, Game, Movie, TV/Drama, anime/manga/book families, Visual Novel, and broad searches.
- Explicit provider scope override.
- Independent provider fan-out with partial-failure isolation.
- AniList, Open Library, TMDB and IGDB canonical-style search normalization.
- Deterministic discovery relevance scoring.
- Canonical catalog matching via the v0.59 identity engine.
- Temporary cross-provider clusters and lower-confidence related evidence.
- Stable external result IDs and explicit provider attribution.
- Top-level Search workspace with routing explanation, provider status, catalog results, external results and Review Queue handoff.
- `/api/search`, `/api/search/route`, `/api/search/demo-plan`.
- `npm run unified-search:selftest`.
- Full cumulative history through v0.62.

## What is deliberately not changed

- No persistent identity groups are created by Search.
- No enrichment run is created by Search.
- No provider account mutations are attempted.
- Existing provider adapters remain responsible for provider-specific requests, credentials, caching and retry policy.
- Review Queue remains the controlled ingestion boundary.

## Next

v0.63 — Final Data Governance Layer.

## Validation

Deterministic regression matrix: Unified Search 13/13, Reliability 8/8, Identity 10/10, Unified Enrichment 10/10, TMDB 17/17, IGDB 25/25, Open Library 5/5. Isolated HTTP end-to-end workflow passed 15/15 assertions. Live provider search remains unclaimed without external credentials/network access.
