# OmniShelf v0.75 — Build Validation

**Release:** v0.75 — Unified Discovery → Library  
**Date:** 2026-10-07  
**Base:** v0.74 — Recommendations 2.0

## Product validation

- Unified workflow deterministic self-test: 12/12.
- Unified workflow HTTP E2E: 8/8 in a disposable workspace.
- Inherited Personal Library HTTP E2E: 19/19.
- Smart Library Collections HTTP E2E: 17/17.
- Personal Statistics HTTP E2E: 15/15.
- Recommendations HTTP E2E: 14/14.
- The Work Page API exposes the workflow projection.
- Workflow actions use the existing personal-library write path, preserving history semantics.
- Explore and Unified Search hand off to durable standalone Work Pages.
- Recommendation “Add to library” uses the workflow action endpoint.
- Review remains an explicit checkpoint using existing personal score/notes; no parallel review store was introduced.
- No provider write is performed by the workflow layer.

## Regression validation

The following 21 deterministic suites were run for v0.75 and passed:

- Personal Library
- Library Experience
- Library History
- Smart Library Collections
- Personal Statistics 2.0
- Recommendations 2.0
- Work Page
- Standalone Work Pages
- Catalog UX
- Catalog Experience
- Medium Experience Framework
- Asian Dramas
- Unified Provider Search
- Provider Reliability
- Cross-Provider Identity
- Unified Enrichment
- Final Data Governance
- Open Library offline/quality coverage
- TMDB offline coverage
- IGDB offline coverage

The live AniList/Open Library/TMDB/IGDB acceptance commands remain operator/network dependent and are not treated as passed merely because their harnesses exist.

## Regression result

21/21 deterministic suites passed. Five disposable HTTP E2E suites passed, covering 73 individual checks in total (19 + 17 + 15 + 14 + 8).

## Code validation

- Node syntax checks pass for the v0.75 server, workflow module, recommendation module, workflow/HTTP E2E scripts, and inherited library/work-page E2E/self-test scripts.
- The single inline client script in `public/index.html` passes `node --check` after extraction.
- `preview.html` is synchronized from `public/index.html`.

## Release-state validation

- Shipped datastore must remain clean after all release validation.
- HTTP mutation checks run only against disposable copies.
- Cumulative `PROJECT_HISTORY.md` and `CURRENT_STATE.md` carry the v0.75 state and next dependency.
- `VERSION.txt` and `package.json` report 0.75.0.
- Final source hash manifest is regenerated after all content is finalized.
