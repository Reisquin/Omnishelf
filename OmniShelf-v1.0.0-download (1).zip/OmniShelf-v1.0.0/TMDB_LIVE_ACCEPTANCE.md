# TMDB Live Read Acceptance

## What this proves
The harness is the final operator-run read validation for the v0.57 TMDB integration. It is not a licensing/authorization approval. Credentials only enable the request path; public/commercial use must still comply with TMDB's current terms.

## Preconditions
1. Use a network-enabled machine.
2. Set `TMDB_READ_ACCESS_TOKEN` (preferred) or `TMDB_API_KEY` in the server environment.
3. Keep the credential server-side. Never paste it into chat or commit it to the repository.

## Plan
The acceptance suite checks:
1. Movie search
2. TV search
3. Movie deep detail
4. Movie collection linkage when the sampled movie has a collection
5. Person detail / combined credits when a sampled credit has a person ID
6. TV deep detail
7. TV season detail when seasons exist
8. TV episode detail when an episode exists

## Run
```bash
npm run tmdb:acceptance -- --plan
npm run tmdb:acceptance -- --query=Inception
```

The server endpoint is:
`POST /api/tmdb/live-acceptance` with confirmation `RUN_TMDB_READ_ACCEPTANCE`.

## Pass criteria
Each applicable read must return a valid TMDB response that normalizes into the expected canonical shape. A resource that is legitimately absent (for example a movie without collection membership) is recorded as not-applicable rather than treated as a false failure.

## Safety
The harness performs read-only TMDB calls. It does not mutate an AniList account, a TMDB account, or the local catalog.

## v0.66 Watch Providers boundary
Asian Drama streaming availability is not part of the ordinary v0.57 read acceptance suite. When live availability is intentionally enabled, both `TMDB_WATCH_PROVIDERS_ENABLED=true` and `TMDB_JUSTWATCH_ATTRIBUTION_ACK=true` are required. The operator must preserve the JustWatch attribution required by the TMDB Watch Providers surface. The v0.66 UI treats availability as read-only and does not persist it into the canonical catalog.
