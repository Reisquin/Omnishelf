# Open Library Official References

Checked for v0.56:

- https://openlibrary.org/developers/api
- https://openlibrary.org/dev/docs/api/search
- https://openlibrary.org/dev/docs/api/books
- https://openlibrary.org/dev/docs/api/authors
- https://openlibrary.org/dev/docs/api/covers
- https://openlibrary.org/dev/docs/api/read

Key implementation decisions from the current documentation:

- Search API is the preferred multi-book search surface and returns work-level information plus edition-level information when requested.
- Work and Edition are distinct concepts; Work is the umbrella logical work, Edition carries publication/ISBN/cover-specific details.
- Work, Edition, ISBN and Author JSON lookup endpoints are available.
- APIs should be used for useful, time-sensitive human-facing requests; cache responses where possible; identify the application via User-Agent and contact information.
- Open Library warns that the APIs are not a backend for bulk/high-traffic services and directs bulk consumers toward data dumps or direct contact.
- Covers should be referenced from covers.openlibrary.org for public-facing pages rather than crawling the covers API.


## Additional v0.56 reference notes

- The Books API documentation models a Work as the logical work and Editions as publication-specific manifestations; v0.56 therefore preserves Work and Edition IDs separately and records their relationship locally.
- The Work Editions endpoint is used only in bounded enrichment/acceptance lookups rather than corpus harvesting.
- Search results expose author IDs and edition information that can be used as identity hints; v0.56 turns those hints into explicit author, ISBN, and Work/Edition diagnostics.
- The API remains a low-volume discovery/lookup surface. v0.56 does not implement bulk harvesting; large-scale ingestion should follow Open Library's documented data-dump/contact guidance.
