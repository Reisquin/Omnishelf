# OmniShelf v0.75 — Unified Discovery → Library

## Purpose
v0.75 connects OmniShelf's existing discovery, canonical work, personal library, progress/history and recommendation layers into one consistent provider-neutral journey.

The product loop is:

**Discover → Work Page → Add to Library → Track → Finish → Review checkpoint → Recommend**

This release does not create another catalog or another personal-state store.

## Journey model

`lib/unified-workflow.js` derives a read-only journey from the canonical catalog item plus the existing personal library state.

The model exposes:
- the current journey stage;
- the state-aware primary action;
- secondary navigation actions;
- current progress and completion state;
- the seven journey stages;
- explicit boundaries for personal state, review publishing and provider writes.

### State-aware primary actions

- Not in library → **Add to My Library**
- Planned → **Start tracking**
- Paused or dropped → **Resume tracking**
- Active/re-experiencing with finite progress below the known total → **Advance**
- Active/re-experiencing at the known total → **Mark completed**
- Completed → **See what to experience next**

The workflow reuses `lib/library.js` for every mutation, so personal history continues to be recorded by the existing v0.71 history layer.

## API

- `GET /api/catalog/:id/work-page` now includes a `workflow` object alongside the existing canonical, personal-library and personal-history projections.
- `GET /api/catalog/:id/workflow` returns the workflow projection directly.
- `POST /api/catalog/:id/workflow/action` performs a state-aware personal action through the existing library layer.
- `POST /api/workflow/selftest` runs the deterministic workflow contract.

Supported workflow actions are `add`, `start`, `resume`, `plan`, `pause`, `drop`, `advance`, `complete`, `favorite`, and `remove`.

## Product behavior

Explore cards now offer a durable Work Page handoff plus a lightweight preview. Catalog and My Library already use durable Work Pages; Recommendations continue into the same Work Page. Recommendation add actions now open the newly tracked Work Page so the user can continue the journey immediately.

The Work Page contains a new **Your journey** panel. Its primary control changes with personal state, and the panel keeps the path from discovery to personal tracking visible without exposing provider internals.

## Review boundary

The current v0.74 application contains provider review metadata and an administrative Review Queue, but it does not contain a separate local user-published review store. v0.75 therefore does not pretend that such a subsystem exists. The journey shows a **Review checkpoint** tied to the existing personal score/notes state and explicitly reserves publishable/community review workflows for the later Social / Community phase.

## Medium behavior

All media share the same workflow contract. Progress remains medium-aware through the existing library inference: episodes, chapters, pages, hours, viewings, acts or generic units as appropriate. No medium-specific catalog or personal database is introduced.

## Safety and provider boundary

Workflow actions are personal-library actions only. They do not mutate AniList, Open Library, TMDB or IGDB records. Provider ingestion, identity, enrichment, reliability and governance continue to use their existing boundaries.
