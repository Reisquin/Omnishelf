# OmniShelf v0.72 — Smart Library Collections

Smart Library Collections are dynamic personal views built over the current My Library state. They are separate from canonical catalog saved views and never duplicate or modify catalog records.

## Built-in quick collections

- Continue — active or re-experiencing items that are not complete.
- Plan to — planned or paused items.
- Completed — personally completed items.
- Favorites — personally favorited items.
- 90+ Rated — personal score of at least 90.
- Recently Updated — personal activity in the last 30 days.

Built-ins are calculated at read time and cannot be edited or deleted.

## Custom collections

Custom collections are stored under `library.smartCollections` and contain a name, description, timestamps, and sanitized rules. The rule engine supports catalog-aware criteria (`q`, type, provider, year, tag) and personal-state criteria (status, status set, favorite, score range, progress percentage range, progress unit, score/note presence, unfinished state, and recent activity windows). Rules can use `all` or `any` matching.

The collection count, statistics, and preview are recalculated from current personal library state each time the collection is read. A personal state change therefore changes matching collections immediately without a rebuild step.

## API

- `GET /api/library/collections` — built-ins plus custom smart collections.
- `POST /api/library/collections` — create a custom smart collection.
- `POST /api/library/collections/from-filters` — save the current library filters as a smart collection.
- `GET /api/library/collections/:id` — inspect a custom collection or built-in preset.
- `PATCH /api/library/collections/:id` — edit a custom collection.
- `DELETE /api/library/collections/:id` — delete a custom collection.
- `GET /api/library?collection=:id` — apply a built-in or custom smart collection to the personal library listing.

## Backup / restore

Smart Library Collections live inside the existing `library` personal-state backup payload, so full JSON backups preserve them together with personal records and history. Restore continues to filter orphaned personal records against the restored canonical catalog while leaving collection rules intact.

## Boundary

v0.72 does not replace the older catalog-level Saved Views feature. Canonical saved views remain catalog filters; Smart Library Collections are specifically for personal library state.
