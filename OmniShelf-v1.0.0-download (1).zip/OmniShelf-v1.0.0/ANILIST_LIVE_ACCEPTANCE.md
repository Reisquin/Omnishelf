# AniList Live Acceptance Runbook

OmniShelf v0.46 includes a portable, read-only acceptance harness for a network-enabled deployment. It does not perform writes or mutate AniList data.

## Safety gates

Live access remains disabled unless both of these are set:

```
ANILIST_MODE=authorized
ANILIST_AUTHORIZED_USE=true
```

These flags are operational safeguards only. They do not grant AniList permission. Review `ANILIST_COMPLIANCE.md` and AniList's current Terms of Use before enabling live traffic.

## CLI

```
npm run anilist:acceptance
```

Add `--require-auth` to make absence/expiry of an access token a failure instead of a skipped authenticated suite.

## HTTP

Readiness (no upstream request):

```
GET /api/anilist/live-readiness
```

Read-only live acceptance:

```
POST /api/anilist/live-acceptance
Content-Type: application/json

{"confirm":"RUN_READ_ONLY_ACCEPTANCE","requireAuth":true}
```

The suite covers public Media retrieval and, when a valid token is loaded, Viewer, paginated `Page.mediaList`, User.statistics, and Viewer media-list options. It also records AniList rate-limit headers without storing the access token.

## What it does not test

It intentionally does not execute list mutations, reviews, follows, favourites, forum mutations, deletions, or other writes. Those need a separate, explicit operator test plan against a disposable/test account.


## Exit codes
- `0`: all attempted checks passed (skips are allowed unless `--require-auth` turns missing auth readiness into a failure).
- `2`: one or more read-only acceptance checks failed.
- `3`: the compliance gate blocked live access, so no upstream request was attempted.


## v0.54 — authenticated write acceptance

Read-only acceptance remains the default. For a real, authorized deployment, the separate `ANILIST_WRITE_ACCEPTANCE` suite can exercise a list-entry Save → Update → Delete round-trip with automatic restoration/cleanup. See `ANILIST_WRITE_ACCEPTANCE.md`.
