# OmniShelf v0.65 — Dedicated Medium Experiences

## Summary
v0.65 begins the dedicated medium-experience phase. Asian Dramas are the first specialized experience, built on top of the canonical catalog and existing TMDB/identity/enrichment/governance architecture.

## Added
- New `Asian Dramas` product tab in the primary navigation.
- New Asian Drama medium read model in `lib/asian-dramas.js`.
- Conservative profile classification for Korean, Chinese, Japanese, Taiwanese, Hong Kong, Thai, Filipino, Vietnamese, Indonesian, Malaysian, Singaporean, Indian, Bangladeshi and Pakistani dramas.
- Explicit user/provider label detection plus narrow language-only fallback signals; ambiguous generic languages do not classify ordinary TV as Asian drama.
- Original-title, alternate-title and international-title presentation with optional explicit romanized title support.
- Country/industry and original-language context.
- Airing/upcoming/completed state classification.
- Season count, episode count, typical runtime and season inventory surfaces.
- Network/production-company context where provider metadata supplies it.
- Creator/cast context and related-work display.
- Search, sorting and facets for industry, language, year, state, genre and network.
- Dedicated rich detail view with Catalog and Unified Search handoffs.
- Demo endpoint/fixtures that never mutate the canonical datastore.
- `POST /api/medium/asian-dramas/selftest` and `npm run asian-drama:selftest`.
- Detailed `MEDIUM_EXPERIENCES.md` documentation including design rationale, limitations and official TMDB references.

## Compatibility
- Existing provider, identity, unified enrichment, reliability, unified search and governance layers are preserved.
- No canonical catalog records are created by the medium view.
- Existing `preview.html` remains the release's synchronized static UI mirror.

## Data boundary
The experience uses TMDB country/language/translation and season/episode data already captured by the provider integration. It does not invent romanization or claim streaming-platform availability without canonical provider data. TMDB's Watch Providers endpoint is documented for future work because it is powered by JustWatch and carries an explicit attribution requirement.

## Next direction
v0.66 should deepen medium-specific infrastructure where useful, with particular attention to live Asian-drama discovery/ingestion quality, platform availability with correct attribution, and reusable medium-experience components for additional storytelling formats.
