# OmniShelf v0.77 — Build Validation

**Release:** v0.77 — Universal Import / Export & Migration  
**Date:** 2026-10-07  
**Base:** v0.76 — Social / Community 2.0

## Product validation

- Portable deterministic self-test: **8/8**.
- Portable HTTP E2E: **7/7** in a disposable workspace.
- Personal portable JSON export validated.
- Workspace portable JSON export validated.
- Personal library CSV export validated, including identity and personal-state fields.
- Preview-first import validated for exact provider identity, new-record creation, and personal-state conflict policy.
- Migration reuses the existing v0.59 identity/reconciliation layer rather than creating a second identity model.
- Missing works are created explicitly during Apply when no strong destination match exists; ambiguous matches are surfaced during Preview rather than silently merged.
- Personal Library, History, Smart Library Collections and local Community references are remapped from source IDs to destination IDs.
- Imported history, reviews and activity use durable portable markers to prevent duplicate repeated imports.
- Full workspace backup/recovery remains separate and unchanged.

## Regression validation

The inherited v0.76 deterministic matrix and v0.77 portability suite are green:

**23 deterministic suites / 245 individual checks passed.**

The seven disposable HTTP E2E suites are all green (**88 individual checks**):
- Personal Library Experience: **19/19**
- Smart Library Collections: **17/17**
- Personal Statistics 2.0: **15/15**
- Recommendations 2.0: **14/14**
- Unified Discovery → Library Workflow: **8/8**
- Social / Community 2.0: **8/8**
- Universal Import / Export & Migration: **7/7**

All mutation tests run against disposable workspaces and leave the shipped datastore untouched.

## Code validation

- Node syntax validation passes for all project JavaScript modules and test scripts.
- `server.js`, `lib/portable.js`, `lib/work-pages.js`, `lib/recommendations.js` and the embedded client JavaScript validate successfully.
- `preview.html` is byte-identical to `public/index.html`.
- Shipped `data/store.json` is clean after all validation.

## Data-ownership boundary

Portable export/import is user-facing migration content. It intentionally omits provider raw payloads, provider operational telemetry, reliability history, audit logs and governance operational history. Full workspace backup remains the recovery artifact for those internal structures.

No provider API is called by the portable export/import layer. AniList authorization/live acceptance remains an independent external boundary.

## Release-state validation

- `PROJECT_HISTORY.md`, `CURRENT_STATE.md`, `README.md` and `SUPPLIED_ARCHIVE_INDEX.md` carry v0.77 forward while preserving prior history.
- `VERSION.txt` and `package.json` report **0.77.0**.
- Source hash manifest regenerated after all release content was finalized.
- Archive extracted successfully and ZIP integrity passed.
- Archive contains exactly one `OmniShelf-v0.77` root directory.

