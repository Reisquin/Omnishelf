# OmniShelf v0.69 — Personal Library Experience

## What changed
- Added a first-class `My Library` product surface for personal tracking.
- Kept personal state separate from canonical catalog/provider metadata.
- Added per-work status, progress, progress-total, progress-unit, 1–100 score, favorite, notes, start date, completion date, and updated timestamp.
- Added conservative medium-aware progress units: episodes, chapters, pages, hours, viewings, acts, or generic units.
- Added one-click progress advancement with automatic completion when a known total is reached.
- Added library search, status/type/favorite filters, sorting, pagination, progress visualization and inline editing.
- Added personal-library controls directly to modal and standalone work pages.
- Added library-aware work-page responses so navigation and personal state share one canonical identity.
- Preserved v0.68 standalone/deep-linkable work pages and medium-specific presentation.
- Added full-backup preservation and restore-time orphan filtering for personal library state.
- Added deterministic `library:selftest` coverage and updated the cumulative project history.

## Architectural rationale
Personal activity must not overwrite canonical metadata. Providers describe the work; OmniShelf's canonical record reconciles that metadata; the personal library describes the user's relationship with the work. Keeping the layers separate allows provider enrichment and governance to continue independently of personal ratings/progress and leaves a clean path to future account-scoped multi-user data.

## Known boundaries
- This release is a single local workspace (`You`), not a multi-account service.
- Personal library changes are local and do not yet synchronize back to AniList or another external list provider automatically. Existing AniList sync remains a separate provider workflow.
- Provider live acceptance and automated headless screenshot capture remain environment-dependent.
