# AniList Live Write Acceptance — v0.54

This is a separate, explicitly opt-in authenticated acceptance suite for a network-enabled OmniShelf deployment. It is not executed automatically and it is never part of the demo workflow.

## Guard rails

The suite refuses to write unless all of the following are true:

- `ANILIST_MODE=authorized`
- `ANILIST_AUTHORIZED_USE=true`
- `ANILIST_WRITE_ACCEPTANCE=true`
- `--confirm-write` is supplied
- an explicit test media ID is supplied via `ANILIST_WRITE_TEST_MEDIA_ID` or `--media-id=`

The token is never printed.

## Default test

```bash
npm run anilist:acceptance-write -- --plan --media-id=<AniList-media-id>
ANILIST_WRITE_ACCEPTANCE=true npm run anilist:acceptance-write -- --confirm-write --media-id=<AniList-media-id>
```

If the selected media already has a list entry, OmniShelf changes only `priority`, verifies the change, and restores the exact captured mutable state. If no entry exists, the suite creates a uniquely annotated temporary `PLANNING` entry, verifies it, exercises `UpdateMediaListEntries`, deletes the entry, and verifies that it is gone.

Optional favourite coverage:

```bash
ANILIST_WRITE_ACCEPTANCE=true npm run anilist:acceptance-write -- --confirm-write --media-id=<AniList-media-id> --include-favourite
```

The favourite probe reads `Media.isFavourite` first and toggles twice, verifying that the original state is restored. If AniList reports the media as favourite-blocked, the probe is skipped.

## Acceptance scope

The write suite covers representative authenticated mutation behavior without trying to exercise every AniList mutation. The broader mutation surface remains available through the dedicated endpoints and the generic GraphQL gateway.

## Why it is separate

AniList requires authentication for mutations. The current AniList API docs also document rate limiting and temporary degraded states, so the write suite is deliberately small and serial.
