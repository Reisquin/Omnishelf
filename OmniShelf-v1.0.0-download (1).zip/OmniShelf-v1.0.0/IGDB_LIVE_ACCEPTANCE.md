# IGDB Live Acceptance — OmniShelf v0.58

This is an operator-run, read-only acceptance procedure. It is not an authorization, license, or commercial-use approval.

## Before running

Configure one of:

```text
IGDB_CLIENT_ID=<Twitch app client id>
IGDB_CLIENT_SECRET=<Twitch app client secret>
```

or:

```text
IGDB_CLIENT_ID=<Twitch app client id>
IGDB_ACCESS_TOKEN=<application access token>
```

Keep secrets outside the datastore and never paste them into OmniShelf catalog fields.

IGDB does not provide browser-direct CORS access, so the test must run through the OmniShelf server.

## Plan

Run:

```bash
npm run igdb:acceptance -- --plan
```

Expected read-only checks:
1. Acquire or refresh the application token.
2. Search a known game.
3. Resolve full game detail.
4. Inspect release records, platforms, developers/publishers, genres/themes, collection/franchise data, external identifiers, ratings and assets.
5. Resolve at least one company and platform, and collection/franchise when the sampled game exposes them.
6. Produce provider-aware catalog matching without mutating the catalog.
7. Confirm the credential boundary and remote-image policy.

## Execute

On a network-enabled machine:

```bash
npm run igdb:acceptance -- --query=The\ Legend\ of\ Zelda
```

The harness is read-only. It does not add to or modify the OmniShelf catalog.

## Acceptance interpretation

- `passed` means a provider read completed successfully.
- `blocked` means the run could not legitimately make the check—for example missing credentials or unavailable network access.
- A blocked run must never be reported as a successful live acceptance.

The build therefore does not mark IGDB live acceptance as passed merely because credentials exist.

## Post-acceptance record

If executed successfully, record the date, environment, query used, provider API behavior observed, and the complete test result in the next OmniShelf release history. Never record the client secret or access token itself.
