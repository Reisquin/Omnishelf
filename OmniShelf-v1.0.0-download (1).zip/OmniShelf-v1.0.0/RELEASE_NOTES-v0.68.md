# OmniShelf v0.68 — Standalone Work Pages & Deeper Medium-Specific Experiences

## What changed
- Added a real `/work/:id` deep-link route that serves the OmniShelf shell and resolves canonical work data client-side.
- Added standalone work-page rendering with a dedicated back/navigation bar, full-page layout, document-title updates, and browser-history integration.
- Added “Open page” actions alongside the existing lightweight work preview.
- Refactored the shared work-page renderer so modal previews and standalone pages use the same provider-neutral presentation contract.
- Added `mediumExperience` to the work-page read model with medium-aware highlights for Asian Dramas, Games, Novels, Anime/Manga/Visual Novels, Film, and TV.
- Added an explicit standalone work-page self-test script.
- Preserved all existing Catalog, Search, Identity, Enrichment, Reliability, Governance, Medium Experience, and provider workflows.

## Architectural rationale
The standalone route is a presentation/navigation layer over the canonical catalog; it is not a second catalog or a second data source. The same work-page API powers the modal preview and deep-linked page, preventing the two experiences from drifting. Browser history is used only for navigation state; canonical writes continue to go through existing governed APIs.

## Known boundaries
- The `/work/:id` route currently reuses the application shell rather than using a separate server-rendered template.
- Live provider acceptance remains external-credential/network dependent.
- Automated Chromium screenshot capture remains environment dependent.
