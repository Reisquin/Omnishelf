# OmniShelf v0.64 — Catalog Experience & Discovery

## Purpose
v0.64 begins the product-experience phase after the provider architecture milestone completed at v0.63. The goal is to make the canonical catalog feel like a consumer-facing story library rather than an operations console, while keeping all existing provider, identity, enrichment, reliability, search and governance layers intact.

## Explore experience
- Added a first-class Explore tab and made it the default landing surface.
- Added a catalog-first search box with a direct bridge into Unified Provider Search for external discovery.
- Added quick medium shortcuts for Anime, Manga, Novel, Movie, TV, Drama, Game and Visual Novel.
- Added catalog KPIs for total works, distinct media types, represented providers and collection count.
- Added Browse by medium cards driven by live catalog facets.
- Added Recently added and Recently updated sections based on canonical timestamps.
- Added a Popular Tags surface driven by the catalog's own tag vocabulary.
- Added a discovery bridge that sends users from the owned catalog to the read-only unified provider search layer.

## Work detail experience
- Added a product-facing work detail modal that consumes the existing `GET /api/catalog/:id` view instead of duplicating canonical data.
- The modal presents cover, title, type, year, provider, description, creators, tags, collections, identity-group state, relationships and governance metadata.
- Added direct actions to open the same record in Catalog or search for related works through Unified Provider Search.
- The Catalog and Explore surfaces remain linked; neither creates a second catalog or second identity system.

## Backend
- Added `lib/explore.js` as the provider-neutral Explore aggregation layer.
- Added `GET /api/catalog/explore` for one-call Explore data.
- Added `POST /api/catalog/explore/selftest` and `npm run catalog-experience:selftest` for deterministic experience aggregation checks.
- Explore aggregation is read-only and derives sections/facets from the current canonical datastore.

## Data safety
- No synthetic catalog records are shipped in `data/store.json`.
- Explore never mutates the identity graph, enrichment state, provider registries or governance history.
- Existing Catalog, Search, Identity, Enrichment, Reliability and Governance APIs remain unchanged except for the added Explore endpoints.

## Asian-drama continuity
v0.64 intentionally exposes `Drama` as a first-class browse shortcut because Asian dramas are a core planned product use case. This release does not pretend that `Drama` alone captures country/industry/language; the richer Asian-drama metadata model remains a later medium-specific product milestone.

## Architecture rationale
- Product UX is layered above the mature canonical architecture rather than replacing it.
- Explore is a read model over the catalog, not a new source of truth.
- Existing canonical detail APIs are reused so governance, identity and enrichment context remain consistent across surfaces.
- The first product phase deliberately improves navigation and comprehension before introducing more specialized recommendation or personalization logic.

## Known boundary
The shipped datastore is intentionally empty/clean in the current development archive, so the Explore page will show empty states until catalog records exist. This is expected. The UI includes a provider-search bridge so an empty local catalog is still useful for discovery.
